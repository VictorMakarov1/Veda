#include "lib.h"   // 11/21/97 12/27/99 3/26/00 10/23/00 12/17/00
#include "myio.h"
#include "achs.h"   
#include "sbs.h"
#include "tt.h"
#include "assert.h"  
// #include "elem.h" 
// #include "topt.h" 
// #include "df.h"
#include "etc.h"
#include "err.h"

//#define sztt 2000  /* the maximum size of tabt ???11/11/99*/

extern int  unused, hh, zz;
extern att maxits;
extern char* extm[1];  // lclad
extern char dirname[80];
extern char* usd;      // used entries in tabt
// extern att* nad;       // new addresses 
// int nad[100];             // ????? change !

char* clon(char* s, int k=0);
int newm(int m1, int* nen, int k);

//  template<typename T>    // T = headp, edenp;
 void tt::wtabt(ofstream* f)
{
 headp hp; int i;
 *pfhis<<"\nwtabt itt= " << itt;
 for(i=0; i <= itt; i++)                           // 9 tabt
 {                         
  hp = tabt[i]; 
  if(hp == 0) error("wtabt: hp=0, i= ", i); // remove !!!
  wf(f, 999, size(hp), (void*) hp, "tabt");
 } // for(i)
} // end wtabt

 void tt::wden(ofstream* f)
{
 edenp hp; int i,j,hl;
 *pfhis << "\nwden iden= " << iden;
 for(i=0; i <= iden; i++)                           // 9 tabt
 {                         
  hp = den[i]; j=0; hl = hp->lth;
  for(j=0; j < hl; j++) if(hp->son[j] == zel) break;
  hp->lth = j;                                         // new number of sons(thorems) 
  if(hp == 0) error("wtabt: hp=0, i= ", i); // remove !!!
  wf(f, 999, size(hp), (void*) hp, "wden");            // 999: no printing;
 } // for(i)
} // end wden

 void rtabt(tt* p, int last, ifstream* f)   // read tabt from f;
{
 headp hp; int i,k; head h;
 *pfhis << "\nrtabt last(itt)= " << last;
 for(i=0; i <= last; i++)                       // 9 tabt
 { 
  rf(f, sizeof(head), (void*) &h);       // reading main part; (because we don't know yet the full size;
  // if(h.tel == 0) error("rtt h.tel == 0, i= ", i);
  k = size(&h);
  hp = (headp) fylloc("rtabt:hp", k); *hp = h;
  p->tabt[i] = hp;
  rf(f, k - sizeof(head), (void *) ++hp); // reading sons and theorems; // ++hp points to sons; (can be used instead 0f
 } // end for i                                                                                  // &(h->son[0]) ???)
} // end rtabt 

  void rden(tt* p, int last, ifstream* f)   // read tabt from f;
{
 edenp hp; int i,k; eden h;
 *pfhis << "\n+rden last(iden)= " << last;
 for(i=0; i <= last; i++)                       // 9 tabt
 { 
  rf(f, sizeof(eden), (void*) &h);       // reading main part;
  // if(h.tel == 0) error("rtt h.tel == 0, i= ", i);
  k = size(&h);
  hp = (edenp) fylloc("rden:hp", k); *hp = h;
  p->den[i] = hp;
  rf(f, k - sizeof(head), (void *) ++hp); // reading sons; // ++hp points to sons;
 } // end for i
} // end rden 

  void tt::wtt(char* s1)     // write den,aden,tt into file s (i.e., d:\veda\0_bool.ved)
{ // lltt,ittd,iden,kuselist,root, uselist,den,aden;
 int i; ofstream* f;  att lastaden; ats lastindthms;  char s[100];
 *pfhis << "\n\n+wtt s1= " << s1;
 cout << "\n\n+wtt s1= " << s1;
 strcpy(s, s1); strcat(s, ".ved");
 // assert(ittd < itt && itt < lltt);
 ofstream out(s, ios::out|ios::binary);
 if(!out) error("cannot open file ", s);
 // chtt();   // change tt (theorems first, compact)
 for(i=maxits; i>= 0; i--)                           // size(laden) = maxits + 1
	 if(aden[i] >= 0) { lastaden = i; goto M1; }
 error("wtt: empty aden, maxits= ", maxits);
 M1: if(lastaden > its) error("wtt: too big lastaden= ", lastaden, " its= ", its);
 // lltt = itt;
 for(i=lden-1; i>= 0; i--)                           // size(laden) = maxits + 1 emptt = 65535;
	 if(indthms[i] != emptt) { ipp("wtt indthms[i] >= 0, = ", indthms[i]); lastindthms = i; goto M2; }  // indthms = (att*) fylloc("indthms", (lden) * sizeof(att)); 
 ipp("wtt: empty indthms, lden= ", lden); lastindthms = -1;
 M2: if(lastindthms > iden) error("wtt: too big lastindthms= ", lastindthms, " iden= ", iden);

 cout << "\n curm itt  iden  lastaden kuselist root\n" ;
 cout << curm <<' '<<itt<<' '<<iden<<' '<<lastaden<<kuselist<<' '<< root;
 *pfhis << "\ncurm itt   iden lastaden kuselist ithms ithmsic root\n" ;
 *pfhis <<curm<<"    " <<itt<<' '<<iden<<' '<<lastaden<<"     "<<kuselist<<"        "<< root; 
 *pfhis << "\nsizeof(curm)= " << sizeof(curm) << " sizeof(att)= " << sizeof(att) << " sizeof(ats)= " << sizeof(ats);
 f = &out;
 wf(f, curm, sizeof(att), (void*)& curm, "curm");                        // 0:2  curm (mym)
 wf(f, itt,  sizeof(att), (void*)& itt, "itt");                          // 1:2  itt  
 wf(f, iden, sizeof(ats), (void*)& iden, "iden");                        // 2:2  iden
 wf(f, lastaden, sizeof(att), (void*)& lastaden, "lastaden");            // 3:2  lastaden: is local 
 wf(f, kuselist, sizeof(ats), (void*)& kuselist, "kuselist");            // 4:2  kuselist
 wf(f, root, sizeof(att), (void*)& root, "root");                        // 5:2  root
 wf(f, ithms, sizeof(ats), (void*)& ithms, "ithms");                     // 6:2  ithms
 wf(f, ithmsic, sizeof(ats), (void*)& ithmsic, "ithmsic");               // 7:2  ithmsic
 wf(f, beg_impconj, sizeof(ats), (void*)& beg_impconj, "beg_impconj");   // 8:2  beg_impconj
 wf(f, end_impconj, sizeof(ats), (void*)& end_impconj, "end_impconj");   // 9:2  end_impconj
 wf(f, beg_rimpin, sizeof(ats), (void*)& beg_rimpin, "beg_rimpin");      // 10:2 beg_rimpin
 wf(f, end_rimpin, sizeof(ats), (void*)& end_rimpin, "end_rimpin");      // 11:2 end_rimpin
 wf(f, beg_equin, sizeof(ats), (void*)& beg_equin, "beg_equin");         // 12:2 beg_equin
 wf(f, end_equin, sizeof(ats), (void*)& end_equin, "end_equin");         // 13:2 end_equin
 wf(f, beg_exist, sizeof(ats), (void*)& beg_exist, "beg_exist");         // 14:2 beg_exist
 wf(f, end_exist, sizeof(ats), (void*)& end_exist, "end_exist");         // 15:2 end_exist
 wf(f, lastindthms, sizeof(ats), (void*)& lastindthms, "lastindthms");   // 16:2 lastindthms

 wf(f, kuselist+1, (kuselist+1) * sizeof(modsize_t), (void*) uselist, "uselist");  // 17 uselist  // typedef short modsize_t;
 cout << "\nuselist: "; for(i=0; i<=kuselist; i++) cout << uselist[i]<<' ';
 *pfhis << "\nuselist: "; for(i=0; i<=kuselist; i++) *pfhis << uselist[i]<<' ';
 
 wf(f, ithms+1, (ithms+1) * sizeof(att), (void*) thms, "thms");           // 18 thms  // ;
 wf(f, ithmsic+1, (ithmsic+1) * sizeof(att), (void*) thmsic, "thmsic");   // 19 thmsic  // ;
 wf(f, lastindthms+1, (lastindthms+1) * sizeof(att), (void*) indthms, "indthms");     // 20 indthms  // ;
 
 wden(f);                                                                 // 21 den
 // wtb(f, den, iden,sizeof(eden), "den");             // 7 den
 wtb(f, aden, lastaden, sizeof(ats), "aden");                             // 22 aden
 wtabt(f);                                                                // 23 tabt
 wtb(f, har, sizehar-1, sizeof(att), "har");                              // 24 har  change to compressed! 
 f->close();
 ipp("-wtt: finished WTT, file ", s);
} // end wtt
                            // sizes of variables must be the same as in sizeof(type) !!!
     tt* rtt(char* s)
{ // lltt,ittd,iden,kuselist,root,uselist,den,aden;
 char s1[kdirname]; int i; ifstream* f; tt* p; //  head h; headp hp; 
 att klltt, kkaden, mmym; ats iiden, kkul,lastindthms; // iithms,iithmsic;
 ipp("+rtt s= ", s);                    // *pfhis << "\n\n+rtt s= " << s; 
 *pfhis << "\nsizeof(mmym)= " << sizeof(mmym) << " sizeof(att)= " << sizeof(att) << " sizeof(modsize_t)= " << sizeof(modsize_t);
 if (strlen(s) >= kdirname - 4) error("rtt: big s= ", s);
 strcpy(s1, s); strcat(s1, ".ved");
 ifstream in(s1, ios::in|ios::binary);
 if(!in.is_open()) error("rtt:cannot open file ", s1);
 f = &in;
 rf(f, sizeof(att), (void*) &mmym, "mym");           // 0:2  mym (curm);
 if(mmym >= maxmod) error("rtt: wrong kmym, s= ", s, " mmym= ", mmym); 
 rf(f, sizeof(att), (void*) &klltt, "lltt");         // 1:2  lltt; 
 rf(f, sizeof(ats), (void*) &iiden, "iden");         // 2:2  iden; 
 rf(f, sizeof(att), (void*) &kkaden, "lastaden");    // 3:2  lastaden  // see att lastaden in wtt
 rf(f, sizeof(ats), (void*) &kkul, "kuselist");      // 4:2  kuselist;


 cout << "\n kmym klltt   iiden kkaden kkul \n" ;
 cout << mmym <<' '<<klltt<<' '<<iiden<<' '<< kkaden<<' '<<kkul; // <<' '<<rroot;
 *pfhis << "\n kmym klltt   kkden kkaden kkul\n" ;
 *pfhis << mmym<<' '<<klltt<<' '<<iiden<<' '<< kkaden<<' '<<kkul; // <<' '<<rroot;
 
 p = new tt(klltt, kkul, iiden, kkaden);
 
 p->mym = mmym;                                // 0
 p->lltt = klltt; p->itt = klltt;              // 1                 
 p->iden = iiden;                              // 2
 p->lastaden = kkaden;                         // 3
 p->kuselist = kkul;                           // 4
 
 rf(f, sizeof(att), (void*)& p->root, "root");                // 5:2  root;
 rf(f, sizeof(ats), (void*)& p->ithms, "ithms");              // 6:2  ithms;
 rf(f, sizeof(ats), (void*)& p->ithmsic, "ithmsic");          // 7:2  ithmsic;
 rf(f, sizeof(ats), (void*)& p->beg_impconj, "beg_impconj");  // 8:2  beg_impconj;
 rf(f, sizeof(ats), (void*)& p->end_impconj, "end_impconj");  // 9:2  end_impconj;
 rf(f, sizeof(ats), (void*)& p->beg_rimpin, "beg_rimpin");    // 10:2 beg_rimpin;
 rf(f, sizeof(ats), (void*)& p->end_rimpin, "end_rimpin");    // 11:2 end_rimpin;
 rf(f, sizeof(ats), (void*)& p->beg_equin, "beg_equin");      // 12:2 beg_equin;
 rf(f, sizeof(ats), (void*)& p->end_equin, "end_equin");      // 13:2 end_equin;
 rf(f, sizeof(ats), (void*)& p->beg_exist, "beg_exist");      // 14:2 beg_exist;
 rf(f, sizeof(ats), (void*)& p->end_exist, "end_exist");      // 15:2 end_exist;
 rf(f, sizeof(att), (void*)& lastindthms, "lastindthms");     // 16:2 lastindthms;

 *pfhis << "\nrtt root= " << p->root << " lastindthms= " << lastindthms;  // for testing
 cout << "\nrtt root= " << p->root << " lastindthms= " << lastindthms;  // for testing

 rf(f, (kkul+1) * sizeof(ats), (void*) p->uselist, "uselist");         // 17 uselist
 cout << "\nrtt: uselist: "; 
 for(i=0; i<=kkul; i++) cout << p->uselist[i]<<' ';
 *pfhis << "\nrtt: uselist: ";
 for(i=0; i<=kkul; i++) *pfhis << p->uselist[i]<<' '; 
 
 rf(f, (p->ithms+1) * sizeof(att), (void*) p->thms, "thms");         // 18 thms
 rf(f, (p->ithmsic+1) * sizeof(att), (void*) p->thmsic, "thmsic");     // 19 thmsic
 rf(f, (lastindthms+1) * sizeof(att), (void*) p->indthms, "indthms");   // 20 indthms
  
 rden(p, iiden, f);                                         // 21 den
 rtb(f, p->aden, kkaden, sizeof(ats), "aden");              // 22 aden 
 rtabt(p, klltt, f);                                        // 23 tabt 
 rtb(f, p->har, sizehar-1, sizeof(att), "har");             // 24 har
 f->close();
 ipp("finished RTT, file ", s1);
 return p;
} // end rtt

// end wtt

