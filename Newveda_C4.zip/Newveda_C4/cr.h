// cr.h 8/10/97 4/03/00 4/16/00 9/20/00 11/06/00 11/22/00 12/08/00

elem cred(elem z);         //, elemp w=0, int k=0); 04/23/01
elem redeq(elem z, headp h,elemp q, elemp w);         // z is (a=b)(Q): rep2(Q,a,b);
elem redAll(elem z, headp h, elemp q, elemp w);       //  All(x1,...,All(xk,P) ...)(z1,z2, ... , k);
elem redA(elem z, headp h,elemp q, headp g, elemp w); // z is A[d, Q1->Q2](Q3); d=w[1], w[2]=Q1->Q2; typ(Q3) = zbool;
elem redAF(elem z, headp h,elemp q, elemp w);         // z is A[d,Q2](z1, ... zk), q[0] = A[d,P], q[1]=z1;
elem redmeth(elem z, headp h, elemp q, elemp w);      // Q(z1, ... zk), Q is a d-method, k = hl1;
elem redRep(elem z);                                  // z is Rep(d,P,md);
bool isst(elem z, elem* red=0, elem* main=0);         // is special term: All(x,P)(y), .... (a=b)(y)
elem rterm(elem z, headp h=0, elemp q=0);             // reduction of term; r=z, if no reduction'
ats linr(elem z, elemp* w);  // r-linearization of z: w1= z,q[0], root(q[0]), ... while(root is composite); k: last occupied;
elem redr(elemp w, ats k, elem v);             // reduction of z(...)(...) ... (...), where z(...) is an rterm;
elem aint(elem, elem);
elem sint(elem, elem);
elem mint(elem, elem);
elem dint(elem, elem);
elem rint(elem, elem);
elem uint(elem);
elem Less(elem z1, elem z2);
elem LessOrEq(elem z1, elem z2);
int  icon(elem z);    // is a constant
elem inst1(elem q, elem p); // q is an 1-instance of p
elem smpb(elem z, bool p = true, int* r=0);    // simplification of booleans
void trbp(elem z);    // translation of booleans into Polish
int valp(int x);      // value of pol under x
int nomv(elem z);     // number of "var" z (0 - most right)
void wrpol(int k);
elem vlot(elem z);    // search z in lot, if z in lot, return true
void wrval(elem z, headp h, elemp q, elem v);    // rouhly, q[h->l] = v; 
elem valrt(elem z, headp h=0, elemp q=0);  // { elem r h->v? q[h->l]: z; } // value of reduced term;
// inline elem val(headp h, elemp q){ return h->v? q[h->l]: zel; }