// typ.h    4/24/97 12/15/99 12/21/99 02/10/00 5/27/00 10/27/00 01/22/01
#define lmftp 10
#define maxdcl 10
extern int ttt;
extern int gg;
// att mel(elem z, headp *h=0, elemp *q=0, int place=0);
// extern elem TSpecialType, TQuantifierType, TOperOnDefType, TPClassDef; 
// extern elem TCurrentTerm;

void typa(elem);
// elem typ(elem z, int n = -1); 
elem typ(elem z, headp* ah=0, elemp* aq=0);
elem typ0(elem z); // if typ(z) == zet or REL then r = typt(z):  look for type of z in thms and then in tabt;
elem tp(elem x, att* m=0); 
elem Tp(elem x);
bool disjoint(elem t1, elem t2);
bool indisj(elem t1, elem t2);                 // t1 and t2 are in disjoint array
// elem mait(elem z, int p = 0); // p=1 -> mait(d, p) = d
elem maid(elem z);
elem typseq(elem z, headp h, elemp q);
elem typcrl(elem z, headp h, elemp q);
elem typabt(elem z, headp h, elemp q);
elem typdot(elem z, headp h, elemp q);
// elem typdotq0(elem z, headp h, elemp q, elemp w);  // z = (f.M)(q[1], ... , q[k]), f=w[1], M=w[2]; moved to trash.txt;
elem typF(elem z, headp h, elemp q);
elem typR(elem z, headp h, elemp q);
elem typidu(elem z, headp h, elemp q, elem x=zel);  // x : exclude from vin !
elem typfnt(elem z, headp h, elemp q, elem t,headp g,elemp w);  // z: f(q1,...); t:fn(w1,w2); t: ifn(...), ...
elem typcnv(elem z, headp h, elemp q);
elem typP(elem z, headp h, elemp q);
elem typmeth(elem z, headp h, elemp q);
// elem meth(elem z, headp h, elemp q);             // f(y)
// elem meth2(elem f, elem y, elem y1);   // f(y,y1), G/N, f = /(ats)
// elem tmthd(elem z);                     // theory for method z : same as scope(z)
// elem adt(elem z, headp h, elemp q, elem t0);    // abridged dot term: M(x): means M.x, t0=typ(q[0])
// inline bool typ(elem z, elem d){ return typ(z) == d || istr2(zin, z, d); }
elem typabbr(elem z, headp h, elemp q); // Q := z;
elem typdclterm(elem z, headp h, elemp q, headp g, elemp w, ats a); // (z,h,q), (q[0], g,w), q[0]=&,..., w = dcl[, &, bool, bool,
elem typbool(elem z, headp h, elemp q);
elem typvarp(elem z, headp h, elemp q);  // variable with parameters
int Typ(elem z, elem ar[], int maxsizear); // ar := t(typ(z)) and all ti, such that t <: t1;
elem typFNseq(elem z, headp h, elemp q, elem t, elem sq=zel);
elem typtlot(elem z, bool p=false);       // search z in _ in tabts, then in lot, if(p): only function types
void wrmftp(elem t);                      // write to mftp (multiple function types);
int numfnt(elem t);                       // t: fn(...):1, bfn(...):2, FN:8;
elem tfromin(elem y, elem z);             // type from in: y is z' in r or y is p -> z' in r
elem typabtvar(elem d, headp h, elemp q, int i); // type of abtvar d(i);
int typd(elem d, elemp qt);               // types of abtterm d in qt, r = #types;
bool tpon(elem f, elemp* qt, int* kt, bool* postfix=0);  // input types of an overname f(z1,...,zk): dcl[f,... or {f:fn(..., ...)
elem ron(elem z, headp h, elemp q,elem x);        // resolve overname f; z = f(q1, ... , qk); exclude x from vin;
bool gabt(elem z, elemp M=0, elemp d=0);          // general abt type( d, d&&p, d.M, (d&&P).M )
elem abt_thm(elem z, bool p=false, elemp M2=0); // look in thms(z) for z in abt term r;
elem mdt(elem z, headp h, int p);     // common part of typdot and typmeth, z = Q.M(p=1) or Q(M)(p=0); 
elem vdt(elem z, elem Q, elem M, int pHM=1, int dpth=1); // value of dot term z = Q.M; (or z=Q(M)); 2: only simple methods;
elem Vdt(elem z, headp h, elemp q, elem Q, elem M);      // vdt expanded for method terms with more than 1 params;
elem valHM(elem z); //, att phm=1);  //, int pHM=1); // value z in Models(Host, Mod); pHM: 1: replace all named methods up to down;
// void HostMod(elem Q, elem M);        // Q,M from Q.M, calculation of Host,Mod; ker.g: Q=ker, M=g;
// elem valHostMod(elem s);  // if for some i Host[i] = s, r = Mod[i], else r = zel;
// void wrHostMod(elem Q, elem M);      //                       pHM: 2: only simple (abt-names or dcl-methods);
// void prHostMod(char* s=0, elem z=zel, char* s1=0,  elem y=zel);     //  printing of Host, Mod;  
elem moddot(elem d, elem M);  // look for a theorem M in d(r = zel1) or M in d.M1 (r = M1) else r = zel;
elem abtyp(elem z, elemp M=0);  // typ(z) can be d.M  // styp.cpp;
elem typnany(elem z);
att fntype(elem t, elemp t1=0,elemp t2=0, elemp f0=0);   // t in FNtypes or t $ fnn(t1,t2) or t $ fnn(t1), *f0 = fnn;
elem findfunt(elem z);  // find a functional type of z from lot and thms;
elem tpseq1(elem z, elem i, elem t);    // z in seq1(t): if(i==0 || i==1 || typ(i)==1..last(z)) r=t;
bool tpseq1a(elem z);                   // z is SEQ...1 or SEQ...2 or seq...1(t) or seq...2(t);
// void wrv(headp h, elem v); 
// elem rdv(headp h, elemp q);          // former valdot;
bool boolt(elem z, headp* ag, elemp* aw);
inline bool fntypn(elem z){ return z==zfn||z==zFn||z==zifn||z==zsfn||z==zbfn||z==zafn;} // function type name
inline bool fntyp(elem z){ headp h; elemp q; return mel(z,&h,&q)==pfs && fntypn(q[0]); }
void chtead(elem z, char* s);
void endchtead(elem z, char* s);
elem tp1(elem z);  // tp1(x): if(x.m==ints):znat,...,if(z.i==0):zel, else tp(x);
elem typthms(elem z, bool fnt=false); // type from lth-theorems; fnt==true: look only for func. types;
elem typtabt1(elem z);  // look for theorems z' in t or z' <: t, r = t or P[t]; 
// elem typt(elem z); // {elem r = typthms(z); if(r==zel) r = typtabt1(z);  return r; }
elem typfnA(elem T,elem f,elem z);  // type from T := f in fn(A,B): r = B; or from T := A[x:t, f(x) in B]: r = B; (if typ(z) = t);
// ats types(elem f, elem x, elemp* q );  // writes all typfnA-sets into ar,return number of elements in ar
bool look1(elem f, elem x, elem goal);    // z: f(x), goal: z in t;
bool lookfnt(elem z, elem goal);          // if fnterm(z): check goal, usually z in t;
int eqthms(elem z, elemp* a);             // equals from thms; // int sizea;
int fromthms2(elem f, elem z, elemp* a);  // second arguments for f(z,r) from thms; // int sizea;
inline int inthms2(elem z, elemp* a){ return fromthms2(zin,z, a); }
elem mait(elem t);                // main type for t;
 void wlotaxs(elem d, headp h, elemp q);
elem typedax(elem d, att i);      // type from i-th d-axiom;
elem typarg(elem f, att i);       // formal type of i-th argument of the function f;
bool disjP(elem t1, elem t2);     // P[t1](P1[t1]) disj t1;
att checktabt(char* s, elem z= zel999);
void prthms(elem z);
bool isfn(elem z);                // z is a function;

/*int ClassType(elem t);
int ClassDef(elem t);
int SetDef(elem t);
int SetType(elem t);
int SetSeq(elem t);
int SystemType(elem t);
int MetaType(elem t);  
int NormalType(elem t);
int ClassSeq(elem t);
int Term(elem z);
int SetOrClass(elem z);
int MainDef(elem d); */