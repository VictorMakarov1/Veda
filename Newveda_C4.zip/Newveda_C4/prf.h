// prf1.h 4/14/00 4/27/00 5/13/00 9/19/00
 
/* struct FrmInfEl  // Formula in Inference Element
 {
  elem x;         // formula 
  bool proved;    // formula is proved
  bool defined;   // formula is defined   
 };  
*/
// void hnassume(elem x1, elem t1, int ii, int lproof, elemp qq, elem* agoal);        // x1; assume;
void compdc(elem goal, char* place);                    // computing dc,gdc,kdc,pdc,idc for goal;
int indc(elem F);                                       // number F in dc; (mostly 1, 0: is not in dc) 
void hnassume(elem F, elem* agoal);                     // F; assume;
void hnassume1(elem x, elem* agoal);                    // assume(x); x is bvar;
void hnis(elem Q, elem J, char* place, bool p=false);   // p==true: called from typseq, not prf; // Q; is(J);   
void hnby(elem y1, elem y, headp h, elemp q, elem y2);  // y1; y:by(y,h,q); y2;
bool hnbybyeq(elem F, elem y, headp h, elemp q, elem G);     // F; (h,q)=by(z1,..., zk); G;   used in byeq, hnby;
bool hnbyeq(elem x1, elem x, headp h, elemp q);  // x1; x: byeq(z1, ... ,zk);
// bool isb(elem F,elem G, elemp qq, int k);       // F; by (qq,k); G; // F; by (qq,k); G; not used: 4.23.20;
bool eqdot(elem z, elem Q, elem W);             // z = Q.W                // vars_are_cons:zel0,zel21,d; see byel
bool eqadt(elem Q, elem J, headp h, elemp q);   // Q; is J;  where h->adt == 1;      // occur=0: each occurrence;
bool isbe(elem F,elem A,elem B, elem G, elem vars_are_cons, elem dpat, ats occur=0); // compare F,G by A=B; 
void byimp(elem x1, elem x, elem x2);  //x1;  x: Q1->Q2; x2; x1 follows from more general x2; ( x2->x1 is instance(Q1->Q2);
elem prf(elem z, headp h, elemp q);     
int cprf(elemp goal, elemp qq, int first, int last1, elemp ada=0, elemp ab= 0);    // common part prf and eqprf;
elem eqprf(elem z, headp h, elemp q);
void trtr(elem z, elem y);           // transfer truth from z to y;
void mktr0(elem z, att tr);          // make true the formula z, tr = truth or ctruth, for use before typa;
void mktr(elem z, att t = truth);    // make true z;
bool Taut(elem f);
bool htaut(elem Q, elem J);      // handling tautologies and set tautologies
bool byel(elem y, elem *a, elem *b, elem* vars_are_cons, elem* dpat);  
                                 // *vars_are_cons=zel1 == iseqmn(y) & y in lot; z
void linassocinve(elem z);       // zel0: y is equality,but not in lot; d: from A[d,a=b];
ats linconj(elem z, elemp* aconjuncts);    // linearization of conjunction // returns # of conjuncts;
void makevarcon(elem z);         // add all free vars from z to convar;
// att stprf(elem V, elem A, elem* B, ats occur, att* occ );  // r=0: ret(error), r=1: Eqt_V1_B, r=2(Nxt1): checked B,
// bool congr(elem V, elem V1, elemp qq, int k); moved to sbs

/* elem typinfel(elem z, headp h, elemp q);
elem typtact(elem z, headp h, elemp q);
elem Taut(elem f);
elem Instance(elem z, elem y);      // z is an instance of y
elem Subst(elem f1, elem f2, elem f3);
elem subst(elem f1, elem A, elem B, elem C = ztrue);  // C -> A = B
elem MatchSubTerm(elem f, elem A, sbst* s);
elem Concr(elem z, elem f, headp h, elemp q, headp g, elemp w);
elem Acontr(elem f1, elem f2, elem f3);
elem Implicat(elem z, elem f, headp h, elemp q, headp g, elemp w);
elem Subst(elem f1, elem f2, elem f3);
elem Subst0(elem f1, elem f2, elem f3);
elem Rewrite(elem f1, elem f2, int k, elemp q);
elem mprd(elem y, elem z, elem f1);   // modus ponens reduction

void WrAllFrm(elem frm, FrmInfEl AllFrm[], int* iAllFrm); 
void PrintFrm(FrmInfEl AllFrm[], int iAllFrm);
int Index(elem frm, FrmInfEl AllFrm[], int iAllFrm);  
int InfElement(elem x, elemp* w, int* k);

extern elem zTaut;       // Taut (ology)
extern elem zInstance;   // Instance
extern elem zSubst;      // Subst
extern elem zSubst0;     // Subst0
extern elem zAcontr;     // A-contraposition (A[d, p], p' |- ~(z in t) )
extern elem zSimplify;   // Simplify
extern elem zSuppose;    // Suppose
extern elem zRewrite;    // Rewrite
extern elem zAxiom;      // Axiom
extern elem zTheorem;    // Theorem  */

