//#include "ts.h"   // 9/18/95 10/8/97
#define lrb 80
#define lcont 200 
#define emptyts -1
extern char sym;
extern char rb[lrb];
extern char* sun;    //[ ] = {"~-!"};
// extern char* slpus;  // ! ,!! ,
extern char* spostfix; // ?factorial?
// extern char* sspms;
// extern ts* pts;
int prt(char* s);
bool uns(char* s);
void inops();
ats name(ats a);
void getsym();
void skip(char);
void skips();
bool isltr(char c);
void glex();
void stp(char c);
void stp1(char c, char* p="",int k= -1);
bool isident(char* s); // checks s.m == ident && s.a=s 
bool isname(char* s);  // checks in cont ident = s
int wrts(char* s);
