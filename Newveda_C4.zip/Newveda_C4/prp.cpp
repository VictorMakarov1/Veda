#include "lib.h"  //11/16/97 3/29/00 7/13/00 12/20/00 01/28/01 02/13/01
#include "achs.h"
#include "sbs.h"  //02/17/01 03/14/01 06/13/01
#include "tt.h" 
#include "adl.h"
#include "myio.h"
#include "typ.h"
#include "elem.h"
#include "term.h"
#include "etc.h"
#include "err.h"

extern int aa, bb, cc, yy, lhis;
extern ats aend;
extern char source[80] ;
extern char namefhis[80];
extern bool errprint;

#define lline 60
#define MaxlPrinting 10
// int fl;      // flag of letter
int ibf;     // index of bufer (ib) for f
int ibcout;  // index of bufer (ib) for cout
int totalsize = 0;
// int depthprp = 0;       // moved to static into prpt;
// elem stdepth[maxdepth]; //  maxdepth == 50 ( see prp.v)
bool flag = true;
int prt(char* s);   // precedence
int bint(elem x, bool* flag_letter=false);
char* svel(elem z);
modsize_t findallm(char* s);  // find s in allm, if not in allm, error
void unom(ofstream* f, elem x);
void upar(ofstream* f, elem x, int p);
bool par(elem x, int i);
// void pelmcom(elem x, ofstream* f);

   void unomv(ofstream* f, elem x)
{
 char* s = "@";
 // if(x.m == bvr) 
 //   s = "$";
 if(nn) ut(f, s);                    // nn > 0 || x.m==bvr
 if(nn) { ut(f, x.m); ut(f, "."); }  // if(x.m){
 if(nn) { ut(f, x.i); ut(f, "."); }  // if(x.i) {
 if(nn) ut(f, x.ad);                 // if(x.m == bvr) ut(f, x.i); else if(nn) ut(f, x.ad);
} // end unomv

  inline void hatt(ofstream* f, headp h)  // output of h-attributes: t,adt,v,at
{
 elem t;
 if(h->t) {  ut(f,"!"); ut(f, h->t); }
 if(h->adt) ut(f,"adt"); 
 if(h->v) ut (f,"v");
 if(h->at) ut (f,"at");
 if(h->postfix) ut(f,"P");
 if((t=h->tp)==zel) ut(f,"?");
 else if(mm&&ttt){ ut(f, ":t:"); ut(f, svel(t)); } 
 ut(f," ");
} // end uatt

   void prp(elem z, ofstream* f ) // pretty printing of an element z to file f
{
 int k, p=pp; pp=0; int g=gg; gg=0; // char* s; // char c;
 if(cc)
 {
  cout<<"\n+prp z="; pelm(z); 
  *pfhis<<"\n+prp z="; pelm(z, f); 
 } 
 if(flag && lhis && ( (k = filesize(namefhis)) > lhis ))   //  *(totalsize+1)
 { 
  // if(totalsize < 2) pfhis->seekp(0); 
  cout << "\n ERROR: too big 0_bool.his, k= " <<k << " totalsize = " << totalsize << "\n\n"; 
  *pfhis << "\n ERROR: too big 0_bool.his, k= " << k << " totalsize = " << totalsize << "\n\n"; 
  /*if(++totalsize > 2)*/ { flag = false; myexit(); }     // flag: to avoid recursion in myexit()-it uses prp in prach, futt.
 } // if(flag ...)
 if(z.m == emps)
 {
  if(f) *f<<" zel"; else cout<<" zel";
  goto ret;
 } // if(z.m == emps)
 if(emptpl(z)) { ut(f, " **0**"); pelm(z,f); goto ret; }
 // m = mel(z, &h, &q,1);   // dp not unwind abbr
 /* if(seqv(z) && h->l > 5) // f == 0
 { 
  cout<<"seq"; pelm(z); *pfhis << "seq" << z.ad<<' '; goto ret;
 }
 */ // if(m == pfs && Ubs(q[0], &a, &pr) && pr == 1) z = q[1];
 
 //cout<<' ';
 //if(z.n) if(f) *f<<"$("; else cout<<"$(";
 prpt(f,z);        //
 //if(z.n) if(f) *f<<")"; else cout<<")";
  ret: pp=p; gg=g; //cout<<"\n-prp"; cin>>c;
} // void prp(elem z, ofstream* f )

   void prp(char* s, elem z, ofstream* f)  // *f << s; prp(x,f);
{
 //if() cout<< "\n+prp s";
 if(f) *f<<s; else cout<<s;
 prp(z, f);
}

   void prp(int i, elem z, ofstream* f)
{
 if(f) *f << "\n"<<i<<' '; else cout << "\n"<<i<<' ';
 prp(z, f);
} 

   void prpt(ofstream* f, elem x, bool b1)  // b1==true: print all sequences,false: only short ones;
{
 static int depthprp = -1; static elem stdepth[maxdepth]; //  maxdepth == 50 ( see prp.v)  
 char* s; int i,k,hl,m=x.m;  ats a; bool bigseqv=false; bool fl;
 headp h; elemp w; //static elem stdepth[51];
 if(cc)
 {
  *pfhis<< "\n+prpt x= "; pelm(x, pfhis); 
  *pfhis<<" depthprp= "<< depthprp;
 }
 // if(i1) if(f) ibf = 0; else ibcout = 0;
 // if(int(x.m) != ints && x.n) ut(f, "N");
 if(m >= maxmod) { prps(x,f); goto ret1; } // ubs,ident,ints, ...
 if((x.i> 0))   //   || (x.m==bvr))
 {
  s = svel(x);
  ut(f, s); // tt* p = clad[m]; 
  // if(isalpha(s[0])) ut(f, " ");
  pelmcom(x, f);
  unomv(f, x);     // if(printing)
  goto ret1;
 }
  // below x is an composite term ---------------------------------------composite!
 if(adel(x, &h, &w)) errorelm("prpt:comp:adel x= ", x);
 if(++depthprp >= maxdepth)
 { 
  for(i=0; i < maxdepth; i++){ *pfhis << "\n"<<i<<' '; pelm(stdepth[i], pfhis); }
  errorelm("prpt: depthprp >= maxdepth, x= ", x, " depthprp = ", depthprp);
 } // if(++depth == maxdepth)
 // if(badm(x)
 // mm=mm;
 stdepth[depthprp] = x; 
 a = h->name; hl = h->l; 
 // hatt(ofstream* f, headp h)  // output of h-attributes: t,adt,v,at
 // if(h->tel != abt && depth == 0 || a != -1) unom(f, x);  // ?? was pdf
 if(a != noname)    // noname == -1;  // named term
 { 
  if(a < 0 || a > its){ ipp("prpt: wrong term name a= ", a); s = "*****"; }
  else s = vts(a);
  ut(f,s);   // if(f) *f<<s; else cout<<s; //
  if(errprint) goto Merrprint;
  if(!errprint || !yy || h->tel == abt)                            //  && !mm)
  { 
   ut(f,"#"); 
   if(x.m){ ut(f, x.m); ut(f, "."); } 
   ut(f, x.ad);  // ut(f," "); 
   hatt(f, h);  // output of h-attributes: t,adt,v,at,z;
   goto ret;
  } // if(!errprint)
 } //  if(a != noname) ---------------------below is a nonnamed term or errprint;
 // z = x; 
 Merrprint:
 ut(f,"#"); 
 if(x.m){ ut(f, x.m); ut(f, "."); }
 ut(f, x.ad); // ut(f," ");
 hatt(f,h);  // output of h-attributes: t,adt,v,at,z;
 if(h->postfix)         //----------------- postfix terms
 {
  prpt(f,w[1]); prpt(f,w[0]); goto ret;
 } // if(h->postfix)
 if((k = bint(x)) > 0)  //------------------binary terms
 {
  fl = comp(w[0]);  
  if(w[1].m == ints) ut(f, " ");
  upar(f,w[1], par(x,1));
  if(fl) ut(f,"(");
  prpt(f,w[0],b1);
  if(fl) ut(f,")");
  upar(f, w[2], par(x,2));
  // if(w[0] == zmdot) ut(f, ")" );
  goto ret;
 } // if(k = bint(...))
  // common case
 if(seqv(x))
 { 
  bigseqv = hl > 5; //if(bigseqv && (!b1) ){ cout<<"seq"; pelm(x); if(f!=0) *f << "seq" << x.ad<<' '; goto ret;} 
  if(bigseqv && b1) ut(f,"\n"); 
  ut(f,"[ "); 
  for(i=1; i < hl; i++)
  {
   prpt(f,w[i],b1); 
   if(i != hl-1) ut(f,", ");
   if(bigseqv && b1) ut(f, "\n");
   if(!b1 && i > 3){ ut(f,"..."); break;}
  } // for(i)
  ut(f, "]");
  if(bigseqv && b1) ut(f,"\n");
  goto ret;
 } // if(seqv(x))
 if(w[0]==zProof || w[0]==zEqProof)
 {
  ut(f, w[0]==zProof? "Proof ": "EqProof "); 
  ut(f, svel(w[1])); 
  // ut(f,")"); 
  goto ret;
 } // if(w[0]==zProof || w[0]==zEqProof)
 for(i=0; i < hl; i++)
 {
  prpt(f,w[i], b1);   // 204 i=1 h->l = 2, f=0, b1=0
  if(i == 0) ut(f, "(" );
  if(i>0 && i < int(h->l)-1) ut(f, ";");   // ??? ","
  if(h->l > MaxlPrinting && w[0] != yvar) newl(f);
  if(x.m == 0 && Att(x) == ptt->root) newl(f);
 } // for(i)
 ut(f,")"); 
 
 ret: if(--depthprp < -1) error("prpt: depthprp= ", depthprp);
 ret1: if(cc)
 {
  *pfhis<< "\n-prpt x= "; pelm(x, pfhis); 
  *pfhis<<" -prpt depthprp= "<< depthprp;
 } // if(cc)
} // end prpt 



  void prpa(elemp a, int last, elem z)    // ??? not used ???
{
 error("prpa");
 cout<<"prpa:";
 if(a == 0){ prp(z); return; }
 if(last) cout<<"\n";
 for(int i=0; i<=last; i++){ prp(a[i]); pelm(a[i]); }
}

  void prpe(elemp a, int last)           // ??? not used ???
{
 error("prpe");
 cout<<"prpe:";
 for(int i=0; i<=last; i++) pelm(a[i]);
}

   void prp(ofstream* f, int m)
{
 prpt(f,elma(m, clad[m]->root));
 if(f) f->close();
 cout<<"\nfinished prp root="<<clad[m]->root<<
        " itt="<<clad[m]->itt;
}

   void tt::fprp(char* y1)
{
 int m = findallm(y1);
 *pfhis << "\n+fprp y1= " << y1 << " root= " << root; cout << "\n+fprp y1= " << y1 << " root= " << root;
 char y[80]; // int i;   // char c; char* s;
 strcpy(y, y1); strcat(y, ".prp");
 ofstream f(y,ios::out);
 if(m < 0)
 {
  *pfhis << "fprp: wrong module name y1= " << y1;
  cout << "fprp: wrong module name y1= " << y1;
  goto ret;
 } // if(m < 0)
 if(prognum == numtrm)
 {
  *pfhis << "\nfprp: prognum = numtrm, module= " << y1; 
  cout << "\nfprp: prognum = numtrm, module= " << y1;
  goto ret;
 } // if(prognum == numtrm)
 if(root < 0 || root > lltt)
 {
  *pfhis <<"\nfprp: wrong root = " << root;  cout <<"\nfprp: wrong root = " << root; 
  f << "fprp: wrong root = " << root;
  goto ret;
 }
 if(!f) error("tt::fprp: cannot open file ", y);
 pfprp = &f;
 f << mytime() << " root= "<<root <<" itt= "<<itt<<"\n\n";  elem z = elm(m,0,root);
 prpt(pfprp, z, true);
 ret: *pfhis << "\nfinished fprp root= " << root << " itt= " << itt << " lltt= " << lltt;
       cout << "\nfinished fprp root= " << root << " itt= " << itt << " lltt= " << lltt;
     f.close(); 
} // end fprp

   void newl(ofstream* f, char* s )
{
 if(f) { *f << '\n'<<s; ibf = strlen(s); }
 else  { cout << '\n'<<s; ibcout = strlen(s); }
} // end newl
  
   void chck(ofstream* f, int k)
{
 //if(f){ if(ibf += k > lline){ *f << "\n   "; ibf = 3; } }
 //else { if(ibcout += k > lline){ cout << "\n   "; ibcout = 3; } }
} // end chck

   void ut(ofstream* f, char* s)
{
 if(s == 0) return;        
 // chck(f,strlen(s));
 if(f) *f << s; else cout << s;
} // end ut(f,s)

  void ut(ofstream* f, int x)
{
 // chck(f, intlen(x));
 if(f) *f << x; else cout << x; //  << ' ';
} // end ut(f,x)

   void utc(ofstream* f, char s)
{
 // chck(f, 1);
 if(f) *f << s; else cout << s;
} // end ut(f,s)

   void prps(elem x, ofstream* f)  // pretty printing of simple x
{
 char* s;
 // if(bb) cout << "\n+prps x.m= "<< int(x.m);
 if(x.m == ident || x.m == ubs) // || x.m == bvr)            // if(idubs(x, &xa))
 {
  // if(x.m != bvr) ut(f,"?"); else { ut(f,"$"); ut(f,x.i); }
  s = vts(x); // p = prt(s);
  // if(p) ut(f," "); 
  ut(f,s); 
  if(int(x.ad)!=aabt) ut(f," "); // pelmcom(x, f);    // no intl!
  if(int(x.ad)==aabt) ut(f, x.i);
	 //if(p) ut(f," ");
	}
 else 
 switch(x.m)
 {
  case chara:     // character 
  if(f) *f << "'" << char(x.ad) << "'";
  else cout << "'" << char(x.ad) << "'";
  break;
  case strng:   ut(f, vts(x));      break;  // string  
  case ints:    ut(f, intval(x) );  break;
  case gpc:     utc(f, x.i);        break;
  case gcom:    utc(f, x.i);        break;
  case meof:    ut(f, "meof");      break; 
  case clp:     if(x.ad==att(aend)) ut(f,"end"); else utc(f, x.i);        break;
  case emps:    ut(f, "zel");       break;
  case 204:     ut(f, "***204");    break;
  case 239:     ut(f, "***239");    break;
  default:   
  
  cout<<"\nprps: strange x= "; pelm(x);
  *pfhis<<"\nprps: strange x= "; pelm(x, pfhis);
  *f << "\nprps: strange x= "; pelm(x, f);
  // error("prps: strange x");     	      
 } // end switch
} // end prps

   void upar(ofstream* f, elem x, int p)
{
 // if(oo) cout<<"upar";
 if(p) if(f) *f<<'('; else cout<<'(';
 prpt(f, x);
 if(p) if(f) *f<<')'; else cout<<')';
} //end upar

    bool par(elem x, int i)
{
 // if(oo)cout<<"par";
 int p; headp h; elemp q; // char c;
 if(adel(x,&h,&q)) return 0;
 p = bint(q[i]);
 //cout<<"\n*****par p="<<p<<"bint(x)="<<bint(x);
 return p>0 && p<bint(x);
} // end par

   int bint(elem x, bool* flag_letter)  // returns prt or 0 // bin_ary t_erm;
{
 // if(oo){ cout<<"\nbint";pelm(x); cout<<"p="<<p; }
 int pr, m, r=0; ats a;  headp h; elemp q; 
 if(emptpl(x)) goto ret;
 m = mel(x,&h,&q);
 if(m != pfs || int(h->l) != 3) goto ret;
 if(Ubs(q[0], &a, &pr) && pr != 0) r = pr;
 // if(r > 0 && q[0].i) s = svel(q[0]);
 ret:  // if(flag_letter) *flag_letter = fl;
 return r;
 /*
 if(emptpl(x) || adel(x,&h,&q)) return 0; // const
 if(h->tel != pfs || int(h->l) != 3) return 0;
 if(comp(q[0])) return 0; // q[0] is composite
 s = svel(q[0]);
 fl = isalpha(s[0]);  // fl:  flag of letter
 return q[0].m==ubs? q[0].i : prt(s);
 */
} // end bint

 void compare(char* s, headp h, headp g) // print differences 
{
 ofstream* f = pfhis;
 if(*h != *g) *f << "\n+compare heads "<<s;
 if(h->tel != g->tel) *f << "\n tel "<<int(h->tel)<<' '<<int(g->tel);
 if(h->t != g->t) *f << "\n t   "<<int(h->t)<<' '<<int(g->t);
 // if(h->lev != g->lev) *f << "\n lev   "<<int(h->lev)<<' '<<int(g->lev);
 if(h->l != g->l) *f << "\n l   "<<int(h->l)<<' '<<int(g->l);
 if(h->ln != g->ln) *f << "\n ln   "<<int(h->ln)<<' '<<int(g->ln);
 if(h->tp != g->tp){ *f << "\n tp   ";pelm(h->tp, f); pelm(g->tp, f);}
 if(*h != *g) *f << "\n-compare heads "<<s;
} // end compare
  
   void unom(ofstream* f, elem x)
{
 ut(f, "#"); 
 if(x.m) { ut(f, x.m); ut(f, "."); }
 ut(f, Att(x));
} // end unom

// end prp.cp