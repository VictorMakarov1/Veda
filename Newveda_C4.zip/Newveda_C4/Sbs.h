#define maxiter 2000   // sbs.h  9/18/97 8/31/00 9/25/00 11/22/00 
#define lsbst 40       // 01/26/01 05/29/01
#define lqff 100
//#define mon1 1
//#define nor 2
//#define uni 3
//#define rrt 4

#define COMMON_T 1                     
#define FOR_CRED 2                     
#define FOR_UNIF 3                     
#define MaxMod 10                     

void pcin();

    class sbst
{
 // char checkedvars[lsbst];  // for chsb1
 public:
 int size;                // size < lsbst !!! 
 bool rpsimple;           // right body has no composite terms; 
 elem body[lsbst];        // x0,x1, ... ,xk , i = 0, 2, 4, ...
 qab stqab;
 int iMod;
 elem Host[MaxMod];
 elem Mod[MaxMod];
 void HostMod(elem Q, elem M);        // Q,M from Q.M, calculation of Host,Mod; ker.g: Q=ker, M=g;
 elem valHostMod(elem s);  // if for some i Host[i] = s, r = Mod[i], else r = zel;
 elem valHM(elem z); 
 void wrHostMod(elem Q, elem M);      //                       pHM: 2: only simple (abt-names or dcl-methods);
 void prHostMod(char* s=0, elem z=zel, char* s1=0,  elem y=zel);     //  printing of Host, Mod;  
 att method(elem R, elem* aM=0, elem* aM0=0);

 elem remd(elem d, int m);            // remove from d xm;

 sbst(); 
 void adds(elem x, elem y);  // adds to body (x,y); // addsp: lambda-notation: Q = lambda(Y[0],...Y[k-1];V)
 void addsp(elem Q, elem Y[], int k, elem V); // add to body (Q,Y[0]), ..., (Q,Y[k-1]), (Q,V); Lambda
 bool addsch(elem x, elem y); // add with checking vals(x) != zel;
 void remove(int i);          // remove body[i], body[i+1];
 void removebvars(elem z);    // remove bvars of qabterm z from body;
 // void adds(elem x, elem y, int k, elemp arqt);   // arqt[0] = top; 
 elem finst(elem z, elem a);  // find an instance r of a in z. return r; // all bvars must be assigned;
 // int inst(elem z, elem y, int p=0); // p: use inst inside inst
 int unif(elem z1, elem z2);
 int unif1(elem z1, elem z2);
 int vvar(elem z, elem* v);
 int occr(elem v, elem z);   // vals returns zel, if not; 
 elem vals(elem x, att k=1); // k=0 : look only in body, k=1: look in body and stqab; k=2: ??? vals2 ??? not imp. yet
 elem vals1(elem z); // { elem r = vals(z); if(r==zel) r = z; return r; } // vals1 can be used only in rep !!!
 elem vals2(elem z); // elem r1, r = vals(z); if(r!=zel){ r1 = vals(r); if(r1 != zel) r = r1; }
 elem valsHM(elem z, att pvals=1, bool abt_in_dt=false);    //  value of z in sbst, using body,stqab,Imod;
 elem valsp(elem x,elemp a,int k, elem b, int place);
 // elem vals(int k);
 // int valsarqt(elem x, elemp ay, elem arq[]); // *ay = vals(x);  arq[] - lambda-arguments; r=last(arq)
 elem rep(elem z, char* place, att pvals=1); // 1: use vals in valsHM, 2: use vals2;
 elem redinab1(elem z, elem x, elem d);      // reduction of z := x in (d:={x1,...,xk; F});
 elem redinab(elem z, elem x, elem D);       // reduction of z := x in D, D=d1,D1&&P, D1&&d2);
 // elem rep1(elem z, int p);
 // elem repd(elem d, int fclon=0); //fclon==1 -> repd == clond
 bool instlot1(elem z, elem ar[], int* piar);  // a lot[i] is instance of z;
 bool instlot(elem z);   // some conjunction of lot[i] is instance of z ;
 bool ismds(elem d);  // all axioms of d are s-true; body in lot.cpp;
 int chsb(char* place, int p=0); // p==1 check for axioms
 int chsb1(int fv); // number of first variable in body
 elem mod1(elem d, elem* t);  // s is 1-complete
 void pref(elem z, elem d, elem f); // computes s= (y->f.y), y in Meth(d)
 // void AddMethods(elem z, elem M, elem T); // for each T-method y in z adds (y, y@M);
 bool isba(elem F, elem G);    // F: [z1, ... ,zk] in {x1,..., xk; Q}
 elem sbbvt(elem z);
 bool Addsqt(elem V, achs* f, elem V1, achs* f1);  // Adds substitutions for qab-terms, also checks bvars are
 bool Addsqt1(elem V, achs* f, elem V1, achs* f1);  // Adds substitutions for qab-terms, also checks bvars are
 att hnpvar(elem V, achs* f, elem V1, achs* f1, elemp Qx, int k); // V1 is Q(x1,...,xk) //  s-equal
 bool fit_inst(elem z, elem z1,elem V, elem V1, achs* f1,achs* f0,att peqt, char** acause);
 bool instance(elem z, elem y, elem d0=zel0, elem dpat=zel0, void* f0=0, att peqt=0); 
   // z is an instance of y; d0: was vars_are_cons;  // dpat: d from Q@d; (d = scopeden(Q@d));
 bool eqt(elem z, elem y, elem  vars_are_cons=zel0, elem dpat=zel0, att peqt=1); // bool vars_are_cons=false);  // remove bool vars_are_cons??? // dt: parent of z is d-term;
 bool congr(elem V, elem V1, elemp qq, int k);
 int gens(elem z); // generate substs: if z is a Q(ab)term then n: new place in tabt for new Qterm and sbsts
 bool depend(elem z); // one of vars (or separate bvars) of s is in z
// void changesize(int save, char* s= " ");
 void psbs(char* s= "");
 void sbst::repr();                    // replace right parts in s, using stqab and rep;
 // void sbst::repr1(elem z, att n);      // replace bvars in right parts in s, using repb2;
 inline bool last(elemp x, elemp y){ bool r = (size>0); if(r){ *x = body[size-2]; *y = body[size-1]; } return r; } 
 void crstqab(achs *f);                // create stqab from achs until V(not including);
};  // end sbst

//elem tp(elem,int*);
bool substabt(elem z, sbst** aps,elem* aF);  // substitutions of abs. term : aF: Axiom
elem sbbv(elem z);               // reduction z = All(x,P)(y) = Sb(P,x,y);
bool eqt2(elem z, elem z1, elem a, elem b);
elem RRep(elem z, elemp q);       // Reduction of Rep(z, d, M)
elem reps(elem z, elem sq);
elem repb2(elem d, elem z, att n); // replace in z every d-bvar y a on y(y.ad=n);
att repvals(elem V, elem V1, elem y1,achs* f,achs* f1, att peqt); // r=1: V=y1: was goto Nxt1; in insteqt;
bool eqfmdot(elem z, elem z1);    // full meth term z is equal to its abridged dot term z1;
bool eqre(elem V, elem y1, achs* f,  achs* f1);  // f->actplace(&root)==0 && isfn(root)) && f1->same && istr2(zincl,root,root1)
