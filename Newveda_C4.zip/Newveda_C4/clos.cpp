// clos.cpp 12/08/00 12/16/00 12/28/00 02/07/01 02/26/01 03/27/01
//          04/30/01 05/08/01 06/04/01

#include "lib.h"  
#include "sbs.h"
#include "tt.h"
#include "adl.h"  
#include "typ.h"     
#include "elem.h"
#include "df.h"
// #include "ismd.h"
#include "clos.h"
#include "simp.h"
#include "eqcl.h"
#include "truf.h"
#include "term.h"
#include "cr.h"
#include "rep.h"
#include "assert.h"
#include "err.h"

extern elemp lot;
// extern int  isteq, istparsimp;
extern elem steq[lsteq];
extern elem stparsimp[lst]; // stack of parameters: to avoid recursive looping 
extern int aa, mm, kk, oo, qq, yy, ilot, MaxCountInsert, prcause;
extern att llot; 
extern char** lot1;
extern elemp lot2;
extern elemp lot3;

   elem reduce(elem z)  // facts(z); closlot; simp(z);
{
 int static istpar = -1; elemp q; elem z1 = z;
 if(9) ipp("+reduce z= ", z, " ilot= ", ilot, " istpar= ", istpar);
 int i, j, k = ilot + 1; elem r; 
 elem static stpar[lst]; // stack of parameters: to avoid recursive looping 
 
 for(i=0; i<= istpar; i++)
  if(req(z, stpar[i]) )       
  {
   error("reduce: already in stpar z= ", z, " istpar= ", istpar);
   r = z; goto ret;
   /*for(j=0; j<istparsimp; j++)
    if(z == stparsimp[j])
    {
     ipp("reduce: z is in stparsimp, z= ", z, " j= ", j);
     goto ret;
    } // if(z == stparsimp[i])
   ipp("reduce: z is not in stparsimp, z= ", z, " istparsimp= ", istparsimp);

   facts(z);  // z, d ??? 2/28/00
   if(closlot(k))
   {
    ipp("reduce0: discovered conntradiction, z= ", z, " r= ", zel);
    r = zel; // closlot discovered false!
   }
   else r = simp(z);

   goto ret; */
  } // if(z == stpar[i], for(i) 

 if(++istpar >= lst) error("reduce: overflow of istpar= ", istpar);
 stpar[istpar] = z;
 if(ist < -1 || ist >= lst)
  error("+reduce overflow of ist, z= ", z, " ist= ", ist);

 /*if(isrt(z, zin, &q) && fit(q[1], q[2]))
 {
  r = ztrue;
  goto ret1;
 } */

 if(isrt(z, zall, &q))
 {
  //ipp("reduce: ALL-formula z= ", z, "\n    new z= ", q[2]);
  //wdal(q[1]);
  z = redA(q[1], q[2]);
  if(z == zfalse || z == ztrue) goto ret1;
 }

 fcts(z);  // z, d ??? 2/28/00

 if(9) prlot("reduce before istr");
 
 if(istr0(z))
 {
  ipp("reduce: istr discovered truth of z= ", z);
  r = ztrue; goto ret1;
 }
 ipp("reduce: istr did not discovered truth of z= ", z);

 if(closlot(k))
 {
  ipp("reduce: discovered conntradiction, z= ", z, " r= ", zel);
   r = zel; // closlot discovered false!
 }
 else 
  if(z1 != z && inlot(z1)) r = ztrue;  // z1 != z means: z1 is an All-formula
  else r = simp(z);
 
 ret1: if(--istpar < -1) error("reduce: underflow of istpar = ", istpar);
 
 ret:  ilot = k - 1; // restoring ilot
 if(9) ipp("-reduce z= ", z, " r= ", r, " ilot= ", ilot);
 if(ist < -1 || ist >= lst)
  error("-reduce overflow of ist, z= ", z, " ist= ", ist);
 return r;
} // end reduce

/*   void facts(elem p) // all facts (axioms and theorems with names from p)
{                      
 if(9) ipp("+facts p= ", p, " ilot= ", ilot);
 if(ist < -1 || ist >= lst) error("+facts: wrong ist= ", ist);
 elem nms[lnms]; int i; elem d; elemp w;
 names(p, nms, lnms);
 if(9) *pfhis<< "\nfacts: nms =";
 if(9) for(i=0; nms[i] != zel; i++) prp(" ", nms[i], pfhis);
 if(mm && kk) ipp("facts nms[0]= ", nms[0], " ist= ", ist);
 for(i=ptt->iach; i>=0; i--)
 {
  d = ptt->ach[i].e;
  if(isdf(d) && dinn(d, nms)) wdal(d, zel, nms);
  if(qtrm(d, &w) && dinn(w[1], nms)) wdal(w[1], zel, nms);
 } // for i
 for(i=0; i<=iclad; i++) clad[i]->facts(nms);
 if(ist < -1 || ist >= lst) error("-facts: wrong ist= ", ist);
 if(9) ipp("-facts p= ", p, " ilot= ", ilot);
 if(pp) prlot("-facts"); 
} // end facts

   void facts1(elem p)
{
 if(9) ipp("+facts1 p= ", p, " ilot= ", ilot);
 if(ist < -1 || ist >= lst) error("+facts1: wrong ist= ", ist);
 elem nms[lnms]; int i;
 names(p, nms, lnms);
 if(9) *pfhis<< "\nfacts1: nms =";
 if(9) for(i=0; nms[i] != zel; i++) prp(" ", nms[i], pfhis);
 for(i=0; i<=iclad && i != snampl; i++) clad[i]->facts(nms);
 if(9) ipp("-facts1 p= ", p, " ilot= ", ilot);
} // end facts1

   void tt::facts(elemp q) // all facts about q[0], q[1], ... (zel is in end!)
{
 if(mm && kk) ipp("+tt::facts q[0]= ", q[0], " mym= ", mym);
 int i, j, kax, kaxth;  elemp pa; elemp pn; elemp pt; elem z;
 // 1. At first, we check all definitions
 for(i=0; i <= ittd; i++)
 {
  elem d1 = elma(mym, i);
  if(valt(d1) == ztrue || iclad == 0) wdal(d1, zel, q); //??? 6/7/00
 } // for(i=0, ..., ittd)
 // 2. Then we check separate axioms and theorems
 for(i=itt; i <= lltt; i++)
 {
  elem z = elma(mym, i);
  if(TrueFormula(z) && Tp(z) == zbool && intersect(z, q)) wlot(z, "TrueFormula");
 } // for(i=itt)
 if(mm && kk) ipp("-tt::facts q[0]= ", q[0], " ilot= ", ilot);
} // end tt::facts(q) */

  void wdal(elem d, elem md, elemp q)
{
 if(mm) ipp("+wdal d= ", d, " md= ", md, " q= ", int(q) );
 elem z; elemp pa; elemp pt; elemp pn; int j, k, kax, kaxth; 
 k = ldeva(d, &pa, &kax, &kaxth);
 if(gg) ipp("wdal: kax= ", kax, " kaxth= ", kaxth);
 if(k <= 0) error("wdal: wrong def d= ", d);
 // if(!Relevant(d)) return;  ??? vars???//d is a root def(dv) or ...
  // see also wdal: it must be the same!
  k = ldev(d, &pn, &pt);
  for(j=0; j < k; j++)
  { 
   z = trm2(zin, vard(d, j+1), pt[j], zbool);
   error("wdal: was commented the next line");
   // if(md != zel) z= Rep(z, d, md); 
   if(!q || intersect(z, q)) wlot(z, "x in type(x)", d);
  }
  // axioms
  for(j=0; j < kaxth; j++)  // zel is the separator
  {
   elem a = pa[j];
   if(a != zel && md != zel) a= Rep(a, d, md);
   if(a != zel && Tp(a) == zbool && (!q || intersect(a, q)))
     wlot(a, "wdal2", d );
   else ipp("wdal: not writing axiom a= ", a, " Tp(a)= ", Tp(a), " q= ", int(q) );
  } // for(j)
 if(mm) ipp("-wdal d= ", d, " k= ", k);
} // end wdal

   void fcts(elem p) // all facts (axioms and theorems with names from p)
{                      
 if(mm) ipp("+fcts p= ", p, " ilot= ", ilot);
 if(ist < -1 || ist >= lst) error("+fcts: wrong ist= ", ist);
 elem nms[lnms]; int i; elem d; elemp w;
 names(p, nms, lnms);
 if(mm) *pfhis<< "\nfcts: nms =";
 if(mm) for(i=0; nms[i] != zel; i++) prp(" ", nms[i], pfhis);
 if(mm) ipp("fcts nms[0]= ", nms[0], " ist= ", ist);
 for(i=ptt->iach; i>=0; i--)
 {
  d = ptt->ach[i].e;
  if(isdf(d) && dinn(d, nms)) wdal(d, zel, nms);
  if(qtrm(d, &w) && dinn(w[1], nms)) wdal(w[1], zel, nms);
 } // for i
 for(i=0; nms[i] != zel; i++)
 {
  if(i > lnms) error("fcts: big i, p= ", p, " i= ", i, " lnms= ", lnms);
  fctn(nms[i]);
 } // for(i)
 if(ist < -1 || ist >= lst) error("-fcts: wrong ist= ", ist);
 if(mm) ipp("-fcts p= ", p, " ilot= ", ilot);
 if(mm) prlot("-fcts"); 
} // end fcts

  void fctn(elem z)  // facts for name z
{
 if(mm) ipp("+-fctn z= ", z);
 if(z.m == strng) return;
 if(!varc(z))
 {
  ipp("fctn: not varc z= ", z);
  return;
 }
 elemp pa; elemp w; int i, kax, kaxth; 
 elem t = typ(z);
 if(t == zel) error("fctn: wrong type, z= ", z);
 elem d = devc(z);
 if(valt(d) != ztrue) ipp("fctn: possibly not consistent def d= ", d); 
 
 wlot(trm2(zin, z, t, zbool), "fctn:in type");
 if(isrt(t, zseg, &w)) { fctn(w[1]); fctn(w[2]); } 
 /*{    // ??? NonEmpty(t, t1, t2) 5/02/01 ???
  elem t1 = typ(w[1]);
  elem t2 = typ(w[2]);
  if(isrt(t1, zseg)) wlot(trm2(zin, w[1], t1, zbool), " fctn seg t1 "); 
  if(isrt(t2, zseg)) wlot(trm2(zin, w[2], t2, zbool), " fctn seg t2 "); 
 } // if(isrt(t, zseg, &w)) */
 int k = ldeva(d, &pa, &kax, &kaxth);
 if(k <= 0) error("fctn: wrong def, z= ", z, " d= ", d);
 for(i=0; i < kaxth; i++)
 {
  elem a =pa[i];
  if(a != zel && Tp(a) == zbool && ElemInTerm(z, a))
     wlot(a, "fctn: axiom"); 
 } // for(i)
} // end fctn

   int closlot(int k) // closure of lot
{
 if(mm) ipp("+closlot k= ", k, " ilot= ", ilot);
 if(mm) prlot("+closlot");
 if(ist < -1 || ist >= lst)
  error("+closlot overflow of ist= ", ist);
 int i, j, r=1;
 for(i = 0; i <= ilot && ilot < llot - 1; i++)  // ilot < llot - 1 means lot is not full!
 {
  ipp("closlot before infer1 i= ", i, " lot[i]= ", lot[i]);
  if(mm) prsteq(" closlot before infer1 ", zel, k);
  if(infer1(lot[i])) goto ret; // it was in wlot!!!
  for(j = i-1; j >= 0; j--) 
  {
   ipp("closlot i= ", i, " j= ", j);
   ipp("closlot: lot[i]= ", lot[i], " lot[j]= ", lot[j]);
   if(infer2(lot[i], lot[j])) goto ret;
  } // for(j)
 } // for(i)
 r = 0;
 ret: if(r) prlot("-closlot: discovered false!");
      else if(mm) plot("-closlot");
      if(ist < -1 || ist >= lst)
       error("-closlot overflow of ist= ", ist);
      return r;
} // end closlot

  int infer1(elem p)         // ip - index p in lot
{
 //assert(ip>=0 && ip <= ilot);
 //elem p = lot[ip];
 if(mm) ipp("+infer1 p= ", p, " ilot= ", ilot);
 elem a, b, c, r; headp h; elemp q; elemp w; elemp pa; int i, kax;
 if(p == zfalse) 
 {
  error("infer1: discovered false in lot!, p= ", p);
  return 1; 
 }   
 if(isrt(p, zmdot))
 { 
  error("infer1: the next line was commented");
  // r = PrefRule(p);
  if(r != p) wlot(r, "infer1:PrefRule ", p);
  return 0;  // ??? not needed ??? 3/27/01
 } // if(isrt(p, zmdot))
 
 if(isrt(p, zin, &w) && mel(w[1]) == psq && isdf(w[2])) 
 {
  wdal(w[2], w[1]);
  return 0;
 }
 
 if(isrt(p, zall, &w)) { wlot(w[2], "infer1: A[d, p]"); return 0; }
 
 //facts1(p);
 r = TrimInf(p);
 if(r != zel) wlot(r, "infer1: TrimInf", p);
 int save = isteq;
 //kk = 1;
 r = eqcl(p, false); // no smel_exit!
 //kk = 0;
 if(r == zfalse) 
 {
  error("infer1: discovered false by eqcl!, p= ", p);
  isteq = save;
  return 1; 
 }   // equality closure of p, the following is not needed???
 if(9)ipp("infer1: writing steq after eqcl save+1= ", save+1, " isteq= ", isteq);
 for(int j=save+1; j <= isteq; j++) wlot(steq[j], "infer1", p);
 isteq = save;
 /*if(isrt(p, zin, &w) && ldeva(w[2], &pa, &kax) && 
 //   w[2] != zREL && w[2] !=zfn)
 // for(i=0; i < kax; i++) wlot(Pref(pa[i], w[2], w[1]), "Infer1: Pref", p); 
 if(mel(zInfRules, &h, &q) != psq) 
      error("infer1: wrong InfRules= ", zInfRules);
 for(int i=0; i < h->l; i++)
 {
  if(!isrt(q[i], zimp, &w) && !isrt(q[i], zequ, &w) ) continue;
  c = w[2];
  if(!isrt(w[1], zconj, &w)) continue;
  a = w[1]; b = w[2];
  corol(p, a, b, c);
  corol(p, b, a, c); 
 } // for(i) */
 if(mm) ipp("-infer1 p= ", p, " ilot= ", ilot, " ist= ", ist);
 return 0;
} // end infer1  

   int infer2(elem p, elem q) // if p' & q' -> r' is a InfR then wlot(r')
{
 if(mm) ipp("+infer2 p= ", p, " \n          q= ", q);
 elem a, b, b1, c, c1, f1, f2, r1, r, t; int k, m;
 headp h; elemp q1; elemp w; sbst s;
 if(mel(p, &h, &q1, "infer2") != pfs) error("infer2: not pfs, p= ", p);
 f1 = q1[0];
 if(mel(q, &h, &q1, "infer2") != pfs) error("infer2: not pfs, q= ", q);
 f2 = q1[0];
 if(isrt(p, znot, &w) && req(w[1], q) || isrt(q, znot, &w) && req(w[1], p) )
 {
  ipp("infer2: discovered contradiction (p & ~p), p= ", p, " q= ", q);
  return 1;
 }
 if(iseq(p, &w)) qparm(p, q);
 if(iseq(q, &w)) qparm(q, p); 

 r = ordinf(p, q);
 if(r != zel) wlot(r, "infer2:ordinf", p, q);
 
 k = trim(f1, f2, &q1); //ii = 1;
 if(mm) ipp("clos after trim, q1= ", q1, k);
 if(mm) ipp("infer2: inf rules, p= ", p, "\n    q= ", q, "\n InfRules= ", zInfRules);
 for(int i=0; i < k; i++)
 {
  r1 = q1[i];
  if(9) ipp("infer2: q1[i]= ", r1, " i= ", i);
  if(!isrt(r1, zimp, &w)) error("infer2: not imp, q1[i]= ", r1);
  c = w[2];
  if(!isrt(w[1], zconj, &w)) error("infer2: not &, q1[i]= ", r1);
  a = w[1]; b = w[2];
  s.size = 0; 
  m = s.inst(p, a) && s.inst(q, b, 1);
  if(!m) { s.size = 0; m = s.inst(q, a) && s.inst(p, b, 1); }
  if(!m)
  {
   if(mm) ipp("infer2: not inst, p= ", p, " q= ", q);
   if(mm) ipp("infer2: not inst, a= ", a, " b= ", b, " s= ", &s);
   continue;
  } 
  if(!s.chsb("infer2", 1)) continue; // 1 means check for axioms
  c1 = s.rep(c, FOR_UNIF);  // was 2 (FOR_CRED) 02/26/01
  if(mel(c1, &h) != pfs)
  {
   ipp("infer2:wrong c1= ", c1, " c= ", c);
   continue;
  }
  //h->tp = zbool;  // ??? 5/21/01
  t = typ(c1);
  if(t == zel) error("infer2: wrong type t, c1= ", c1, " t= ", t);
  if(mm)ipp("infer2: c= ", c, " c1= ", c1, " s= ", &s);
  if(mel(c1) == var)
  {
   ipp("infer2: error! p= ", p, "\n    q= ", q);
   error("infer2: c= ", c, "\n    c1= ", c1, " s= ", &s);
  }
  if(mm) ipp("infer2: success! p= ", p, "\n  q= ", q, "\n   c1= ", c1);
  if(wlot(c1, "infer2", p, q)) 
  {
   ipp("infer2: discovered false! p= ", p, " q= ", q);
   //ii = 0;
   return 1; // false discovered!
  }
 } // for(i)
 if(mm) ipp("-infer2 p= ", p, " q= ", q, " ilot= ", ilot);
 //ii = 0;
 return 0;
} // end infer2  

   elem ordinf(elem y, elem z)
{    // a < b && c < d && b = c -> a < d (and more) 
 elem f, m1, a=zel, b=zel, m2, c=zel, d=zel, r=zel; headp h; elemp q; headp g; elemp w;
 if(mel(y, &h, &q) == pfs && mel(z, &g, &w) == pfs && h->l == 3 && g->l == 3)
 {
  if(q[0] == zlt || q[0] == zle)
  {
   m1 = q[0]; 
   a = q[1]; b = q[2];
  }
  else if(q[0] == zgt || q[0] == zge)
       {
        m1 = (q[0] == zgt? zlt : zle);
        a = q[2]; b = q[1];
       };

  if(w[0] == zlt || w[0] == zle)
  {
   m2 = w[0]; 
   c = w[1]; d = w[2];
  }
  else if(w[0] == zgt || w[0] == zge)
       {
        m2 = (w[0] == zgt? zlt : zle);
        c = w[2]; d = w[1];
       };

  if(b != zel && b == c)   // a < b, c < d, b = c -> a < d
  {
   f = (m1 == m2? m1 : zlt);
   r = trm2(f, a, d, zbool);
   ipp("ordinf: success1! y= ", y, " z= ", z, "\n  r= ", r);
  }

  else if(a != zel && a == d)  // a < b, c < d, a = d -> c < b
  {
   f = (m1 == m2? m1 : zlt);
   r = trm2(f, c, b, zbool);
   ipp("ordinf: success2! y= ", y, " z= ", z, "\n  r= ", r);
  }
 } // if(mel)
 return r;
} // end ordinf

   void corol(elem f, elem a, elem b, elem c)  // a&b -> c
{                                              // corollary
 // if f is a theorem, a&b -> c is an inference rule
 // and f is an instance(s)of a, and b1 = rep(b, s) is a theorem,
 // then r = rep(c, s) is a theorem
 if(9) ipp("+corol f= ", f, " a= ", a);
 elem b1, r = zel; sbst s;
 if(!s.inst(f, a))
 {
  if(mm) ipp("corol: not inst(f, a),  f= ", f, " a= ", a); goto ret;
 }
 b1 = s.rep(b);
 if(eqvl(b1) != ztrue)
 {
  if(mm) ipp("corol: eqvl(b1) != ztrue,  b= ", b, " b1= ", b1); goto ret;
 }
 r = s.rep(c, 2); wlot(r, "corol");
 ret: if(9) ipp("-corol c= ", c, " r= ", r);
} // end corol 

   void qparm(elem e,  elem p)  // quasiparamodulation
{
 if(mm) ipp("+qparm e= ", e, " p= ", p);
 sbst s; elem p1, p2, a, b, t; elemp w;
 if(!iseq(e, &w)) error("qparm: not equality e= ", e);
 a = w[1]; b = w[2];
 if(!ElemInTerm(a, p))
 {
  if(mm) ipp("-qparm: a is not in p, a= ", a, " p= ", p);
  return;
 } 
 s.adds(a, b);
 if(mm) ipp("qparm a= ", a, " b= ", b, " p= ", p);
 p1 = s.rep(p, COMMON_T);  // 1: a may be not a var or con
 if(mm) ipp("qparm p= ", p, " p1= ", p1, " s= ", &s);
 t = typ(p1);
 if(t == zel) error("qparm: wrong type of p1, e= ", e, " p= ", p, " p1= ", p1);
 if(p1 != p)
 {
  ipp("qparm: Success1! p = ", p, " a= ", a, " b= ", b); 
  wlot(p1, "qparm", e, p);
 }
 /*s.size = 0;
 s.adds(b, a);
 p2 = s.rep(p, 2);
 if(p2 != p)
 {
  ipp("qparm: Success2! p = ", p, " b= ", b, " a= ", a);  
  wlot(p2, "qparm2");
 } */
 if(mm) ipp("-qparm p= ", p, " p1= ", p1); //, " p2= ", p2); 
} // end qparm;

/*   int wlot(elem z, char* place, elem a, elem b)
{
 elem t; headp g; elemp w; int i, r=0; int static count = 0;
 if(mm) ipp("+wlot z= ", z, " place= ", place);
 error("wlot in clos.cpp, z= ", z);
 if(z == zfalse) 
 {
  if(ilot < llot-1)
  {
   lot[++ilot] = z; 
   lot1[ilot] = place;
   lot2[ilot] = a;
   lot3[ilot] = b;
   prlot("wlot: writing false!");
  }
  r = 1; goto ret;
 }
 if(z == ztrue)
 {
  ipp("wlot: z = true, no writing!");
  goto ret;
 }
 if(ilot == llot-1) goto ret; // lot is full!
 if(smel(z, &g, &w)){ ipp("wlot: simple z= ", z); goto ret; }
 //else
 {
  t = g->tp;   // was typ(z);  4/25/01
  if(t == zel)
  {
   error("wlot: wrong type(zel) z= ", z, " t= ", t, place );
   goto ret;
  }
  if(t == TCurrentTerm)
  {
   ipp("wlot: recusive call in typ, z= ", z);
   goto ret;
  } // if(t == TCurrentTerm)
 } // else
 if(isrt(z, zconj, &w))
 {
  if(wlot(w[1], "wlot &1", z)) { r = 1; goto ret; }
  if(wlot(w[2], "wlot &2", z)) { r = 1; goto ret; }
 }
 //if(isrt(z, zall, &w)) { r = wlot(w[2], "wlot A[d, p]"); goto ret; }
 for(i= 0; i<=ilot; i++)
  if(lot[i] == z) goto ret;
 if(isrt(z, zconj)) goto ret;
 lot[++ilot] = z;                  // error: 5/2/97: not freezd w[1],w[2]
 if(9) ipp("wlot: writing z= ", z, " ilot= ", ilot);
 //if(Att(z) == 9847 && ilot == 20 && ++count == 15) error("wlot 9847");
 lot1[ilot] = place;
 lot2[ilot] = a;
 lot3[ilot] = b;
 if(ilot == llot - 1)
 {
  //--ilot;
  //prlot("wlot: lot is full! ");
  ipp("wlot: lot is full, ilot= ", ilot);
  goto ret;
 }
 //infer1(z);
 ret: if(mm) ipp("-wlot z= ", z, " ilot= ", ilot);
 return r;
} // end wlot
*/
  int inlot(elem z)    // z in lot
{
 if(mm) ipp("+inlot z= ", z);
 int r = 1;
 int save = prcause;
 for(int i = 0; i <= ilot; i++)
 {
  //if(Att(z) == 9693 && isrt(lot[i], zall) ) prcause = 1; 
  if(req(z, lot[i])) goto ret;
 }
 r = 0;
 ret: //prcause = save;
     if(mm) ipp("-inlot z= ", z, " r= ", r);
 return r;
} // end inlot

  elem redA(elem d, elem p) // reduce A[d, p] 
{      // check for consistency of d!!!
 if(mm) ipp("+redA: d= ", d, " p= ", p);
 elem r = p; headp h; elemp pn; elemp pt; elemp pa; int kax;
 if(mel(d, &h) != aterm) error("redA: not def d= ", d, " p= ", p);
 if(h->t == False) 
 {
  ipp("redA: d is false, d= ", d, " p= ", p);
  r = ztrue;
 }
 else wdal(d);
 /*int k = ldev(d, &pn, &pt, &pa, &kax);
 if(k <= 0) error("redA: wrong d= ", d, " p= ", p);
 if(k == 1 && kax == 0)
 {
  elem x1 = vard(d, 1);
  elem t1= pt[0];
  elem d1 = cred(t1);
  if(ldev(d1)) r = rep(p, x1, stm(d1) );
 }  */
 if(mm) ipp("-redA: r= ", r);
 return r;
} // end redA
   
  void plot(char* s)
{
 *pfhis << "\nplot: "<<s<<" ilot= "<<ilot;
 for(int i = 0; i <= ilot; i++)
 {
  *pfhis << "\n"<<i; 
  prp(") ", lot[i], pfhis);
  *pfhis << ' '<<lot1[i];
  prp(" ", lot2[i], pfhis);
  prp(" ", lot3[i], pfhis);
 } // for(int i) 
} // end plot
