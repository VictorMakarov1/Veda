// #include "achs.h"
 class Lot
{
 elem tot[maxvars];                      //  maxvars = 100 = current llot;
 public:   
 elem goal;
 ats itot;                              // last occupied in ar;
 ats itot0;                             // value of itot when entering wtot;
 ats count;                             // to catch looping;
 Lot(elem z);                           // main constructor;    //  maxvars = 100 = current llot;
	    // Lot::Lot(elem z){ itot = -1; count = -1; goal = z; }               // main constructor;
 void Lot::addtpthms(elem x0);          // add type theorems : x in t=typ(x), t in t1=typ(t), t1 in t2:=typ(t1), ...
                                        // until trivt(ti): ti = set,any,REL,SEQ or i >= 10   
	bool Lot::innerinf(elem z);            // for each x = son of z add(wtot) all thmbase_thms(x);// from den or tabt;// ?z?
  // return true iff z is in lot or goal is in tot; TEMP !!! a simple version(not considering sons(x) is implemented !!!
 bool Lot::wtotpat1(elem g, elem x, elem t, elem f); // pattern1: g(x,t) & f(t, &t1) -> g(x,t1);
       //  x in t & t <: t1 -> x in t1;  x <: t & t <: t1 -> x <: t1; // r == g(x,t1) = goal & goal in tot; 						                                                                               
 att wrtot(elem z);                     // just write z in tot: r==1: already in tot, r==2: z==goal, r==0: not in tot;
 bool wtot(elem x, char* place);        // write(wrtot) z into tot; then wrtot defrp(z); // defrp(z: x in P[t]) = x <: t; 
 bool add(elem x);                      // write x into tot, if repetition, ipp; also check x=P[] or x=P1[];
 void lclos();                          // light closure of ar, using linf;
 bool intot(elem x);                       // checking if x is in ar;
 bool in2(elem f, elem x, elem y);      // checking if f(x,y) is in ar; // not using trm2;
 void print(char* s= "", elem x= zel);  // print ar and possibly x;
}; // end class Lot;
bool tplclos(elem x, elem goal);        // typ(x)=L, goal: x in elg;
bool In(elem x, elem t);               // checking if x in t;
bool separ(elem z);                     // // z is separation: begin("text");
void wlot(elem z, char* place);         // write into lot; true pconj: wlot again; 
bool wrlot(elem z, bool p=true);        // r==true: already in lot; // p=false: don't check fnt2(z,zconj,&z1,&z2)
void inflot(elem z,int i);              // add to lot z x lot(0..i);
bool closlot(elem z=zel);               // closure of lot, if found z, break;
bool inftabt(elem z, elem goal);        // p: look also for scope = zel;
void infvith(elem z); 
bool invith(elem z);                    // z is an instance of a very imp. theoerem
bool invith2(elem f, elem a, elem b); 
void wlotinf(elem z, int it=10);        // write into lot and infer1(z);  not used.
bool addlot(elem z,elem goal);          // add to lot linf(lot, thms(z)); new version 7.17,20
bool addlot1(elem z,elem goal);         // add to lot linf(lot, z);  7.17,20                                                                                      
bool addtabt(elem z=zel);               // add to lot inftabt(lot(i)) for each i; if found y, break;
elem linf(elem y, elem z, bool mayvar=false); // light infer
elem Adpzind(elem x, elem y);            // x: A[d,P] & y: z in d -> Rep(d,P,z);
void infer(elem Q1, elem Q2);
bool instA(elem z, elem d, elem P, elem Q);      // s.instance(Q,P) & s.ismds(d);
bool inlot(elem z, bool p=true);      // z in lot: p==true: also look for A[d,P], such that z is an instance of P;
// inline Truth1(elem z){ return Truth(z) || inlot(z,false); }
bool intabt(elem z, elem T);         // z is an instance of a global or T-local theorem in tabt ( T :: ...) 
bool inlot2(elem f, elem a, elem b); // f(a,b) in lot
elem inlot2a(elem f, elem a);        // find b, such that f(a,b) in lot, return b;
bool inlot2a2(elem f,elem a, elem f1, elem* b, elem* c);  // find in lot: f(a,f1(*b,*c));
bool inlot2eq(elem a, elem b);       // look in lot for a=b, b=a, a==b, b==a;
elem inlot2eq1(elem a);              // find in lot for a=r, r=a, r==a, a==r;  see inlot2a;
bool inloti(elem z, sbst* s);        // find in lot z, using s->instance(lot[i], z);
void prlot(char* s=" ");             // printing lot
void wrdep(elem x, elem x1, elem x2=ztrue);              // x depends on x1,x2 
bool axat(elem d, headp hd, elemp qd, elem x1); // x1 is an axiom of abterm d;
// bool istr(elem z);                   // int flag_inlot=1, int flag_eqvl=1);
bool istr00(elem z, char* place);    // the simplest istr: check only h->t and inlot(z): recursion if z is conjunction;
bool istr0(elem z, elem d=zel);      // look for possible theorem z (or A[z,d]) in lot and thmbase for T=z,z=T,T->z,...
bool istrbyis(elem z,headp h,elemp q);  // is true (by,byeq,is,add)(q1,...,q_hl-1);
bool notempty(elem z);               // looking for the theorem "z ~= {}",using instance, body in tt;
bool istr2eq(elem a, elem b);        // looking for theorems a=b,a==b,b=a,b==a; 
bool istr2inst(elem f, elem a, elem b);  // looking for the theorem "f(a,b)",using instance, body in tt;
bool istr2thms(elem f, elem a, elem b);  // looking for the theorem "f(a,b)",using thmbase and instance; // ~ intabt;
bool istr3(elem x, elem f1, elem f2, elemp Q, elemp M); // x f1 (Q f2 M) is true; body in tt.cpp
bool istrdt(elem z);                 // check if z is true, using den and tabt via thmbase and instance
bool istrlh(elem z, elem hint);      // hint is a theorem of the form h1 & ... & hk -> c; use lot and hint to prove z
bool simp2b(elem f, elem a, elem b); // look in lot for f(x,y); r = istr2eq(a,x) && istr2eq(b,y);
inline bool fnt1(elem z, elem f, elem a){ headp h; elemp q; return  mel(z,&h,&q)==pfs && h->l==2 && q[0]==f && q[1]==a; }
inline bool inim(elem z, elem t){ headp h; elemp q; return mel(z,&h,&q)==pfs && fnt1(t,zim,q[0]); } // z:f(x,...), t:im(f);
bool fit(elem z, elem t, bool hard = true);             // "z in t" is true;
bool Fit(elemp q,elemp w, int k); // fit(q[i], w[i])
bool indep(elem z, int k);           // k: beginning in dep for z;
int cldep(elem goal, int a);         // closure of dep, r = # of unproved formulas
void prdep(elem goal=zel);           // printing dep;
elem typlot(elem z, bool p=false);   // if "z in t" in lot, return t; p:true: look only for function types
elem axin(elem a, elem d, int i);    // a is di in ti; return ti;
elem simd(elem d);                   // d is {x; x in t}, return t (or zel)
elem simr(elem z);                   // simplification (via reductions)
bool fnexp(elem* ay);
elem explot(elem z);
elem expand(elem z);
// elem tt::expand(elem z);
elem expvith(elem z);
elem wrar(elem x);
void prar(); 
int lind(elem z,elem Q=zel, int* adisp=0); // z is a Dterm;  r: size of model; also checks that Q is a very simple method and computes D, Dd, dispDd;
bool vsmethod(elem D, elem Q, int* adisp); // Q is a very simple method in z, if true then *adisp = place of Q in model;
bool ismd(elem z, elemp q, int n, sbst** as=0); // z: d,d&&P, d&&d1, z&&P,z&&d; model M = q[1], ..., q[n]; q points to M-1;
// bool Ismd(elem z, int nq);              // z: d,d&&P, d&&d1, z&&P,z&&d;          
// bool thax(elem z, elem* T);
elem typeax(elem a, elem d, att i);        // if a is i-th type axiom of d then return the type from a; else zel; 
bool equal(elem z, elem z1);               // r = istr2(zeq,z,z1) || istr2(zeq,z1,z);
// inline bool Dterm(elem z){ headp h; elemp q; int m = mel(z,&h,&q); return m==abt || m==pfs && q[0]==zdconj; } 
elemp firsecargthms(elem f, elem z, int n); // n: place of z in z f x or x f z in lth-theorems(z), zel: means end;
elemp impequthms(elem z);                   // Look for thms z->P,z==P,P==z and write P into ar;
bool lookthms(elem z, bool (*cond)(elem T, elem par1, elem par2), elem par1, elem par2);
            // a general function: look in thms for T such that cond(T,par1)
bool cond1(elem T, elem goal, elem par2);   // goal is an instance of T; or if T is A[d, P], then goal is an instance of P;
elem expdcl(elem z);  // expand(wrar) z  using an equiv-theorem T in thms(f)(z = f(...) or z = x in f(...);
bool istrin1(elem z, elem t);   // look for T: z in t in thms(z);
bool istrin(elem z, elem t);   // look for T: z' in t in thms(t);
// void chilot(char* s, int newilot);        // change ilot: ilot = newilot; moved to lib.h
// void chiMod(char* s, int newiMod);        // change iMod: iMod = newiMod;