// rep.h 03/27/01 05/09/01
elem Rep(elem z, elem d, elem md);   // simp z(md), Host(z) = d, md in d; md means "model of d"
elem Rep1(elem z, elem d, elem md);
// elem Repd(elem z, elem d, elem md);
elem metaterm(elem z, elemp w, int k);
elem component(elem z, elem d, elem md);
// elem dott(elem z, elem f, elem d=zel);
// elem PrefRule(elem z);
elem redimp(elem z,elem P,elem Q,elem R);                               // reduction of (P->Q)(R);
// bool isst(elem z, elem* red=0, elem* main=0);      // is special term: All(x,P)(y), .... (a=b)(y)
elem redsb1(elem K, elem a, elem b);
elem redsb(elem z, headp h, elemp q);              // reduction of z = Sb(K, a, b);
elem redst(elem z);               // reduction of special terms: All(x,P)(z), .... (a=b)(z)
void chabt(elem z, elem y0, elem y);  // y0: old abterm, y: new abterm, z: raw subterm of y
void prstdd(char* s);
elem fsegh(head h, att n=emptt);             // writes using wrtt the h.l segment from st to current tabt;
elem fsegh1(elem z, headp h, att n=emptt);   // same as fsegh but also uses findtabt to merge equal terms;
elem repq(elem z, elem d, elemp q, int nq);  // replace in z all d.i on q[i], q points to model-1;
elem repqmd(elem z, elemp arm);              // repq multiple d, using D, Dd; arm point to mode1-1;
elem Repq(elem z, elem D, elemp q, int nq);  // q points to model-1;
elem rep2(elem z, elem x, elem y);           // replace in z all x on y;
elem repd(elem z, elem d, elem md);          // replace in z all d.i on md[i]; // ats k=0: rep2i replaces all occurrences
elem rep2i(elem z,elem x,elem y, elem vars_are_cons=zel1, elem dpat=zel0, ats k=0);   
                                             // z, by x=y; r; Find k-th instance V(s) of x in z
elem rep2i1(elem z, elem , elem b);          //  simpler rep2i, using finst  // and replace V in z on  s(y);
// elem repm(elem z,elem M,elem T, bool p=false); // replace in z every method m of T on m.z, p=true, replace abtbvars;
// elem stripm(elem z,elem M);                  // replace in z x.M on x; (inverse to repm) moved to trash.txt;
// elem repbv(elem z);     // replace bvar z using stqab (and s);
// elem repb(elem z);      //, sbst* s=0);     // replace in z every bvar x on repbv(x) using stqab (and s);
elem reparg(elem z, headp h, elemp q, int p, elem y, qab* W); // replace p-th arg in z with y; n: new address
                                                             // for qabterms;
