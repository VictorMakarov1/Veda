#include "lib.h"   // 4/14/00 5/19/00 10/11/00 01/10/01 02/23/01
#include "myio.h"  // 03/30/01 04/12/01 04/16/01
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h" 
#include "typ.h" 
#include "etc.h"
#include "term.h"
#include "elem.h"
#include "err.h"
#include "assert.h"
#define lb 60
extern int aa,bb,hhh,mm,rrr; 
extern ats asop, avar, adcol,amnbool,amnint,amnint1,aexc1,aexc2,anot1,arestr,adconj,aanyd,acrlf;
extern elem zcol,zfinabterm,zfinset,zpostfix;   // colon ":"
extern char* countts;
extern char farb[lfarb];
extern char source[80];
extern achs* pntu;

int lvin = 64;
int ivin;
elemp vin;          // rr: visible names
ofstream* pfden;

int iarel = -1;     // index of arel,arscope: last occupied;
// #define maxarel 100;  // currently in Lib.h, move to dd ???
elem arel[maxarel]; // for use ONLY in fdent(ats a), same for iarel,arscope !!!
elem arscope[maxarel];

int wrts(char*s);
void wvin(elem z, int k = 0, ats id = -1);         // writing z to vin (visible names), s: scope;

 void wrarelscope(elem z, elem s)
{
 if(++iarel >= maxarel) error("wrarelscope: overflow of arel, z= ", z," iarel= ",iarel, " maxarel= ",maxarel);
 arel[iarel] = z; arscope[iarel] = s;
 if(mm) ipp("+-wrarelscope: z= ", z, " s= ", s, " iarel= ", iarel);
} // void wrrelscope(elem z, elem s)

   int tt::firstad(ats a)
{
 int r = -1;
 if(a < 0 || a>its) error("firstad: a<0 or a > its, a= ", a, " its= ", its);
 if(a > lastaden)
	 error("firstad: a > lastaden, mym= ", mym, " a= ", a, " lastaden= ", lastaden, " its= ", its);
 r = aden[a];
 return r;
} // int tt::firstad(ats a)

   elem tt::uniqden(ats a, elem s, ats named)  // named used in mzcn for to resolve overloading;
{                                                       // if(named != -2) find first appropriate name;
 elem r= zel;  int count = 0; edenp q;elem z; headp h; elemp w; 
 int i = firstad(a);
 if(i == -1) error("tt::uniqden: not in den, s= ", s, " a= ", vts(a));
 while(i<=iden)
 {
  q = den[i];
  if(q->a != a) break;
  if(s == zel1 || q->scope == s)
  {
   z = q->inn; r = z;
   if(z.i == 1)
   {
    z.i = 0; 
    if(mel(z,&h,&w) == pfs && Dcl(w[0]) && h->l > 2 && h->name == named)
    {
     if(9) ipp("uniqden: a in named declaration, a= ", vts(a), " named= ", vts(named));
     if(ats(w[1].ad) != a) error("tt::uniqden: wrong named declaration z= ", z, " a= ", a, " atsname in dcl= ", w[1].ad);
     r = q->inn; goto ret;
    } // if(mel(z,&h,&q) ...
   } // if(z.i == 1)
   ++count; 
  } // if(q.scope == s)
  ++i;
 } // while(i<=iden)
 // r = (count==1); 
 if(count > 1){ ipp("uniqden: multiple names in den: mym= ", mym, " name= ", vts(a)); r = zel; }
 ret: return r;
} // elem tt::uniqden(ats a, elem s, ...)

  elem Fden1s(char* b, elem s, ats named)  // total search b in den_0, den_eul[0], ....
{                                          // used only in Mzcn;
 elem r; att i,m;
 if(bb || rrr) ipp("+Fden1s: s= ", s, " b= ", b, " named= ", named);
	r = clad[0]->fden1s(b,s,named);
	if(r != zel) goto ret;
	for(i=0; i<=ieul; i++)
	{
	 m = eul[i]; if(rrr) ipp("Fdent1s:for: ieul= ", ieul, " i= ", i, " m= ", m); 
		if(m==0) continue;
		r = clad[m]->fden1s(b,s,named);
	 if(r != zel) goto ret;
	} // for(int i=0)
	ret: if(bb || rrr) ipp("-Fden1s b= ", b, " r= ", r);
 return r;
} // end elem Fden1s(char* b, ...)

  elem tt::fden1s(char* b, elem s, ats named)   // named used in Mzcn, for resolving overloading
{                                               // used only in Fden1s(twice);
 elem r=zel; ats a;
	if(bb || rrr) ipp("+fden1s: s= ", s, " b= ", b, " named= ", named);
 a = findts(b);
 if(a < 0){ ipp("tt::fden1s: a < 0, s= ", s, " b= ", b); goto ret; }
	if(a > lastaden){ ipp("tt::fden1s: a > lastaden, b= ", b, " a= ", a, " lastaden= ", lastaden); goto ret; }
 r = fdent1(a,s,named);
 // if(r == zel) error("fden1s: not in den, scope= ", s, " b= ", b);
 ret: if(bb || rrr) ipp("-fden1s b= ", b, " r= ", r);
 return r;
} // end fden1s(char* b, elem s) 	

   void tt::fdentuns(ats a)     // find a in unsorted den, write .inn, .scope to arel, arscope
{                               // if Abterm(scope) ???
 int i; elem s; headp h;                      
 if(bb || rrr) ipp("+tt::fdentuns: a= ", vts(a), " iden= ", iden, " mym= ", mym);
 for(i=iden; i >= 0; i--)
  if(den[i]->a == a && Abterm(s = den[i]->scope, &h)) wrarelscope(den[i]->inn, s);// yes, =, not == !!!
 if(bb || rrr)  ipp("-fdeneuns iarel= ", iarel);
} // end fdentuns(ats)
  
   elem tt::fdenuns(ats a, elem s)     // find a in unsorted den, return den[i].inn, else zel;  
{
 int i; elem r=zel;
 if(bb || rrr) ipp("+fdenuns  s= ", s, " a= ", a, " iden= ", iden);
 for(i=iden; i >= 0; i--)
  if(den[i]->a == a && (s == den[i]->scope || s==zel1)){ r = den[i]->inn; break; } 
 if(bb || rrr)  ipp("-fdenuns r= ", r);
 return r;
} // end fdenuns(ats, elem s)

   elem tt::fdenabtdc(ats a)     // find abt term named a, in den, return den[i].inn, else zel;  
{
 int i,m,k; elem r=zel; eden z; headp h; elemp q;
 if(bb || rrr) ipp("+tt::fdenabtdc a= ", vts(a), " iden= ", iden);
 if(prognum < numsortden) //  && mym==eul[ieul])    // unsorted den;
 for(i=iden; i >= 0; i--)
 {
  z = *den[i];
  if(z.a==a)
  {
   m = mel(z.inn, &h, &q);
   if(bb) ipp("tt::fdenabtdc(unsorted): found z.inn= ", z.inn, " q[0]= ", q[0], " zdconj= ", zdconj, " mel= ", m);
   if(m==abt || m==pfs && (q[0]==zdconj || strcmp(svel(q[0]), "&&")==0 || q[0]==zdot)){ r = z.inn; goto ret; }  // 8.7.22
  } // if(z.a==a)      // || q[0].m==ubs && int(q[0].ad) == adconj
 } // for(i)
 else
 {
  k = firstad(a);            // sorted den;
  for(i=k; i<=iden; i++)
  {
   z = *den[i];
   if(z.a != a) goto ret;
   m = mel(z.inn, &h, &q);
   if(bb) ipp("tt::fdenabtdc(sorted): found z.inn= ", z.inn, " m= ", m);
   if(m==abt || m==pfs && q[0]==zdconj){ r = z.inn; goto ret; }
  } // for(i) 
 } // else
 ret: if(bb || rrr)  ipp("-tt::fdenabtdc r= ", r, " mym= ", mym);
 return r;
} // end tt::fdenabtdc(ats)

   elem fdenabtdc(ats a) // find abt or &&(dc) term named a, in all dens, return den[i].inn, else zel;
{
 elem r = zel; int i,m;
 if(bb) ipp("+fdenabtdc: a= ", vts(a));
 for(i=0; i<=ieul; i++)
 {
  m = eul[i];       // current den is 
  r = clad[m]->fdenabtdc(a);
  if(r != zel) break;
 } // for(i)
 if(bb) ipp("-fdenabtdc: a= ", vts(a), " r= ", r);
 return r;
} // elem fdenabtdc(ats a)

  elem fdent(ats a)   // total search: at first at current(possibly unsorted den), then in eul[1], eul[2], ...
{                     // writing (if den[i]->a ==a) .inn and .scope to arel and arscope;
 int i,m; elem r = zel;
 if(mm) ipp("+fdent:  a= ", vts(a), " a= ", a, " ieul= ", ieul);
 iarel = -1;
 if(prognum < numsortden) ptt->fdentuns(a); else ptt->fdent(a); // so i=1 in for(i=1; ...)
 for(i=1; i <= ieul; i++)   // was i=0; eul[0] is current module, fdent1 will be called twice ???
 {
  m = eul[i];
  clad[m]->fdent(a);
 } // for(i)
 if(iarel==0) r = arel[0];
 if(mm) ipp("-fdent: ieul= ", ieul, " iarel= ", iarel, " arel= ", arel, iarel);
 return r;
} // end void fdent(ats)
                                              
   void tt::fdent(ats a)  // total search: writing (if den[i]->a ==a) .inn and .scope to arel and arscope;
{
 if(mm) ipp("+tt::fdent1: a= ", vts(a), " iarel= ", iarel, " mym= ", mym);
 int i; edenp q;     
 // if(a < 0) error("fden1a: a<0, a= ", a);      // replace on firstad
 if(a > lastaden) goto ret;                      // because ts is common; name a for a tt can be > current lastaden;
 // i = aden[a];
 i = firstad(a);
 if(i < 0) { ipp("tt::fdent: not in den, name= ",  vts(a), " mym= ", mym); goto ret; } // ??? unsorted ???
 while (i <= iden)
 {
  q = den[i];
  if(q->a != a) break;
  wrarelscope(q->inn, q->scope);
  ++i;
 } // while (i <= iden)
 ret: if(mm) ipp("-tt::fdent a= ", a, " iarel= ", iarel);
} // end void tt::fdent(ats a) 

   elem tt::fden(char* s)             // search s in den, return .inn; use only for unique s;
{
 elem r = zel; int i; ats a; edenp q;
 if(mm) ipp("+tt::fden: s= ", " mym= ", mym);     
 a = findts(s);
 if(a==emptyts) error("tt::fden: s is not in ts, s= ", s);
 if(a > lastaden){ ipp("tt::fden: s is not in current den, s= ", s, " a= ", a); goto ret; }       
 i = firstad(a);
 if(i < 0) { ipp("tt::fden: not in den, name= ",  vts(a), " mym= ", mym); goto ret; } // ??? unsorted ???
 q = den[i];
 if(q->a != a) error("tt::fden: wrong firstad, s= ", s, " a= ", a, " i= ", i);
 if(i < iden && den[i+1]->a == a) error("tt::fden: name s is not unique, s= ", s, " a= ", a, " i= ", i);
 r = q->inn;
 ret: if(mm) ipp("-tt::fdent s= ", s, " r= ", r);
      return r;
} // end void tt::fden(char* s) 


  elem fdent1t(ats a, elem s)   // total search: at first at current(unsorted den), then in eul[1], eul[2], ...
{                              // s==zel1: all scopes
 if(mm) ipp("+fdent1t: s= ", s, " a= ", vts(a), " a= ", a, " ieul= ", ieul);
 int i,m; elem r = prognum < numsortden? ptt->fdenuns(a,s) : ptt->fdent1(a,s); // so i=1 in for(i=1; ...)
 if(r == zel)
  for(i=1; i <= ieul; i++)   // was i=0; eul[0] is current module, fdent1 will be called twice ???
  {
   m = eul[i];
   r = clad[m]->fdent1(a,s);
   if(r != zel) break;
  } // for(i)
  if(mm) ipp("-fdent1: r= ", r);
  return r;
} // end elem fdent1t(ats, elem s)
                                         // if(s==zel1): if unique(a) then dont check scope and s1 = scope(a);
   elem tt::fdent1(ats a, elem s, ats named, elemp s1)  // find unique(or basic) a in den[i] scope=s, return  den[i].inn;
{                                    // a must be unique in the scope s, if not, return zel;
 if(mm) ipp("+tt::fdent1:  s= ", s, " a= ", a, " named= ", named, " mym= ", mym);
 if(mm)
 mm=mm;
 elem r = zel; int i; edenp q; 
 // if(a < 0) error("fden1a: a<0, a= ", a);      // replace on firstad
 // if(a > lastaden) goto ret;
 // i = aden[a];
 i = firstad(a);
 if(i < 0) 
  { ipp("tt::fdent1: not in den, scope= ", s, " name= ",  vts(a), " mym= ", mym); goto ret;} // ??? unsorted ???
 while (i <= iden)
 {
  q = den[i];
  if(q->a != a) break;
  if(s == zel1)   // zel1: if unique(a) then dont check scope ???
  {
   if(i==iden || den[i+1]->a != a)
   { 
    r = q->inn; 
    if(s1) *s1 = q->scope; 
    break; 
   } // if(s == zel1) // checking that a is unique in den;
  } // if(s == zel1)
  if(q->scope == s)
  {
   if((r= uniqden(a,s,named)) != zel) break;   // eqel(q.scope, s)
   if(basic_name(q->inn, s)){ r = q->inn; break; }      // q->inn is a basic name
  } // if(q->scope == s) // inline bool basic_name(elem x, elem s){ return htbv(x)==s; }
  ++i;
 } // while (i <= iden)
 ret: if(mm) ipp("-tt::fdent1 a= ", a, " s= ", s, " r= ", r);
 return r;
} // end fdent1(ats a, elem s) 

  ats Fdenaz(ats a, elem z)                             //  search for a, z(inn) in sorted den_z.m;
{
 ats r; tt* h;
 if(mm) ipp("+Fdenaz: z= ", z, " a= ", z);
 if(z.m >= maxmod) errorelm("Fdenaz: z.m >= maxmod, z= ", z, " a= ", a);
 h = clad[z.m];
 if(h==0) errorelm("Fdenaz: h==0, z= ", z, " a= ", a);
 r = h->fdenaz(a, z);
 if(mm) ipp("-Fdenaz: z= ", z, " a= ", a, " r= ", r);
 return r;
}

  ats tt::fdenaz(ats a, elem z)  // a must be in den!, returns index of z in in den;
{                                 // 5.12.20: not always: bvars from newly created Qterms (All,...);
 ats i,k, r = -1; char* s = vts(a);
 if(mm) ipp("+tt::fdenaz: z= ", z, " a= ", s);
 if(prognum <= numsortden) 
	 error("fden: prognum <= numsortden, z= ", z, " prognum= ", prognum, " numsortden= ", numsortden);
 k = firstad(a);
 if(k == -1){ ipp("fdenaz: wrong k= -1, z= ", z, " a= ", a); goto ret; }
 for(i=k; i<=iden && den[i]->a == a; i++)
  if(den[i]->inn == z){ r = i; goto ret; }
 ipp("fdenaz: possiblle error: no z in den, z= ", z, " a= ", a, " k= ", k); // was ipp 2.16.20;
 ret: if(mm) ipp("-tt:fdenaz: z= ", z, " a= ", vts(a), " r= ", r);
      if(ww) checktabt("tt::fdenaz z= ", z);
      return r;  
} // end fdenaz

 ats tt::fdenz(elem z)
 {
  if(mm) ipp("+tt::fdenz: z= ", z);
  ats a = avel(z);      //  a == -1 for unnamed composite terms, but fdenaz will catch it !!!
  ats r = fdenaz(a,z);
  if(r < 0 || r >= lden) ipp("tt::fsenz: wrong r, z= ", z, " r= ", r); // for newly created bvars r = -1;
  if(mm) ipp("-tt::fdenaz: z= ", z, " r= ", r);
  return r; 
 } // end  ats tt::fdenz(elem z)

/*  elem tt::host(elem z) // search in den for z.d = d, return d (or zel)
{
 elem r=zel;
 if(pp) ipp("+tt::host z= ", z);
 for(int i=0; i<=iden; i++)
 //  if(den[i].inn == z && den[i].d != zel) { r = den[i].d; goto ret; } ???????
 ret: if(pp) ipp("-tt::host z= ", z, " r= ", r);
      return r;
} */ // end tt::host
 
   int tt::mltn(ats x)
{
 if(pp)cout<<"\nmltn:"<<x;
 assert(x >= 0 && x <= its);
 int i = aden[x];
 return i<iden && den[i+1]->a == x;
} // end mltn

   int comparden(const void* p1, const void* p2) 
{
 edenp P1 = *(edenp*)p1; edenp P2 = *(edenp*)p2; // P1 =  *p1
 char* s1 = vts(P1->a); 
 char* s2 = vts(P2->a);  
 int p = strcmp(s1, s2);
 if(p) return p;
 int k1 = (P1->scope).ord();
 int k2 = (P2->scope).ord();
 return k1-k2;
}  // end comparden

    void tt::sortden()
{
 if(pp)cout<<"sortden"<<iden;
 int i,n,n1; // elem x; // char c;
 // eden* dena = (eden*) &farb[0];   // mylloc?
 // if((iden+1) * sizeof(eden) >= lfarb)
 //  error("sortden  big iden, lfarb ", iden, lfarb);
 for(i=0; i<laden; i++) aden[i] = emptyaden;
 qsort(&den[0],iden+1,sizeof(void*),comparden);
 n=0;
 for(i=0; i <= iden; i++)
 {
  n1 = n;
  //n=name(den[i].a);
  n = den[i]->a;
  if(n != n1) aden[n] = i;
 } // for(i)
 uden();
 time_sortden = myclock(" sortden finished ");
}  // end sortden

   void tt::wrden(ats a, elem x, elem s)
{
 assert(a >= 0 && a <= its); char* sa = vts(a); ats a1,i; edenp hz;
 if(bb) ipp("+wrden a= ", a, " sa= ", sa);
 if(bb) ippelm("+wrden x= ", x, " s= ", s);
 if(++iden >= lden){--iden; error("wrden: overflow, iden= ",iden, " name a= ", a); } // --iden: for pden!
 den[iden] = (edenp)fylloc("wrden",sizeof(eden) + iszthmb*sizeof(elem));  // iszthb: initial size of theorem block;
 if(++countts[a] > 1)
 {
  for(i=0; i<iden; i++)
  {
   hz = den[i];
   if(hz->a==a && hz->scope==s)
   {
    if(overname(x) && overname(hz->inn)) goto M2;
    errmsg("wrden: double name with same scope s= ", s, " name= ", vts(a));
    pntu->prach("wrden");
   } // if(z.a==a ...)
  } // for(i)
 } // if(++countts[a] > 1)
 if(idubs(x, &a1))     // a := x;
 {
  if(a1 < 0 && a1 > its) error("wrden: wrong a1= ", a1, " a= ", a); 
  // for(i=0; i<=iden; i++) if(den[i]->a==a1) goto M1;
  x = fdent1t(a1, zel1);
  if(x != zel) goto M2;
  pntu -> prach("\n\nwrden: not in den");
  error("wrden: not in den a1= ", a1, "string a1= ", vts(a1));
  // M1: x = den[i]->inn;
  // if(x.m == ident || x.m == ubs) error("wrden: wrong x= ", x, " a= ", vts(a));
 } //  if(idubs(x, &a1))
 M2: den[iden]->a   = a;
 den[iden]->inn = x;
 den[iden]->scope = s;
 den[iden]->lth = iszthmb;   // iszthb = 4;
 for(i=0; i<iszthmb; i++) den[iden]->son[i] = zel;
 if(bb) ipp("-wrden iden= ", iden);
} // end wrden

// inline bool badthm(elem T){ headp h; return badm(T.m) || mel(T,&h) != pfs || h->tp != zbool || h->t != truth; } 

   void tt::wrthmden(elem T, ats id)        // write theorem T into den[id].son;
{
 edenp hp, hp1; elemp q,q1;  ats i, bsz, bsz2=0;
 if(mm) ipp("+wrthmden: T= ", T, " id= ", id); 
 if(badthm(T)) errorelm("wrthmden: wrong T= ", T, " id= ", id); 
 if(id < 0 || id > iden) error("wrthmden: wrong id, id= ", id);
 hp = den[id];
 q = &(hp->son[0]);            // q points to 
 bsz = hp->lth;                // hpl: number of  theorems;
 for(i=0; i < bsz && q[i] != zel; i++);                         // i: free place for writing T;
 if(i < bsz)
 {
  q[i] = T;   
  if(mm) ipp("wrthmden: i < bsz: den[id].i := T, T= ", T, " id= ", id, " i= ", i);
  goto ret;
 } // if(i < bsz)
 if(mm) ipp("wrthmden, l-block filled completely, T= ", T,  " a= ", vts(hp->a), " id= ", id, " bsz= ", bsz);
 bsz2 = bsz*2;  // if hpl == e.g., 1024, then hpl2 can be maxszthmb: later !!! done for maxszthmtabt !
 if(bsz2 > maxszthmbden) // currently, maxszthmbden = 32768, still can be increased to 65365
  error("wrthmden: bsz2 > maxszthmbden, T= ", T, " bsz2= ", bsz2, " maxszthmbden= ", maxszthmbden);
 hp1 = (edenp) fylloc("wrthmden",sizeof(eden) + bsz2 * sizeof(elem));
 q1 = &(hp1->son[0]);
 *hp1 = *hp;         // copy main part
 hp1->lth = bsz2;    // new lth = hpl * 2;
 for(i=0; i < bsz; i++) q1[i] = q[i];   // copied theorems from hp;
 q1[bsz] = T; 
 for(i=bsz+1; i < bsz2; i++) q1[i] = zel;
 den[id] = hp1;
 free(hp);
 ret: if(mm) ipp("-wrthmden T= ", T, " id= ", id, " bsz= ", bsz);
      if(ww) checktabt("-wrthmden T= ", T);
} // end tt::wrthmden

   void tt::uden()
{
 if(pp) cout<<"\nuden lltt"<<lltt<<' '<<itt; char y[80];
 // int k,j; // elemp pe;  char c; char* s; // headp p;
 strcpy(y, source); strcat(y, ".den");
 ofstream f(y,ios::out);
 if(!f)cerr<<"\ncannot open file "<<y,exit(1);
 pfden = &f;
 pden(pfden);
} // end uden

   void tt::pden(ofstream* f)       // write den to file source.den
{
 int i,j,m,kson,z=0; char* s; ats a,a1;  elem inn, sc, x; edenp hp; headp h; elemp q;
 // ofts(f, tabs, its);
 *pfhis << "\n+pden iden= " << iden;  cout << "\n+pden iden= " << iden;
 if(f==0) error("pden: f=0");
 *f<<"\n"<<mytime()<<"\niden= "<<iden<<" root= "<<root; 
 // else cout<<"\niden= "<<iden<<" root= "<<root;
 for(i=0; i<=iden; i++)
 {
  hp = den[i];
  a = hp->a; // inn = den[i].inn; sc = den[i].scope;
  if(a < 0 || a > its)
  {
   cout << "\npden: wrong ats a= " << a << " i= "<<i;
   *pfhis << "\npden: wrong ats a= " << a << " i= "<<i;
   ptt->futt(source);  ptt->fprp(source);
   exit1();
  } // if(a < 0 || a > its)
  s = vts(a); 
  inn = hp->inn; 
  sc = hp->scope; 
  kson = hp->lth;
  if(kson > 1000) *pfhis << "\npden: bsz > 1000, a= " << s << " i(den)= " << i << " bsz= " << kson; 
  *f<<'\n'<<i<<") a= "<<s<<" inn= "; pelm(inn, f);
  *f<<" s= "; 
  if(sc==zel){ *f << "zel"; goto M; }
  if(sc.ad > lltt){ *pfhis<<"pden: wrong sc.ad, i= " << i << " sc.ad= " << sc.ad; *f<<"*****"<<sc.ad; goto M;}
  m = mel(sc,&h,&q);
  if(!comp(m)) error("pden: not composite scope, inn= ", inn, " sc= ", sc, " a= ", vts(a));
  a1 = h->name;
  if(a1 != noname){ *f << vts(a1); goto M; }        // a1 == -1: non-named scope; 
  if(m==pfs && (q[0]==zProof || q[0]==zEqProof))
  {
   if(q[0]==zProof) *f << "Proof ";
   if(q[0]==zEqProof) *f << "EqProof ";
   prp(q[1],f); goto M;
  } // if(m==pfs)
  if(m==abt){ *f << "#"<<sc.ad; goto M; }
  pelmprp(sc, f); 
  // } // if(f);
  /*else
  {
   cout<<'\n'<<i<<") a= "<<s<<" inn= "; pelm(inn);
   cout<<" s= "; pelm(sc, f);
  }
  if(i%18==0 && i!=0 && f==0) 
  {
	  cout<<"\ntt::pden: ---------------------------";
	  cin>>c; if(c=='*')return; 
  } */
  M: *f<<" lth= "<<kson<<": "; 
  for(j=0; j < kson; j++)
  {
   x = hp->son[j];
   if(x == zel) break;
   if(j%10 == 0) *f << "\n";
   prp(" ",x,f);
  } // for(j)
 } // for(i);
 *f<<"\n\n aden:\n "; // else cout<<"\naden ";
 for(i=0; i<laden; i++)
  if(aden[i] != emptyaden)
  {
   *f<<i<<':'<<aden[i]<<' ';
   // else cout<<i<<':'<<aden[i]<<' ';
    if((z+=intlen(i)+intlen(aden[i])+2)>lb)
     {z=0; if(f)*f<<'\n'; else cout<<'\n';}
  } // end for, if(aden ...)
 *pfhis << "\nfinished pden root="<<root<<" its="<<its
	<<" itt="<<itt<<" iden="<<iden;
 f->close();
} // end pden

           // elem tt::fden1d(ats a, elemp az)    // find in den METHOD a (mel(den[i].s) = abt);
/*  elem host(elem z)   // bvar(z) : htbv(z), comp(z): no name: check for dot-term: error? zel? , named(a): fden1d(a);
{          // inline bool abtbvar(elem z, elem* d){ *d = htbv(z); return mel(*d) == abt; }
 elem y, r = zel; headp h; elemp q; int m; ats a;
 if(mm) ipp("+host: z= ", z);
	if(abtbvar(z, &r)) goto ret;
 if(r != zel && isrt(r,zexistx))                            // because artbvar changed r in any case;
 {
  if(mm) ipp("host: existx: z= ", z);
  if(!boundvar(z,&a)) error("host: not bound var z= ", z);
  r = clad[z.m]->fden1d(a, &y); 
  if(y != z) error("host: existx: y != z, z= ", z, " y= ", y);
  goto ret;
 } // if(r != zel && isrt(r,zexistx))
 m = mel(z, &h, &q);
 if(comp(m))
 {
  a = h->name; 
  if(a != noname){ r =  clad[z.m]->fden1d(a, &y); goto ret; }
  if(q[0] != zdot || h->l != 3)
   error("host: not dot term z= ", z);
  r = host(q[2]);
 } //  if(comp(m))
 ret: if(mm) ipp("-host: z= ", z, " r= ", r);
 return r;
} // elem host(elem z)
*/

/*  elem fden1d(ats a,elemp az)   // find in ALL dens METHOD a (mel(den[i].s) = abt);
{
 if(bb) ipp("+fden1d:  a= ", vts(a));
 int i,m; elem r = zel;
 for(i=0; i <= ieul; i++)     
 {
  m = eul[i];
  r = clad[m]->fden1d(a, az);
  if(r != zel) break;
 } // for(i)
 if(bb) ipp("-fdent1d: r= ", r);
 return r;
} // end elem fden1d(ats)

   elem tt::fden1d(ats a, elemp az)    // find in den METHOD a (mel(den[i].s) = abt);
{                            // a must be unique in the scope s
 elem r = zel; int i; edenp q;
 if(a < 0) error("fden1d: wrong a, a<0 or a > lastaden, a= ", a, " lastaden= ", lastaden);
 if(bb) ipp("+fden1d a= ", a, " vts(a)= ", vts(a), " mym= ", mym);
 i = aden[a];
 if(i < 0){ if(bb) ipp("fden1d: not in den, name= ", vts(a), " mym= ", mym); goto ret; }
 while (i <= iden)
 {
  q = den[i];
  if(q->a != a) break;
  if(mel(q->scope) == abt) 
  { 
   if(i<iden && den[i+1]->a == a) error("tt::fden1d: not unique, a= ", a, " vts(a)= ", vts(a)); 
   r = q->scope ;   *az = q->inn;   break; 
  }  // if(mel(q.scope) == abt)
 ++i;
 } // while (i <= iden)
 ret: if(bb) ipp("-fden1a a= ", a, " r= ", r);
 return r;
} // end fden1d(ats a) 
*/

  void visndot(ats a, elem s)   // total search for all names with scope s in eul[0], eul[1], ...
{
 if(mm) ipp("+visndot: scope= ", s, " a= ", vts(a));
 int i,m; 
 ivin = -1;
 for(i=0; i <= ieul; i++)
 {
  m = eul[i];
  clad[m]->visndot(a,s);
 } // for(i)
 if(mm){ ipp("-visndot: s= ", s, " a= ", vts(a)); pvin(); }
} // end visndot(ats, elem s)

   void tt::visndot(ats a, elem s)    // search for all names with scope s in tt::den;
{
 if(mm) ipp("+tt::visndot:  s= ", s, " a= ", vts(a));
 int i; eden q;
 i = firstad(a);
 if(i < 0) goto ret;
 while (i <= iden)
 {
  q = *den[i];
  if(q.a != a) break;
  if(q.scope == s) wvin(q.inn,lvin-1);
  ++i;
 } // while (i < laden)
 ret: if(mm) ipp("-tt::visndot s= ", s, " a= ", vts(a), " ivin= ", ivin);
} // end tt::visndot(ats a, elem s) 

   elem tt::scope(ats a, elem z)   // find den[i].a = a && den[i].inn==z, return den[i].scope;
{
 elem r=zel1; int i;
 if(mm&&dd) ipp("+tt::scope z= ", z,  " a= ", vts(a));
 if(a < -1 || a > lastaden) 
   error("tt::scope: wrong a, z= ", z, " a= ", a, " lastaden= ", lastaden);
 if(a == -1){ ipp("tt::scope: a == -1, z= ", z); goto ret; }
 i = aden[a];
 if(i < 0){ ipp("scope: name is not in den, name= ", vts(a), " mym= ", mym); goto ret; }
 while(i<=iden && den[i]->a == a)
 {
  if(den[i]->inn == z) goto M;
  i++;
 } // while
 ipp("tt::scope: inn not in den, z= ", z, " a= ", vts(a), " i= ", aden[a]); //  was error, 2023.03.29 (new term, not in den);
 goto ret;
 M: r = den[i]->scope;
 ret: if(mm&&dd ) ipp("-tt::scope z= ", z, "\nr= ", r, " a= ", a);
 return r;  
} // end tt::scope

   elem scope(elem z)
{
 static elem r = zel1; ats a; tt* pnt; int hl,b,i,j,k,k0,k1, m = z.m, m0, m1; headp h; elemp q;
 elem T,d,y;  elem S[maxvars]; static int depth=0; // zel1: because zel is the main scope;
 static int istlbv; static elem stlbv[sizestscp];      // sizestscp = 31; stlbv: stack for local bvterms; 
 if(++depth == 1) istlbv = -1;
 if(mm&&dd) ipp("+scope z= ", z, " istlbv= ", istlbv);
 if(m==ints || m==strng || z==zopsqbr || z==zel){ r = zel; goto ret; }  // ??? zopsqbr
 if(m >= maxmod)
   errorelm("scope: wrong z.m >= maxmod, z= ", z);  
 pnt = clad[m];
 if(pnt==0) errorelm("scope: wrong z, clad[z.m]=0, z= ", z);
 m = mel(z,&h,&q); 
 switch(m)
 {
  case bvar: d = htbv(z);      // d = z; d.i = 0; htbv(host for bvar): former qtbvar
             if(inList(d,stlbv,istlbv)) goto ret;  // if(inList(z)): r = zel1; local bvars be skipped
             assert(boundvar(z, &a));
             goto M;
             // if(q[0] == zexistx){ assert(boundvar(z, &a)); goto M; }
             // r = d; // if(badel(r)) error("scope:bvar: badel(r), z= ", z);
             // goto ret;
  case var:  if(!freevar(z, &a)) error("scope: not free var, z= ", z);
             M: r = pnt->scope(a, z);  // if(badel(r)) error("scope:M: badel(r), z= ", z, " a= ", vts(a));
             goto ret;  // free var can be in a local scope;
  case con:  if((k=z.i) == 0) error("scope: con: z.i==0, z= ", z);
             if(!dclname(z,&h,&q,&a) && z != zcrlf) error("scope: con: not dclname(z), z= ", z);
             if(z==zcrlf) a = acrlf;  goto M;    // dcl[{], but dclname({) == false; 
  case pfs:  // below are composite terms;
  case abt:  hl = h->l; a = h->name;              // z = Gr(K), m = pfs, b=0; hl=2;
  if(a != noname) goto M;                         // #define noname -1
  if(q[0]==zdot && hl==3)
  { 
   r = scope(q[2]);  // if(badel(r)) error("scope:zdot: badel(r), z= ", z);
   goto ret; 
  } //  if(q[0]==zdot && hl==3)
  if(h->adt)
  {
   if(hl != 2) error("scope: adt: hl != 2: z= ", z);
   r = scope(q[1]); // if(badel(r)) error("scope:adt: badel(r), z= ", z);
   goto ret;
  } // if(h->adt) 
  b = kmain(h);
  if(b>0) wrlist(z,stlbv,&istlbv,sizestscp);
  if(hl-b >= maxvars) error("scope: overflow of S, z= ", z, " hl= ", hl, " b= ", b);
  if(b!=0) ++b;
  j = -1; T = pntu->ndcol();               // 3. in scope;
  for(i=b; i<hl; i++)
  {
   y = scope(q[i]);        
   if(y==T)          // if(T::[ ... z ...]) and z contains a subterm of scope T,then r=T;
   { 
    r = T;           // if(badel(r)) error("scope:for:T: badel(r), z= ", z);
    goto ret; 
   } // if(y==T)        
   if(y != zel1) wrlist(y,S,&j,maxvars);  // local bvars skipped;
  } // for(i=b)
  if(j < 0) error("scope: j < 0, z= ", z, " j= ", j, " b= ", b);;
  bsort(S,j+1);
  k0 = Lev(S[0]);
  if(j>=1)
  {
   if(S[0]==S[1]){ r = S[0]; goto ret; }
   k1 = Lev(S[1]);
   if(k0==k1) 
   {
    ipp("scope: k0==k1, z= ", z, "\nS[0]= ", S[0], " S[1]= ", S[1], " k0= ", k0, " k1= ", k1);
    m0 = hgt(S[0]); m1 = hgt(S[1]);
    if(m0==m1) error("scope: m0==m1, z= ", z, "\nS[0]= ", S[0], " S[1]= ", S[1], " m0= ", m0, " m1= ", m1);
    if(m0 < m1) S[0] = S[1];
   } // if(k0==k1)
  } // if(j>=1)
  r = S[0];  if(dterm(r,&d)) r = d; goto ret;
  default: error("scope: wrong m, z= ", z, " m= ", m);
 } // end switch(m) 
 ret: if(--depth < 0) error("scope: wrong depth, z= ", z, " depth= ", depth);
   if(mm&&dd) ipp("-scope z= ", z, " r= ", r); 
   // if(badel(r)) error("scope: badel(r), z= ", z);
 return r;                         // r == zel1: 
} // elem scope

   elem scopeden(elem z)
{
 elem r = zel1; ats a; tt* pnt; int hl,k, m = z.m; headp h; elemp q;
 elem d;  // zel1: because zel is the main scope;
 if(z.ad==stad2)
 mm=mm;
 if(mm&&dd) ipp("+scopeden z= ", z, " zel1= ", zel1);
 if(m==ints || m==strng || z==zopsqbr || z==zel){ r = zel; goto ret; }  // ??? zopsqbr
 if(m >= maxmod)
 { 
  ippelm("scopeden: wrong z.m >= maxmod, z= ", z, " mm= ", mm);         // was errorelm 
  goto ret; 
 } // if(m >= maxmod) 
 pnt = clad[m];
 if(pnt==0) 
    errorelm("scopeden: wrong z, clad[z.m]=0, z= ", z);
 m = mel(z,&h,&q); 
 switch(m)
 {
  case bvar: d = htbv(z);      // d = z; d.i = 0; htbv(host for bvar): former qtbvar
             assert(boundvar(z, &a));
             goto M;
  case var:  if(!freevar(z, &a)) error("scopeden: not free var, z= ", z);
             M: r = pnt->scope(a, z);        // ??? REWORK !!! 2023.03.26;
             goto ret;  // free var can be in a local scope;
  case con:  if((k=z.i) == 0) error("scopeden: con: z.i==0, z= ", z);
  if(!dclname(z,&h,&q,&a) && z != zcrlf){ ipp("scopeden: con: not dclname(z), z= ", z); goto ret; } // REWORK! 
             if(z==zcrlf) a = acrlf;  goto M;    // dcl[{], but dclname({) == false;                // empty place in tabt
  case pfs:  // below are composite terms;
  case abt:  hl = h->l; a = h->name;              // z = Gr(K), m = pfs, b=0; hl=2;
  if(a != noname) goto M;                         // #define noname -1
  goto ret;                                       // r=zel1: unnamed comp. terms
  /* if(q[0]==zdot && hl==3)
  { 
   r = scope(q[2]);  // if(badel(r)) error("scope:zdot: badel(r), z= ", z);
   goto ret; 
  } //  if(q[0]==zdot && hl==3)
  if(h->adt)
  {
   if(hl != 2) error("scope: adt: hl != 2: z= ", z);
   r = scope(q[1]); // if(badel(r)) error("scope:adt: badel(r), z= ", z);
   goto ret;
  } // if(h->adt) 
  */
  default: error("scopeden: wrong m, z= ", z, " m= ", m);
 } // end switch(m) 
 ret:  if(mm&&dd) ipp("-scopeden z= ", z, " r= ", r); 
      return r;         
} // elem scopeden

   bool tt::gtrm(att i, elem T, bool p)         // if(p): global theorem (scope = zel) or T-local(scope = T);
{
 headp h = tabt[i]; bool r; elem s; char* s1;
 elem a1,b, Q = elm(mym,0,i);
 ats a = h->name;
 r = (Truth(h) && a != noname && (h->son[0] != zimp || goodimp(Q,&a1,&b)) );   // h->t == truth
 if(r)
 {
  s = scope(a,Q); s1 = vts(a);  
  if(strcmp(s1,"Axrefl")==0 || strcmp(s1,"TreflIn")==0) r = false;  // wlotinf was looping;
  else r = (s==T || p&&(s==zel));         // above comment:  see ineq !!!
  if(hhh && r) ipp("\n\ntt::gtrm: found true Q= ", Q, " s= ", s, " T= ", T, " i= ", i, " r= ", r); 
 } // if(r)
 return r;
} // end tt::gtrm

  void Mzcn()          // make z constants
{                            //"overflow its" means here that 
 ats adpsetset = wrts("dpsetset");   // necessary because # is overloaded;
 ats affn1 = wrts("ffn1");
 ats affn2 = wrts("ffn2");
 ats asetdif = wrts("setdif");
 ipp("+Mzcn ieul= ", ieul, "eul[0]= ", eul[0] );      //the name is not in snam.ved
 zvariable  = Fden1s("variable",zel);
 zbvar  = Fden1s("bvar",zel);
 // zasop = fden1a(asop, zel); ippelm("mscn: zasop= ", zasop);
 // zvar = fden1a(avar, zel);
 zbool = Fden1s("bool",zel);
 ztrue = Fden1s("true",zel);
 zfalse= Fden1s("false",zel);
 zif   = Fden1s("if",zel);
 // zif2  = Fden1s("if2"),zel);
 zeq   = Fden1s("=", zel);
 zequ  = Fden1s("==", zel);
 zneq  = Fden1s("~=", zel);
 znequ = Fden1s("~==", zel);
 znot  = Fden1s("~", zel, anot1);   // ~ is also binary
 zdis  = Fden1s("or",zel);
 zrestr = Fden1s("|",zel, arestr);
 zxor  = Fden1s("xor",zel);
 zxor3  = Fden1s("xor3",zel);
 zimp  = Fden1s("->", zel);
 zrimp  = Fden1s("<-", zel);
 zconj = Fden1s("&", zel); 
 zeps  = Fden1s("eps", zel);
 zall  = Fden1s("All",zel);
 zexist = Fden1s("Exist", zel); // Exist(x, P)
 zexist1 = Fden1s("Exist1", zel); 
 zexistx = Fden1s("Existx", zel);
 zexist1x = Fden1s("Exist1x", zel); 
 zmnbool = Fden1s("-", zel, amnbool);
 zin   = Fden1s("in", zel);           // in
 znin   = Fden1s("nin", zel);         // not in
 zincl  = Fden1s("<:",zel);           // inclusion
 zun  = Fden1s("\\/",zel);            // union of 2 sets \\ is \, like \n is newline (escape sequences)
 zinter  = Fden1s("/\\",zel);         // intersection
 zdp = Fden1s("#",zel,adpsetset);     // direct product;
 zP    = Fden1s("P[", zel);
 zP1   = Fden1s("P1[", zel);
 zemp = Fden1s("{}",zel);
 zany  = Fden1s("any", zel);
 zset  = Fden1s("set", zel);
 zfinset = Fden1s("finset",zel);
 zdisjoint = Fden1s("disjoint",zel);
 zempseq = Fden1s("[]",zel);
 zA = Fden1s("A[",zel);
 zE = Fden1s("E[", zel); // E[d.P]
 zEx = Fden1s("Ex[", zel); // Ex[d.P]
 zE1 = Fden1s("E1[", zel); // E1[d,P]
 zF = Fden1s("F[", zel); // F[d,f]
 zR = Fden1s("R[", zel); // R[d,f]
 zU = Fden1s("U[", zel); // U[d,w]
 zS = Fden1s("S[", zel); // S[d,w]
 zint  = Fden1s("int", zel);
 znat  = Fden1s("nat", zel);
 znat1  = Fden1s("nat1", zel);
 znatm  = Fden1s("natm", zel);
 zplint = Fden1s("+", zel, aplint);
 zmltint = Fden1s("*", zel, amltint);
 zmnint = Fden1s("-", zel, amnint);
 zmnint1 = Fden1s("-", zel, amnint1);     // minus unary
 zseg  = Fden1s("..", zel);
 zNotAxiom = Fden1s("NotAxiom", zel);
 zabterm = Fden1s("abterm", zel);
 zProof = Fden1s("Proof", zel);
 zEqProof = Fden1s("EqProof", zel);
 zis  = Fden1s("is", zel);
 zby  = Fden1s("by", zel);
 zbyeq = Fden1s("byeq", zel);
 zbyimp = Fden1s("byimp", zel);
 zassume  = Fden1s("assume", zel);
 // zsuppose  = Fden1s("suppose", zel);
 // zfrom  = Fden1s("from", zel);
 zwith  = Fden1s("with", zel);
 zcrlf = Fden1s("{", zel);
 zTaut = Fden1s("Taut", zel);
 zStaut = Fden1s("Staut", zel);
 zInstance = Fden1s("Instance", zel);
 zWitness    = Fden1s("Witness", zel);
 zrecdef    = Fden1s("recdef", zel);
 zexc  = Fden1s("!", zel, aexc2);   // binary "!"
// zexc1  = Fden1s("!", zel, aexc1);   // unary "!"
// zdexc  = Fden1s("!!", zel);
 zAxab  = Fden1s("Axab", zel);
 zBred  = Fden1s("Bred", zel);
 zRed  = Fden1s("Red", zel);
 zsb  = Fden1s("Sb", zel);
 zanyd = Fden1s("^", zel, aanyd);         // anyd := dcl[^,abterm,any];
 zdot = Fden1s(".",zel); 
 zat = Fden1s("@",zel);
 zNI = Fden1s("NI",zel); 
 zsetdif = Fden1s("--",zel, asetdif);
 zadd = Fden1s("add",zel);       // add used only in EqProof
 zcol = Fden1s(":",zel);
 zdcol = Fden1s("::",zel);
 zdconj = Fden1s("&&",zel);
 zfn = Fden1s("fn",zel);
 zFn = Fden1s("Fn",zel);
 zifn = Fden1s("ifn",zel);
 zsfn = Fden1s("sfn",zel);
 zbfn = Fden1s("bfn",zel);
 zafn = Fden1s("afn",zel);
 zFN = Fden1s("FN",zel);
 zAFN = Fden1s("AFN",zel);
 zFFN = Fden1s("FFN",zel);
 zffn = Fden1s("ffn",zel);
 zFNtypes = Fden1s("FNtypes",zel);
 zfntypes = Fden1s("fntypes",zel);    
 zrel  = Fden1s("rel",zel);
 zREL  = Fden1s("REL",zel);
 zseq  = Fden1s("seq",zel);
 zSEQ  = Fden1s("SEQ",zel);
 zseq1  = Fden1s("seq1",zel);
 zSEQ1  = Fden1s("SEQ1",zel);
 zlast  = Fden1s("last",zel);
 zdom = Fden1s("dom",zel);
 zim = Fden1s("im",zel);
 zvith = Fden1s("vith",zel);    // vith : very imp.theorems: vith := [FN <: REL, ... ];
 zbegin = Fden1s("begin",zel);
 ztypeaxiom = Fden1s("typeaxiom",zel);
 zpostfix = Fden1s("postfix",zel);
 zdebug = Fden1s("debug",zel);
 zfinabterm = Fden1s("finabterm",zel);
 zgroup = Fden1s("group", zel);
 zdbsl = Fden1s("\\\\", zel);
 zelg = zgroup; zelg.i = 1;
 zAssocinve = Fden1s("Associnve", zel);
 zRep = Fden1s("Rep",zel);
 zfnsetbool = Fden1s("fnsetbool",zel);
} // end Mzcn

/*   elem fdent(char* s) //total search of s in all dens
{
 int a; elem r = zel; tt* p;
 if(pp) ipp("+fdent s= ", s);
 for(int i=0; i<=iclad; i++)
 {
  p = clad[i]; assert(p);
  a = findts(s);
  if(a != emptyts)
  {
   r = p->fden(a, "fdent");
   if(r != zel) goto ret;
  } // if(a)
 } // for(i)
 ret: if(pp) ipp("-fdent r= ", r);
      return r;
} // end fdent
           
   int fdent(elem z, elem d) //total search of z in all dens with .d == d
{
 int a; int r; tt* p;
 if(pp) ipp("+fdent z= ", z, " d= ", d);
 assert(d != zel);
 for(int i=0; i<=iclad; i++)
 {
  p = clad[i]; assert(p);
  r = p->host(z) == d; //p->fden(z, d);
  if(r) goto ret;
 } // for(i)
 r = 0;
 ret: if(pp) ipp("-fdent z= ", z, " r= ", r);
      return r;
} // end fdent

   elem tt::ffom(ats x, elem* d)  // find field or method (of d)
{
 if(pp) ipp("+ffom x= ", vts(x));
 int k, A = aden[x]; elem r = zel; eden y;
 if(A < 0) error("ffom: wrong x= ", x, " A= ", A);
 for(k = A; k <= iden && den[k].a == x; k++)
 {
  y = den[k]; r = y.inn;
  if(varc(r)) { *d = devc(r); break; }
  else if(y.d != zel) { *d = y.d; break; }
 } // for k
 if(pp) ipp("-ffom r= ", r);
 return r;
} // end tt::ffom

   elem tffom(char* s, elem* d)   // total search of field or method
{
 if(pp) ipp("+tffom s= ", s);
 elem r=zel; int i; tt* p; ats x;
 for(i=0; i<=iclad; i++)
 {
  p = clad[i];
  x = p->find(s);
  if(x == emptyts) continue;
  r = p->ffom(x, d);
  if(r != zel) break;
 } // for i
 if(pp) ipp("-tffom r= ", r, " d= ", *d);
 return r;
} // end tffom

  elem tt::Dcol(headp h)  // if h points to d::f, returns d else zel
{
 int a; elem d = zel; 
 if(h->tel == pfs && Ubs(h->son[0], &a) && a == adcol)
 {
  elem x = h->son[1]; elem f = h->son[2];
  if(!Ident(x, &a)) error("Dcol: not ident d in z = d::f, d= ", x);
  d = fdent(vts(a));
  if(!isdf(d)) error("Dcol: not definition d in z = d::f, d= ", x, "\n    f= ", f);
 } // if(h->tel ... && a == adcol)
 return d;
} // end Dcol

   elem defval(elem z)
{
 if(z.m != strng) error("defval: wrong z= ", z);
 elem d = fdent(strval(z)); 
 if(!isdf(d)) error("typdot: wrong d1, z= ", z, " d= ", d);
 return d;
} */ // end defval

// end den
