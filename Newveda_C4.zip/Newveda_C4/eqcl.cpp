// eqcl.cpp 12/07/00 02/14/01 04/26/01 05/17/01

#include "lib.h" 
#include "achs.h" 
#include "sbs.h"
#include "tt.h"
#include "adl.h"  
#include "typ.h"     
#include "elem.h"
#include "rep.h"
#include "lot.h"
#include "eqcl.h"
#include "term.h"
#include "cr.h"
#include "assert.h"
#include "err.h"

extern int aa, mm, kk, oo, qq, yy, fff, ilot, MaxCountInsert, prcause; 
extern att llot;
extern elemp lot;
// extern int  istparsimp;
// extern elem stparsimp[lst]; // stack of parameters: to avoid recursive looping 
// extern int isteq;
extern elem steq[lsteq];
int isteq;

     elem eqvl(elem x, int p, sbst* s)  // p=1: find an instance of x 
{                         
 if(mm && kk) ipp("+eqvl x= ", x, " p= ", p); 
 int i; elem r;
 //elem r = eqvlot(x);
 for(i=0; i<=ieul; i++)
 {
  if(mm && kk) ipp("eqvl: module i= ", i);
  r = clad[eul[i]]->eqvl(x,p,s);
  if(r != x) goto ret;
 }
 ret: if(mm && kk) ipp("-eqvl x= ", x, "\n    r= ", r);
      return r;
} // end eqvl
  
   elem esolv(elem d, elem p)  // solve E[d, p]: find an instance of p
{
 if(fff) ipp("+esolv: d= ", d, " p= ", p);
 elem f, d1=zel, r = zel; sbst s;
 f = eqvl(p, 1, &s);
 if(f != p)
 {
  if(fff) ipp("esolv: f= ", f, " s= ", &s);
  // x = s.mod1(d, &t);
  error("esolv: commented devc");
  // d1 = devc(s.body[0]);
  if(d1 == d) r = ztrue;
  else error("esolv: d != d1, d= ", d);
 } // if(f != p)
 if(fff) ipp("-esolv: p= ", p, " r= ", r);
 return r;
} // end esolv

/*   elem eqcl(elem x, bool smel_exit)  // equality closure of x: to steq!
{ 
 if(fff) ipp("+eqcl x= ", x, " ilot= ", ilot, " ist= ", ist);
 int i, j, k, save; 
 elem sbt[lst1];
 //if(smel_exit != false) error("eqcl: smel_exit= ", smel_exit);
 //fff = (Att(x) == 9836); kk = fff;
 if(ist < -1 || ist >= lst1) error("+ecql overflow of  ist= ", ist);
 if(smel(x))
 {
  prlot("eqcl: smel(x)");
  error("eqcl: smel(x), x= ", x);
 }
 save = ist;  
 k = subt(x);  // subterms of x in st, k is the beginning in st
 for(i=k, j=0; i<=ist; i++, j++) sbt[j] = st[i];
 k = ist - k + 1;  // k == number of subterms 
 //if() ipps("eqcl: subterms: ", &st[k+1], ist-k);
 if(fff) ipp("eqcl: subterms: ", &sbt[0], k);
 elem r = eqclot(x, &sbt[0], k, smel_exit);
 if(smel_exit && r != zel && smel(r)) goto ret; //??? 02/14/01
 for(i=0; i<=ieul; i++)                        // #define iclad ieul
 {
  r = clad[eul[i]]->eqcl(x, &sbt[0], k, smel_exit); // k+1 : because except of x 
  if(smel_exit && r != zel && smel(r)) goto ret;
 }
 r = zel;
 ret: ist = save;
      if(r != zel && smel(r)) ipp("-eqcl: discovered simple r= ", r, " x= ", x);
      //if() ipp("-eqcl x= ", x, " r= ", r, " isteq= ", isteq);
      if(fff) prsteq("-eqcl x=", x, save);
      if(ist < -1 || ist >= lst) error("-eqcl overflow of ist= ", ist);
      return r;
} // end eqcl
*/  
   elem eqvlot(elem z) // eqvl for lot
{
 if(fff) ipp("+eqvlot z= ", z);
 int i; elem y, r= z; elemp w; // a = w[1], b = w[2]
 for(i = 0; i <= ilot; i++)
 {
  y = lot[i];
  //if(i == 33) yy = 1; else yy = 0;
  if(req(z, y)) { r = ztrue; break; }
  if(iseq(y, &w) && req(z, w[1]) ) { r = w[2]; break; }
 } // for(i)
 if(r != z) ipp("-eqvlot: Success! z= ", z, "\n   r= ", r, "i= ", i);
 if(fff) ipp("-eqvlot z= ", z, " r= ", r);
 return r;
} // end eqvlot

   elem eqclot(elem z, elem sbt[], int ksbt, bool smel_exit) // equality closure by lot
{         // ksbt is the number of elems in sbt
 if(fff) ipp("+eqclot z= ", z);
 int i; sbst s; elem y, r;  elemp w; // a = w[1], b = w[2]
 for(i = 0; i <= ilot; i++)
 {
  y = lot[i];
  //if() ipp("eqclot: before instance: z= ", z, " y= ", y);
  if(req(z, y))   // was if(s.instance(z, y)
  { 
   if(mm && kk) ipp("eqclot1: discovered true, z= ", z, " ilot= ", ilot);
   r = ztrue; 
   if(smel_exit) goto ret; 
  }

  r = eqcs(z, y, ztrue, sbt, ksbt, smel_exit);
  
  if(r != zel && smel(r))
  {
   ipp("eqclot2 z= ", z, " discovered  simple r= ", r);
   if(smel_exit) goto ret;
  } // if(r)

  if(iseq(y, &w))
  {
   r = eqcs(z, w[1], w[2], sbt, ksbt, smel_exit);
   if(r != zel && smel(r))
   {
    ipp("eqclot z= ", z, " discovered  simple r= ", r);
    if(smel_exit) goto ret;
   } // if(r)
  } // if(iseq)
 } // for(i)
 r = zel;
 ret: if(fff) ipp("-eqclot z= ", z, " r= ", r);
 return r;
} // end eqclot

   elem eqcs(elem z, elem a, elem b, elem sbt[], int ksbt, bool smel_exit)
{       // ksbt is the number of elems in sbt
 if(mm) ipp("+eqcs z= ", z, " a= ", a, " b= ", b);
 sbst s; elem b1, y, r=zel;  elemp q; int i;
 if(iseq(z, &q) && q[1] == a && q[2] == b)
 {
  ipp("eqcs: the same z= ", z, " a= ", a, " b= ", b);
  goto ret;
 }
 for(i=0; i<ksbt; i++)
 {
  y = sbt[i];
  //if(!s.instance(y, a)) continue; 4/16/00
  if(!req(y, a)) continue;
  ipp("eqcs:SUCCESS: z= ", z, " a= ", a, " b= ", b);
  b1 = s.rep(b, "eqcs");
  r = rep2(z, y, b1);  // 1: b1 may be composite! was FOR_CRED 
  ipp("eqcs: a new equal term z= ", z, " r= ", r);
  if(smel(r)) 
  {
   ipp("eqcs: z= ", z, " discovered smel r= ", r);
   if(smel_exit) goto ret;
  }  
  wrsteq(r); 
  if(typ(r) == zel) error("eqcs: wrong type of r= ", r);
 } // for(i)
 ret: if(mm) ipp("-eqcs z= ", z, " r= ", r, " isteq= ", isteq);
      return r;
} // end eqcs

    elem tt::eqcl1(elem z, bool smel_exit, int save)
{   // all terms equal to z, are in steq(not using subterm equality)
       return zel; 
} // end tt::eqcl1 

/*   elem tt::eqcl(elem z, elem sbt[], int ksbt, bool smel_exit) // equality closure
{            // all terms equal to z, are in steq
 if(fff) ipp("+tt::eqcl z= ", z, " smel_exit= ", (int)smel_exit );
 if(fff) ipp("+tt::eqcl sbt= ", sbt, ksbt);
 //isteq = -1; 
 int i, j, save; elem y, r = zel;
 r = eqcl1(z, smel_exit);    // all terms - patternly equal to z, are in steq
 //if(smel_exit && r != zel && smel(r)) goto ret;
 //for(i=0; i <=  isteq; i++) if(wlot(steq[i])) return 1;  // false!!!
 for(i=0; i < ksbt; i++)
 {
  save = isteq;
  y = sbt[i];
  if(smel(y)) error("tt::eqcl: simle y, z= ", z, " y= ", y);
  if(fff) ipp("tt::eqcl: will be writing terms equal to y= ", y, " isteq= ", isteq);
  r = eqcl1(y, false, save);   // all terms - patternly equal to y, are in steq
  if(fff) ipp("tt::eqcl: finished writing terms equal to y= ", y, " isteq= ", isteq);
  //if(smel(r)) goto ret;
  for(j = save + 1; j <= isteq; j++)
  {
   r = rep2(z, y, steq[j]);  //, 2);  // wrong! 4/6/00: r can be in steq already!
   if(r != z) ipp("tt::eqcl: Success! z= ", z, " y= ", y, " r= ", r);
   if(smel(r))
   {
    ipp("tt::eqcl z= ", z, " discovered simple r= ", r, " smel_exit= ", smel_exit);
    if(smel_exit) goto ret;
   }
   if(fff) ipp("tt:eqcl1: changing steq[j]= ", steq[j], "\n   on ", r, " j= ", j);
   if(mel(r) == abt) error("tt::eqcl: def r, z= ", z, "\n   r= ", r); 
   steq[j] = r;
   if(typ(r) != zbool) error("tt::eqcl: wrong type of r= ", r);
  } // for(j)
 } // for(i=0; i < ksbt; i++)
 r = zel;
 ret: if(fff) ipp("-tt::eqcl z= ", z, " r= ", r);
 return r;
} // end tt::eqcl
*/
   void wrsteq(elem z, int save) 
{
 if(mm && kk) ipp("wrsteq z= ", z, " save= ", save);
 if(isteq >= 0 && mel(steq[0]) == abt) error("wrsteq: wrong steq[0]= ", steq[0],
  "\n  z= ", z, " isteq = ", isteq);
 if(mel(z) == abt) error("wrsteq wrong(def) z= ", z);;
 for(int i = save + 1; i <= isteq; i++)
  if(steq[i] == z)
  {
   ipp("wrsteq: already in steq, z= ", z, " isteq= ", isteq);
   return;
  }
 if(++isteq < 0 || isteq >= lsteq) error("wrsteq: overflow isteq= ", isteq);
 steq[isteq] = z;
 if(mm && kk) ipp("-wrsteq z= ", z, " isteq= ", isteq);
} // end wrsteq

   void prsteq(char* s, elem z, int x)
{
 *pfhis << "\n\nPrinting steq s= "<< s; prp(" z= ", z, pfhis);
 *pfhis << " x(save)= " << x << " isteq= " << isteq;
 for(int i=0; i <= isteq; i++)
 {
  *pfhis << "\n" << i; prp(") ", steq[i], pfhis);
 } // for(i)
} // end prsteq


// end eqcl.cpp