#include "lib.h"  //11/18/97 11/09/99 01/25/00
#include "achs.h" 
#include "sbs.h"
//#include "adl.h"
#include "myio.h"
#include "err.h"
//#include "elem.h"
#include "etc.h"
extern int aa, uu, zz,maxl;
extern char dirname[];

char farb[lfarb];
 
    charp rstr(ifstream* f)
{
 char c, s[256], s1[2]; charp p;
 int i,j;
 for(i=0; i<256; i++) // use rstr(f, s, ssize)!!!
 {
  f->read(s1, 1); c = s1[0]; s[i] = c;
  if(c == ' ') ipp("rstr c is blank!, s= ", s);
  if(c == 0) goto M;
 }
 error("rstr: too long string s= ", s);
 M: p = (charp) fylloc("rstr", i+1);
 for(j=0; j<=i; j++) p[j] = s[j];
 //*pfhis<<"\n-rstr(f) p= "<<p;
 return p;
}  // end rstr	

    bool rstr(ifstream* f, char* s, int ssize)
{
 f->getline(s, ssize);
 int k = strlen(s); bool r = false; int static bigcount=0;
 if(aa) cout<<"\n+rstr s= " << s << " ssize= "<< ssize;
 if(zz==6 && pfhis) *pfhis << "\n+rstr s= " << s << "\nssize= "<< ssize<<" k= "<<k;
 if(k >= maxl-10)  // currently(12.07.22) maxl = 160, 150: line size(if font size = 12) on my 11 inches laptop;
 { 
  ipp("rstr: big line: k >= maxl-10,  s=\n", s, "\nk= ", k, " maxl= ", maxl);
  *pfhis << " bigcount= " << ++bigcount; cout << " bigcount= " << bigcount;
 } // if(k >= maxl-10)
 if(k >= ssize-1) error("rstr: line is too big: k >= ssize-1,  s=\n", s, "\nk= ", k, " ssize= ", ssize);
 if(f->eof()) r = true;
 if(aa) cout<<"\n-rstr r= "<<r;
 if(aa && pfhis) *pfhis << "\n-rstr s= " << s << " ssize= "<< ssize;
 return r;
} // end rstr

    bool rstr1(ifstream* f, char* s, int ssize)               // for using in checkcnt;
{
 f->getline(s, ssize);
 int k = strlen(s); bool r = false; int static bigcount=0;
 if(aa) cout<<"\n+rstr s= " << s << " ssize= "<< ssize;
 if(zz==6 && pfhis) *pfhis << "\n+rstr s= " << s << "\nssize= "<< ssize<<" k= "<<k;
 // if(k >= maxl-10)  // currently(12.07.22) maxl = 160, 150: line size(if font size = 12) on my 11 inches laptop;
 if(k >= ssize)
 { 
  ipp("rstr1: big line: k >= maxl-10,  s=\n", s, "\nk= ", k, " maxl= ", maxl);
  *pfhis << " bigcount= " << ++bigcount; cout << " bigcount= " << bigcount;
 } // if(k >= maxl-10)
 if(k >= ssize-1) error("rstr: line is too big: k >= ssize-1,  s=\n", s, "\nk= ", k, " ssize= ", ssize);
 if(f->eof()) r = true;
 if(aa) cout<<"\n-rstr1 r= "<<r;
 if(aa && pfhis) *pfhis << "\n-rstr1 s= " << s << " ssize= "<< ssize;
 return r;
} // end rstr1

    bool rwcm(ifstream* f, char* s, int ssize)   // read without comments
{
 bool peof, p = true; int l; bool r = false; // char c;
 if(aa) ipp("+rwcm ssize= ", ssize);
 while(p)
 {
  peof = rstr(f,s, ssize);  // ) { r = true; goto ret; }
  if(++nstr >= maxnstr) error("rwcm: too big nstr= ", nstr, " maxnstr= ", maxnstr);
  strvalue[nstr] = clon(s);
  if(uu) *pfhis << "\n"<<nstr<<' '<< " s= "<<s;  // <<"\n"<< strvalue[nstr];
  // if(9) *pfhis << "\n"<<nstr<<' '<< " s= "<<s<<"\n"<<strvalue[nstr];
  // if(9) cout << "\n"<<nstr<<' '<< " s= "<<s<<"\n"<<strvalue[nstr];
  // cin >> c;
  if(peof){ r = true; goto ret; } 
  l = strlen(s);
  p = l==0 || l >= 2 && s[0]=='/' && s[1]=='/';  
 }
ret:  if(aa) ipp("-rwcm s= ", s);;
      return r;
} // end rwcm

   void wts(ofstream* f, charp* ts, int its)
{
 int i; // charp s; int j;
 if(pp) cout<<"\nwts "<<its;
 //f->write((char*)&its,sizeof its);
 //wf(f, sizeof its, (void*)&its);
 for(i=0; i<=its; i++) f->write(ts[i], strlen(ts[i]) + 1);
 //{
 // for(j=0; ts[i][j]; j++) *f << ts[i][j];
 // *f << '\0';
 //} // for(i)
  //* f<<ts[i]<<'\0';
  //if(pp && (i == 0 || i == its )) cout<<"\ni="<<i<<' '<<ts[i];
}  // wts

   void wtb(ofstream* f, void* tb, int itb, int s, char* place)
{
 // char c; int i,j;  //char* p = (char*) tb;
 int k = (itb+1)*s;
 cout<<"\nwtb: tb= "<<int(tb)<<" itb="<<itb<<" size= "<<s<<" k= "<<k<<" place= "<< place;
 *pfhis<<"\nwtb: tb= "<<int(tb)<<" itb="<<itb<<" size= "<<s<<" k= "<<k<<" place= "<< place;
 if(k <= 0) { ipp("wtb zero or neg k= ", k); goto ret; }
 wf(f, 999, k, tb, place);
 ret: if(bb) ipp("-wtb place= ", place);
}

/*   void wtb(ofstream* f, void far* tb, int itb, int s)
{
 char c; int i,j;  //char* p = (char*) tb;
 if(pp) cout<<"\nwtb "<<itb<<' '<<s;
 //wf(f, sizeof(int), (void*)&itb);
 //if(pp)cout<<"\nfirst byte="<<int(p[0]);
 wf(f,(itb+1)*s, (char far *) tb);
} */

   void rtb(ifstream* f, void* tb, int itb, int s, char* place)   // read k = (itb+1)*s bytes from f to tb;
{
 int k = (itb+1)*s;     // s: element size
 cout<<"\nrtb: tb= "<<int(tb)<<" itb="<<itb<<" size= "<<s<<" k= "<<k<<" place= "<< place;
 *pfhis<<"\nrtb: tb= "<<int(tb)<<" itb="<<itb<<" size= "<<s<<" k= "<<k<<" place= "<< place;
 if(k <= 0) { ipp("rtb zero or neg k= ", k); goto ret; }
 rf(f,k,tb,place);
 ret: if(bb) ipp("-rtb place= ", place);
} // void rtb

/*   void rtb(ifstream* f, void far* tb, int itb, int s)
{
 char c; int i,j;  char* p = (char*) tb;
 if(pp)cout<<"\nrtb "<<itb<<' '<<s;
 //rf(f, sizeof(int), (void*)itb);
 rf(f, (itb+1)*s, (char far*) tb);
 if(pp)cout<<"\nfirst byte="<<int(p[0]);
} */

   void rf(ifstream *f, int k, void* a, char* s)
{
 att x; // char c0,c1;
 f->read((char*)a,k);
 x = *(att*)a;
 // c0 = *(char*)a; 
 // c1 = *((char*)a + 1);
 if(s) *pfhis << "\n+rf k= " << k << " a= " << x << ' ' << s;
} // void rf

   void rf(ifstream *f, int k, charp b)
{
 int i,d;
 if(pp)cout<<"rf far "<<k;
 while(k>0)
 {
  if(k<=lfarb) d=k; else d = lfarb;
  f->read((char*)farb,d);
  for(i=0; i<d; i++) b[i]=farb[i];
  b+=d; k-=d;
 }
} // void rf 

    void wf(ofstream *f,int v, int k, void* a, char* s)
{
 if(v != 999) *pfhis << "\nwf v= "<<v << " k= " << k << ' ' << s;
 f->write((char*)a, k);
} // void wf

   void wf(ofstream *f, int k, charp b)
{
 if(pp) cout<<"\nwf far "<<k; error("wf");
 int i,d;
 while(k>0)
 {
  if(k<lfarb) d=k; else d = lfarb;
  for(i=0; i<d; i++) farb[i]=b[i];
  f->write(farb,d);
  b+=d; k-=d;
 }
}

   void ots(charp* ts, int its)
{
 int i; // char c; int j;
 cout<<"\nots "<<its;
 for(i=0; i<=its; i++)
 {
  cout<<"\n"<<i<<" "<<ts[i];
 }
}

   void ofts(ofstream* f, charp* ts, int its)
{
 int i;
 if(f) *f<<"\nots "<<its;
 else cout<<"\nots "<<its;
 for(i=0; i<=its; i++)
    {
     if(f) *f<<"\n"<<i<<" "<<ts[i]<< " "<<strlen(ts[i])<<' '<<int(ts[i][1]);
     else cout<<"\n"<<i<<" "<<ts[i];
    }
}

   void rts(ifstream* f, charp* ts, int its)
{
 int i;
 //f->read((char*)its,2);
 //rf(f, sizeof its, (void*)its);
 if(pp)cout<<"\nrts "<<its;
 // if(its>l)
 //  {
 //   free(ts);
 //  (void*)tabs=mylloc(l=its+d);
 // }
 for(i=0; i <= its; i++) ts[i] = rstr(f);
} // end rts

   char* nextname(charp* s, int* k=0)
{
 static char T[80]; char* p = *s; int i;
 if(p[0]==0) return 0;
 while(p[0]==' ') ++p;                         // skip spaces;
 for(i=0; i<80; i++,p++)
 {
  if(isalnum(p[0]) || p[0]=='_'){ T[i] = p[0]; continue; }
  T[i] = 0;  goto M;
 } // for(i)
 T[79] = 0;
 error("nextname: too long name T= ", T);
 M: *s = p; 
 if(!ww) ipp("-nextname T= ", T, " p= ", p);
 return T;   
} // end nextname;

   void mycopy() // 0_bool.v => 0_bool_new.v line by line replacing Proof(T; => Proof T; and so on;
{
 char s[256]; char*  T; char D[80]; charp p,p0,s0,s2;    // typedef char* charp
 int i, nstr=0, c,c1=0,c2=0,c3=0,c4=0,k;                 // c1:Proof, c2:endProof, c3:EqProof,c4:endEqProof;
 int ist = -1, stPEqP[100]; charp stT[100];

 strcpy(D, dirname); strcat(D, "0_bool.v");
 static ifstream fbool(D,ios::in);
 if(!fbool.is_open()) cout<<"\ncannot open file "<<D,exit1();

  strcpy(D, dirname); strcat(D, "0_bool_new.v");
 static ofstream fbool_new(D, ios::out);
 if(!fbool_new.is_open()){ ipp("mycopy: cannot open file 0_bool_new.v, D=",D); goto Finish; }

 while(!rstr(&fbool,s,maxl))
 {
  ++nstr;
  ipp("mycopy:while: s= ", s, " nstr= ", nstr, " ist= ", ist);
  for(i=0; i<=ist; i++) *pfhis << '\n'<<stT[i];
  *pfhis<<"\nend of stT";
  // p = strstr(s, "); // end EqProof(");
  // if(p==0) p = strstr(s, s_end_EqProof= "); // end EqProof ");
  p = strstr(s, s0 = "); //"); p0 = p;                     // ); // end Proof or ); // end EqProof
  if(p && p-s < 5)
  {
   p += strlen(s0);
   if(nstr==1190)
   mm=mm;
   s2 = nextname(&p, &k);                        // waiting for "end"  // now p points to next char after d;
   if(s2==0 || strcmp(s2, "end")){ ipp("mycopy: no end after ); //, s= ", s); goto Finish; }
   s2 = nextname(&p, &k);                        // waiting for "Proof" or "EqProof"
   if(s2==0){ ipp("mycopy: no name after end, s= ", s); goto Finish; }
   c = 0;
   if(strcmp(s2,"Proof")==0){ c = 1; goto M; }
   if(strcmp(s2,"EqProof")==0){ c = 3; goto M; }
   ipp("mycopy: not Proof or EqProof after end, s= ", s); goto Finish;
   M: if(p[0]=='(') ++p;                         // skipping '(' in end Proof(
   T = nextname(&p);                             // below s2 is Proof or EqProof
   if(T==0){ ipp("mycopy: no name T after end (Eq)Proof( or end (Eq)Proof ,s= ", s);  goto Finish; }
   if(ist < 0 || stPEqP[ist] != c){ ipp("mycopy: wrong stPEqP[ist]= ", ist<0? 999: stPEqP[ist], " c= ", c);  goto Finish; }
   if(strcmp(stT[ist], T)){ ipp("mycopy: different stT[ist], T= ", T, " stT[ist]= ", stT[ist]);  goto Finish; }
   p0[0] = 0;                                    // now s contains the initial spaces;
   if(c==1){ strcat(s," end Proof "); ++c2; } else{ strcat(s," end EqProof ");  ++c4; }
   strcat(s,T); strcat(s,";");
   --ist; goto Write;
  } // if(p)

  p = strstr(s, "EqProof(");
  if(p && p-s < 5)
  {
   p[7] = ' '; ++ c3;                            // 7 point to '('
   p+=8;                                         // now p points to T
   T = nextname(&p);
   if(T==0){ ipp("mycopy: no name after EqProof(, s= ", s);  goto Finish; }
   stPEqP[++ist] = 3; stT[ist] = T;
   if(ist > 0)
   { 
    ipp("mycopy: EqProof: big ist= ",ist, " s= ", s); 
    for(i=0; i<=ist; i++) *pfhis << '\n'<<stT[i];
    *pfhis<<"\nend of stT";
    // goto Finish;
   } // if(ist > 5)

   goto Write;
  } // if(p)    
  
  p = strstr(s, "Proof(");
  if(p && p-s < 5)
  {
   p[5] = ' '; ++ c1;                            // 7 point to '('
   p+=6;                                         // now p points to T
   T = nextname(&p);
   if(T==0){ ipp("mycopy: no name after Proof(, s= ", s);  goto Finish; }
   stPEqP[++ist] = 1; stT[ist] = T;
   if(ist > 0)
   { 
    ipp("mycopy: Proof: big ist= ",ist, " s= ", s); 
    for(i=0; i<=ist; i++) *pfhis << '\n'<<stT[i];
    *pfhis<<"\nend of stT";
   // goto Finish;
   } // if(ist > 5)
   goto Write;
  } // if(p)    

  Write: fbool_new << s << "\n";
   *pfhis << "\nmycopy: Write s= " << s;                    
 } // while
 fbool_new << "\n// nstr= "<<nstr<<
              "\n// Proof= "<<c1<<" end Proof= "<<c2<<
              "\n// EqProof= "<<c3<<" end EqProof= "<<c4;
 if(ist != -1)
 { 
  ipp("mycopy: ERROR: wrong ist= ", ist); 
  for(i=0; i<=ist; i++) *pfhis << '\n'<<stT[i]; 
  *pfhis<<"\nend of stT";
 } else ipp("mycopy SUCCESS!   nstr= ", nstr);
 M1: fbool.close();
 fbool_new.close();
 pfhis->close();
 beep(2); exit(1);
 Finish: *pfhis << "\nmycopy: ERROR\n\n"; cout << "\nmycopy: ERROR"<<"\n"; goto M1;
} // end  void mycopy()

   void remproofs(ifstream* pfin, char* name) // 0_bool.v => 0_bool_new.v line by line removing proofs;
{
 char s[256]; char s1[256]; char D[80]; charp p,p1,T,T1,Pr; char preq = 0;   // typedef char* charp
 int  nstr=0, c1=0,c2=0,cexc=0,cdexc=0,cdexc_notAx=0, k,errcount=0; bool pin=false; 
 // pfin<<"\n+remproofs name= " << name;        // // c1:Proof, c2:endProof, c3:EqProof,c4:endEqProof;
 ipp("\n+remproofs name= ", name);
 // strcpy(D, dirname); strcat(D,name); strcat(D,".v");            // strcat(D, "0_bool.v");
 // static ifstream fbool(D,ios::in);
 // if(!fbool.is_open()) cout<<"\ncannot open file "<<D,exit1();

  strcpy(D, name);   strcat(D, "h");  // here name is a full name, like "E:\Newveda_C2\0_bool.v"
 static ofstream fbool_new(D, ios::out);
 if(!fbool_new.is_open()){ cout << "\nremproofs: cannot open file .vh, D=" << D; goto Finish; }
 
 /* strcpy(D, dirname); strcat(D, "0_bool_new.his");
 static ofstream fbool_new_his(D, ios::out);
 if(!fbool_new_his.is_open()){ ipp("mycopy: cannot open file 0_bool_new.his, D=",D); goto Finish; }
 */
 while(strcpy(s1,s),!rstr(pfin,s,maxl))       // maxl : maximal size of v-line;
 {
  ++nstr;
  if(strlen(s) >= 3)
  {
   if(s[0]!='!') goto M2;
   if(s[1]==' '){ ++cexc; goto M2; }
   if(s[1]=='!' && s[2]==' ')
   {
    ++cdexc;
    if(strlen(s) >= 5 && (s[3] != 'A' || s[4] != 'x'))
    {
     ++cdexc_notAx; 
      // fbool_new << "\nError: remproofs: not !! Ax... \n" << s; 
    } // if(strlen(s) >= 5 && ...)
   } // if(s[1]=='!' && s[2]==' ')
  } // if(strlen(s) > 3)  
  M2: p = strstr(s, " Proof ");
  if(p==s)
  {
   p += 7;                                    // 7 = strlen(" Proof ");
   T = nextname(&p, &k);                      // waiting for "end"  // now p points to next char after d;
   if(T==0){ ++errcount; fbool_new << "\nError: remproofs: no theorem name after Proof, s=\n" << s; goto Finish; }
   if(pin){ ++errcount; fbool_new << "\nError: remproofs: no end for the previous theorem, s=\n" << s; goto Finish; }
   if(s1[0] != '!' || s1[1] != ' ')
   { 
    p1 = strstr(s1, "// Another proof of ");
    if(p1!=s1 || strcmp(nextname(&p1, &k),T))  
    {
     ++errcount; 
     fbool_new << "\nError: remproofs: no ! or no space after ! in the previous line, s=\n" << s; 
    } // if(p1!=s1 ...)
   } // if(s1[0] != '!'
   p1 = s1+2;
   T1 = nextname(&p1, &k);
   if(strcmp(T,T1))
    { ++errcount; fbool_new << "\nError: remproofs: different proof names in s1 and s, \ns1= "<<s1<<"\ns= "<<s; }
   pin = true; preq = 'P'; ++c1;
   // fbool_new<<"skipping Proof "<<T;
   continue;                                  // skipping s;
  } //  if(p-s = 0), Proof;   

  p = strstr(s, " EqProof ");
  if(p==s)
  {
   p += 9;                       // 9 = strlen(" EqProof ");
   T = nextname(&p, &k);                        // waiting for "end"  // now p points to next char after d;
   if(T==0){ ++errcount; fbool_new << "\nError: remproofs: no theorem name after EQProof, s=\n" << s; goto Finish; }
   if(pin){ ++errcount; fbool_new << "\nError: remproofs: no end for the previous theorem, s=\n" << s; goto Finish; }
   if(s1[0] != '!' || s1[1] != ' ')
   { 
    p1 = strstr(s1, "// Another proof of ");
    if(p1!=s1 || strcmp(nextname(&p1, &k),T))  
    {
     ++errcount; 
     fbool_new << "\nError: remproofs: no ! or no space after ! in the previous line, s=\n" << s; 
    } // if(p1!=s1 ...)
   } //  if(s1[0] != '!' ...)
   p1 = s1+2;
   T1 = nextname(&p1, &k);
   if(strcmp(T,T1))
    { ++errcount; fbool_new << "\nError: remproofs: different proof names in s1 and s, \ns1= "<<s1<<"\ns= "<<s; }
   pin = true;   preq = 'E'; ++c2;
   // fbool_new_his<<"skipping EqProof "<<T;
   continue;
  } //  if(p-s = 0), EqProof;

  p = strstr(s, " end ");
  if(p-s == 0)
  {
   if(!pin){ ++errcount; fbool_new << "\nError: remproofs: no Proof or EqProof before end, s=\n"<<s; goto Finish; }
   p += 5;                       // 5 = strlen(" end ");
   Pr = nextname(&p, &k);                        // waiting for "end"  // now p points to next char after d;  
   if(strcmp(Pr, "Proof")==0)
   {
    if(preq == 'E'){ ++errcount; fbool_new << "\nError: remproofs: end Proof after EqProof, s=\n" << s; goto Finish; }
    goto M;
   } //    if(strcmp(Pr, "Proof")==0)
   if(strcmp(Pr, "EqProof")==0)
   {
    if(preq == 'P'){ ++errcount; fbool_new << "\nError: remproofs: end EqProof after Proof, s=\n" << s; goto Finish; }
     goto M;
   } //    if(strcmp(Pr, "Proof")==0)
   ++errcount; 
   fbool_new << "\nError: remproofs: no Proof or EqProof after end, s=\n" << s; goto Finish; 
   M: p += 1;                      // 1: the space after (Eq)Proof;
   T1 = nextname(&p, &k);
   if(strcmp(T,T1))
   { 
    ++errcount; fbool_new << "\nError: remproofs: different proof names T= "<<T << " T1= "<<T1<<" s=\n" << s; 
    goto Finish;
   } // if(strcmp(T,T1))
   pin = false; continue;
  } // if(p-s = 1) end

  if(pin) continue;                // skipping s inside of a proof;
  fbool_new << s << "\n";          // writing s to fbool_new;                  
 } // while
  
  if(errcount==0)
  {
   fbool_new << "\nremproofs: SUCCESS !!!\n";
   cout << "\n\nremproofs: SUCCESS !!!\n\n";
  } 
  else
  {
   fbool_new << "\nremproofs: ERRORS: errcount = "<<errcount<<"\n";
   cout << "\nremproofs: ERRORS: errcount = "<<errcount<<"\n";
  } // else


  M1: fbool_new << "\n// nstr= "<<nstr<<
              "\n// main Proof count= "<<c1<<
              "\n// main EqProof count= "<<c2<<
              "\n// main Proof and EqProof count= "<<c1+c2<<
              "\n// cexc= "<<cexc<<
              "\n// cdexc= "<<cdexc<<
              "\n// cdexc_notAx= "<<cdexc_notAx<<
              "\n// errcount= "<<errcount<<"\n\n";
              
 pfin->close();
 fbool_new.close();
 cout << "\n-remproofs name= " << name;
 // pfhis->close();
 return; // exit(1);
 Finish: fbool_new << "\nremproofs: ERROR\n\n"; cout << "\nremproofs: ERROR"<<"\n"; goto M1;
} // end  void remproofs()

  void checkcnt()
{
 char s1[2560]; char s2[2560]; char D[80]; // charp p,p0,s0,s2;
 // ipp("+checkcnt");
 cout << "\n+checkcnt";
 strcpy(s1, "***");
 strcpy(s2, "***");

 strcpy(D, dirname); strcat(D, "1_group_5794.his");
 ifstream f1(D,ios::in);
 if(!f1.is_open()) cout<<"\ncannot open file "<<D,exit1();

 strcpy(D, dirname); strcat(D, "1_group_6685.his");
 ifstream f2(D,ios::in);
 if(!f2.is_open()) cout<<"\ncannot open file "<<D,exit1();

 while(!rstr1(&f1,s1,2500) && !rstr1(&f2,s2,2500))
 {
  while(strstr(s1,"prext:")==0) 
  { if(rstr1(&f1,s1,2500)) goto ret0;  }// looking in f1 for the line "prext:";
 
  while(strstr(s2,"prext:")==0) 
  { if(rstr1(&f2,s2,2500)) goto ret0; } // looking in f1 for the line "prext:";
 
  if(strcmp(s1,s2))
  {
   cout << "\n\ncheckcnt: found incoincidence: \ns1= "<<s1 << "\ns2= "<<s2;
  // *pfhis << "\n\ncheckcnt: found incoincidence: \ns1= "<<s1 << "\ns2= "<<s2;
   goto ret;
  }  // if(strcmp(s1,s2))
  cout << "\ncheckcnt: s1 and s2 are same: \ns1= "<<s1 << "\ns2= "<<s2;
 //  *pfhis << "checkcnt: s1 and s2 are same:: \ns1= "<<s1 << "\ns2= "<<s2;
 } // while(!rstr1(&f1,s1,maxl) && !rstr1(&f2,s2,maxl))
 ret0: cout << "\nEnd of file"; // *pfhis << "\nEnd of file";
 ret: ;
} // checkcnt

// end myio.cpp