// styp.h 11/24/99 12/21/99 12/25/00 4/19/01
#define lconjuncts 10
elem typTaut(elem z, headp h, elemp q);    // z: Taut(P)
elem typdbsl(elem z, headp h, elemp q);    //  \\ double back slash; 
                                           //  z \\ a=b: each inst a' of a pn z replace with b';
elem typfn(elem z, headp h, elemp q);
elem typif(elem z, headp h, elemp q);
elem typrestr(elem z, headp h, elemp q);
elem typconj(elem z, headp h, elemp q);
elem typimp(elem z, headp h, elemp q);
elem ptyp(elem p, elem z);
elem typin(elem z, headp h, elemp q);
elem typsle(elem z, headp h, elemp q);
elem typmod(elem z, headp h, elemp q);     // type modification using lot
                                           // method is always a NAMED term. // r=0: R is not a method, M=zel;
// att method(elem R, elem* aM, elem* aM0=0); // r=1: VSmethod, M=value R in HostMod; M0 is the model for R.M0;
                                           // r=2: R is a NVSmethod, M is the model for R.M from HostMod; 
int funt(elem f, elem t, elem* a, elem* b); // f in t -> f in fn(A, B)
bool tp1last(elem y, elem f, int a = -1);  // y ~ a..last(f) (if(a != -1, else z ~ 1..last(z) 
elem tph(elem z);                          // mel(z,&h); return h->tp;
elem normt(elem t);                        // r=t; if(!PP1(t) && PP1(typ(t), &r) return r;
void changeqi(elem z, elemp q, headp g, elemp w, att i, char* place);  // replace(if inside by(...) or is(...)) q[i] with valrt(q[i],...);
elem ptd(elem z, headp h, elemp q, headp g, elemp w); // precizing type definition, z: f(q1, ...), w[0]=dcl[. w[1]=f;
elem typtyp(elem t);   // x in H, H in subgr, subgr in P1[P1[elg]] => x in elg; retutn elg,
int numPP1(elem tt, elemp aa);  // number of P,P1 in Q[...Q[a]], Q is P or P1
// end styp.h
