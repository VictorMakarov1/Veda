// styp.cpp 11/24/99 2/11/00 3/16/00 5/19/00 7/22/00 12/25/00
#include "lib.h"  // 4/19/01 6/13/01
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h"  
#include "rep.h" 
#include "term.h"
#include "typ.h"     
#include "elem.h"
#include "prf.h"
#include "styp.h"
#include "lot.h"
#include "assert.h"
#include "cr.h"
#include "etc.h"
#include "err.h"
extern achs* pntu;
extern int mm,zz, ilot, ivin;
extern elem yre,savetyp;
extern elemp lot; 
extern bool nowlotinf, wasassume;
extern int iDd,iD;
extern int dispDd[maxsynv];          // dispDd[0] = 0, dispDd[i+1] = dispDd[i-1] + kmain(Dd[i-1]);
extern elem D[maxsynv];
extern elem Dd[maxsynv];
#define MaxMod 10
// int iMod;
// elem Host[MaxMod];
// elem Mod[MaxMod];
int PlDd(elem d);
inline elem superset(elem z){ elem t, r=zel1; if(fnt2(z,zdconj, &t)) r = t; return r; }  // temporary !!!

   elem typTaut(elem z, headp h, elemp q)    // z: Taut(P)
{
 elem r, t; // headp g; elemp w;
 if(mm) ipp("+typTaut z= ", z);
 if(h->l != 2) error("typTaut: h->l != 2, z= ", z);
 t = typ(q[1]);
 if(t != zbool) error("typTaut: not a formula in z= ", z, " q[1]= ", q[1]);
 if(!Taut(q[1])) error("typTaut: not tautology in z= ", z, " q[1]= ", q[1]);
 wrval(z,h,q,q[1]);
 r = zbool;
 if(mm) ipp("-typTaut z= ", z, " r= ", r);
 return r;
} // end elem typTaut(elem z, ...)

  elem typdbsl(elem z1, headp h, elemp q)     //  \\ double back slash; 
{                                             // z \\ a=b: each inst a' of a pn z replace with b';
 elem r,z,y0,y,a,b,d0,dpat; elemp w; int k=0; // z \\ [a=b, 2]; second occurrence a' of a replace with b'; 
 // mm=1;
 if(mm) ipp("\n+typdbsl z1=", z1);            // k=0: each inst a' of a pn z replace with b';
 if(h->l != 3) error("typdbsl: the number of parameters is not 2, z1= ", z1);
 z = q[1];
 if(seqv(q[2], &k, &w))
 {
  if(k != 2) error("typdbsl: seqv(q[2]):the number of elements is not 2, z1= ", z1, " q[2]= ", q[2]);
  y0 = w[1];
  if(w[2].m != ints) error("typdbsl:seqv: second element w[2] is not integer, z1= ", z1, " w[2]= ", w[2]);
  k = intval(w[2]);
 } // if(seqv(q[2], &g, &w))
 else y0 = q[2];
 y = rterm(y0); 
 if(! byel(y, &a, &b, &d0, &dpat)) error("typdbsl: wrong byel(y): , z1= ", z1, " y0= ", y0, " y= ", y);
 r = rep2i(z,a,b,d0,dpat);
 wrval(z1,h,q,r);
 if(mm) ipp("-typdbsl z1= z1", z1, " r= ", r);
 return r;
} // elem typdbsl(elem z, ...)

  elem typfn(elem z, headp h, elemp q)  // checking fn(A1,.., Ak, B)
{
 if(mm) ipp("+typfn z= ", z); 
 elem r = zset; int i,hl=h->l; bool p = false;
 if(hl < 3) error("typfn:l",z,hl);
 for(i=1; i < hl; i++)
  if(!iset(q[i])) errmsg("typfn: not set, z= ", z, " q[i]= ", q[i]);
 if(mm)ipp("-typfn r= ",r); 
 return r;
} // end typfn

     elem typif(elem z, headp h, elemp q)     // z: if(p,a,b);
{
 if(mm) ipp("+typif z= ", z, " ilot= ", ilot);  
 int save = ilot, k = h->l - 2, iar = -1; elem r,r1,t1,t2,notp,p,a,b; // ar[maxvars];  // elem x,t1,t2,notp;
 if(k & 1) error("typif:wrong(not even) k=h->l-2, z= ", z, " k= ", k);
 if(k != 2) error("typif: wrong (k != 2) if(P,x,y), z= ", z, " k= ", k);
  p = q[1]; a = q[2], b = q[3];
  if(typ(p) != zbool) error("typif: wrong condition p, z= ", z, " p= ", p); 
  wlot(p,"typif:1");  
  t1 = typ(a);
  chilot("-typif:1, ilot=save ", save); // ilot = save;
  notp = trm1(znot, p, zbool); 
  wlot(notp,"typif:2");
  t2 = typ(b);
  if(t1 != t2){ ipp("typif: t1 != t2, z= ", z, "\nt1= ", t1, "\nt2= ", t2); r = zany; }
  chilot("-typif:2, ilot=save ", save); // ilot = save;
  r = t1;
 if(strcmp(hintstr, "nosimr") == 0) goto ret;
 r1 = simr(q[1]);
 if(r1==ztrue || r1==zfalse)
 { 
  if(mm) ipp("typif: after successful r1 = simr(q[1]), z= ", z, " r1= ", r1); 
  wrval(z,h,q, r1==ztrue? q[2]:q[3]);
 } // if(r==ztrue || ...) 
 ret: if(mm) ipp("-typif: z= ", z, " r= ", r, " ilot= ", ilot);
 return r;
  
 /*
 if(istrdt(q[1]))                     // q[1]: cond;
 { 
  if(99) ipp("typif: istrdt discovered truth of q[1], z= ", z, " q[1]= ", q[1]);
  wrval(z,h,q, q[2]);
  r = typ(q[2]); 
  goto ret; 
 } // if(istrdt(q[1]))
 
 for(i=1; i<k; i+=2)
 { 
  x = q[i];
  if(typ(x) != zbool) error("typif: wrong condition p, z= ", z, " p= ", x, " i= ", i);
  save = ilot; wlot(x,"typif:1");  
  wrlist(typ(q[i+1]),ar,&iar,maxvars);
  chilot("-typif:2, ilot ", save); // ilot = save;
  notp = trm1(znot, x, zbool);  wlot(notp,"typif:2");
 } // for(i)
 wrlist(typ(q[k+1]),ar,&iar,maxvars); 
 r = ar[0];
 if(iar != 0){ prlist("typif",ar,iar); ipp("typif: multiple types: r := zany, , z= ", z); r = zany; }
 chilot("-typif, save1 ", save1);  // ilot = save1;
 r = ar[0];
 
 
  t1 = typ(q[1]);
 if(t1 != zbool) errmsg("typif:wrong condition z= ", z);
 wlot(q[1]);
 t1 = typ(q[2]);
 if(t1 == zel) errmsg("typif: wrong A in z=if(p, A, B), z= ", z);
 ilot = save;  // in \* ... *\
 notp = trm1(znot, q[1], zbool); 
 wlot(notp);
 t2 = typ(q[3]);  // p==1: ~(q[1])
 if(t2 == zel) errmsg("typif: wrong B in z=if(p, A, B), z= ", z);
 //if(!istrue(trm2(zin,q[3],t1,zbool)))      use it later!
 if(t1 != t2)  // temporarily!
 {
  ipp("typif: : t1 ~= t2, (returning zany) z= ", z);
  ipp("typif: t1 ~= t2, t1= ", t1, " t2= ", t2);
  t1 = zany;
 } // if(t1 != t2)
 ilot = save;   // in \* ... *\
 if(mm) ipp("-typif z= ", z, " t1= ", t1, " t2= ", t2);
 return t1; 
 */
}  // end typif

  elem typrestr(elem z, headp h, elemp q)   // typ(f|C)
{
 if(mm) ipp("+typrestr z= ", z, " ilot= ", ilot);  
 elem r = zREL, t0,t1,t2,A,B,f0,f=q[1],C=q[2]; att a;
 // assert(q[0]==zrestr);
 if(h->l != 3) error("typrestr: wrong h->l, z= ", z);
 if(q[2]==zemp) goto ret;                     // f|{} = {}; // empty relation;
 t0 = typ(f); 
 t1 = typ(q[1]); 
 t2 = typ(q[2]);
 if(t0==zany || t0==zset) t0 = typlot(f);
 if(t0==zREL) goto ret;
 a = fntype(t0,&A,&B,&f0);
 if(a==0)
 {
  if(istr2(zin,q[1],zREL)) goto ret;
  error("typrestr: not fntype(t0), z= ", z, " t0= ", t0);    // q[1] == f;
 } // if(a==0)
 if(a==1 || a==3){ A = trm1(zdom, f, zany); B = zany; } // better: im(f0); [FN,IFN,BFN,AFN,FFN,SEQ,SEQ1,SEQ2, SEQinj,SEQinj1,SEQinj2];
 else if(a!=2 && a!=4) error("typrestr: wrong a, z= ", z, " a= ", a); 
 if(istr2(zincl,q[2],A))
 {
 if(a==2){ if(f0==zfn) r = trm2(f0,C,B,zset); }                // 
 else if(t0==zFN) r = zFN;
 } // if(inlot2(zincl,q[2],A) || ... )
 else ipp("typrestr: z = f|C, but C is not included in A, r=REL!, z= ", z, "\nC= ", q[2], "\nA= ", A);
 ret: if(mm) ipp("-typrestr z= ", z, " r= ", r);
      return r;
} // end elem typrestr

  elem tifc(elem z,headp h, elemp q)             // 102
{
 if(pp){cout<<"\ntifc z="; prp(z); }
  h; q; 
 error("tifc z= ", z);
 return zel; // temporarily
} //end tifc

     elem typconj(elem z, headp h, elemp q)     //109
{      
 elem  r=zel,t1,t2, v=zel, ar1, ar2, z1=zel; int save = ilot; headp g; elemp w; bool pv=false;
 if(mm) ipp("\n+typconj z= ", z, " ilot= ", ilot, " nowlotinf= ", nowlotinf); 
 if(z.ad==stad2)
 mm=mm;
 if(h->l != 3) error("typconj: z= ", z, " h->l= ", h->l); 
 t1 = typ(q[1],&g,&w);
 v = valrt(q[1],g,w);
 if(v==zel) ar1 = q[1]; else{ ar1 = v; pv = true; };
 if(t1 != zbool && v != zel && typ(v) != zbool) 
    error("typconj: wrong  q[1], z= ", z, "\nq[1] = ", q[1], "\nt1= ", t1, "\nv= ", v);
 wlot(q[1],"typconj"); // was wlotinf(Q);
 t2 = typ(q[2],&g,&w);
 v = valrt(q[2],g,w);
 if(v==zel) ar2 = q[2]; else{ ar2 = v; pv = true; };
 if(t2 != zbool && v != zel && typ(v) != zbool) error("typconj: wrong q[2], z= ", z, "\nq[2]= ", q[2], "\nt2= ", t2, "\nv= ", v);
 if(pv)
 { 
  z1 = trm2(zconj, ar1, ar2, zbool);
  // if(mel(z1, &g, &w) != pfs) error("typconj:pv:mel(z1,...) != pfs, z1= ", z);   
  wrval(z,h,q,z1);
 } // if(pv)
 r = zbool; 
 chilot("-typconj, save ", save); // ilot = save;
 if(mm) prlot("-typconj");
 if(mm) ipp("-typconj z= ", z, " v= ", v, " r= ", r, " ilot= ", ilot);
 return r;
}  // end typconj

     elem typimp(elem z, headp h, elemp q)    
{
 if(mm) ipp("\n+typimp z= ", z, " ilot= ", ilot);
 elem ab, r = zbool; int save = ilot;
 if(h->l != 3) error("typimp: z= ", z, " h->l= ", h->l); 
 if(typ(q[1]) != zbool) errmsg("typimp: wrong q[1], z= ",z, " q[1]= ", q[1]);
 wlot(q[1],"typimp");   // was wlotinf(q[1]);
 if(typ(q[2]) != zbool) errmsg("typimp: wrong q[2], z= ",z, " q[2]= ", q[2]);
 if(r != zbool) error("typimp: wrong r, z= ", z, " r= ", r);
 r = zbool;
 ab = root(pntu->above());
 if(mm) ipp("typimp: ab= ", ab, " zconj= ", zconj, " zimp= ", zimp);
 // if(ab != zconj && ab != zimp)  // 2022.09.09
 chilot("-typimp, save ", save); // ilot = save;
 if(mm) prlot("-typimp");
 if(mm) ipp("-typimp z= ", z, " r= ", r, " ilot= ", ilot);
 return r;
}  // end typimp

    elem typcrl(elem z, headp h, elemp q)         // {a,b,c,d}
{
 elem r, t, tpred = zel; int i,hl=h->l; bool p = false;
 if(mm) ipp("+typcrl z = ", z);
 //elem t1 = typ(q[0]);
 //if(t1 == zel) error("typ: wrong term in sequence q[0]= ",q[0]);
 for(i=1; i < hl; i++)
 {
  elem y = q[i];
  t = typ(y); //   i->0;y=trm2(zin, x,t0,zbool);
  if(t == zel) error("typ: wrong term in  q[i]= ", y);  // was errmsg
  if(i > 1 && t != tpred) p = true;
  tpred = t; 
 }              // 9/13/96 : was goto zret;
 r = p? zset: trm1(zP, t, zset);
 if(mm)ipp("-typcrl z= ", z, " r= ", r); 
 return r;  // at the end
} // end typcrl

  elem typabt(elem z, headp h, elemp q)
{
 elem a,x,t,tx,r = zset; bool p = false, save_wasassume = wasassume;
 int savemm = mm, saveilot = ilot; // typ(q[i]) == zel, for some i
 int i,j; // headp g; elemp w;
 elem types[maxabtv];   // types[0] not used;
 assert(h->tel == abt);
 //if(stad != 0 && z.ad==stad)
 // mm=1;
 int k = kmain(h);  int hl1 = int(h->l) - 1; int k2 = k*2;
 if(mm) ipp("+typabt: z= ", z, " k= ", k); // untyped abterms allowed only in standard modules
 if(k2 > hl1 && curm > lsm) error("typabt: untyped z= ", z, " k= ", k, " hl1= ", hl1);
 if(k >= maxabtv) error("typabt: k >= maxabtv, z= ", z, " k= ", k);
 for(i=k+1; i <= hl1; i++) // 1..k: names, after names: axioms;
 {
  a = q[i];
  t = typ(a);
  if(mm && i==5)
  if(mm) ipp("typabt: q[i]= ", a, " t= ", t, " i= ", i);
  if(t == zel) { p = true; continue; }
  if(t != zbool) { ipp("typabt:  'axiom' is not formula q[i]= ", a, " zbool= ", zbool); continue; }
  if(i<=k2)
  {
   j = i-k;
   if(fnt2(a,zin,&x,&tx) && htbv(x)==z && int(x.i)==j) types[j] = tx;
   else
   { 
    types[j] = zel; 
    if(curm>lsm) error("typabt: not in-axiom q[i]= ", a);
   } // else
  } // if(i<=k2)
  if((i==hl1 || i < hl1 && q[i+1] != zNotAxiom))
  {
    mktr(a);           // was by mistake commented; 2.3.21;
    wlot(a,"typabt");  // was wlotinf(a);  // internal abterm  if(pntu->iach > 1) 
  } // if(i==hl-1)  
 } // end for(i)
 //  wlot(a, "typdef:ax");
 // ilot = save;
 //if(!p) if(k == 1) r = types[1]; else r = zset; // CP(types1, ..., typesk) later!!!
 if(k==1 && types[1] != zel){ r = trm1(zP,types[1],zset); h->tp = r; /*mktr(trm2(zin,z,r,zbool));*/ }
 // else ???
 if(mm) prlot("-typabt");
 if(mm) ipp("-typabt of z= ", z, "\n r= ", r);  mm = savemm;
 if(!pntu->topachDabt(z))
 { 
  wasassume = save_wasassume; 
  chilot("-typabt, saveilot ", saveilot);  // ilot = saveilot; 
 } // if(!pntu->topachDabt(z)) // else lot can be used in the Dterm;
 return r;       // more full checks(consistensy, ...) - done! 5/30/00
} // end typabt

   void wlotaxs(elem d, headp h, elemp q)
{
 int i, hl = h->l;
 if(mm) ipp("+wlotaxs d= ", d);
 for(i=kmain(h)+1; i<hl; i++) wlot(q[i], "wlotaxs"); 
 if(mm) ipp("-wlotaxs d= ", d);
} // end wlotaxs

   elem typdot(elem z, headp h, elemp q)             // z = m.M, M in t;
{
 elem r;  int hl = int(h->l); 
 if(mm) ipp("\n+typdot z= ", z, " q[1]= ", q[1], " hl= ", hl, " mm= ", mm);   //  gabt: mel==abt || mel==pfs&&zdconj;
 // typ(q[1]);
 r = mdt(z,h,1);
 if(mm) ipp("-typdot z= ", z,  "\nr= ", r); 
 return r;
} // end  typdot

// elem typdotq0(elem z, headp h, elemp q, elemp w) moved to trash.txt on 03.06.23

   elem typF(elem z, headp h, elemp q)   // z is F[d,Q];
{                                        // remake: see typR;
 elem r=zel, t1, t2; headp h1; int saveilot = ilot;
 if(mm) ipp("+typF: z= ", z);
 if(h->l != 3) error("typF: wrong h->l, z= ", z, " h->l= ", h->l);
 typ(q[1]);                              // checking q[1]: if(typ(q[1]): zel: will be error in typ;
 t1 = simd(q[1]);                        // simd({x; x in t}) = t; (else zel);
 t2 = typ(q[2]);
 if(!Abterm(q[1], &h1) || h==0) error("typF: wrong Abterm q[1], z= ", z, " q[1]= ", q[1]);
 if(t2 != zel) r = trm2(zfn,t1==zel? q[1]: t1, t2, zset);
 if(mm) ipp("-typF: z= ", z, " r= ", r);   chilot("-typF, saveilot ", saveilot); // ilot = saveilot;
 return r;
} // end typF

   elem typR(elem z, headp h, elemp q)   // z is R[d,Q];
{ 
 elem r=zel, f, tt, d=q[1], Q=q[2], td, tQ; int m, hl = h->l; headp g; elemp w;
 if(mm) ipp("+typR: z= ", z);
 if(hl != 3) error("typF: wrong h->l, z= ", z, " h->l= ", hl);
 td = typ(d); tQ = typ(Q);
 m = mel(d,&g,&w);
 if(m==abt)
 {
  if(!bvarfree(d,tQ)){ ipp("typR:was error: tQ is not free from d, z= ", z, "\nd= ",d, "\ntQ= ", tQ); tQ = zset; }
  if(istr2(zneq,d,zemp)){ f = zP1; tt = trm1(zP1,trm1(zP1,tQ,zset), zset); } // d != {}: tt = P1[P1[tQ]];
  else{ f = zP; tt = trm1(zP,trm1(zP,tQ,zset), zset); }    // d == {}; tt = typ(typ(R[d,tQ])) = P[P[tQ]];
  r = trm1(f,tQ,tt); goto ret;
 } // if(m==abt)
 if(m==pfs)
 {
  if(w[0] != zdconj) error("typR: m==pfs, but w[0] != zdconj, z= ", z, "\nd= ", d); 
  goto ret1;
 } // if(m==pfs)
 if(m!=var) error("typR: not abt, not pfs,  not var d, z= ", z, "\nd= ", d); // R[d,Q], d,Q: vars;
 // if(mel(Q) != var) error("typR: not var Q, z= ", z, "\nd= ", d, "\nQ= ", Q);
 if(tQ != zany && tQ != zset){ r = trm1(zP,tQ,zset); goto ret; }
 ret1: r = zset;
 ret: if(mm) ipp("-typR: z= ", z, " r= ", r);
 return r;
} // end typR


   elem typFNseq(elem z, headp h, elemp q, elem t, elem sq)   // z is f(x) typ(f)= FN or seq(t) or seq1(t);
{          // return t, if x in dom(f); else error;           // sq = SEQ1,seq1, or zel; SEQ1 can be typ(f);
 elem x,f,tx,t1,v, r=t; int hl= h->l, save = ilot; // headp g; elemp w;
 if(mm) ipp("\n+typFNseq: z= ", z, "\nt= ", t, " sq= ", sq);
 if(check(z.ad, stad))
 mm=mm;
 // if(mm){ prp("\n--------------------1 +typFNseq z= ", z, pfhis); *pfhis<<" itt= " << ptt->itt; }
 if(mm) ipp("\n+typFNseq z= ", z, " itt= ", ptt->itt); 
 f = q[0]; 
 if(hl != 2)
 { 
  error("typFNseq: strange h->l (!= 2),looking in lot for dom(f)=A1#A2, z= ", z, " h->l= ", hl);
  // x1 = trm1(zdom,f,zany);
  // x = inlot2eq1(x1);
  // if(x==zel || ! fnt2h(x,zdp,) error("typFNseq: 
 } // if(hl != 2) 
 x = q[1]; tx = typ(x); assert(tx != zel);        // q[0] = f, q[1] = x; typ(x) = dom(f); (in the best case);
 if(x==zel0 && tpseq1a(sq)){ ipp("typFNseq: x==zel0 && tpseq1a(sq), z= ", z); goto ret; }
 if(fnt1(tx,zdom,&v) && v==f) goto ret;
 if(sq == zseq1)
 {
  r = tpseq1(f,x,t); // if(x==0 || x==1 || typ(x)==1..last(z)) || 
  if(r != zel) goto ret;        // x ~ i-1 && typ(i)==1..last(z)) r=t; else r = zel;
 }  //  if(sq == zseq1)
 /* if(sq == zseq1)
 {
  if(x==zel0){ ipp("typFNseq: 0 in dom(f:seq1(t)), z= ", z);  goto ret; }
  if(fnt1(x,zlast,&v) && v==f){ ipp("typFNseq: last(f) in dom(f:seq1(t)), z= ", z); goto ret; }
 } */
 t1 = trm1(zdom, f, zany);                    // dom(f),   typ(q[0]) == zFN
 if(!fit(x,t1)) error("typFNseq: x does not fit t1, z= ", z, "\nx= ", x, "\nt1= ", t1);
 if(t==zany)
 /*if(mel(x)==bvar){ closlot(); if(inlot2(zin,x,t1)) goto ret; } // for TinjreA
 if(mm) pntu->prach("d");
 d = pntu->seekdtd();                         // d != zel -> we are inside A[d,P],E[d,P],F[d,P], ...
 if(istr2(zin,x,t1,d)) goto ret;
 y = trm2(zin,x,t1,zbool);                    // x in dom(f)
 if(addtabt(y)) goto ret; 
 if(closlot(y)) goto ret;                              // -----------
 if(inlot(y)) goto ret; 
 /// T = pntu->ndcol();
 if(intabt(y, T)) goto ret;                      // 
 // if(addlot(y,T,0,ilot)) goto ret; 
 if(9) ipp("typFNseq: hard case: z= ", z, " y= ", y);
 y1 = simr(y);
 if(y1 != ztrue) 
      error("typFNseq: not true after r = simr(y), \ny= ", y, "\nz= ", z, " y1= ", y1);
 */
 ret: if(mm) ipp("\n----------- -typFNseq: z= ", z, " t= ", t, "\nr= ", r); 
      chilot("--typFNseq,save ", save);  // ilot = save;
      return r;
} // end elem typFNseq
                            // z = tr(a,b), t = afn({a,b}), kz=2, kt=2;
    elem typfnt(elem z, headp h, elemp q, elem t, headp g, elemp w)   // z = f(q1,..., q_kz); t:fn(w1,w2); t: ifn(...), ...
{
 elem ar[3],tz, r = zel;  int m,m1,n, hl = h->l, kt = g->l, kz = hl-1;  headp g1; elemp w1; 
 if(mm) ipp("+typfnt z= ", z, "\nt= ", t, "\n w[0]= ", w[0], " kz= ", kz, " kt= ", kt);    // t = fn(t1,...,tm); kt = m+1;
 // if(z.ad==15993)
 // mm=mm;
 assert(hl >= 2);                            // z = f(q1, ... , qk), hl = k+1;
 m1 = mel(w[1],&g1,&w1);                     // w[1] = t1;
 if(m1 == abt)    // abt case: t = fn(d,T); d=w[1], T=w[2];
 {
  if(mm) ipp("typfnt:abt: z= ", z, " t= ", t);
  if(kt != 3) error("typfnt:abt: wrong kt, z= ", z, " t= ", t, " kt= ", kt);
  n = kmain(g1);
  if(n != kz) error("typfnt: abt case, n != kz, z= ", z, "\nt= ", t);
  if(kz==1)
  { 
   tz = typ(q[1]);  
   if(typcmpr1(w[1],&tz,q[1])==1) goto ret1;   // w[1]==t1;
  } // if(k==1)
  if(!ismd(w[1],q,n)) 
      error("typfnt: not ismd z= ", z, "\nt= ", t);
  ret1: r = repq(w[2],w[1],q,n); goto ret;
 } // end abt case   
                                             
 if(m1 != pfs){ if(mm) ipp("typfnt:m1 != pfs(goto Main_Case), w[1]= ", w[1], " m1= ", m1); goto Main_Case; }
 if(w1[0]==zdp || w1[0]==opb)      // t = fn(A#B,T) or t = fn([A1,A2,A3]???, T): CP not imp yet;
 {                                 // CP(A1,A2,A3) can be replaced with {a1,a2,a3; a1 in A1,...} // CP: Cartesian Product
  if(mm) ipp("typfnt:dp: z= ", z, " t= ", t);  // dp: direct product;
  n = int(g1->l) - 1;              // t1 is A1#A2, n = 2;   (CP not imp yet;)     
  if(n != kz)                       // k: # of args in z;
  {
   if(mm) ipp("typfnt: CP case, n != kz, z= ", z, "\nt= ", t, " n= ", n, " kz= ", kz);
   if(!seqv(z,&kz,&q) || n != kz)
     error("typfnt: CP case, not seqv(n), z= ", z, "\nt= ", t, " n= ", n, " kz= ", kz); 
  } // if(n != k)
  if(!Fit(q,w1,kz)) error("typfnt: wrong dp case, not Fit z= ", z, "\nt= ", t, " kz= ", kz);
  r = w[2];  goto ret;
 } // if(w1[0]==opb || w1[0]==zdp)    // end CP case

 Main_Case:               // t = fn(w[1],...,w[m]), z = f(q[1],...,q[k]); k=m-1, kt=m+1 => kt=k+2;
 if(mm) ipp("typfnt:Main_Case: z= ", z, " t= ", t, " kz= ", kz, " kt= ", kt);
 if(w[0]==zafn)                     // afn(A) = fn(A,A);
 { 
  assert(kt==2); 
  ar[0] = zfn; ar[1] = w[1]; ar[2] = w[1]; w = ar; kt = 3;
 } // if(w[0]==zafn)
 else if(kt < 3) error("typfnt: kt < 3, z= ", z, "\nt= ", t, " kt= ", kt);   // t = fn(t1,...,tm); 
 m = kt-1;            // m is number of parameters in t = fn(A,B); here m = 2;
 if(m-1 != kz) error("typfnt:main: m-1 != k, z= ", z, "\nt= ", t, " m= ", m, " kz= ", kz, " kt= ", kt);   
 {
  if(!Fit(q,w,kz))   // q[i] in w[i], i=1, ... ,kz;
    error("typfnt: wrong main case z= ", z, "\nt= ", t);  // was errmsg
   r = w[m]; // goto ret;
 } // end main case
/*
 if(m != 2) error("typfnt: m != 2, z= ", z, " t= ", t);
 r = w[2];
 m1 = mel(w[1], &g1, &w1);
 if(m1 != pfs) error("typfnt: wrong CP case z= ", z, "\nt= ", t);
 error("typfnt: wrong w1[0],  z = ", z, "\nt= ", t, " w1[0]= ", w1[0]); */
 ret: if(mm) ipp("-typfnt z= ", z, " r= ", r); 
 return r;
} // end typfnt   t:: fn(A1,...,Ak, B)

    elem typcnv(elem z, headp h, elemp q)
{
 headp g; elemp w; elem v, v1; ats i,gl; // v: verx, top cannot be used: top defined st[ist] !!! 
 if(mm) ipp("+typcnv: z= ", z);
 if(h->l != 3) error("typcnv: wrong conversion term z= ", z); // typ(q[1]) in fit;
 elem t = q[2]; 
 if(typ(t) == zel) error("typcnv: wrong q[2], z= ", z, " q[2]= ", t);  // below was not ipp but error; 6.16.22;
 if(! fit(q[1], t)){ ipp("typcnv: wrong type conversion term z, assigning the type 'any' to z= ", z); t = zany; }
 if(comp(q[1]))  // z is q[1] : q[2];   // was commented and uncommented on 09.01.19
 {
  if(mm) pntu->prach("typcnv");
  i = pntu->iach; assert(i>1);
  v = pntu->ach[i].e; v1 = pntu->ach[i-1].e;
  if(!comp(mel(v1,&g,&w))) error("typcnv: wrong(not comp) v1, z= ", z, " v1= ", v1);
  gl = g->l;
  for(i=0; i<gl; i++)
   if(w[i]==v){ w[i] = q[1]; goto ret; }
  pntu->prach("typcnv:no v in v1");
  error("typcnv: no v in v1, z= ", z, " v= ", v, " v1= ", v1); 
  // g = clad[q[1].m]->tabt[q[1].ad]; 
  // clad[z.m]->tabt[z.ad] = g;  // x:t => x;
  // g->tp = t;           // was commented on 10.26.18 and on 11.03.18;
 } //  if(comp(q[1]); // 10.26.18
 ret: if(mm) ipp("-typcnv z= ", z, " t= ", t);
 return t;
}  // end typcnv - type conversion term

   elem typdclterm(elem z, headp h, elemp q, headp g, elemp w,ats a)
{                      // (z,h,q), (q[0], g,w), q[0]=&,..., w = dcl[, &, bool, bool,bool]
 elem x, r=zel,t,t0,t1,t2; ats k=0; int i, hl = h->l, saveilot=ilot; headp h1; elemp q1;
 bool p_bdname; elem art[maxdcl]; sbst s;
 if(mm) ipp("+typdclterm z= ", z, "\nq[0]= ", q[0], " w[0]= ", w[0],   " ilot= ", ilot,  " a= ", vts(a) );
 for(i = kmain(h)+1; i < hl; i++)
 { 
  pntu->wrp(i);
  t = typ(q[i]);
  if(t==zel) error("typdclterm: wrong parameter i, z= ", z, "\nq[i]= ", q[i], " i= ", i);
 } // for(i)
 if(tupl(z)) { r = zany; goto ret; }
 if(mm) ipp("typdclterm: q[0]= ", q[0]);
 if(q[0]==zanyd && h->l == 2){ if(pntu->seekdtd(zA,q[1]) != zel) r = q[1]; else r = zany; goto ret; }
 if(h->l != g->l - 2)        // 2: dcl[, ..., tr;
 {
  if(q[0] == zby)
  {
   for(i=1; i < hl; i++)
	  if(typ(q[i]) != zbool && !Ints(q[i])) error("typdclterm:by : typ(q[i]) != zbool, q[i]= ",q[i]);
   r = zby; goto ret;      // errmsg
  } // if(q[0] == zby) 
 
  if(q[0] == zbyeq)
  {
   for(i=1; i < hl; i++)
	  if(typ(q[i]) != zbool) error("typdclterm:byeq: typ(q[i]) != zbool, q[i]= ",q[i]);
   r = zbyeq; goto ret;    // errmsg
  } // if(q[0] == zbyeq)
 
  if(q[0] == zfn)
  {
   for(i=1; i < hl; i++)
	  if(typ(q[i]) == zel) error("typdclterm:fn: typ(q[i]) == zel, q[i]= ",q[i]);
   r = zset; goto ret;    // errmsg
  } // if(q[0] == zfn)

  if(q[0] == zWitness)
  {
   for(i=1; i < hl; i++)
	  if(typ(q[i]) == zel) error("typdclterm:Witness: typ(q[i]) == zel, q[i]= ",q[i]);
   r = zbool; goto ret;      // ??? why bool ??? because bool is in dcl[Witness,any,bool]; 
  } // if(q[0] == zWitness)  // ??? dclm[Witness,any,bool]???
  
  ippelm("\ntypdclterm: Dclname: q[0]= ", q[0]); 
  ippelm("typdclterm: Dclname: w[1]= ", w[1]);
  error("typdclterm: h(z)->l != g->l - 2, \nz= ",z, "\nDclname= ", q[0], " h->l= ", hl, " g->l= ", int(g->l));
 } // if(h->l)
 p_bdname = bdname(q[0]);             // A[, E[, F[, ... ;
 for(i=1; i<hl; i++)
 {
  if(i >= maxdcl) error("typdclterm: too big i, z= ", z, " i= ", i);  // #define maxdcl 10
  x = q[i];                          // x: current actual parameter;
  art[i] = zel;                      // art: types of args q[i];
  t0 = w[i+1];                       // t0: current dcl-type;
  if(t0 == zbvar)
  { 
   if(Ident(q[i]) || mel(q[i]) == var) continue; // var: xx,yy, ...
   error("typdclterm: wrong bvar(not ident, q[i]= ", q[i]);
  } // if(t0 == zbvar)
  if(t0 == zvariable) 
  { 
   if(mel(x) != var) error("typdclterm: not var: q[i]= ", q[i]);
   continue;
  } //  if(t0 == zvariable) 
  t = typ(x); 
  art[i] = t;          // t: current actual type, art: types of actuals;
  if(t==zbool && t0==zset || t==zset && t0==zbool)
     error("typdclterm: wrong subterm(bool): t != t0, z= ", z, "\nq[i]= ", q[i], "\nq[0]= ", q[0], 
            "\nt0(q[0]:i)= ", t0, " t(q[i])= ", t);
  if(Any(t0))  continue;  // currently, zset is almost same as any 
  if(t0 == zabterm && (Dterm(q[i]) || q[i] == zemp) ) continue; // was mel(q[i]) == abt, 6.11.20
  // addtabt(); // closlot();
  if(p_bdname && i==1 && mel(x,&h1,&q1)==abt) wlotaxs(x,h1,q1); // x: current actual, t0: current formal type;
  // if(ground(t0)){ 
  if(!fit(x,t0)) 
   error("typdclterm: x does not fit t0= ", t0, "\nx= ", x, " tx= ", t,  "\nz= ", z);                
  // else if(!s.instance(t,t0))     // x: current actual, t = typ(x), t0: current dcl type;
  // {
  // s.psbs();
  // error("typdclterm:  t0= ", t0, "\nx= ", x, " tx= ", t,  "\nz= ", z); 
  // } // else if(!s.instance(t,t0))  
   
   /*ippelm("t= ", t); ippelm("t0= ", t0);
   ipp("typdclterm: x does not fit t0= ", t0, "\nx= ", x, " tx= ", t,  "\nz= ", z);
   x = q[0];  y1 = elm(ident,0,a); q[0] = y1;
   r = typidu(z,h,q,x);
   if(r==zel)
   {
    ipp("typdclterm: possibly wrong term z= ", z, " x= ", x, " a= ", a);
    if(h->l==3)
    {
     y = meth2(y1,q[1],q[2]);
     if(y != zel){ q[0] = y; r = typ(y); goto ret; }
    } // if(h->l==3)
    error("typdclterm:  wrong term z= ", z, " x= ", x, " y1= ", y1);
   } // if(r==zel)
   goto ret;
  } */ // if(!fit(x,t0))
 } // for(i)
 r = w[int(g->l) - 1];                              // tr from dcl;
 if(s.size) r = s.rep(r, "typdclterm");
 if(mm) ippelm("typdclterm r= ", r, " k= ", k);
 if(Ints(r, &k))
 {
  if(mm) ipp("typdclterm:after Ints(r, &k), z= ", z, " r= ", r, " k= ", k);
  if(k >= int(g->l))
  {   
   for(i=0; i < int(g->l); i++) ipp("w[i]= ", w[i], " i= ", i);
   error("typdclterm:  z= ", z, " r= ", r, " g->l = ", g->l, " k= ", k);
  } // if(k >= int(g->l))
  r = art[k];    // move up before if(s.size) r = s.rep(r); 2022.06.04 ???
 } // if(Ints(r, &k))
 ret: // if(r==zset || r==zREL){ t = typt(z); if(t!=zel) r= t; }
 if(q[0]==zun)
 {             elem tq1,tq2;
  if(mm) ipp("+typdclterm:zun: z= ", z);
  t1 = normt(tq1 = typ(q[1]));          // -normt z= #1.10537 P1[(0 1 1686)(elg(1 1 0)) r= #1.10537 P1[(0 1 1686)(elg) 
  t2 = normt(tq2 = typ(q[2]));          // -normt z= subgr#1.4158  r= #1.10537 P1[(0 1 1686)(elg(1 1 0)
  if(mm) ipp("typdclterm:zun: q[1]= ", q[1], " q[2]= ", q[2], "\ntq1 = ", tq1, " tq2= ", tq2);
  if(t1==t2){ if(mm) ipp("-typdclterm:zun: t1=t2, r= ", t1);  r = t1; goto ret1; }
  eqPP1(t1,t2,&r); if(mm) ipp("-typdclterm:zun: eqPP1(t1,t2,&r), r= ", r); goto ret1;
 } // if((q[0]==zun)
 if(q[0]==zinter && art[1]==art[2] && mel(art[1],&h1,&q1)==pfs && (q1[0]==zP || q1[0]==zP1))
  { r = art[1]; goto ret1; }
 if(allex1(q[0])) goto ret1;
 x = ptd(z, h, q, g, w);
 if(x != zel) r = x;
 ret1: if(q[0] != zis && q[0] != zEx) chilot("-typdclterm, saveilot ", saveilot);  // ilot = saveilot;     // ??? by,... ??? 
 if(mm) ipp("-typdclterm z= ", z, " r= ", r, " k= ", k, " ilot= ", ilot); 
 return r;
} // end typdclterm	
                                                       // ptd: precizing type definition (handling of)
 elem ptd(elem z, headp h, elemp q, headp g, elemp w)  // z: f(x1, ...); d: dcl[f,t1,..., tk, tr];
{                                                              // w: dcl[f, t1, tr]; // t1=SEQ1, tr=SEQ;
 elem r=zel, f=q[0], tzi,zi, tr=rtdcl(g,w),a,c,d,cptd,P,Q,R,x,tc; ats i,k;  att dad; char* spdt;
 int savemm=mm; headp g1; elemp cnjncts,w1; sbst s; elem X[lconjuncts];   // #define lconjuncts 10  
 if(mm) ipp("+ptd z= ", z, " f= ", q[0], " tr= ", tr, " r= ", r); 
 // if(z.ad==stad2) mm=1;
 d = f; d.i = 0;  dad =  d.ad;         // must: seq(t) <: SEQ1;             
 while(isproptail("_ptd", spdt= strnamet(cptd = elm(d.m, 0, dad-=2))))  // 2: Lx := Lx;
 {                                     // cptd: the current precizing type def  ; All pdts must be just before the dcl; 
  if(mm) ipp("\nptd:while cptd= ", cptd, " spdt= ", spdt);    // Q is a type formula R in tr;
  if(!fnt2(cptd,zimp,&P,&Q) ) error("ptd: wrong cptd(not imp), z= ", z, " cptd= ", cptd); // look for parsimp !!!  
  k = linconj(P, &cnjncts);              // each conjunct: x in t; x is var, s.instance(typ(q[i+1]), T);
  if(k != npardcl(g)) error("ptd: (k != npardcl(g)), z= ", z, " k= ", k); // npardcl(g) = g->l - 3; (-dcl,-f,-tr);           
  if(mm) ipp("ptd cptd= ", cptd, "\nP= ", P, " Q= ", Q, "\ncnjncts[0]= ", cnjncts[0], " k= ", k);
  for(i=0; i<k; i++)
  {                 // each cptd has the form c1 -> Q or c1 & ... & ck -> Q; k is the number of args of f; 
   c = cnjncts[i]; zi = q[i+1];        // zi is the actual argument q(i+1) in z = f(z0, )'... , z_k-1
   if(mm) ipp("ptd:for c= ", c, " zi= ", zi, " i= ", i);      // typ(x) must be set or any???
   if(mel(c, &g1, &w1) != pfs || g1->l != 3) error("ptd: wrong conjunct: mel(c) or g1->l, z= ", z, "c= ", c);
   x = w1[1];  X[i] = x;               // each c is x=a or x in tc, x is a free variable;
   if(!isvar(x)) error("ptd: wrong conjunct c: x is not a var, z= ", z, "c= ", c, " x= ", x);  
   if(w1[0]==zeq)    // c: x = a;
   {
    a = w1[2];       // the corresponing to x actual arg z1 must be a; 
    if(a != zi){ if(mm) ipp("ptd: a != zi, z= ", z, " zi= ", zi, " c= ", c, " a= ", a, " i= ", i); goto Endwhile; }
    continue;  
   } //  if(w1[0]==zeq)
   if(w1[0] != zin) error("ptd: wrong conjunct c: not zeq or zin,  z= ", z, "c= ", c, " i= ", i);  
   tzi = typ(zi); tc = w1[2]; 
   if(tzi==zany) tzi = typlot(zi);
   if(mm) ipp("ptd:for:zin c= ", c, " zi= ", zi, " tzi= ", tzi, " tc = ", tc);
   if(ground(tc))
   { 
    if(!fit(zi,tc)){ if(mm) ipp("ptd:ground(t): !fit(zi,tc), z= ", z, " zi= ", zi, " tc= ", tc, " i= ", i); goto Endwhile; }
  } // if(ground(tc))
  else
  { 
   if(!s.instance(tzi, tc)){ if(mm) ipp ("ptd: !s.instance(ti, t), tzi= ", tzi, " tc= ", tc); goto Endwhile; }  
  } // else
 } // for(i=0);     // if(!istr2(zincl,X,t1)) goto ret;
 if(!Truth(cptd)) error ("ptd: !Truth(cptd), z= ", z, " cptd= ", cptd); 
 if(!fnt2(Q,zin,&R, &tr)) error("ptd: !fnt2(Q,zin,&R, &tr), Q= ", Q);
 if(mel(R, &g1,&w1) != pfs || w1[0] != f) error("ptd: wrong R, z= ", z, " cptd= ", cptd, " R= ", R, " f= ", f); 
 for(i=0; i<k; i++) 
  if(w1[i+1] != X[i]) error("ptd: wrong R: w1[i+1] != X[i], z= ", z, " cptd= ", cptd, " R= ", R, " X[i]= ", X[i]," i= ", i);
 if(mm) ipp("pdt: found!, z= ", z, " cptd= ", cptd);  
 if(s.size) r = s.rep(tr, "ptd"); else r = tr;
 goto ret;
 Endwhile: ; } // while
 ret: if(mm) ipp("-ptd z= ", z, " f= ", f, " r= ", r);   mm=savemm;
      return r; 
} // end elem ptd
                                                         // r==false: cannot compute the types;
   bool tpon(elem f, elemp* qt, int* kt, bool* postfix)  // types of an overname f: dcl[f,t1,... or
{    // in dcl format, qt[0]=t1;   // f:fn(..., ...)     // types(*kt): result type!                                                  
 bool r = true; headp g; elemp w,q; int k,hl,m; elem d,tf=zel; static elem types[maxvars];
 if(mm) ippelm("+tpon: f= ", f);   // f(z1, ... , zk);
 if(postfix) *postfix = false;                 // false == 0;
 if(f.i == 0)            // f is composite
 {
  if(prognum==numrnam) goto ret1;
  tf = typ(f); 
  goto M;
 } // if(f.i == 0)
 if(dclname(f,&g,&w))    // w: dcl[ats(f),t1,...,tk,tr]; g->l == k + 3;
 {
  k = int(g->l) - 3;             // the number of parameters, minus dcl,ats(f), tr;
  if(mm) ipp("tpon: dclname f= ", f, " number of params(f) = ", k);
  if(k==0)                       // dcl[f,t1]; f is a constant of type t1;
  {
   tf = w[2];                    // the result type
   goto M;
  } // if(k1==0)
  if(k >= maxvars) error("tpon: k >= maxvars, k= ", k, " maxvars= ", maxvars);           // here k > 0;
  *qt = w+2;                     // w+2: address of t1;
  *kt = k;           
  if(postfix) *postfix = g->postfix; goto ret;
 } // if(dclname(z,&g,&w))
 if(abtbvar(f,&d) || freevar(f) || boundvar(f))              // {...,f, ...; ..., f in t1; ... ; ...}
 {                              // d not used;
  tf = tp(f);
  M:  hl = isrt(tf,zfn,&w);       // t1 = fn(d,tr) or fn(t1#t2,tr) or fn(t1,t2, ... ,tr)
  // if(hl==0) hl = isrt(tf,zFn,&w);
  if(mm) ipp("tpon: abt or dcl0 name f= ", f, " tf= ", tf, " hl= ", hl);
  if(hl==3)
  {
   m = mel(w[1]);
   if(m==abt)                 // t1 = fn(d, w[2]
   {                          // d = w[1]
    *kt = typd(w[1], types);  // kt = kmain(d), types: t1,t2, ... , tk;
    types[*kt] = w[2];        // result type = w[2]
    *qt = types; goto ret;
   } // if(m==abt)
   if(fnt2h(w[1],zdp,&g,&q))  // t1 = fn(A1#A2,B);
   { 
    *qt = types; 
    types[0] = q[1]; types[1] = q[2]; types[2] = w[2]; // q[1]=A1, q[2]=A2, w[2]=B;
    *kt = 2; goto ret; 
   } // if(fnt2h(w[1],...)
  } // if(hl==3)
  if(hl >= 3)                // t1 = fn(t1,t2, ..., tr);
  {
   *qt = w+1;                // w+1 points to t1;
   *kt = hl-2;               // minus fn,tr;
   goto ret;
  }  // if(hl >= 3)
 } // if(abtvar(f,&d)) 
 ipp("tpon: wrong type of f= ", f, " tf= ", tf);  // , " w[1]= ", w[1], "\nd= ", d);  // ??? t = fn(d,B); ???
 /* t1 = typ(f);  // t1 != zel: f is pfs bvar // was typbvar(f);
 if(fnt2h(t1,zfn, &g,&w))
 {
  if(g->l == 3 && mel(w[1]) == abt)
  {
   *kt = typd(w[1], types);  types[*kt] = w[2]; *qt = types; 
   goto ret;
  } // if(g->l == 3 ... )
  *qt = w+1; *kt = int(g->l)-2; goto ret;
 } // if(fnt2h(t1,zfn, &g,&w))
 if(t1 != zel)
 { 
  *qt = types; *kt = 1; types[0] = t1; types[1] = zany; 
  if(mm) ipp("tpon: last case: t1= ", t1);
  goto ret; 
 } // if(t1 != zel)
 if(mm) ipp("tpon: not dclname, not abtbvar, not qbvar, f= ", f);
 */
 ret1: r = false; *kt = 0; *qt = types; types[0] = zel;
 ret: if(mm) ipp("-tpon: f= ", f," r= ", r, " *qt= ", *qt, *kt-1);
      return r;
} // end tpon

   elem ron(elem z, headp h, elemp q, elem x)  // z = f(q1,...,qk), resolve overname f=q[0]
{                                              // exclding x
 elem f,f1,t,tx,A, r = zel; headp g; elemp qt,w; bool postfix;  // bl b,b1;
 int i,j,k1, hl=int(h->l),k = hl-1, m, saveitt = ptt->itt, savemm=mm; // saveff=ff;; 
 elem tpq[maxvars];  // tpq[i] = typ(qi);  types of q1,q2, ... ,qk; tpq[0] not used;
 // if(stad1 != 0 && z.ad==stad1)
 // mm=1;
 if(mm) ipp("\n----------+ron: z= ", z, " x= ", x, " itt= ", saveitt, " h->t= ", h->t);
 if(k >= maxvars) error("ron: k >= maxvars, z= ", z, " k= ", k, " maxvars= ", maxvars);
 if(h->tp != zel) error("ron: wrong (not zel) h->tp, z= ", z, " h->tp= ", h->tp);
 if(ivin==1 && !overname(vin[1]))  // r = dclname(z) || abtbvar(z ???
 { 
  if(mm) ipp("ron:ivin==1 && !overname(vin[1]):q[0] = vin[0], z= ", z, " vin[0]= ", vin[0], " vin[1]= ", vin[1]);
  q[0] = vin[0];                   x.i = 0; prp(" ", x, pfhis); prp(" ", x);
  r = typ(z);
  goto ret;
 }  // if(ivin==1 ...)
 for(i=1; i<=k; i++){ tpq[i] = typ0(q[i]); if(mm){ *pfhis<<"\nron:tpq["<<i<<"]= "; prp(tpq[i], pfhis); } }
 for(i=0; i<=ivin; i++)
 {
  f = vin[i]; 
  if(mm) ipp("\n---------ron:for: f= ", f, " def= ", nami(f,0), " i= ", i);
  if(postfixname(f))
  { 
   if(mm) ipp("ron: skipping postfixname:they currently cannot be overloaded, f= ", f); 
   continue;
  } // if(postfixname(f))
  if(f == x)  // !overname(y) ||
  {
   if(mm) ippelm("ron:for: skipping y==x, x= ", x);
   continue; 
  } // if(f == x) 
  if(f.i == 0) t = tph(f); else t = tp(f); // tph(f) = h->tp; // t for f(dfg) is fn(group,group);
  if(fnt2(t,zfn,&A,&x))
  {
   if(h->l==2)
   {
    tx = typ(q[1]);                               // tx = dom(h); // q[1] = x; // A = elg.G;
    if(tx==A || fnt1(tx, zdom, &f1) && f1==f)     // q: actuals !  // t for h: fn(elg.G, elg.G1) 
    { 
     if(mm) ipp("ron: success! case f(x) & typ(f) = fn(type(x),Y), f= ", f, "\nt= ", t, "\ntx= ", tx, " A= ", A);
     goto Changeq_0;
    } // 
   } // if(h->l==2 && ...)

   if(mel(A)==abt && ismd(A,q,k))
   {
    if(mm) ipp("ron: success! fnd case: z= ", z, " t= ", t, " itt= ", ptt->itt);
    Changeq_0: 
    q[0] = f;                                          // changing term in tabt !!! must add it to har:
    // if(z.ad == stad2){ ipp("ron:1 before findtabt, z= ", z);  ff= 1; }
    ptt->findtabt(hl,q,'h',z.ad);
    // ff = saveff;
    r = x; h->tp = r; goto ret;
   } // if(mel(A)==abt && ...)
  } // if(fnt2(t,zfn, ...))
  
  if(!tpon(f,&qt,&k1,&postfix))    // tpon calculates the input types for the current candidate f in qt;
  {
   pvin();
   ipp("ron: wrong overname f= ", f);  // dcl[f,t1,...,tk1,tr];
  } // if(!tpon(y,...)
  if(k != k1)
  { 
   if(mm) ipp("ron:for: does not fit:  k!=k1, z= ", z, " f= ", f, " k(z)= ", k, " k1(f)= ", k1);
   continue;                 // same as goto Nexti; 
  } // if(k != k1)
  for(j=0; j<k; j++)         // compare tpq and qt, must tpq[j+1] <: qt[j];
  {
   elem ta = tpq[j+1];       // ta: is actual type, ta = typ(q[j+1]);
   elem tc = qt[j];          // tc is a candidate type (from input types for the current candidate f)
   elem a = q[j+1];          // a is the actual argument;
   elem d;
   if(ta==zany && (d = htbv(a)) != zel && mel(d) == abt) ta = trm1(zP,a,zset);  // move to tp? 2022.11.16;
   if(mm) ipp("ron:for:for(j) ta= ", ta, "\ntc= ", tc, " a= ", a);
   // if(b.lev+1 != b1.lev){ ipp("ron: disj: b(y).lev+1 != b1(y).lev, z= ", z, "\ny= ", y, "\nt1= ", t1); goto Nexti; }
   
   if(root(a) == zcrlf && blev(tc).lev == 1) goto Nexti;  // !! L05b := {e.G1} <: elg.ImG;  a = {e.G1}, tc = group;
   if(PP1(a) && tc==zgroup) goto Nexti;        // ??? temporarily !!! 12.6.21
   if(ta==tc) continue;
   if(ta==zbool || tc==zbool) goto Nexti;
   if(istr2(zin,a,tc)) continue;
   if(disjoint(ta,tc))
   {
    if(mm) ipp("ron: disjoint ta and tc, f= ", f, " ta= ", ta, " tc= ", tc);
    goto Nexti; 
   } // if(disjoint(t,t1))
   // if(tead) ipp("ron: before typcmpr, t1= ", t1, "\ntz= ", tz, " y= ", y, " f= ", f, " itt= ", ptt->itt);
   m = typcmpr1(tc,&ta,a);
   // if(tead) ipp("ron: after typcmpr, t1= ", t1, "\ntz= ", tz, " y= ", y, " f= ", f, " itt= ", ptt->itt);
   if(m==1) continue;     // ok, ta <: tc is true; continue to check other parameters;
   if(m==0) goto Nexti;   // disjoint, f does not fit;
   // if(istr2(zincl,tz,t1)) continue;
   if(mm) ipp("ron: cannot resolve current f, z= ", z, " f= ", f, "\nta= ", ta, "\ntc= ", tc); 
   goto Nexti;
  } // for(j) 
  // if(mm) ipp("ron: success !!!, z= ", z, " f= ", f);
  if(bool(h->postfix) != postfix)
  { 
   if(mm) ipp("ron diff. postfixes, z= ", z, "f= ", f, " h->postfix= ", h->postfix, " postfix= ", postfix); 
   continue;
  } // if(bool(h->postfix) != postfix)

  /* if(mm) ipp("-ron:for: after disjoint: k= ", k);
  for(j=0; j<k; j++)
   if(!fit(q[j+1], qt[j], false))
   {
    if(mm) ipp("ron: q[j+1]: not fit qt[j], z= ", z, "\nq[j+1]= ", q[j+1], "\nqt[j]= ", qt[j], "\nj= ", j);
    goto Nexti;
   } // if(!fit(q[j+1], qt[j], false))
  */
  q[0] = f;                                 //success: changing term in tabt !!! must add it to har:
  if(mm) ipp("ron: success !!!, z= ", z, " f= ", f);
  ptt->findtabt(hl,q,'h',z.ad);
  r = qt[k1]; h->tp = r; 
  if(dclname(f,&g,&w)){ x = ptd(z,h,q,g,w); if(x != zel){ r = x; h->tp = r; } }
   goto ret;
  // if(h->t==ctruth) mktr(q[1], ctruth);   // if(q[0]==zexc1) mktr(q[1]); goto ret;                               // fit !!!
  Nexti:;
 } // for(i)
 ret: if(mm) ipp("-ron: z= ", z, " r= ", r, "\nditt= ", ptt->itt - saveitt); mm = savemm;
      return r;
} // end elem ron

  elem typmeth(elem z, headp h, elemp q) // q = Thomsbg(M1,f,H); M1 in GG1, f in hom.M1, H in dHG.f; h->l=4;
{
 elem r=zel, Q=q[0],t,t1,d,scpd,D0,D1,M0,M1,v=zel; headp g; ats k = h->l - 1;  // 2: 3 parameters: 0..2;
 if(mm) ipp("\n+typmeth: z= ", z); int static count2 = 0;
 if(k==1){ r = mdt(z, h, 0); goto ret; }                              // h->l == 2: one parameter;
 d = scopeden(Q); scpd = scopeden(d);         // was d = scope(Q);
 if(!h->adt) ipp("typmeth: !h->adt, z= ", z); // was error;
 if(!fnt2(q[1], zdcol, &D0,&D1)) goto Model;
 if(k != 3) error("typmeth: k != 3: curretntly this case is not imp-ed yet, z= ", z, " k= ", k);
 M0 = q[2]; M1 = q[3];                          // z = Q(A::B, a,b);
 if(!In(M0,D0)) error("typmeth:: !In(M0,D0) z= ", z, "\nD0= ", D0, "\nM0= ", M0);
 t1 = trm2(zdot,D1,M0,zel);  // zany);   // zany): ERROR, no typ(r) and therefore, no val !!!; 
 if(!In(M1,t1)) error("typmeth:: !In(M1,D1.M0) z= ", z, "\nt1= ", t1, "\nM1= ", M1);
 t = typ(Q); r = t; goto ret;    // r = Vmt(t?) or r = Vdt(t?);

 Model:
 if(d==zel || d==zel1 || ! Dterm(d)) error("typmeth: wrong s=scope(Q), z= ", z, " Q= ", Q, " d= ", d);
 if(mm) ipp("typmeth before ismd, z= ", z, " d= ", d, " scpd= ", scpd, "\nq[0]= ", q[0], " q[1]= ", q[1]);
 if(!ismd(d,q,k)) error("typmeth: not model, z= ", z, " d= ", d, " k= ", k); 
 t = typ(Q); r = Repq(t,d,q,k); ++count2;
 v = Repq(Q,d,q,k); 
 wrval(z,h,q,v);    // was q[h->l] = v; h->v = 1;
 ret: if(Truth(Q)){ h->t = truth; if(mel(v,&g)==pfs) g->t = truth; }
 if(mm) ipp("-typmeth: z= ", z," r= ", r, "\nv= ",v, " h->v= ", h->v, " count2= ", count2);  h->adt = 1;
 return r;
} // end elem typmeth
                                                 // vdt vs mdt ??? 
  elem mdt(elem z, headp h, int p)               // common part of typdot(p=1) and typmeth(p=0); 
{    // used only in typdot,typmeth,typidu;      // m: method m for dot term  Q.M or adt term Q(M); 
 elem r, m=zel,d=zel999,dQ=zel999,M1=zel999,t1,v=zel; ats a; headp g; elemp q = &(h->son[0]); sbst s; // Q1,
 elem Q = q[p], M = q[p+1]; int hl = h->l;      // z is a vterm Q.M (p=1) or Q(M) (p=0);
 if(mm) ipp("+mdt z= ", z, "\nQ= ", Q, " M= ", M, " p= ", p); 
 r = h->tp;
 if(r != zel) goto ret; 
 if(idubs(Q,&a))             // below r==zel;
 {
  d = abtyp(M,&M1);
  if(d==zel){ ipp("mdt: wrong M, z= ", z, " M= ", M); goto ret; }     // r==zel already;
  m =  fdent1t(a,d); // search a in Den with scope d; // d = fingroup;
  if(mm) ipp("mdt: after fdent1: z= ", z, " d= ", d, " M= ", M, " Q= ", Q);  
  if(m==zel)
  { 
   if(mm) ipp("mdt: fdent1 did not find Q= ", Q, " in scope= ", d, " M= ", M);
   d = typlot(M);
   if(d==zel){ ipp("mdt: d=zel after typlot(M), z= ", z, " M= ", M); goto ret; }
   m =  fdent1t(a,d); // search a in Den with scope d;
   if(m==zel)
   { 
    if(mm) ipp("mdt: in another search with scope from typlot, fdent1 did not find Q = ", Q, " scope= ", d, " M= ", M);
    goto ret;
   } //  if(m==zel)
  } // if(m==zel)
  if(mm) ipp("mdt: changing q[p] to m, z= ", z, " q[p]= ", q[p], " m= ", m, " p= ", p);
  q[p] = m;  Q = m;          // changing term in tabt !!! must add it to har:
  ptt->findtabt(hl,q,'h',z.ad);
  if(mm) ipp("mdt: changed q[p] on m= ", m, " new z= ", z);   
  goto Found_m; 
 } // if(idubs(Q,&a))         // checking Thomsbg(H):
 typ(Q);                      // because idubs in Q were not resolved;
 dQ = scope(Q);               // scope(Thomsbg) = dHG, ! H in dHG.fc;
	if(dQ==zel) error("mdt: scope(Q)=zel, \nz= ", z, "\nQ= ", Q);

 Found_m: if(mm) ipp("mdt: m found, Q= ", Q, "\nM= ", M, "\nm= ", m, "\nd= ", d, " dQ= ", dQ);
 s.HostMod(Q,M);         // from vdt; 
 s.stqab.init();       // s.istqab = -1; 
 if(typ(Q)==zbool) trtr(Q,z); // transfer truth from m to z;
 t1 = typ(Q); 
 s.stqab.init();       //s.istqab = -1; ??? twice ???
 if(mm) s.prHostMod("mdt: after s.HostMod(Q,M), t1= ", t1);  // , " s= ", s);
 if(mm) pntu->prach("mdt:C2b", z);                   // is z(y)

 // p_above_is_x = fnt1(pntu->above(), zis, &x) && x==z; // && fnt2(Q,zA, &d,&P) && mel(d,&g,&w)==abt && g->name != noname;
 // if(mm) ipp("mdt:p_above z= ", z, " x= ", x, " p_above_is_x= ", p_above_is_x);
 // if(p_above_is_x || x != z) // because eqdot; // because eqdot; is z; is Q.M; // above: iach-1

 if(trivdt(z,Q,M)) v = Q;      // trivial dot term Q.M: Gr.H = Gr ;
 else   
 {
  if(mm) ipp("mdt:before v = s.rep(Q) z= ", z, " Q= ", Q);
  // ats name = namet(Q, &g);         // to prevent rep(Gr) = Gr.K;
  // if(name != noname) g->name = noname;
  v = s.rep(Q, "v = s.rep(Q) in mdt");    // 2(not used) : if( Q is A[d,P], then goto inside of named d (discarding the name of d);
  // g->name = name;
 } // else
 wrval(z,h,q,v);  
 if(Truth(Q) && mel(v,&g)==pfs){ mktr(v); g->t = 1; }  // ??? mktr ???               
 if(mm) ipp("mdt:before r = s.rep(t1) z= ", z, "\nQ= ", Q, " t1= ", t1);
 r = s.rep(t1, "r = s.rep(t1 in -mdt");  // ,1);      
	h->tp = r;  
 // chiMod("-mdt", -1);                       // iMod = -1; 
 ret: if(r==zel) ipp("mdt: wrong dot or adt term z (wrong method), z= ", z);
      if(mm) ipp("-mdt z= ", z, "\nQ= ", Q, " M= ", M, "\nv=  ", v, "\nr= ", r);
      return r;
} // end  mdt;

   elem inddot(elem T, elem d, elem M) // T:thms(z) is M in d or T is a=b and typ(other(z,a,b))=d (r=zel1)
{   // used only in moddot;            //  or T is M in d.M1 (r= M1) else r = zel; // g in hom(G1,G2): M=g, d=hom;
 elem r=zel, a,b,d1; int k; headp h,g; elemp q,w;
 if(mm) ipp("+inddot T= ", T, "\nd= ", d, " M= ", M);    
 if(mel(T,&g,&w) != pfs) error("inddot: T in thms*z): wrong mel(T), \nT= ", T, "\nd= ", d, "\nM= ", M);
 if(g->l != 3) goto ret;
 a = w[1]; b = w[2];
 
 if(w[0]==zin)                                // was if(!fnt2(x,zin,&M1, &d1)) goto ret;  
 {
  if(mm) ipp("inddot:in: T= ", T, " a= ", a, " b= ", b);
  if(b==d && a==M){ r = zel1; goto ret; }                   // zel1: theorem T is M in d;
  if(mel(b,&h,&q) != pfs || (k=h->l) != 3) goto ret; 
  if(q[0]==zdot){ if(q[1]==d) r = q[2]; goto ret; } // was if(fnt2(d1,zdot,&d1,&M1) && d1==d) r = M1;
  if(q[0]==d)
  {
   d1 = scope(d);
   if(mm) ipp("inddot: b is a possible adt term,T= ", T, " b= ", b, "\nd= ", d, " d1= ", d1);
   if(!(h->adt)) error("inddot: not adt term, T= ", T, "\nd= ", d, " M= ", M, " b= ", b); // d = 
   typ(d); // to be sure that [
    r = trmseq(k-1, q+1);
   if(mel(r,&h,&q) != pfs) error("inddot: wrong mel(r), T= ", T, "\nd= ", d, "\nM= ", M, "\nr= ", r);
   h->tp = d1;
  } // if(q[0]==d)
  goto ret;
 } // if(w[0]==zin)

 if(w[0]==zeq)
 {
  if(mm) ipp("inddot:eq: T= ", T, " a= ", a, " b= ", b);
  elem x = other(M,a,b);
  if(x==zel) goto ret;  // error("inddot: theorem T is a==b, but M != a and M != b, M= ", M, "\nT= ", T);
  elem t = typ(x); 
  if(t==d) r = zel1;                                // goto ret;
  } // if(w[0]==zeq
 ret: if(mm) ipp("-inddot T= ", T, " d= ", d, " M= ", M, "\nr= ", r);
      return r;
} // elem inddot;               //  M in d(m1, ..., mk) == M in d.[m1, ..., mk];
                                // addedd 3.9.22: or M in d(m1, ..., mk), will be created M1=[m1, ..., mk], r=M1;
   elem moddot(elem d, elem M)  // look for a theorem M in d(r = zel1) or M in d.M1 (r = M1) else r = zel;
{        //  ats thmbase(elem z, elemp* base)   // returns the size of the theorem block and theorem base;
 elem r=zel, T,t,d1,M1; ats i,k; headp h; elemp q;         // moddot replaces abtyp in hostmod;
 if(mm) ipp("+moddot d= ", d, " M= ", M);
 if(d==zel || d==zel1) error("moddot: wrong d(d==zel || d==zel1), d= ", d, " M= ", M); 
 if(istr2(zin,M,d) || istrin(M,d) ){ r = zel1; goto ret; }
 t = typ(M);
  if(t==d || istr2(zincl,t,d)){ r = zel1; goto ret; } 
 if(mel(t,&h,&q) == pfs && (q[0]==zfn)) t = zFN;    // see more general in abtyp;                        // used M in typ(M);
 if(fnt2(t,zdot,&d1,&M1) && d1==d){ r = M1; goto ret; }

 k = thmbase(M,&q);    //  look for a theorem M in d(r = zel1) or M in d.M1 (r = M1) else r = zel;
 for(i=0; i<k && (T=q[i]) != zel; i++)
 {
  r = inddot(T,d,M);    // T is M in d or T is z=z1 & z=M(or z1=M) & typ(z1(r=zel1) or M in d.M1(r=M1);
  if(r != zel) goto ret;                  // or M in d(m1, ...mk) // hom(Gr1, Gr2);
 } // for(i=0)

 for(i=0; i<=ilot; i++)
 {
  r = inddot(lot[i],d,M);    // T is M in d(r=zel1) or M in d.M1(r=M1);
  if(r != zel) goto ret;
 } // for(i=0)
 ret: if(mm) ipp("-moddot d= ", d, " M= ", M, " r= ", r);
      return r;
} // end moddot;

   elem abt_thm(elem z, bool p, elemp M2) // p:false:looking in z-theorems for a theorem of the form z in d or z=z1;
{                                         // p:true: look in z-theorems for a theorem of the form z in Q.M
 elem r=zel, a,b,y,Q,M; ats i,k; elemp q,w; headp g; 
 if(mm) ipp("+abt_thm z= ", z, " p= ", p);
 k = thmbase(z, &q);  // in abt_thm: p:false:looking in z-theorems for a theorem of the form z in d or z=z1; or z in Q.M;
 for(i=0; i<k && (y=q[i]) != zel; i++)
 {
  if(mm) ipp("abt_thm:for: y= ", y, " i= ", i);
  if(mel(y,&g,&w) != pfs) error("abt_thm: y in thms*z): wrong mel(y), z= ", z, "\ny= ", y);
  if(g->l != 3) continue;
  a = w[1]; b = w[2];
 
  if(w[0]==zin) 
  {
   if(mm) ipp("abt_thm:for:in: y= ", y, " a= ", a, " b= ", b);
   if(a != z) continue;
   if(p){ if(fnt2(b,zdot,&Q,&M)){ r = Q; if(M2) *M2 = M; break; }  continue; }
   if(mel(b) == abt){ r = b; break; }
   continue;
  } // if(fnt2(y,zin,&a,&b))

  if(w[0]==zeq)
  {
   if(mm) ipp("abt_thm:for:eq: y= ", y, " a= ", a, " b= ", b);
   if(a==z){ r = typ(b); if(mel(r)==abt) break; continue; }
   if(b==z){ r = typ(a); if(mel(r)==abt) break; continue; }
   ipp("abt_thm: theorem y is a==b, z != a and z != b, z= ", z, "\ny= ", y);
  } // if(w[0]==zeq)
 } // for(i)
 if(mm) ipp("-abt_thm z= ", z, " r= ", r, " p= ", p);
 return r;
} // end elem abt_thm(elem z)
                                        // d denotes abt-term, D ::= d | D&&P | D&&d1;
   bool gabt(elem t, elemp M, elemp d)  // t is a general abt-term:  D-term  or D.M; 
{                                       // t ~ D: r = true, *M = zel, *d = t;
 headp h,g; elemp q,w; bool r=false;    // t ~ Q.M : r = (Q is D-term), *M = M, *d = Q;
 int m = mel(t,&h,&q);                  // z = hom.M2 -> *M=M2, *d=hom, r=true;
 if(mm) ipp("+gabt: t= ", t, " d= ", int(d)); // z = GG1 -> *M = zel, *d = GG1, r=true;
 if(m==abt) goto M_true;                // 
 if(m==pfs)
 {
  if(q[0]==zdconj) goto M_true;        // D&&P or D&&d
  if(q[0]==zdot)
  {
   m = mel(q[1], &g, &w);
   r = (m==abt || m==pfs && w[0]==zdconj);
   if(r)
   { 
    if(M) *M = q[2]; if(d) *d = q[1];
    if(mm) ipp("gabt: t is a dot- or &&-term, t= ", t, " d= ", q[1]);
   } // if(r)
   goto ret;
  } // if(q[0]==zdot)
 } // if(m==pfs)
 r = false; if(M) *M = zel; if(d) *d = zel;
 ret: if(mm) ipp("-gabt: t= ", t, "\nM= ", M==0?zel:*M, "\nd= ", d==0?zel:*d, " r= ", r);
 return r;
 M_true: r = true; if(M) *M = zel; if(d) *d = t; goto ret;
} // bool gabt
                                        // typ(z) must me d(abt term) or d&P or d.M; otherwise search for such a type;
   elem abtyp(elem z, elemp M)          // t:=typ(z) is D-term: r = t; *M = zel);  // or fntype: see below;    
{                                       // t is D.M: r = D; *M = M; 
 elem r = zel, d=zel; bool p; headp h;  // g in hom.M2, z = g -> *M = M2,  r=hom;
 if(M) *M = zel;                        // z=M2 -> r = GG1, *M=zel;
 if(mm) ipp("+abtyp: z= ", z);
 r = typ(z);                            // d denotes abt term, D ::= d | D&&P | D&&d1;
 p = gabt(r,M,&d);                      // gabt checks if r is D-term or D.M: see above;
 if(r!=zel && p){r = d; goto ret; }     // gabt found that r is D-term or D.M;
 if(fntype(r)){ r = zFN; goto ret; }    // added on 2021.03.14
 r = abt_thm(z);                        // look in thm(z) for z in abt term or z=z1 and typ(z) is ;
 if(r!=zel)
 {
  if(M) *M = zel;
  if(mm) ipp("abtyp: abt_thm found abtyp r, z= ", z, " r= ", r);
  goto ret;
 } // if(r!=zel)  
 r = typtlot(z);                        // if abt_thm(z) was unsuccessful, then try typtlot(z)           
 // if(r==zel) r = typt(z);             // only in the last case M,d parameters assigned M,d
 if(r!=zel && gabt(r,M,&d))             // r is D.M: d=D, *M = M;
 {                                      // r is D: d=D, *M=zel;
  if(mm)  ipp("abtyp: typtlot found abtyp r, z= ", z, " r= ", r, " d(r)= ", d);
  r = d; goto ret; 
 } // if(r!=zel && gabt(r,M,&d))        // in other cases *M,*d = zel;
 if(mel(z,&h) == bvar && h->tel==abt && kmain(h)==1) // T:={x; P(x)}: abtyp(x)=T;
 { 
  r = htbv(z); if(M) *M = zel;
  if(mm) ipp("abtyp: z is bvar:abt1, z= ", z, " r= ", r);
  goto ret; 
 } // if(mel(z,&h) == bvar ...)
 r = zel; if(M) *M = zel; 
 ret: if(mm) ipp("-abtyp: z= ", z, " r= ", r, "\nM= ", r!=zel && M!=0? *M : zel);
 return r;
} // end abtyp

 void sbst::HostMod(elem Q, elem M)   // Q,M from Q.M, calculation of Host,Mod; ker.g: Q=ker, M=g;
{                               // ker.g:  g in hom.M2; M2 in GG1; 
 elem Sc=scope(Q), M1, M0=M; int i=0;  // chiMod("+HostMod", -1); // iMod = -1;   
 if(mm) ipp("\n+HostMod: Q.M: Q= ", Q, " M= ", M, " Sc(Q)= ", Sc);
 if(Sc==zel || Sc==zel1) error("HostMod: wrong Sc=scope(Q), Q= ", Q, " M= ", M, " Sc= ", Sc);
 do    // while(M0 != zel)              // 1: M0=g; 2: M0=M2; 3: M0=zel: finish!
 {
  // ker(g): g in hom(Gr, H*N/N): form M2 = [Gr, H*N/N]
  // d = abtyp(M0, &Mi); //, &d1);  // 1: M0=g, Mi=M2, d1=hom, d= hom.M2; 2: M0=M2,Mi=zel,d1=GG1;
  M1 = moddot(Sc,M0); // look for a theorem M0 in Sc(r = zel1) or M0? in d.M1 (r = M1) else r = zel; // or M0 in Q?(...) 
  if(M1==zel) error("HostMod: wrong dot(adt) term Q.M, M0 is not in Sc, Q= ", Q, "\nM= ", M, "\nSc= ", Sc, "\nM0= ", M0);
  if(mm) ipp("HostMod after moddot, Sc= ", Sc, " M0= ", M0, " M1= ", M1, " i= ", ++i);
  wrHostMod(Sc,M0); 
  M0 = M1;
  Sc = scopeden(Sc);
  // Sc = scope(Q0);  // 1: H=ker, Sc=hom; 2: H=hom, Sc=GG1;
  // if(Sc != d && !istr2(zin,M0,Sc) && (Q2 = abt_thm(M0,true,&M2)) != Sc)
  // {
  // Sc1 = scopeden(Sc);     // case Axisnormal.Grk  10.29.20
  // if(Sc1==d) Sc = Sc1;
  // else {
  //  prHostMod(" Q= ", Q, " M= ", M);
  //  error("HostMod: Sc=scope(Q0) != d or scopeden(Sc) != d, \nM0= ", M0, 
  //          "\nM= ", M, "\nQ0= ", Q0, "\nSc= ", Sc, "\nd:abtyp(M0)= ", d); // was error;
  // } // else {
  //} // 	if(Sc != d && ...)
  // wrHostMod(Sc,M0);
  // 1: Host[0] = hom, Mod[0]=g; 2: Host[1]=GG1, Mod[1]=M2;
		// if(M2==zel){ Q0 = d; M0 = Mi; } else { Q0 = Q2; M0 = M2; }
 }  
 while(M1 != zel1);        // zel1: M in d, not M in d.M2;

	if(mm) ipp("-HostMod: Q.M: Q= ", Q, " M= ", M, " iMod= ", iMod);
 if(mm) prHostMod("-HostMod ");
	//if(mm) prlist("-HostMod: Host= ", Host, iMod); 
	//if(mm) prlist("-HostMod: Mod= ", Mod, iMod);
} // void HostMod  
                                       
                                 // method is always a NAMED term. // r=0: R is not a method, M=zel;
  att sbst::method(elem R, elem* aM, elem* aM0)  // r=1: VSmethod, M0=Mod[i], M=value R in M0;
{                                // r=2: R is a NVSmethod, M is the model for R.M from HostMod; 
  att r=0; elem S,H,M0,htbvR; int i,k,p,kd; // elemp q;   // for vdt in hnis,reduction: pHM=1;
 if(mm){ ipp("+method: R= ", R); prHostMod("+method"); }
 S = scopeden(R); htbvR = htbv(R);
 if(mm) ipp("method: scopeden(R): S= ", S);        // S = HK;
 if(R.ad==stad2)  
 mm=mm;                                  
 if(S==zel1 || S==zel || freevar(R))
 { 
  if(mm) prHostMod("S==zel1 || S==zel || freevar(R))"); 
  if(mm) ipp("method: unnamed R= ", R, " S= ", S); 
  goto ret0; // r=0 for unnamed composite terms; 
 }  // if(S==zel1 || S==zel)   
 for(i=0; i<=iMod; i++)
 {
  H = Host[i]; M0 = Mod[i];                       // H = HK;
  kd = lind(H); 
  if(inList(htbvR,Dd,iDd,&k))                   // case 1: R is a very simple method;
  {
   p = dispDd[k];                                // 
   // if(p == -1) continue;                      // error
   if(mm) ipp("method: R is a VS method: found htbv(R) in Dd, R= ",R, "\nS= ", S, " H= ", H, " i= ", i, " p= ", p);
   r = 1;   
   if(aM) *aM =  valm4(M0, H, kd,  R.i + p);  // 3,4: seqtype (seqname); // fntype(S)==3,4? M: moved to valm4;
   if(aM0 != 0) *aM0 = M0;                        // M0 = Mod[i];
   goto ret;   // r=1: VS method;
  } // if(inlist((htbvR,Dd,iDd,&k)) 
  
  if(inList(S,D,iD))                             // case 2: S in H;
  {
   if(mm) ipp("method: R is a NVS method in H: found S in D, R= ",R, "\nS= ", S, " H= ", H, " i= ", i);
   r = 2; 
   if(aM) *aM = M0; goto ret;
  } // if(inlist((S,D,iD))
  
  if(H==S && htbvR != H)                         // case3 ??? lind did not found it ??? 9.15.22
  { 
   if(mm) ipp("method: R is a NVS method in H: found S in Host, R= ",R, "\nS= ", S, " M0= ", M0, " H= ", H, " i= ", i);
   r = 2; 
   if(aM) *aM = M0; goto ret;
  } // if(H==S && htbvR != H)

  if(mm) ipp("method: S(R) is not in D, R= ",R, "\nS(R)= ", S, " Host[i]= ", H, " i= ", i);  // case 3 S is not in H;  
  if(DinD(S,H))
  { 
   if(mm) ipp("method: DinD(S,H, R= ",R, "\nS= ", S, " M0= ", M0, " H= ", H, " i= ", i);
   r = 2; 
   if(aM) *aM = M0; goto ret;
  } // if(H==S && htbvR != H)
 } // for(i)
 if(mm)
 {
  prHostMod("method: is not in Host");
  ipp("method: not method: R and S(R) is not in Host, R= ",R, "\nS= ", S, " i= ", i); // case 3 S is not in Host;  
 } // if(mm) 
 ret0: r = 0;  if(aM) *aM = zel;              
 ret: if(mm) ipp("-method: R= ", R, " *aM= ", aM? *aM: zel999, " r= ", r);
 return r;
} // end att method(elem R, elem* aM) // pHM=1: look in rep for all named methods,
                                      // old: pHM=2: look for only simple methods, going inside of all comp.methods;                               

/*   att cmpvt(elem V, headp h, int m, elem V1, int m1, elem W)  // compare vterm V with V1; used in eqdot; // headp h;
{                                            // r=0: not equal, r=1: equal, r=2: unknown;                       
 att a, r=0;  elem Q,Q1,M,M1,M1a, x;
 if(mm) ipp("+cmpvt: V= ", V, " V1= ", V1, "\nW= ", W, " m= ", m, " m1= ", m1);
// a = method(V1, &M1); // a=0: not a method, a=1: VS method, a=2: NVS method;
 if(a==0){ r= 2; goto ret2; }//{ if(req(V,V1)) r = 1; else r = 0; goto ret; } // a=0: V1 is not a method; 
 if(a==1)                           // a=1: V1 is a VS method; ??? else ??
 { 
  if(mm) ipp("cmpvt:a==1, V= ", V, " V1= ", V1, " M1= ", M1);
  if(req(V,M1) || equal(V,M1) ) goto ret1;
 } // if(a==1)
 if(vterm(h,&Q,&M))        // V = *.Gr, Q = *, M = Gr;
 { 
  if(mm) ipp("cmpvt: V is a vterm(Q,M), V= ", V, " Q= ", Q, " M= ", M);
  if(Q==V1 && M==W) goto ret1;         // the case V = *.Gr, Q = *, M = Gr;
  // if(vterm(V1, &Q1, &M1a) && Q==Q1 && (M==M1a || M == valHM(M1a) )) goto ret1;  // added on 6.10.20 ??? rework ???
  if(Q==V1 && M==M1) goto ret1;   // ??? rework ??? 10/19/20
 } // if(vterm(h,&Q,&M))         
 if(a==2) goto ret2;                             // a=2: V1 is a NVS method;
 if(mm) ipp("cmpvt: hard case: V= ", V, " V1= ", V1, " m= ", m, " m1= ", m1);
 if(simple(m) || simple(m1) || m != m1)            // ???
 {
  M = M1;
  if(mm) ipp("cmpvt: now looking for a theorem V=V1.M,  M= ", M, "\nV= ", V, " V1= ", V1); 
  x = trm2(zdot,V1,M);
  if(istr2c(zeq, V, x) || istr2c(zeq,x,V))
  {
   if(mm) ipp("cmpvt: r=1: found truth V = V1.M, V= ", V, " V1= ", V1, " M= ", M); goto ret1;
  } // if(istr2c(zeq, V, x) || ...)
  if(mm) ipp("cmpvt: r=0: cause: simple(m) || simple(m1) || m != m1, V= ",V," V1= ",V1," m= ",m," m1= ",m1);
  goto ret;
 } // if(simple(m) || simple(m1) || m != m1)
 if(mm) ipp("cmpvt: r=2: composite NOT method V1: need for further comparations, V= ", V, " V1= ", V1);
 ret2: r = 2; goto ret;   // ??? see if(a==0){ if(req(V,V1) ...  above;
 ret1: r = 1;
 ret: if(mm) ipp("-cmpvt: V= ", V, "V1= ", V1, " r= ", r);
 return r;
} // end  att cmpvt(elem V, int m, elem V1, int m1)
*/
  elem vdt(elem z, elem Q, elem M, int pHM,int dpth)    // value of dot term z = Q.M; (or z=Q(M));
{                                             // z is used only for printing and return;
 elem x, r = z; headp h; elemp q;  sbst s;  
 if(mm) ipp("+vdt: z= ", z, "\nQ= ", Q, "\nM= ", M, " mm ", mm); // " dpth= ", dpth,
 if(mel(z, &h, &q)==pfs && h->v){ ipp("vdt: already h->v, z= ", z); r = valrt(z,h,q); goto ret; }
 s.HostMod(Q, M);                                                      // normally, pHM=1;
 s.stqab.init();  // s.istqab = -1; 
 if(seqv(M) || s.iMod >= 0)
 {
  x = s.rep(Q, "vdt");  // , pHM); // , dpth);  // rework ???
  // if(x != Q || iMod==0 && htbv(Mod[0])==Host[0]) r = x; // 01.01.20 : Added || ... because LH4.H = H;
  if(x != Q) r = x;
 } // if(seqv(M)...)
 if(r!=Q) trtr(Q,r);       // transfer truth from Q to r;
 ret: if(mm)ipp("-vdt: z= ", z, "\nQ= ", Q, "\nM= ", M, "\nr= ", r);   // chiMod("-vdt", -1);  // iMod = -1;
 return r;
} // elem vdt

  elem Vdt(elem z, headp h, elemp q, elem Q, elem M)  // vdt expanded for method terms with more than 1 params;
{
 elem r,d,t1,D0,D1,M0,M1; int hl1 = h->l - 1; sbst s;
 if(mm) ipp("+Vdt z= ", z, " Q= ", Q, " M= ", M);
 if(h->tp == zel) ipp("Vdt: no type for z= ", z);   //  was error("Vdt:  12.09.21
 if(h->v){ ipp("Vdt: already h->v, z= ", z); r = valrt(z,h,q); goto ret; }
 if(!fnt2(q[1], zdcol, &D0, &D1)) goto Model;         // z: can be R(D0::D1, M0, M1); same as in typmeth;
 if(9 || hl1 != 3) error("Vdt: /*hl1 != 3:*/ currently this case is not imp-ed yet, z= ", z, " hl1= ", hl1);
 M0 = q[2]; M1 = q[3];                                // z = Q(A::B, a,b);
 if(!In(M0,D0)) error("Vdt:: !In(M0,D0) z= ", z, "\nD0= ", D0, "\nM0= ", M0);  // ??? already checked ???
 t1 = trm2(zdot,D1,M0,zel);  // zany): ERROR:  no typ(t1) and hence no val 
 if(!In(M1,t1)) error("Vdt:: !In(M1,D1.M0) z= ", z, "\nt1= ", t1, "\nM1= ", M1);  // ??? already checked ???
 // Host[0] = D0; Mod[0] = M0;
 // Host[1] = D1; Mod[1] = M1;
 // chiMod("Vdt", 1);                                           // iMod = 1;
 s.wrHostMod(D0,M0);
 s.wrHostMod(D1,M1);
 r = s.rep(q[0], "Vdt");  // ,1);                                   // 1: pHM==1: rep(z,1) must use Host and Mod
 goto ret;    
 Model:
 if(q[0]==zdot || hl1==1){ r = vdt(z,Q,M,1); goto ret; }    // hl1==1: 1 parameter;
 d = scope(Q);
 if(mm) ipp("Vdt hl1 != 1: z= ", z, "\nQ= ", Q, "\nd= ", d, " hl1= ", hl1); 
 if(d==zel || d==zel1 || ! Dterm(d)) error("Vdt: wrong s=scope(Q), z= ", z, "\nQ= ", Q, "\nd= ", d);
 if(!ismd(d,q,hl1)) error("isst: not model, z= ", z, "\nd= ", d, " hl1= ", hl1); 
 r = Repq(Q,d,q,hl1);
 if(r!=Q) trtr(Q,r);       // transfer truth from Q to r; 11.23.20
 ret: if(mm) ipp("-Vdt z= ", z, " r= ", r);
      return r;
} // end elem Vdt(elem z,...)
 
  elem typnany(elem z)
{
 elem r = zel;
 if(mm) ipp("+typnany: z= ", z);
 r = typ(z);
 if(Any(r)) r = typtlot(z);
 if(mm) ipp("-typnany: z= ", z, " r= ", r);
 return r;
} // end elem typnany

 att fntype(elem t, elemp t1, elemp t2, elemp f0)  // r=1: t in FNtypes; r=2: t in fntypes; r=0: else;
{            // t is FN, BFN, ..., SEQ, or t is fn(t1,t2) or ... t is afn(t1), ...; f0 is fn,...,afn, ...
 att r=0; headp h,g; elemp q,w; elem tt; ats a; char* s="999";
 if(mm) ipp("+fntype: t= ", t);
 // if(mel(t,&h,&q)!=pfs) goto ret;
 // a = h->name; 
 // if(a==noname) goto ret;   // error("fntype: no name, t= ", t);
 // s = vts(a);                 // (seqname(s))?3:
 if(inseqv(zFNtypes,t))
 { 
  s = strnamet(t);
  r = seqname(s)? 3:1; 
  if(t1) *t1 = zany; if(t2) *t2 = zany; if(f0) *f0 = t;
  goto ret;
 } // if(inseqv(zFNtypes,t))
 if(mel(t,&h,&q)!=pfs){ if(mm) ipp("fntype: mel(t) != pfs, t= ", t); goto ret; }
 if(!dclname(q[0], &g, &w, &a)){ if(mm) ipp("fntype: not dclname in t= ", t, " q[0]= ", q[0]); goto ret; }
 {
  if(inseqv(zfntypes, q[0]))
  {
   s = vts(a);
   r = seqname(s)?4:2;                  // (seqname(s))?3:
   if(t1) *t1 = q[1]; 
   if((h->l==3) && t2)  *t2 = q[2]; else if(t2) *t2 = q[1];
   if(f0) *f0 = q[0];
  } // if(inseqv(zfntypes, q[0]))
 } // if(mel(t,&h,&q)==pfs)
 tt = typ(t);                                            // q[1] != t : because looping in fntype !!! 12.22.20
 if(mel(tt,&h,&q)==pfs && h->l==2 && (q[0]==zP || q[0]==zP1) && q[1] != t) r = fntype(q[1],t1,t2,f0);
 ret: if(mm) ipp("-fntype: t= ", t, "r= ", r);
 return r;
} // end bool fntype

 elem findfunt(elem z)  // find a functional type of z from lot and thms;
{
 elem r1=zel, r = zel; att k; elemp ar; int iar,i;
 if(mm) ipp("+findfunt z= ", z);
 r = typlot(z);
 k = fntype(r);
 if(k==2 || k==4) goto ret;          // r is fn(A,B) or similar;               4: seq,seq1, ...
 if(k==1 || k==3) r1 = r;            // r is FN or similar, see fntype above;  3: SEQ, SEQ1, ...
 iar = inthms2(z,&ar);
 for(i=0; i<=iar; i++)
 {
  r = ar[i];
  k = fntype(r);
  if(k==2 || k==4) goto ret;          // r is fn(A,B) or similar;              4: seq,seq1, ...
  if(k==1 || k==3) r1 = r;            // r is FN or similar, see fntype above; 3: SEQ, SEQ1, ...
 } // for(i) 
 if(r1 != zel) r = r1; 
 ret: if(mm) ipp("-findfunt z= ", z, " r= ", r, " iar= ", iar);
      if(r != zel) ipp("findfunt found r!, z= ", z, " r= ", r);
      return r;
} // end elem findfunt

 elem tpseq1(elem z, elem x, elem t) // z in seq1(t): if(x==0 || x==1 || typ(x)==1..last(z)) r=t;
{
 elem tx,ta,a,b,v, r=t; 
 if(mm) ipp("+tpseq1: z= ", z, " x= ", x, " t= ", t);
 if(x==zel0){ ipp("tpseq1: 0 in dom(z:seq1(t)), z= ", z);  goto ret; }
 if(fnt1(x,zlast,&v) && v==z){ ipp("tpseq1: last(z) in dom(f:seq1(t)), z= ", z); goto ret; }
 tx = typ(x);  // add x:
 if(tp1last(tx,z))     // tx ~ a..last(z);
  { ipp("tpseq1: x:a..last(z) in dom(z:seq1(t)), z= ", z, " x= ", x, " tx= ", tx );  goto ret; }
 if(fnt2(x,zmnint,&a,&b) && b==zel1 )  // x is a-1; // zel1 = 1;
 {
  ta = typ(a);
  if(mm) ipp("tpseq1: a= ", a, " ta= ", ta);
  if(tp1last(ta,z,1))
   { ipp("tpseq1: a:1..last(z) in dom(z:seq1(t), z= ", z, " a= ", a, " ta= ", ta); goto ret; }  // ta ~ 1..last(z)
 } // if(fnt2(x,zmnint,&a,&b))
 r = zel;
 ret: if(mm) ipp("-tpseq1: z= ", z, " x= ", x, " t= ", t, "\nr= ", r);
 return r;
} // end elem tpseq1

 bool tpseq1a(elem z)                          // z is SEQ...1 or SEQ...2 or seq...1(t) or seq...2(t);
{  // char* Name(elem z){ headp h; char* r = 0; if(comp(mel(z,&h)) && h->name != noname) r = vts(h->name); return r; }
 bool r = false; elem R=zel; char* s, s1[4]; char c; size_t l;
 if(mm) ipp("+tpseq1a z= ", z);
 s = Name1(z);
 if(s==0) s = Name1(R = root(z));              // Name1: composite and dcl terms;
 if(s==0)  goto ret;                             // no name;
 l = strlen(s);
 if(l > 20) error("tpseq1a: l > 20, z= ", z, " l= ", l);
 if(l < 4) goto ret;
 strncpy(s1, s, 3);  s1[3] = 0;
 if(strcmp(s1,"SEQ") && strcmp(s1,"seq")) goto ret; // not SEQ... and not seq...  ;
 c = s[l-1];                                        // last char in s;
 if(c == '1' || c == '2') r = true;
 ret: if(mm) ipp("-tpseq1a z= ", z, " r= ", r);
      return r;
} // end bool tpseq1a(elem z)

 bool tp1last(elem t, elem f, int a1)  // y ~ a..last(f) (if(a != -1, else z ~ 1..last(z) 
{
 bool r; elem a,b,c;
 if(mm) ipp("+tp1last: t= ", t, " f= ", f, " a1= ", a1);
 r = fnt2(t, zseg,&a,&b) && fnt1(b,zlast,&c);
 if(!r || a1 == -1) goto ret;   // below r && a1 != -1;
 r = (a == elmint(a1));
 ret: if(mm) ipp("-tp1last: t= ", t, " f= ", f, " a1= ", a1, "\nr= ", r);
      return r;
} // end bool tp1last

    elem typabtvar(elem d, headp h, elemp q, int i)
{
 int n = kmain(h); int j,k,hl = h->l; elem a,y,r = zany; d.i = 0; // (necesary, when called from tp);
 elem x = d; x.i = i;
 if(mm) ipp("+typabtvar: d= ", d, "\ni= ", i);
 if(i < 1 || i > n) error("tp: wrong i, d= ", d, " i= ", i, " n= ", n);
 if(n*2 >= hl && curm > lsm) error("tp: no type axioms in abterm for x= ", x);
 if(d.ad==stad2)
 mm=mm;
 if(d==zFN){ r = zFN; goto ret; }           // make more general: d={x; ...} -> r=d; 04.20.23;
 k = n + i;
 if(k >= hl) goto M;    // no type axiom for x; r == zany;
 y = q[k];                            // y is x.i-th axiom
 if(mm) ipp("typabtvar: y= ", y);
 if(fnt2(y, zin, &a, &r))
 { 
  if(a==x) goto ret;        // y is "x in b"; (normal case)
  if(curm > lsm) error("typabtvar: wrong name a in in-axiom y, x= ", x, " y= ", y, " a= ", a);
  if(zz==3) ipp("typabtvar: y(x.i-th axiom) is not type axiom for x= ", x, " y= ", y); r = zany;
  goto M;
 } // if(fnt2)
 if(fnt2(y, zconj, &a, &y))            // temporarily !!! use conjunct(...) !!! 2022.01.21
 {
  if(fnt2(a, zin, &a, &r) && a==x) goto ret;
 } // if(fnt2(y, zconj, &a, &y)
 M: for(j=n+1; j<hl; j++) if(fnt2(q[j],zin, &a, &r) && a==x) goto ret;
    r = zany;
 ret: if(mm) ipp("-typabtvar: d= ", d, "\nr= ", r, " i= ", i);
 return r;
} // elem typabtvar(elem d, h,q,int i)

   int typd(elem d, elemp qt)            // types of abtterm d in qt, r = #types;
{
 headp h; elemp q; int i,j,k;
 if(mm) ipp("+typd: d= ", d);
 if(mel(d,&h,&q) != abt) error("typd: not abterm, d= ", d);
 k = kmain(h);
 if(k >= maxvars) error("typd: too many names in abterm d= ", d, " k= ", k);
 for(i=k+1,j=0; j<k; i++,j++) qt[j] = typabtvar(d,h,q,j+1);
 if(mm) ippq1("-typd: d= ", d, " qt= ", qt, k);
 return k; 
} // int typd;
/* void wrv(headp h, elem v) 
{
 att hl = h->l; 
 if(!vterm(h))
   error("wrv: not vterm(h), v= ", v);
 h->son[hl] = v;
 if(h->lth) --(h->lth);  //  = h->lth - 1;
} // void wrv(headp h, elem v)

   elem rdv(headp h, elemp q)
{
 att hl = h->l; elem r;
 // error("valdot");
 if(!vterm(h))
    error("rdv: not vterm, q[0] = ", q[0], " hl= ", hl, " adt= ", h->adt);
 if(mm) ipp("+rdv: q[1]= ", q[1], " q[0(adt) or 2(dot)]= ", h->adt? q[0]:q[2]);
 if(h->tp == zel) error("rdv: (h->tp == zel, q[1]= ", q[1], " q[0(adt) or 2(dot)]= ", h->adt? q[0]:q[2]);
 r = q[hl];                        // extra elem
 if(mm) ippelm("-rdv: r= ", r);    // return ipp !!!
 return r;
} // elem rdv(headp h, elemp q)

  bool boolt(elem z, headp* ag, elemp* aw) // 
{
 headp g; elemp w; 
 return mel(z,&g,&w)==pfs && g->l==3 && 
       (w[0] == zall || w[0] == zA && w[0] == zexist || w[0] == zimp); 
} // bool boolt
*/
  elem typmod(elem z, headp h, elemp q)  // type modification using lot
{
 elem f,A,B,C,A1,A2,C1,C2,t,r = zel; headp g; elemp w; bool p;
 if(mm) ipp("+typmod z= ", z);
 t = typlot(z); 
 if(t != zel){ r = t; goto ret; }    // type in lot has priority;
 p = dclname(q[0],&g,&w);
 if(p && w[1]==yre)
 {
  f = q[1]; C = q[2]; t = typ(f);
  if(t==zany) t = typlot(f);
  if(mm) ipp("typmod: restriction term z= ", z, " f= ", f, " t= ", t);
  if(fnt2(t,zfn,&A,&B))
  {
   if(inlot2(zincl,C,A)){ r = trm2(zfn,C,B,zset); goto ret; } // C <: A -> r = fn(C,B);
   if(fnt2(A,zdp,&A1,&A2) && fnt2(C,zdp,&C1,&C2))
   {
    if(mm) ipp("typmod: case fn(A1#A2,B) and f|(C1#C2), A1= ",A1," A2= ",A2," C1= ",C1," C2= ", C2);
    if(inlot2(zincl,C1,A1) && inlot2(zincl,C2,A2)){ r = trm2(zfn,C,B,zset); goto ret; }
   }   
  } // if(fnt2(t,zfn,&A,&B))
 } // if(dclname(q[0])
 ret: if(mm) ipp("-typmod z= ", z, " r= ", r);
 return r;
} // elem typmod(elem z, headp h, elemp q)

  elem sbst::valHostMod(elem s)  // if for some i Host[i] = s, r = Mod[i], else r = zel;
{
 elem r = zel; 
 for(ats i=0; i<=iMod; i++) 
   if(Host[i]==s){ r = Mod[i]; break; }
if(mm) ipp("-+valHostMod s= ", s, " r= ", r);
return r; 
} // elem valHostMod(elem s)

  void sbst::wrHostMod(elem Q, elem M)
 {
	 elem a;
  if(fnt2(M,zcol,&a)){ ipp("wrHostMod: type conversion term M= ", M, " changing to a= ", a); M = a; }
  if(++iMod >= MaxMod) error("HostMod: overflow of iMod,  Q= ", Q, " M= ", M, " iMod= ", iMod);
		// chiMod("wrHostMod", iMod+1);
  Host[iMod] = Q; Mod[iMod] = M;
  if(mm) ipp("+-wrHostMod Q= ", Q, " M= ", M, " iMod= ", iMod);
 } // end void wrHostMod

  void sbst::prHostMod(char* s, elem z, char* s1, elem y)
{
	*pfhis << "\nprHostMod: ";
 if(s) prp(s, z, pfhis);  
 if(s1) prp(s1, y, pfhis); 
 *pfhis << " iMod= "<< iMod;
 for(int i=0; i<=iMod; i++)
 {
  *pfhis<<"\ni= "<<i;  cout<<"\ni= "<<i;
   prp(" Host[i]= ", Host[i], pfhis);  prp(" Host[i]= ", Host[i]);
   prp(" Mod[i]= ", Mod[i], pfhis); prp(" Mod[i]= ", Mod[i]);
 } // for int i=0;
 // prlist(" Host= ", Host, iMod); 
	// prlist(" Mod= ", Mod, iMod);
} // void prHostMod(char* s)

  elem tph(elem z)
{
 headp h;
 if(!comp(mel(z,&h))) error("tph: not composite, z= ", z);
 return h->tp;
} // elem tph

  elem tp1(elem z)  // // tp1(x): if(x.m==ints):znat,...,if(z.i==0):zel, else tp(x);
{ 
 att m = z.m; elem r;
 if(m==ints){ r = znat; goto ret; }
 if(m == strng){ r = TPstring; goto ret; } 
 if(m >= maxmod || z.i==0){ r = zel; goto ret; }
 r = tp(z);
 ret: return r;
} // end elem tp1(elem z)

  elem typthms(elem z, bool fnt) // type from lth-theorems (separate function ?);
{
 elem T, r = zel, tz; ats i,k; headp h; elemp q, w;
 if(z.ad==stad1)
 mm=mm;
 if(mm) ipp("+typthms: z= ", z);
 tz = typ(z);
 k = thmbase(z, &w);
 if(mm) ipp("typthms: z= ", z, " k= ", k);
 for(i=0; i<k && (T = w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(badm(T.m)) error("typthms: wrong T.m, z= ", z, " k= ", k, " T.m= ", T.m);
  if(mm) ipp("typthms:for: z= ", z, " w[i]= ", T, " i= ", i);
  if(mel(T,&h,&q)==pfs && h->l == 3)
  {
   if(h->t != truth) error("typthms: h->t != truth, z= ", z, " T= ", T);
   if(q[0]==zin && q[1]==z)
   { 
    r = q[2];
    if(fnt && !fntype(r)) continue; 
    goto ret; 
   } // if(q[0]==zin ...)
   if(q[0]==zincl && q[1]==z){ r = trm1(zP,q[2],zset); goto ret; };
   if(q[0]==zincl && q[1]==tz){ r = q[2]; goto ret; };
  } // if(mel(x, ...)
 } // for(i)
 ret: if(mm) ipp("-typthms: z= ", z, " r= ", r);
 return r;
} // end elem typthms(elem z)

  int eqthms(elem z, elemp* a)  // equals from thms; if z=x then x is in a; r: index of a: (-1 if no such thms);
{                               
 elem x,y; int iar = -1, i,k; headp h; elemp q, w; static elem ar[maxvars]; // static ats dpth=0;
 if(mm) ipp("+eqthms: z= ", z);
 // if(++dpth > 1) error("eqlthm: recursive call, z= ", z, " dpth= ", dpth); Rec. calls are impossible !!!
 k = thmbase(z, &w);
 for(i=0; i<k && (x = w[i])!=zel; i++)  // i = k; i>=0; i-- ???
  if(mel(x,&h,&q)==pfs && h->l == 3 && (q[0]==zeq || q[0]==zequ))
  {
   y = zel;
   if(q[1]==z) y = q[2];
   else if(q[2]==z) y = q[1]; 
   if(y==zel) continue; // { ipp("eqthms: no use from theorem w[i], z= ",z, " w[i]= ", w[i]); continue; }
   wrlist(y,ar,&iar,maxvars);
  } // mel(x,&h,&q)==pfs ...)  // for(i)
 *a = ar;
 if(mm) ipp("-eqthms: z= ", z, " iar= ", iar);  // --dpth;
 return iar;
} // end int eqthms

  int fromthms2(elem f, elem z, elemp* a)  // second arguments for f(z,r) from thms; // int sizea;
{                                          // ??? same as seqarg ???
 elem x,y; int iar = -1, i,k; headp h; elemp q, w; static elem ar[maxvars]; // static ats dpth=0;
 if(mm) ipp("+fromthms2: f= ", f, " z= ", z);
 // if(++dpth > 1) error("eqlthm: recursive call, z= ", z, " dpth= ", dpth); Rec. calls are impossible !!!
 k = thmbase(z, &w);   // in fromthms2;
 for(i=0; i<k && (x = w[i])!=zel; i++)  // i = k; i>=0; i-- ???
  if(mel(x,&h,&q)==pfs && h->l == 3 && (q[0]==f))
  {
   y = zel;
   if(q[1]==z) y = q[2];
  // else if(q[2]==z) y = q[1]; 
   if(y==zel){ ipp("fromthms2: no use from theorem w[i], z= ",z, " w[i]= ", w[i]); continue; }
   wrlist(y,ar,&iar,maxvars);
  } // mel(x,&h,&q)==pfs ...)  // for(i)
 *a = ar;
 if(mm) ipp("-fromthms2: z= ", z, " iar= ", iar, " ar= ", ar, iar);  // --dpth;
 return iar;
} // end int fromthms2;

  elem typtabt1(elem z)  // look for theorems z' in t or z' <: t, r = t or P[t]; // not used, 2022.11.04;
{
 elem Q, r=zel; int i; headp h; elemp q; sbst s; 
 achs g(z); pntu->copy(&g);
 if(mm) ipp("---------+typtabt1: z= ", z, " curm= ", curm);
 for(i=0; i <= lview; i++)
 { 
  Q = g.prevt(pntu,i);
  if(Q==zel) break;
  if(Q.ad==stad && z.ad == stad1)
  mm=mm;
  if(mm) ipp("typtabt1: found in tabt true  z= ", z, " Q = ", Q, " i= ", i);
  if(Q.m != curm) ipp("typtabt1: Q.m != curm, Q= ", Q, " curm= ", curm);  // goto ret; }
  if(mel(Q,&h,&q)==pfs && h->l == 3)
  {
   if(q[0]==zin)
   {
    if(mel(q[1])==var){ if(z==q[1]){ r = q[2];  goto ret; } continue; }
    if(s.instance(z, q[1])){ r = s.rep(q[2], "typtabt1_1"); goto ret; }  // was s.instance(z, q[1], false) // s.rep(q[2]) ???
   } // if(q[0]==zin)
   if(q[0]==zincl)
   {
    if(mel(q[1])==var){ if(z==q[1]){ r = trm1(q[2],q[2],zset);  goto ret; } continue; }
    if(s.instance(z, q[1])){ r = trm1(zP,s.rep(q[2], "typtabt1_2"),zset); goto ret; }; // ???
   } // if(q[0]==zincl)
  } // if(mel(Q...)
 } // for(i)
 ret: if(r != zel) ipp("--------typtabt1: found! z= ", z, "\nr= ", r, " i= ", i);
      if(mm) ipp("----------typtabt1: z= ", z, " r= ", r);
      return r;
} // end elem typtabt1


   int checkts(char* s, elem z)
{
 int i;
 try { for(i=0; i<=its; i++) vts(i); }
 catch(...)
 {
	 cout<<"\nCheckts: error: exception: "<<s<<" i= "<<i<<" dd= "<<dd;
	 *pfhis<<"\nCheckts: error: exception: "<<s<<" i= "<<i<<" dd= "<<dd;
	 // cpp("z= ", z); 
  return 1;
 }
 return 0;
} // end checkts

/*   elem typt(elem z)
{
 if(mm) ipp("+typt z= ", z);
 elem r = typthms(z); 
 // if(r==zel) r = typtabt1(z);  
 if(mm) ipp("-typt z= ", z, "\nr= ", r);
 return r;
} //  elem typt(elem z)
*/
   elem typfnA(elem T,elem f,elem z)  // type from T := f in fn(A,B): r = B; or from T := A[x:t, f(x) in B]: r = B; (if typ(z) = t);
{                                     // A more general version is possible for multi(binary, ternary, ...) functions;                    
 elem r, A,B,P,d,fx,f1,x;
 if(mm) ipp("+typfnA T= ", T, " f= ", f, " z= ", z);
 if(fnt2(T,zin,&f1,&B) && fnt2(B,zfn, &A,&r)) goto ret;   // 
 if(fnt2(T,zA,&d,&P) && fnt2(P,zin, &fx,&r) && fnt1(fx,f,&x)) goto ret;  // && Abt1(d)==typ(z)
 r = zel;
 ret: if(mm) ipp("-typfnA T= ", T, "\nf= ", f, " z= ", z, " r= ", r);
      return r;
} // elem typfnA(elem T,elem f,elem z)
/*
  ats types(elem f, elem x, elemp* q )   // writes all typfnA-sets into ar,return number of elements in ar
{                                        // q : address ar;
  ats r,i,k,iar= -1; elemp w;  elem T,t; static elem ar[lsbin];       // lsbin = 16;
 if(mm) ipp("+types: f= ", f, " x= ", x);
 // k = thmbase(f, &w);
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  // if(badm(x.m)) error("typthms: wrong x.m, z= ", z, " k= ", k, " x.m= ", x.m);
  if(mm) ipp("types:for: f= ", f, " w[i]= ", x, " i= ", i);
  t = typfnA(T,f,x);                // T is f in fn(
  if(t==zel) continue;
  if(++iar >= lsbin) error("types: overflow of ar, f= ", f, " x= ", x, " iar= ", iar);
  ar[iar] = t;
 } // for(i)
 r = iar + 1; *q = ar;
 if(mm) ipp("-types f= ", f, " x= ", x, " k= ", k, " r= ", r);
 return r;
} // ats types(elem f,...)
*/
  bool look1(elem f, elem x, Lot* L) // z: f(x), goal: z in t;
{
 bool r=false; ats i,k,iar= -1; elemp w;  elem T,t, tx=typ(x); 
 if(mm) ipp("+look1: f= ", f, " x= ", x, " tx= ", tx);   //  " goal= ", goal);
 k = thmbase(f, &w);   // in look1: for wrtot: type from T := f in fn(A,B): r = B; or from T := A[x:t, f(x) in B]: r = B;
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mm) ipp("look1:for: f= ", f, " w[i]= ", x, " i= ", i);
  t = typfnA(T,f,x);
  if(t!=zel) L->wrtot(T); // Lot::wrtot(elem z):   r==1: already in tot, r==2: z==goal, r==0: not in tot;
 } // for(i)
 L->wrtot(trm2(zin,x,tx,zbool));
 // the same for(i) for lot;
 L->lclos();
 r = L->intot(L->goal);            // WAS l.intor(goal)
 if(mm) ipp("-look1 f= ", f, " x= ", x, " k= ", k, " r= ", r);
 return r;
} // bool look1(elem f,...)

  bool lookfnt(elem z, elem goal)     // fnterm(z): check z in t; // goal: z in t;
{
 bool r=false; att k,k1; elemp q,w; elem f,g,x,y,tx; Lot L(goal);  
 if(mm) ipp("+lookfnt z= ", z, "\ngoal= ", goal);
 k = fnterm(z, &q);             // z is function (not adt) term; 
 if(k==0) goto ret;
 if(k!=1) goto lookfnt2;

 // lookfnt1: 
 f = q[0]; x = q[1]; tx = typ(x);  // z: f(x);
 r = look1(f,x, &L);               // look for a theorem T: f in 
 if(r) goto ret;
 k1 = fnterm(x, &w);
 if(k1==0) goto ret;
 if(k1!=1)goto lookfnt12;
  
 // lookfnt11: 
 g = w[0]; y = w[1]; 
 r = look1(g,y, &L);

 lookfnt12: // not imp. yet
 lookfnt2:  // not imp. yet
 ret: if(mm) ipp("-lookfnt z= ", z, "\ngoal= ", goal, " r= ", r); // mm=savemm;
      return r;
} // bool lookfnt(elem z, elem t)

  elem normt(elem z)        // normalization of type: r=z; if(!PP1(z) && PP1(typ(z), &r) return r;
{
 elem r = z, t; elemp q;
 if(mm) ipp("+normt z= ", z);
 if(PP1(z)) goto ret;       //  bool PP1(elem z, elemp* aq)  // z is P[y] or P1[y];
 t = typ(z);                // z in t;  // t = P[q[1]]; // typ(subgr) = P[P1[elg]];
 if(PP1(t, &q)){ if(mm) ipp("normt:PP1(t,&q): typ(z)= ", t, " q[1]= ", q[1]);  r = q[1]; }
 ret: if(mm) ipp("-normt z= ", z, " r= ", r);
 return r;
} // elem normt(elem t)

  void changeqi(elem z, elemp q, headp g, elemp w, att i, char* place)  // replace(if inside by(...) or is(...)) q[i] with valrt(q[i],...);
{ 
 elem y, v;
 if(mm){ ipp("+-changeqi q[i], z= ", z, "\nq[i]= ", q[i], " i= ", i); *pfhis << " place= " << place; }
 if(g != 0 && g->v)                // twice !!! make a separate proc !!! also for q[2] !!!
 {
  assert(w != 0);
  v = valrt(y=q[i],g,w);          // if(y is a dot term then above is not 
  if(v != y && pntu->inbyis())    // && (!fnt2(y,zdot) || root(pntu->above()) != zis))   // because eqdot;
  { 
   if(curm != 0 && z.m == 0) error("changeqi: curm != 0 && z.m == 0, z= ", z, "\nq[i]= ", q[i], "\nv= ", v);
   ipp("changeqi: changing q[i] to v, z= ", z, "\nq[i]= ", y, "\n v= ", v, " i= ", i); *pfhis << "\nplace= "<<place;
   if(z.ad == stad2) ipp("changeqi: z.ad==stad2, z= ", z,"\nq[i]= ", y, "\n v= ", v, " i= ", i);
   ipp("changeqi:not really: q[i] = v, z= ", z, "\nq[i]= ", q[i],  "\nv= ", v); *pfhis << " place= " << place; // q[i] = v;  
  } // if(v != y && ...)       
 } // if(g != 0 && g->v)
if(ww) checktabt("-changeqi z= ", z);
} // end changeqi               
                                // calculating tt = typ(t), tt = typ(tt), ... until tt is P[A] or P1[A];
 elem typtyp(elem t)            // x in H, H in subgr, subgr in P1[P1[elg]] => x in elg; return elg, 
{                               // used in wlot(x), if the type of x is t;                           
 elem r=zel, tt=t, a; int i= -1, k= -1; 
 if(mm) ipp("+typtyp t= ", t);
 while(++i<=10)
 {
  if(PP1(tt)) goto M;
  tt = typ(tt);
 } // while(++i<=10) 
 if(mm) ipp("typtyp: failure: all TTs are not PP1-terms, t= ", t, " last tt= ", tt, " i= ", i);
 goto ret;
 M: k = numPP1(tt, &a);
 if(k==i) r = a; // *ai = k;
 ret: if(mm) ipp("-typtyp t= ", t, " tt= ", tt, "\nr= ", r, " i= ", i, " k= ", k);
      return r;
} // end elem typtyp

 int numPP1(elem tt, elem* aa)  // number of P,P1 in Q[...Q[a]], Q is P or P1
{
 int r= -1, i; elem t=tt, a=zel; elemp q;
 if(mm) ipp("+numPP1 tt= ", tt);
 for(i=0; i<=10; i++)
 {
  if(!PP1(t,&q)) goto M;   // t is P[q[1],  q[0] = P (or P1); 
  else a = q[1];
  t = a;
 } // while(++i <= 10)
 if(mm) ipp("numPP1: failure: too many P,P1 in tt= ", tt, " t= ", t, " i= ", i); goto ret;
 M: r = i; *aa = a;
 ret: if(mm) ipp("-numPP1 tt= ", tt, " a= ", a, " r= ", r);
       return r;
} // end int numPP1

// end styp.cpp