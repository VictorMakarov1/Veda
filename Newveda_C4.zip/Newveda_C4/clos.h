// clos.h  12/08/00 02/07/01 05/02/01 06/04/01 clos.CPP: see Archive;

elem reduce(elem z);  // facts(z); closlot; cred(z);
void facts(elem p);
void facts1(elem p);  // without snam
void wdal(elem d, elem md=zel, elemp q=0);
void fcts(elem p); // all facts for term p
void fctn(elem z); // all facts for name z
// int closlot(int k);
int infer1(elem p);         // ip - index p in lot
int infer2(elem p, elem q); // ip - index p in lot, iq - index q 
elem ordinf(elem y, elem z); // a < b && c < d && b = c -> a < d (and more) 
void corol(elem f, elem a, elem b, elem c);  // a&b -> c
void qparm(elem e, elem p);  // quasiparamodulation
int wlot(elem z, char* place=0, elem a=zel, elem b=zel);    // write into lot, return 1, false!
elem redA(elem d, elem p); // reduce A[d, p] 
// void ptlot(char* s);   // printing lot
