// prf1: 4/29/00 5/27/00 6/13/00 6/21/00 8/23/00 9/19/00 1/4/16 6/27/16
#include "lib.h"   // mm : for test printing in this file
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h" 
#include "typ.h"     
#include "prf.h"
#include "term.h"
#include "lot.h"
#include "rep.h"   // simp.h
#include "elem.h"  // clos.h
#include "styp.h"  
#include "cr.h"
#include "assert.h"
#include "err.h"
#include "etc.h"

#define SizeAllFrm 1000
elem x1a;                  // formula before is: see hnis;
int idep;                  // initialization in typa;
elem dc;                   // if goal is A[d,P]: d, if goal is P->Q: P;
elem gdc;                  // if goal is A[d,P]: P, if goal is P->Q: Q;
int kdc;                   // kname for d, number of conjuncts in P;
int idc;                   // the number of last handled axiom or conjunct;
bool pdc;                  // true for A[d,P], false for  P->Q;
extern int maxlsm,ilot,idep,prcause,proofdepth,curtritt,maxdittp,maxditteqp;
extern bool wasassume;
extern bool errprint;
extern char* allm[maxmod];    // stansard modules
extern elem zgiven,maxzp,maxdittzeqp; 
extern achs* pntu;
// extern int iMod;
// extern elem Host[];
// extern elem Mod[];
extern att adimp, adenconj;
extern elemp dep;
extern char* CAUSE;
extern elem cause_V;
extern elem cause_V1;
int maxdittp,maxditteqp;
int ilinassoc = -1;                       // last occupied in linassoc
// #define lconjuncts 10                  // moved to styp.h
#define lookaheadassume 16
int iconvar = -1;
int chnis, cAssocinve,ctrue,cTaut,cStaut,cTautP,cAxab,ctypeaxiom,cRed,cInstance,cWitness,cWitness_E,cadt_gt1,cvterm,cmnbool,
       cexc,cisst_y0,cw0_Taut_Staut,cimp,cMimp,cAll,cAllm,cAllimp,cA,cAimp_equ,cAModel,cw0_eq_equ,cM10;
elem maxdittzp;          // for proofs;
elem maxdittzeqp;        // for eqproofs;
elem linassoc[maxvars];  // 
elem convar[maxvars];    // constant variables, after assume;

att cmpvt(elem V, headp h, int m, elem V1, int m1, elem W);    // W: the initial model;
inline bool groupmlt(elem z){ elem s=zel; bool r =  strcmp(svel(z),"*")==0 && (s = scope(z))==zgroup; 
     if(mm) ipp("+-groupmlt z= ", z, " s= ", s, " r= ", r); return r;  } //  z.i==2 &&
inline bool groupe(elem z){ elem s= zel; bool r= strcmp(svel(z),"e")==0 && scope(z)==zgroup;
     if(mm) ipp("+-groupe z= ", z, " s= ", s, " r= ", r); return r;  }
inline bool groupinv(elem z){ elem s= zel; bool r = strcmp(svel(z),"inv")==0 && scope(z)==zgroup; 
     if(mm) ipp("+-groupinv z= ", z, " s= ", s, " r= ", r); return r;  } 
elem groupinvarg(elem z){ headp h; elemp q; return mel(z,&h,&q)==pfs && h->l==2 && groupinv(q[0])?q[1]:zel; }
inline bool groupmltinve(elem z){ bool r = groupmlt(z) || groupinv(z) || groupe(z);
                   if(mm) ipp("+-groupmltinve z= ", z, " r= ", r); return r;  } 
bool seektrimp1(elem y);  // seek for a generalization of y = Q1 -> Q;     
bool hnexcwith(elem Q, elem Q1, elem Q2);
void hnwith(elem M1, elem M2, elem Q);  // M1; with(Q); M2;
// bool seqv(elem z, int* k, elemp* aq);  // z is a sequence of the length k
bool isbd(elem F,elem d, elem z, elem G);
// inline bool vsmethod(elem V1){ return V1.i && inlist(htbv(V1),Host,iMod); } // very simple method

   bool seektrimp(elem Q, elem Q1, elem Q2)  
{ // seek for a generalization of Q1&Q2 -> Q; 
 int j,m; bool r = false;
 if(mm) ipp("+seektrimp Q= ", Q, " Q1= ", Q1, " Q2= ", Q2);
 for(j=0; j <= ieul; j++)    // change later to "j < lsm" !!!
 {
  m = eul[j];
  r = clad[m] -> stimp(Q,Q1,Q2,m);   // found eul[i] = sm[j]
  if(r) break;                       // clad[eul[i]] = rtt(allm[eul[i]);  eul[0] = curm;           
 } // end for(j)
 if(mm) ipp("-seektrimp r= ", r);
 return r;
} // end bool seektrimp

  bool seektrimp1(elem Q, elem Q1)  
{ // seek for a generalization of Q1 -> Q; 
 int j; bool r = false;
 if(mm) ipp("+seektrimp1 Q= ", Q, " Q1= ", Q1);
 for(j=0; j < lsm; j++)
 {
  r = clad[j] -> stimp1(Q,Q1,j);   // found eul[i] = sm[j]
  if(r) break;                     // standard modules:   0,1,...,lsm-1                       
 } // end for(j)
 if(mm) ipp("-seektrimp1 r= ", r);
 return r;
}  // end bool seektrimp1

   bool tt::stimp(elem Q, elem Q1, elem Q2, int m)  // new version: m is not used; wrthmsic-version: 5.20.21
{                                                   // seek for a generalization of Q1 & Q2 -> Q;
 ats i,savemm=mm; elem P1,P2,P3,T; bool r = false, save = errprint; ats k;
 sbst s;
 // if(check(Q.ad, stad)) 
 // mm=1;
 if(mm) ipp("+tt::stimp Q= ", Q, " Q1= ", Q1, " Q2= ", Q2, " m= ", m);
 // a = find2(zimp, zconj);  // adimp: address in den -> (imp);
 k = ptt -> ithmsic;
 for(i=0; i<=k; i++)         // for(i=beg_impconj; i <= end_impconj; i++)
 {
   //mm= (i==stad1);
  if(mm) ipp("tt::stimp:for: Q= ", Q, " i= ", i); 
  T = elm(mym, 0, thmsic[i]);  // T = elm(mym, 0, thms[i]);
  if(!fnt22l(T, zimp, zconj, &P1, &P2, &P3))                        // P1&P2 -> P3;
   error("tt::stimp: T is not (->,&)-formula, \nT= ", T, " k= ", k); 
      //    " beg_impconj= ", beg_impconj, " i= ", i, " end_impconj= ", end_impconj); 
  if(mm) ipp("tt::stimp: found true T= P1&P2->P3, \nT= ", T, "\nP1= ", P1, "\nP2= ", P2, "\nP3= ", P3, " m= ", m);
  s.size = 0;
  if(!s.instance(Q1,P1)){ if(mm) ipp("tt::stimp: Q1 is not instance of \nP1= ", P1, " Q1= ", Q1);  continue; }
  if(!s.instance(Q2,P2)){ if(mm) ipp("tt::stimp: Q2 is not instance of \nP2= ", P2, " Q2= ", Q2, " s= ", &s);  continue; }
  r = s.eqt(Q,P3);
  if(r)
  { 
   ipp("tt::stimp: found applicable implication, \nT= ", T, "\nQ= ", Q, "\nQ1= ", Q1, "\nQ2= ", Q2);
   goto ret;
  } // if(r)
  else { if(mm) ipp( "tt::stimp: Q is not equal(eqt) to  P3= ", P3, " Q= ", Q, " s= ", &s); }
 } // for(i=a)
// errprint = true;  // commented on 2.4.21;
 if(9) ipp("tt::stimp: -for: not found,\nQ= ", Q, "\nQ1= ", Q1, "\nQ2= ", Q2, " k= ", k);
          //  " beg_impconj= ", beg_impconj, " end_impconj= ", end_impconj);
 ret: if(mm) ipp("-tt::stimp r= ", r, " beg_impconj= ", beg_impconj, " m= ", m); errprint = save;  mm=savemm; 
      return r;
} // end bool tt::stimp

/*   bool tt::stimp(elem Q, elem Q1, elem Q2, int m)
{                            // seek for a generalization of Q1&Q2 -> Q;
 int i,k=itt; elem z; elem P1; elem P2; elem P3; bool r = false;
 sbst s;
 if(mm) ipp("+tt::stimp Q= ", Q, " Q1= ", Q1, " Q2= ", Q2, " m= ", m);
 if(mym==curm) k = curtritt;
 for(i=0; i <= k; i++)  // later: true implications are in the beginning
 {	 
  // if(i >= itt) error("stimp: no separator after true implications sm, i= ", i);
  z = elm(m,0,i); s.size = 0;
  if(Truth(tabt[i]) && fnt22l(z,zimp,zconj, &P1, &P2, &P3))  // z := P1 & P2 -> P3
  {
   if(mm) ipp("tt::stimp: found true implication z= ", z, " P1= ", P1, " P2= ", P2, " P3= ", P3, " m= ", m);
   if(!s.instance(Q1,P1)){ if(mm) ipp("tt::stimp: Q1 is not instance of P1= ", P1, " Q1= ", Q1);  continue; }
   if(!s.instance(Q2,P2)){ if(mm) ipp("tt::stimp: Q2 is not instance of P2= ", P2, " Q2= ", Q2, " s= ", &s);  continue; }
   r = s.eqt(Q,P3);
   if(mm) ipp("tt::stimp: Q is not equal(eqt) to  P3= ", P3, " Q= ", Q, " s= ", &s); goto ret;
  } // end if
 } // end for(i)
 if(mm) ipp("-tt::stimp: for, k= ", k);
 ret: if(r) ipp("tt::stimp: found applicable implication z= ", z);
//      if(vv) ipp("-tt::stimp r= ", r, " m= ", m);
      return r;
}  // end tt::stimp
*/
   bool tt::stimp1(elem Q, elem Q1, int m)  // change int to bool
{
 int i,k=itt; elem z; elem P1; elem P2; bool r = false;
 sbst s;
 if(mm) ipp("+tt::stimp1 Q= ", Q, " Q1= ", Q1);
 if(mym==curm) k = curtritt; 
 for(i=0; i <= k; i++)  // true implications are in the beginning
 {	 
  // if(i >= itt) error("stimp: no separator after true implications sm, i= ", i);
  z = elm(m,0,i);
  r = istr0(z);
  if(r && fnt2(z, zimp, &P1, &P2)) // z := P1 -> P2
  {
   if(!s.instance(Q1,P1)) break;
   r = s.eqt(Q,P2); goto ret;
  } // end if
 } // end for(i)
 ret: if(r) ipp("tt::stimp1: found true implication z= ", z);
 if(mm) ipp("-tt::stimp1 r= ", r, " m= ", m);
 return r;
}   // end tt::stimp1

 bool eqAssocinve(elem y, elem z)
{
 bool r=false; int iar,j; elem y1,y2;  elem ar[maxvars];
 if(mm) ipp("+eqAsssocinve: y= ", y, "\nz= ", z);
 linassocinve(y); iar = ilinassoc; 
 for(j=0; j<=ilinassoc; j++) ar[j] = linassoc[j];
 linassocinve(z);
 if(iar != ilinassoc)
 { 
  ipp("eqAsssocinve : iar != ilinassoc : y= ", y, " z= ", z, " iar= ", iar, " ilinassoc= ", ilinassoc);
  goto ret; 
 }  
 for(j=0; j<=iar; j++) if(!req(y1=linassoc[j],y2=ar[j]))
 {
  ipp("eqAsssocinve : not equal(y1,y2): y= ",y," z= ",z," y1= ",y1," y2= ",y2," iar= ",iar," ilinassoc= ",ilinassoc);
  goto ret;
 } // for j
 r = true; 
 ret:if(mm) ipp("-eqAsssocinve: y= ", y, "\nz= ", z, " r= ", r);
 return r;
} // end bool eqAssocinve(elem y, elem z)
                                                                   // Q2; by A=B; Q;
 bool hnexcwith(elem Q, elem Q1, elem Q2) //  seek for Q1&Q2 -> Q; // Q1 := A=B; with Q2; Q;  see above;         
{                                         // Q1; with Q2; Q;   or     Q; is Q1 ! Q2;
 bool r=true;  elem a,b, P1, P2; sbst s; int savemm = mm; elem vars_are_cons=zel0, dpat=zel0;
 if(99) ipp("+hnexcwith Q= ", Q, "\nQ1= ",Q1, "\nQ2= ", Q2); // keep 9 !!!
 // if(check(Q1.ad, stad1) || check(Q.ad, stad1) ) mm=1; // ??? use byel,  vars_are_cons ???
 if(iseq(Q1,&a,&b))
 {
  if(inlot(Q1)) vars_are_cons = zel9;   // in lot; zel9: all vars and hanging bvars are constants;
  if(isbe(Q2,a,b,Q,vars_are_cons,dpat) || isbe(Q2,b,a,Q,vars_are_cons,dpat)) goto ret;   // Q1 := A=B; with Q2; Q;
 } // if(iseq(Q1,&a,&b))   
 // if(iseq(Q2,&w) && eqt2(Q,Q1,w[1],w[2])) goto ret;                   // is same as: Q2; by A=B or B=A; Q;  
 if(isneg(Q1,Q2) && Q == zfalse) goto ret;            
 if(fnt2(Q2,zimp,&P1,&P2))                // Q2 is P1 -> P2;
 { 
  if(!s.instance(Q1,P1)){ if(mm) ipp("hnexcwith: Q1 is not instance of P1= ", P1, " Q1= ", Q1);  goto M; }
  if(!s.instance(Q,P2)){ if(mm) ipp("hnexcwith: Q2 is not instance of P2= ", P2, " Q2= ", Q2, " s= ", &s);  goto M; }
  if(mm) ipp("hnexcwith: imp(Q2): Success! Q= ", Q, " Q1= ",Q1, " Q2= ", Q2, " s= ", &s); goto ret;
 } //  if(fnt2(Q2,zimp,&P1,&P2))
 M: if(mm) ipp("hnexcwith: main part: Q= ", Q, " Q1= ",Q1, "\nQ2= ", Q2);
 r = seektrimp(Q,Q1,Q2);
 ret: if(mm) ipp("-hnexcwith r= ", r);  mm= savemm;
 return r;
} // bool hnexcwith(elem Q, ... )

/*   bool axall(elem z)   // z must be All(x,P)->R; R is an instance of P;
{
 bool r; headp h,g; elemp q,w; sbst s;
 if(mm) ipp("+axall z= ", z);
 r = fnt2h(z,zimp,&h,&q);          // q = ->,All(x,P),R;
 if(r) r = fnt2h(q[1],zall,&g,&w); // P = w[2], R = q[2]; 
 if(r) r = s.instance(q[2],w[2]);
 if(mm) ipp("-axall r= ", r);
 return r;
} // end bool axall(elem z)
*/
   void hnis(elem Q, elem J, char* s1, bool p)  // Q; is J; p==true: called from typseq, not prf; 
{                                               // J: Justification;
 elem z,A,B, P,P1,P2,Q0,Q1,Q2,Q3,Q4,J0=J,J1=zel0,t1,t2, D1=zel, D2=zel, r,x,y,y0,y1,val,d=zel, d0=zel0, dpat=zel0, 
      t = typ(Q); // J1: 3rd param for instance;
 int i,hl1,save; headp h,g; elemp q,w; ats a; bool p0=true,pat=false; static int count=0;
 sbst s; int savemm = mm; // pat: priznak of at-term Q@d, dpat: d from Q@d; (d = scopeden(Q@d));
 ++chnis;
 if(check(Q.ad, stad2)) 
 mm=1; //  && J.ad==stad1);  
 if(9){ ipp("\n+hnis Q= ", Q, "\nJ= ", J, " place= ", s1); *pfhis <<  " mm= " <<  mm; }
 if(mm) ipp("hnis:checking mm, mm= ", mm);
 ++ count; 
 if(count > 1) error("hnis: recursive call, Q= ", Q, "\nJ= ", J, "\nplace= ", s1);
 if(t != zbool) error("hnis: not a formula, Q= ", Q, " t= ", t);
 Q0 = (x1a = Q);                   // Q0: for mktr;
 if(J==zAssocinve)                // 0.1 Q: x=y; is Associnve;
 {                ++cAssocinve;
  if(!iseq(Q,&x,&y)) error("hnis: Associnve: Q is not an equality, Q= ", Q);
  if(!eqAssocinve(x,y)) error("hnis: Associnve: not eqAssocinve(x,y), Q= ", Q, " x= ", x, " y= ", y);
  goto ret_mktr;                     // p0==true here; so mktr(Q);
 } // eqAssocinve(x,y)

 //ret1: if(p0) mktr(Q);  
 //      else if(proofdepth==0) error("hnis:ret: proofdepth==0: not istr0(Q), \nQ= ", Q, "\nJ= ", J );
 typ(J);
 if(J==ztrue)                     // 0.2 Q must be true;
 {                ++ctrue;
  if(mm) ipp("hnis: true: Q= ", Q);
  if(!istr0(Q)) error("hnis:true: Q is not true, Q= ", Q);
  goto ret_mktr;                      // p0==true here; so mktr(Q);
 } // if(J==ztrue)

 if(J==zTaut || J==zStaut)        // 0.3  Q; is Taut; (or is Staut)
 {               
  if(J==zTaut) ++cTaut; else ++cStaut;
  if(!htaut(Q,J)) error("hnis: not tautology Q= ", Q, " J= ", J);  
  goto ret_mktr;                      
 }  // if(J == zTaut || J == zStaut) 

 if(J==zAxab)                     // 0.4 Q; is Axab;  the simplest case implemented;
 {               ++cAxab;
  if(mm) ipp("hnis:+Axab: Q= ", Q);
  if(fnt2(Q,zall,&P,&P1)){ ipp("hnis:Axab:All: changing to new Q= ", P1); Q = P1; }
  if(!fnt2(Q,zequ,&Q1,&Q2)) error("hnis:Axab: not equivalence, other cases not imp. yet, \nQ= ", Q); 
  if(!inabt(Q1,&x,&y)) error("hnis:Axab: not inabt term Q1, Q= ", Q, "\nQ1= ", Q1);
  // if(mel(y) != abt) error("hnis:Axab: not abt term y, Q= ", Q, "\nQ1= ", Q1, "\ny= ", y);
  r = s.redinab(Q1,x,y);         // Q1 === x in y;
  if(!req(r,Q2)) error("hnis:Axab: r not equal to Q2, Q= ", Q, "\nQ1= ", Q1, "\nr= ", r);
  if(mm) ipp("hnis:-Axab: OK! Q= ", Q);
  Q = Q0; 
  goto ret_mktr;                      // p0==true here; so mktr(Q);               
 } // if(J==zAxab)

 if(J==ztypeaxiom)                // 0.5: Q; is typeaxiom;
 {                ++ctypeaxiom;
  if(fnt2(Q,zA, &d, &P)) Q = P;
  if(mm) ipp("hnis: typeaxiom Q= ", Q);
  if(!fnt2(Q,zin,&x,&y)) goto Mincl;// error("hnis:typeaxiom: Q is not x in y, Q= ", Q);
  if(mm) ipp("hnis: typeaxiom Q= ", Q, " x= ", x, " y= ", y);
  if(freevar(x,&a,&t) && t==y) goto M; 
  if(dclname1(x,&t) &&  req(t, y)) goto M;
  if(x.m==ints && y == znat){ t = znat; goto M; }
  t = typ(x); // if(mm) kk = 1;  
  if(req(t,y)){ if(9) ipp("hnis:typeaxiom: case 1, Q= ", Q, " t= ", t); goto M; }
   error("hnis:typeaxiom:x in t: x is not a dclname or t != y (or x.m != ints), Q= ", Q, " x= ", x, "\nt= ", t, "\n y= ", y);
    // if(t != y) error("hnis:typeaxiom: wrong Q: (t:=tp(x)) != y, Q= ", Q, "\nx= ", x, " y=" , y, " t= ", t); 
  M: // if(!notempty(t)) error("hnis:typeaxiom: no theorem: t ~= {}, Q= ", Q, " x= ", x, " t= ", t); // bcs x in t ->
     goto ret_mktr;                 // p0==true here; so mktr(Q);                                    // t ~= {} !!!
  Mincl:if(!fnt2(Q,zincl, &x,&y)) goto Mimpin; // error("hnis:typeaxiom: Q is not x in y or x <: y Q= ", Q);
  t = typ(x);
  if(fnt1(t,zP,&z) && fnt2(Q,zincl,&A,&B) && A==x && B==z) // t = P[z]: x in P[z] ==  & x <: z;  Q: x <: z;
    { if(9) ipp("hnis:typeaxiom: case 2, Q= ", Q, " t= ", t); goto M; }  
   error("hnis:typeaxiom:incl: t != P[z] or Q != x <: z), Q= ", Q, " x= ", x, "\nt= ", t, "\n z= ", z);
           // x in t -> x in t1 is true if typ(t) = P[t1], because x in t & t in P[t1] => x in t1;  
  Mimpin: if(!fnt2(Q, zimp, &x,&y) || !fnt2(x,zin, &x,&t) || !fnt2(y,zin, &y,&t2) || x != y)
             error("hnis:typeaxiom: Q is not x in y or x <: y or x ->y, Q= ", Q);
  t1 = typ(t);
  if(!fnt1(t1,zP,&t1) || t1 != t2) error("hnis:typeaxiom: x->y, typ(t: from x in t) != P[t1],  Q= ", Q, "\ntyp(t)= ",t1); ;
  if(9) ipp("hnis:typeaxiom: case 3, Q= ", Q);
  goto ret_mktr; 
 } // if(J==ztypeaxiom)         

 if(J==zRed)                      // 0.6 Q; is Red;
	{                   ++cRed;
  if(mm) ipp("hnis:+Red, Q= ", Q);  // currently, Q must be an equality;
  // r = rep2i(Q,zRed,zRed); //,false);   // but a more common case is possible: use istr after r = rep2i(Q, ... );
  r = cred(Q);
  if(mm) ipp("hnis:-Red, Q= ", Q, " r= ", r);
  if(r != ztrue) error("hnis: wrong Red, Q= ", Q, " r= ", r); //  && !iseq(r,&x,&y) && x != y
  goto ret_mktr;                     // p0==true here; so mktr(Q);
	} // if(j==zRed)                // last simple J: 1.Associnve,2.true,3.Taut(or Staut),4.Axab,5.typeaxiom, 6.Red;

 if(mel(J,&h,&q) != pfs) error("hnis: wrong is-element, J= ", J);
 if(h->v)
 {
  val = valrt(J,h,q);
  if(fnt2(val,zA)) J1 = val;
  if(mm) ipp("hnis: valued J, Q= ", Q, "\nJ= ", J, "\nval= ", val, "\nJ1= ", J1);
  // if(req(val,Q)) goto ret_mktr;
  if(s.instance(Q, val, J1)){ ipp("hnis:val: SUCCESS!, Q= ", Q, "\nval= ", val); goto ret_mktr; }
  s.size = 0;  J1 = zel0; 
  if(mm) ipp("hnis:val: !s.instance(val,Q), checking Q is A[d,P], Q= ", Q);
  if(fnt2(Q,zA, &d,&P))
  {
   if(mm) ipp("hnis:val: Q = A[d,P], considering P as  Q, Q= ", Q, " P= ", P);
   if(s.instance(P, val)){ ipp("hnis:valA: SUCCESS!, Q= ", Q, " P= ", P, "\nval= ", val); goto ret_mktr; }
  } // if(fnt2(Q,zA,&d,&P))
  s.size = 0;  
  if(mm) ipp("hnis:val: !s.instance(val,Q), trying (if h->adt) eqadt Q= ", Q, "\nJ= ", J, "\nval= ", val); 
  if(h->adt) if(eqadt(Q,J,h,q)) goto ret_mktr;  // else error("hnis: adt: eqadt: wrong is-element, Q= ", Q, " J= ", J);
  if(mm) ipp("hnis:val: not eqadt(Q,J), trying if val = A[d,P], instance(A,P,d), Q= ", Q, " val= ", val);
  if(fnt2(val,zA,&d,&P))
  {
   if(mm) ipp("hnis:val: val = A[d,P], considering P as  J, Q= ", Q, "\val= ", val, "\nP= ", P);
   s.size = 0;
   if(s.instance(Q,P,d)){ ipp("hnis:val = A[d,P]: SUCCESS!, Q= ", Q, " P= ", P, "\nval= ", val); goto ret_mktr; }
  } // if(fnt2(val,zA,&d,&P))
  // error("hnis:val: wrong is-element, Q= ", Q, "\nJ= ", J, "\nval= ", val);
 } // if(h->v)                                 // see // 4. adt multiple: Q; is Q1(z1,z2,...); 

 if(h->at){ pat = true; dpat = scopeden(J); }      // J is T @ D;

 hl1 = int(h->l) - 1; y0 = q[0]; y1 = q[1];

 if(y0 == zTaut)                  // 1. Q; is Taut(P);
 {                ++cTautP;
  if(hl1 != 1) error("hnis: wrong  is-element Taut(P), J= ", J);
  if(typ(y1) != zbool) error("hnis: not a formula P in Taut(P), P= ", y1);
  r = smpb(y1);
  if(r != ztrue) error("hnis: not a tautology P in Taut(P), P= ", y1);
  if(!s.instance(Q, y1))
  {
   error("hnis: y0 == zTaut, Q is not instance of q[1] in J, \nQ= ", Q, "\nJ= ", J, "\ns= ", &s);
  } // if(!s.instance(Q, q[1]))
  goto ret_mktr;                    // p0==true here; so mktr(Q);  D1==zel also;
 } // if(y0 == zTaut)
 
 if(y0 == zInstance)               // 2. Q; is Instance(J);  // not used.
 {                  ++cInstance;
  if(mm) ipp("hnis:Instance Q= ", Q, "J= ", J);
  D1 = q[1];
  if(!istr0(D1)) error("hnis: 2. Q; is Instance(D1), D1 is not true, Q= ", Q, "\nJ= ", J, "\nD1= ", D1);   
  if(hl1 != 1) error("hnis: wrong  is-element Instance(D1), Q= ", Q, " J= ", J);
  if(typ(D1) != zbool) error("hnis: not a formula D1 in J: Instance(D1), Q= ", Q, " J= ", J);
  s.size = 0;
  if(!s.instance(Q, D1)) error("hnis: Q is not an instance(D1), Q= ", Q, "\nJ= ", J, " D1= ", D1);
  // if(p && !istr0(q[1])) error("hnis:Q is instance(P): not true P, Q= ", Q, "\nJ= ",J, " P= ", q[1]);
  // if(proofdepth){  wrdep(Q, q[1]); goto ret; }
  goto ret_mktr;  //retD1: p0 = istr0(D1); ret1: if(p0) mktr(Q);  else if(proofdepth==0) error(...);
 } // if(y0 == zInstance)     //            if(D1 != zel) wrdep(Q,D1,D2);    // if D1==zel then D2==zel also;
 
 if(y0 == zWitness)                   // 3. Witness: Q := Exist(x,P(x)); is Witness(a); // Exist(x,P(x)) <= P(a);
 {                   ++cWitness;      // 3a.         Q := E[d,P];        is Witness(a1,...,ak);
  if(mm) ipp("hnis:Witness Q= ", Q, "J= ", J, " mm= ", mm);     // Witness can occure only in is (not by,...)
  // if(!fnt2(Q,zexist, &x,&P)) error("hnis:Witness: not Exist formula Q= ", Q);
  if(mel(Q,&g,&w) != pfs || g->l != 3) error("hnis: wrong formula Q before Witness(a), Q= ", Q);
  if(w[0] != zexist) goto Witness_E;
  x = w[1]; P = w[2];
  if(hl1 != 1) error("hnis: wrong  is-element Witness(P), Q= ", Q, " J= ", J);
  x = nami(Q,1);                      // because Q := Exist(x,P(x));
  D1 = rep2(P,x,y1);
  if(mm) ipp("hnis:Witness:after rep2: \nP= ", P, "\nD1= ", D1);  // mm=1;
  if(!istr0(D1)) error("hnis:Witness: not true D1= ", D1, "\nQ= ", Q, "\nJ= ", J);
  goto ret_mktr;                     // mktr(Q); goto ret;                  // no wrdep !!!
 
  Witness_E:        ++cWitness_E; 
  if(w[0] != zE) error("hnis: not E[d,P]-formula Q before Witness(a1,...,), Q= ", Q);
  d = w[1]; P = w[2];
  if(!ismd(d,q,hl1)) error("hnis:Witness: (q1,...,qk) not a model of d, Q= ", Q, "\nd= ", d, "\nq1= ", q[1]);
  P1 = Repq(P,d,q,hl1); 
  if(!istr0(P1)) error("hnis:Witness_E: not true P1= ", P1, "\nQ= ", Q, "\nJ= ", J);
  // if(proofdepth){ wrdep(Q,ztrue); goto ret; } // goto MWit; 8.14.20 added wrdep: Q must be in dep (otherwise error);
  goto ret_mktr;                    // mktr(Q); goto ret;                  // no wrdep !!!
 } // if(y0 == zWitness)

                                       // 4. adt multiple: Q; is Q1(z1,z2,...); 
 // if(typ(J) != zbool) error("hnis: J is not formula, Q= ", Q, " J= ", J);
 if(h->adt && hl1 > 1)                // Q1(z_1,...,z_hl1)
 {                    ++cadt_gt1;
  if(mm) ipp("hnis:adt: Q= ", Q, " J= ", J);
  if(typ(J) != zbool) error("hnis: J is not formula, Q= ", Q, " J= ", J);
  if(!istr0(y0)) error("hnis:4.1 adt multiple: Q; is Q1(z1,...); y0 is not true, Q= ", Q, "\nJ= ",J,
                       "\ny0= ", y0);
  D1 = y0; d = scope(D1); 
  if(!Dterm(d)) error("hnis: 4.2 adt multiple: Q; is Q1(z1,z2,...): wrong d, Q= ", Q, "\nJ= ", J, "\nd= ", d);  // was mel(d) != abt
  Q1 = Repq(y0,d,q,hl1);
  trtr(y0,Q1);
  if(req(Q,Q1)) goto ret_mktr;
  ipp("hnis:4 adt multiple: Q; is Q1(z1,z2,...), changing J and d0 to Q1 , \nQ= ", Q, "\nQ1= ", Q1, "\nJ= ", J);
  J = Q1;  d0 = Q1; goto M10;
 } // if(h->adt && hl1 > 1)

 if(vterm(h,&D1,&z))                 // 5. Q; is D1.z or D1(z)
 {                    ++cvterm;
  if(mm) ipp("hnis: J is a dot term D1.z, \nQ=  ", Q, "\nD1= ", D1, "\nz= ", z);
  if(!istr0(D1)) error("hnis: 5. Q; is D1.z;  D1 is not true, Q= ", Q, "\nJ= ", J, "\nD1= ", D1);   
  if(eqdot(Q,D1,z)) goto ret_mktr;
  if(mm) ipp("hnis: eqdot failed, checking D1 is A[d,P], Q= ", Q, " D1= ", D1, " z= ", z);
  if(fnt2(D1,zA,&d, &P))
  {
   Q1 = h->v? valrt(J,h,q): vdt(J,D1,z); 
   // if(!h->v) error("hnis: J is D1.z or D1(z), no h->v,  Q= ", Q, "\nJ= ", J);
   // Q1 = valrt(J,h,q);
   if(mm) ipp("hnis:eqdot failed, changing J= ", J, " to \nQ1= ", Q1);
   J = Q1; goto M10;
  } // if(fnt2(D1,zA,&d, &P))
   error("hnis:zdot: Q != D1.z, \nQ= ", Q, "\nD1= ", D1, "\nz= ", z);
  // trtr(D1,Q);
  goto ret_mktr;                    // goto retD1;   //  retD1: p0 = istr0(D1); ret1: if(p0)
 } //  if(vterm(h,&Q1,&z))          // if(fnt2(J,zdot, &Q1, &z))
 
 if(fnt1(J,zmnbool,&D1))             // 6. Q; is -(x=y) or -A[d,  x=y]; 
 {             ++cmnbool;
  if(mm) ipp("hnis: J = -D1,  Q= ", Q, " J= ", J, " D1= ", D1);
  if(!istr0(D1)) error("hnis: 6. Q; is -(x=y) or -A[d,  x=y]; D1 is not true, Q= ", Q, "\nJ= ", J, "\nD1= ", D1);
  if(fnt2(D1,zA, &d0, &P1)){ d0 = D1; D1 = P1; }   
  if(mel(D1,&g,&w)==pfs && g->l==3 && (w[0]==zeq || w[0]==zequ) )
  {
   J = trm2(w[0], w[2], w[1], zbool); 
   if(mm) ipp("hnis:6:-(x=y): J was changed, Q= ", Q, " new J= ", J);
   trtr(D1, J); y0 = w[0];  //  mm=1;        // trtr: transfer truth from D1 to J;
   goto M10;
  } // if mel(D1,&g,&w)==pfs ...)
  error("hnis:6: mnbool: wrong J, Q= ", Q, " J= ", J);
 } // if(fnt1(J,zmnbool,&D1)

 if(y0 == zexc)                      // 7. Q; is D1 ! D2;
 {                  ++cexc;
  if(hl1 != 2) error("hnis: wrong  is-element Q1 ! Q2, J= ", J, "\nplace= ", s1);
  D1 = q[1]; D2 = q[2];  
  if(mm) ipp("hnis:exc: D1= ", D1, "D2= ", D2);
  if(typ(D1) != zbool) error("hnis: not a formula D1 in D1 ! D2) J= ", J, "\nplace= ", s1);
  if(typ(D2) != zbool) error("hnis: not a formula D2 in D1 ! D2) J= ", J, "\nplace= ", s1);  
  // Q1v = valn(Q1);
  if(!hnexcwith(Q,D1,D2)) error("hnis: wrong element D1 ! D2, J= ", J, "\nplace= ", s1);
  if(!istr0(D1)) error("hnis:7:exc: D1 is not true, Q= ", Q, " D1= ", D1);
  if(!istr0(D2)) error("hnis:7:exc: D2 is not true, Q= ", Q, " D2= ", D2);
  goto ret_mktr;                   //  goto retD1D2;  // retD1D2: p0 = istr0(D1) && istr0(D2); goto ret1;
 } //  end if(y0 == zexc) 
                                   // y0 = q[0];
 if(isst(y0,&y1))                  //  isst:6  hnis  isst(y0,&y1) -------------------??? move up ??? 12.01.20
 {                 ++cisst_y0;
  if(mm) ipp("hnis: isst(y0, &y1), Q= ", Q, " J= ", J, "\ny0 = ", y0, " y1= ", y1);   // ??? wrdep ???
  y0 = y1;
 } // if(isst(y0,&y1)) 

 if(mel(y0, &g, &w) == pfs)        // 8. y0 is composite(pfs); // mel(J,&h,&q)
 {                                
  if(w[0]==zTaut || w[0]==zStaut)  // 8.1; Q; is Taut(Q1->Q2)(Q3) // Q does not depend on Q1,Q2,Q3; ????
  {             ++cw0_Taut_Staut;
   // error("hnis //assert(g->l == 2);
   if(mm) ipp("hnis: case 8.1: is Taut(Q1->Q2)(Q3),\nQ= ", Q, " \ny0= ", y0);
   if(!htaut(w[1], w[0])) error("hnis: not Tautology w[1]= ", w[1], " Q= ", Q, " J= ", J);
   mktr(y0);
   if(!fnt2h(w[1], zimp, &g, &w)) error("hnis: not implication in tautology w[1]= ", w[1], " Q= ", Q, " J= ", J);
   // w[0] is now not zTaut or zStaut, but zimp
  } // if(w[0]==zTaut   // no goto ret_mktr, see 8.2.
  // 
  if(g->l != 3) error("hnis: wrong  impall in J= ", J);            // implication or all
  if(typ(y0) != zbool) error("hnis: wrong impall J= ", J);
  Q3 = q[1];
  elem t3 = typ(Q3);
  if(t3 == zel) error("hnis: wrong Q3 in (imp or all)(Q3) J= ", J);  
  
  if(w[0] == zimp)        // 8.2 Q;  is (Q1->Q2)(Q3);   // Q1->Q2 normally can contain vars; // MP=formula
  {	                  ++cimp;                  
   if(!istr0(y0)) error("hnis: 8.2a Q;  is (Q1->Q2)(Q3);  y0 is not true, Q= ", Q, "\nJ= ", J,
                         "\ny0= ", y0); 
   Mimp: Q1 = w[1]; Q2 = w[2];  ++cMimp; // if(mel(y0, &g, &w) == pfs)        // 8. y0 is composite(pfs);
   if(mm) ipp("hnis:imp or equ: Q; is (Q1->Q2)(Q3) or (Q1==Q2)(Q3)): \nQ1= ", Q1, "\nQ2= ", Q2, "\nQ3= ", Q3, "\nQ= ", Q);
   if(typ(Q1) != zbool) error("hnis: not a formula Q1 in ,Q1->Q2)(Q3) J= ", J);
   if(typ(Q2) != zbool) error("hnis: not a formula Q2 in ,Q1->Q2)(Q3) J= ", J);
   if(t3 != zbool) error("hnis: not a formula Q3 in Q1->Q2)(Q3) J= ", J);
   s.size = 0;
   if(mm) ipp("hnis:imp: checking Q3 is instance of \nQ1, Q= ", Q,"\nQ1= ",Q1, "\nQ3= ", Q3, "\nJ= ", J);
   if(!s.instance(Q3, Q1, d0))    // cannot be Q1@S; 
   {
    *pfhis << "\nCAUSE= "<<CAUSE; prp("\ncause_V= ", cause_V, pfhis); prp("\ncause_V1= ", cause_V1, pfhis);
    error("hnis(MP):  'Q; is (Q1->Q2)(Q3)'; Q3 is not instance of Q1, \nQ= ", Q,
           "\nQ1= ", Q1, "\nQ3= ", Q3, " s= ", &s);
   } // if(!s.instance(Q3, Q1))
   if(!istr0(Q3)) error("hnis: 8.2b Q;  is (Q1->Q2)(Q3);  Q3: not true, Q= ", Q, "\nJ= ", J, "\nQ3= ", Q3);   
   if(isst(Q2)){ Q2 = s.rep(Q2, "hnis_1"); Q2 = redst(Q2); }  // isst:5  hnis   // Q3=Q(W) <<< Q1=ExP(a), s={[P------???
   if(mm) ipp("hnis:imp: checking Q is s.instance of Q2= ", Q2, " Q= ", Q);
   save = s.size;
   if(s.instance(Q, Q2)) goto ret_mktr; 
   {
    if(99) ipp("hnis:imp: checking Q is A[d,P], Q= ", Q);
    if(fnt2(Q,zA,&d,&P))
    {
     if(99) ipp("hnis:imp: Q = A[d,P], considering P as  Q, Q= ", Q, " P= ", P);
     if(s.instance(P, Q2)) goto ret_mktr; 
    } // if(fnt2(Q,zA,&d,&P))    
    s.psbs(); error("hnis: 8.2c Q;  is (Q1->Q2)(Q3); Q is not instance of Q2, J is (Q1->Q2)(Q3), \nQ= ",
                   Q, "\nQ1= ",Q1,"\nQ2= ",Q2,"\nQ3= ",Q3);
    
   } // if(!s.instance(Q, Q2))
   // if(p && !istr0(q[0])) error("hnis:Q is (Q1->Q2)(Q3): not true q[0]=Q1->Q2, Q= ", Q, "\nJ= ", J, " q[0]= ", q[0]);
   // if(p && !istr0(q[1])) error("hnis:Q is (Q1->Q2)(Q3): not true q[1]=Q3, Q= ", Q, "\nJ= ", J, " q[1]= ", q[1]);
   // goto ret_mktr;                    // ret1: wrdep(Q, q[0], q[1]);
  } // if(w[0] == zimp) 
  
  if(w[0] == zrimp)                 // 8.2a Q; is (Q1 <- Q2)(Q3);   (MP1)
  {
   error("hnis:zrimp: Q= ", Q, " J= ",J);
   Q1 = w[1]; Q2 = w[2];
   if(mm) ipp("hnis:rimp: Q1= ", Q1, "Q2= ", Q2);
   if(typ(Q1) != zbool) error("hnis: not a formula Q1 in ,Q1<-Q2)(Q3) J= ", J);
   if(typ(Q2) != zbool) error("hnis: not a formula Q2 in ,Q1<-Q2)(Q3) J= ", J);
   if(t3 != zbool) error("hnis: not a formula Q3 in Q1<-Q2)(Q3) J= ", J);
   if(!s.instance(Q, Q1)) error("hnis(MP): Q is not instance of Q1, J= ", J);
   if(!s.instance(Q3, Q2)) error("hnis:MP <<Q; is (Q1 <- Q2)(Q3)>>: Q3 is not instance of Q2,\nQ= ", 
                                  Q, "\nQ1= ", Q1, "\nQ2= ", Q2, "\nQ3= ", Q3);
   goto ret_mktr;
  } // if(w[0] == zrimp)
  
  if(w[0] == zall)                  // 8.3: Q; is All(x, Q2)(Q3);
  {                   ++cAll;
   // w[1]:    variable x, was checked in pars?
   if(!istr0(y0)) error("hnis: 8.3: Q; is All(x, Q2)(Q3) y0 is not true, Q= ", Q, "\nJ= ", J, "\ny0= ", y0);   
   Q2 = w[2]; Q3 = q[1];
   if(mm) ipp("hnis: 8.3: Q; is All(x, Q2)(Q3), Q= ", Q, "\nQ2= ", Q2, "\nQ3= ", Q3);
   if(typ(Q2) != zbool) error("hnis: not a formula Q2 in All(x,Q2)(Q3) J= ", J);  // model
   
   if(typ(Q3) != zbool)            // 8.3a Q; is All(x1,...,All(xk,P) ...)(a,b, ... , z);
   {                  ++cAllm;      // y0 = All(x1,...,All(xk,P) ...);
    if(mm) ipp("hnis: +case 8.3a: Q; is All(x, Q2)(Q3), Q= ", Q, " y0= ", y0);
    x = y0;
    for(i=1; i <= hl1; i++)
    { 
     if(typ(q[i]) == zel) error("typbool: wrong q[i], Q= ", Q, "\nJ= ", J, "\nx= ", x, " i= ", i, "\nplace= ", s1);
     x.i = 1; s.adds(x, q[i]);
     x = w[2]; 
     if(fnt2h(x, zall, &g, &w)) continue;  // last x is the formula P;
     if(i < hl1)
      error("typbool: All: too many arguments in J, Q= ", Q, "\nJ= ", J, "\nx= ", x, " i= ", i, "\nplace= ", s1);
    } // for(i) 
    if(! s.instance(Q, x))  // last x is the formula P;  // true: use Allbvar in instance instead ???
      error("hnis:All: not instance Q= ", Q, "\n of x= ", x, "\nJ= ", J, "\nplace= ", s1);
    // if(istr0(y0)) mktr(Q);    // ???
    // if(proofdepth) wrdep(Q, y0); 
    if(mm){prlot("8.3");  ipp("hnis: -case 5.1: y0= ", y0); }
    goto ret_mktr;
   } // if(typ(Q3) != zbool)

   if(!istr0(Q3)) error("hnis: 8.3: Q; is All(x, Q2)(Q3) Q3 is not true, Q= ", Q, "\nJ= ", J, "\nQ3= ", Q3);     
   if(fnt2(Q2, zimp, &Q1, &Q4))            // 8.3b Q; is All(x, Q1->Q4)(Q3)           
   {            ++cAllimp;                   
    if(mm) ipp("hnis: 8.3b Q; is All(x, Q1->Q4)(Q3) Q= ", Q, "\nQ1= ",Q1,"\nQ4= ", Q4, "\nQ3= ", Q3);
    if(s.instance(Q3,Q1)) // varbvar: true, because All;
    {
     if(mm) ipp("hnis:All:imp: Q3 is an instance of Q1= ", Q1, " Q3= ", Q3);  // s.instance(Q,Q4,true) ; All;
     if(!s.instance(Q,Q4)) error("hnis:All:imp not instance Q= ",Q, " of Q3= ",Q3, " s= ", &s);
     // if(proofdepth) wrdep(Q,y0,Q3);  goto ret; // y0 = q[0] = All(x, Q2);
     goto ret_mktr;
    } // if(s.instance(Q3,Q1,false))
    error("hnis:8.3: Q; is All(x, Q2)(Q3)  J=All(x, Q1->Q4)(Q3), Q= ", Q, "\nJ= ", J, "\nplace= ", s1);
   } // if(fnt2(Q2...)              // 12.3: Q; is All(x, Q2)(Q3) // Q3 is not used;
   if(mm) error("hnis:8.3: Q2:not imp: Q; All(x,Q2)(Q3): Q= ", Q, " Q2= ", Q2, " Q3= ", Q3);
   if(!s.instance(Q,Q2)) error("hnis: wrong J=All(x,P)(z), J= ", J, " Q= ", Q, "\nplace= ", s1);
   // later: use z(Q3) !!!!!
   // if(proofdepth) wrdep(Q, y0);
   goto ret_mktr;
  }
 
  if(w[0] == zA)         // 8.4 Q; is Model: A[d,Q2](z1,...,zk) or A[d, Q1->Q2)(Q3) // or A[d, Q2](Q3 := z in d) ;
  {              ++cA;
   if(!istr0(y0)) error("hnis: y0 is not true, Q= ", Q, "\nJ= ", J, "\ny0= ", y0); // y0 =  A[d, Q2];   
   elem d = w[1];  Q2 = w[2];
   if(mm) ipp("hnis: 8.4 Q; is A[d, Q2](Q3 := z in d); or A[d,Q2](z1,...,zk); \nQ= ", Q, "\nJ= ", J);
   elem t = typ(d);
   if(!Dterm(d)) error("hnis: zA: wrong d in J = ", J, "\nd= ", d, "\nt= ", t);    // was mel(d,&g1) != abt
   // k = kmain(g1);                // not used; 6.12.20
   if(hl1 == 1)
   {              
    Q3 = q[1]; t3 = typ(Q3);
    if(t3 != zbool) goto Model;
    if(mel(Q2,&g,&w) != pfs) error("hnis: wrong(not pfs) Q2, Q= ", Q, "\nJ= ", J, "\nQ2= ", Q2);
  
    if(w[0]==zimp || w[0]==zequ)                   // 8.4a
			 {                ++cAimp_equ;
     d0 = y0;                                      //wa d0 = d;	6.15.22;
     if(mm) ipp("hnis:8.4a Q: is A[d, Q1->Q2)(Q3); t3= ", t3, " d0= ", d0); goto Mimp; //  Mimp: Q1 = w[1]; Q2 = w[2]; 
    } // if(w[0]==zimp || w0==zequ) 
    error("hnis: wrong Q2 in 8.4: Q: is J: A[d,Q2](Q3); Q= ", Q, "\nJ= ", J);
    // if(!isrt(Q3, zin, &v)) goto Model; // 8.4a. Q; is A[d, Q2](Q3 := z in d) 
    // if(v[2] != d) error("hnis: // 8.4a. Q; is A[d, Q2](Q3 := z in d) wrong d in(z in d), Q= ", Q, "\nJ= ", J); 
    // if(!istr0(Q3)) error("hnis: // 8.4a. Q; is A;d, Q2](Q3 := z in d), Q3 is not true, Q= ", Q, "\nQ3= ", Q3);   
    // z = v[1]; ??? goto Model ???
    // if(!isbd(Q2,d,z,Q)) error("hnis:// 8.4a. Q; is A;d, Q2](Q3 := z in d),!isbd(Q2,d,z,Q), Q= ", Q, " J= ", J); //  Q; is A[d, Q2](Q3 := z in d)
    // goto ret_mktr; // isbd(Q2,d,z,Q) == Rep(Q2,d,z) = Q; 
   } // if(hl1 == 1)
  
   Model:  ++cAModel;
   if(mm)ipp("hnis:8.4: Model: Q: is A[d, Q2)(z1, ..., zk); Q= ", Q, " J= ", J);
   if(!ismd(d,q,hl1)) error("hnis: zA: Model, not model, Q= ", Q, "\nJ= ", J, "\nd= ", d, "\nhl1= ", hl1);
   Q1 = Repq(Q2,d,q,hl1);
   if(!req(Q,Q1)) // error("hnis: zA: Model: wrong Q1, J=\n", J, "\nQ =\n", Q, "\nQ1= ", Q1);
   {
    ipp("hnis: zA: Model, changing J to Q1, Q= ", Q, " J= ", J, " Q1= ", Q1);
    J = Q1; mktr(Q1);  goto M10;  // goto ret_mktr; 
   } // if(!req(Q,Q1))
   if(mm) ipp("hnis:A, after Repq, Q= ", Q, "\nQ1= ", Q1, "\ny0= ", y0); 
   // if(istr0(y0)) mktr(Q);   // ???
   // if(proofdepth) wrdep(Q, y0);
   goto ret_mktr;  
  } // if(w[0] == zA)

  if(w[0]==zeq || w[0]==zequ)         // 8.5 Q; is (a=b)(x);
  {                ++cw0_eq_equ;
   if(!istr0(y0)) error("hnis: 8.5 Q; is (a=b)(x); y0 is not true, Q= ", Q, "\nJ= ", J, "\ny0= ", y0); 
   assert(g->l == 3); 
   elem a = w[1]; elem b = w[2];   x = q[1];
   if(mm) ipp("hnis: +(a=(==)b)(x), w[0]= ", w[0], " a= ", a, "\nb= ", b, "\nx= ", x);
   y = rep2(x,a,b);                  // if w[0]==zequ then unnecesary terms can be created. REWORK !!! 11.06.20
   if(req(Q,y)) goto M8;
   y = rep2(x,b,a);
   if(req(Q,y)) goto M8;    // 
   if(w[0]==zequ) goto Mimp;
    error("hnis: y := (a=b)(x), y != Q, Q= ",Q, " y= ", y, "\na= ", a, "\nb= ", b, "\nx= ", x);
   // y = zel;
   // if(req(x,a)) y = b; else if(req(x,b)) y = a;     // ??? instance ???
   // if(y==zel) error("hnis: Q; is (a=b)(x): x != a or b, Q= ", Q, "\na= ", a, " b= ", b, "\nx= ", x); 
   M8: if(w[0]==zequ) ipp("hnis: not imp: (a==b)(x), , Q= ", Q, " y= ", y, "\na= ", a, " b= ", b, " x= ", x);
   goto ret_mktr;   // if(proofdepth) wrdep(Q, y0, q[1]); goto ret2;
  } // if(iseq)
 } // end if(mel(y0, &g, &w) == pfs)

  M10: s.size = 0;   ++cM10;          // 10: Q; is J;  // main case;
 if(mm) ipp("hnis:10: Q; is J, Q= ", Q, "\nJ= ", J, "\nd0= ", d0, " dpat= ", dpat);
 if(!istr0(J)) error("hnis:10:J: not true, Q= ", Q, "\nJ= ", J);    // 12.02.20

 if(s.instance(Q,J,d0,dpat))          // 10.1
 {
  if(mm) ipp("hnis:10a instance(first)!!!, Q= ", Q, "\nJ= ", J, "\nd= ", d);
  goto ret_mktr; 
 } // if(s.instance(Q,J,d0,dpat))

 if(mm) ipp("hnis:10b: before stripalls(Q,J), Q= ", Q, " J= ", J);
 Q0 = stripalls(Q); J = stripalls(J);
 if(Q0 != Q || J != J0) if(s.instance(Q0, J,d0,dpat)) goto ret_mktr;  // 10.0 the most common case; // ??? goto ret? 12.02.20 // , d0
 P = J;
 if(fnt2(Q0,zA,&d,&P))
 {
  if(!normd(d))
  {
   elem dJ;
   if(fnt2(J,zA,&dJ) && dJ != d)            // because Q is not an instance of J;
           error("hnis: Q0=A[d,P] is not instance of J & not normd(d): \nd= ", d, "\nQ0= ", Q0, "\nJ= ", J);  
  } // if(!normd(d))
  Q0 = P;
 } // if(fnt2(Q0,zA))
                                             // 10c
 if(mm) ipp("hnis:10c after stripingA(Q0), now trying  s.instance(Q0,J,d0,dpat)) \nQ0 = ", Q0, "\nJ= ", J, "\nP= ", P, "\nd= ", d);
 if(s.instance(Q0,J,d0,dpat)) goto ret_mktr;
 
 if(mm) ipp("hnis:10d now stripingA(J), now trying  s.instance(Q0,J,d0,dpat)) \nQ0 = ", Q0, "\nJ= ", J, "\nP= ", P, "\nd= ", d);
 P1 = J; J1 = J;
 while(fnt2(J,zA,&d0,&P1))                      // 10d Q; is A[d0,P1]; 
 { 
  if(!normd(d0))
  {
   elem d2;                                    // 
   if(fnt2(Q,zA,&d2) && d2 != d0) 
          error("hnis: 10.1: d0 is not normal  in J= A[d0,P], d0= ", d0, "\nQ= ", Q, "\nJ= ", J);
  } // if(!normd(d0))
  if(mm) ipp("hnis:10e J= A[d0,P1], changing J on P1, Q0= ", Q0, "\nJ= ", J, "\nJ1= ", J1, "\nP1= ", P1);
  if(J1==zel0) J1 = J;
  J = P1;
 } // while(fnt2(J,zA,&d0,&P1))  
  s.size = 0;
  if(s.instance(Q0,P1,J1)) goto ret_mktr;     // was s.instance(Q0,J,d0)) J1: must be first A[ 7.30.22
  J1 = zel0;
  ipp("hnis:10f: Q0, P: both are strippedA, but !s.instance(Q0,P1,J1), Q0= ", Q0, "\nP1= ", P1, "\nJ1= ", J1);
 
 s.size = 0; // if(pat) d0 = dpat; // com-ed 6.15.22
 if(s.instance(Q0,J,J0,dpat)) goto ret_mktr;  // Q0 is an instance of P in A[d,P]; // was if(s.instance(Q0,J,d0) 6.15.22
 if(!fnt2(J,zimp, &P,&P1)) error("hnis:10.1: Q0 is not instance of J,P and !fnt2(J,zimp), \nQ0= ", Q0, "\nJ= ", J);
 s.size = 0;
 if(!s.instance(Q0,P1,J0,dpat)) error("hnis:10.2: zimp: Q0 is not an instance of P1, \nd0= ", d0, "\nQ0= ", Q0, "\nJ= ", J);
 P2 = s.rep(P, "hnis_2"); 
 if(istr0(P2)) goto ret_mktr;
 error("hnis:zimp: P2 is not true, \nP2= ", P2, "\nQ0= ", Q0, "\nJ= ", J);
 ret_mktr: mktr(Q);
 if(proofdepth) wrdep(Q,ztrue); // goto ret;
    
 // ret3: if(istr0(J)) mktr(Q);                    // ??? wrdep has to do it; ???
 // if(proofdepth) wrdep(Q, J); 
 // goto ret;
                                     // 17: else: error;
 // error("hnis: wrong J-element, Q= ", Q, " J= ", J, "\nplace= ", s1);  // ??? no way to come here ???
 // ret1: if(proofdepth) wrdep(Q, y0, q[1]); 
 // ret2: mktr(Q);
 
 // retD1D2: p0 = istr0(D1) && istr0(D2); goto ret1;
 // retD1: p0 = istr0(D1);
 // ret1: if(p0) mktr(Q);  // p0: istr0(D1) or istr0(D1) && istr0(D2);
 //        else if(proofdepth==0) error("hnis:ret: proofdepth==0: not istr0(Q), \nQ= ", Q, "\nJ= ", J );
 --count;
 if(mm)
 {
  *pfhis << "\n-hnis place= "<<s1<<' '<<"chnis= "<<chnis;
  ipp("-hnis Q= ", Q, " J= ", J, "\nD1= ", D1, "\nD2= ", D2);  
  // else ipp("-hnis: end,keeping mm==1, chnis= ", chnis, " stad1= ", stad1);
 } // if(mm)
 mm=savemm;
} // end bool hnis

   void hnby(elem y1, elem y, headp h, elemp q, elem y2)   // y1; by(y,h,q); y2; ??? add parameter: proof goal!!!
{
 int m,i,hl = h->l; headp g; elemp w; elem a,b, x,z,t, A; elem vars_are_cons=zel0, dpat=zel0; ats v;
 // if(check(y1.ad, stad2)) mm=1; // only hnby, typseq and newtt can change mm;
 if(9) ipp("\n+hnby y1= ", y1, "\ny= ", y, "\ny2= ", y2, " mm= ", mm);  // y: by-element
 // if(istqab != -1){ error("hnby: istqab != -1, y1= ", y1, "\ny= ", y, "\ny2= ", y2, " istqab= ", istqab); istqab = -1; }
 // if(tead != 0 && int(y1.m)==curm && int(y1.i)==0 && int(y1.ad)==tead){ mm=1; ttt=1; }
 
 if((t=typ(y2)) != zis)         // == zbool)             // y2 is a formula
 {
  if(hnbybyeq(y1,y,h,q,y2))
  {
   if(t==zbool)
   {
    if(istr0(y1)){ if(Truth(y1)) mktr(y2); else wlot(y2, "hnby:1");  goto ret; }  //mktr(y2);  // Wrong: y1 can be locally true;  // not in hnbybyeq !!!
    if(istr0(y2)){ if(Truth(y2)) mktr(y1); else wlot(y1, "hnby:2");  goto ret; }  // mktr(y1);   // Wrong: y2 can be locally true; see dd.dd for suggestios.
   } // if(t==zbool)
   goto ret;
  } // if(hnbybyeq(y1,y,h,q,y2))
  error("hnby: wrong by-element = ", y, "\ny1= ",y1, "\ny2= ", y2);
 } // if(t=typ(y2) != zis )
 
 if(99) ipp("hnby: typ(y2)==zis, y= ", y, "\ny1= ", y1, "\ny2= ", y2);
 m = mel(y2,&g,&w);
 if (m != pfs) error("hnby: not composite y2, y= ", y, "\ny1= ", y1, "\ny2= ", y2);
 if(w[0] != zis) error("hnby: wrong y2 (not is-element) after by-element, y= ", y, " y1= ",y1, " y2= ", y2);
 if(mm) ipp("hnby:is, y1= ", y1, " y2= ", y2);
 A = y1;    // y1; by(e1,e2,...,); y2;
 i = 1;
 while(i < hl)
 {
  x = q[i];
  if(!byel(x, &a, &b, &vars_are_cons, &dpat)) 
  {
   ipp("hnby: not equality (or eqv), q[i]= ", x);
   if(typ(x) != zbool) error("hnby: not formula, q[i]= ", x);
   a = x; b = ztrue;
  } // if(!byel(x, ...)
  
  // if(qabterm(a) || dterm(a)) pall = true;   // ??? 7.9.19 ???
  if(i < hl-1 && Ints(q[i+1],&v)) ++i; else v = 0;   //++i: skipped v;
  if(mm) ipp("hnby:is:while: before rep2i A= ", A, "\na= ", a, "\nb= ", b); //, " istqab= ", istqab);
  z = rep2i(A, a, b, vars_are_cons,dpat, v);        // ??? dpat ??? false: was vars_are_cons     // v: occurrence number;
  if(z == A) error("hnby:is: no change, y1= ", y1, "\nA= ", A, "\nq[i]= ", q[i], "\ny(by)= ",y);
  if(mm) ipp("hnby:for:is: changed! \nA= ", A, "\nby ", q[i], "\nto z= ", z, " i= ", i);
  A = z;
  ++i;
 } // while
 if(mm) ipp("hnby:after for, A= ", A, "itt= ", ptt->itt);
 if(proofdepth){ wrdep(A,y,y1);   wrdep(y1,y,A); }
 if(mm) ipp("hnby: is-element after by-element, A= ", A); 
 if(w[0] == zis)
 {
  if(g->l != 2) error("hnby: wrong is-element y2= ", y2);
  hnis(A,w[1]," hnby "); // wrdep in hnis
  if(istr0(A)) mktr(y1);
 } // if(w[0])
 ret: if(9) ipp("-hnby y1= ", y1); 
} // end int hnby(elem y1, ... )     

   bool hnbybyeq(elem F, elem B, headp h, elemp q, elem G)     // F; B:(h,q)=by(z1,..., zk); G;
{
 int i, k = int(h->l)-1; elem vars_are_cons=zel0, dpat=zel0; bool r=false; ats v,v1=0; // elem ar[maxvars]; 
 elem a,b,z,y,y1,P,P1,Q, A = F; bool nonconjunct = false; // elem G = valdexc(GG);
 // if(check(F.ad, stad2)) 
 //  mm=1;
 if(9) ipp("\n+hnbybyeq F= ", F, "\nG= ", G, "\nB= ", B, "\nk= ", k, " mm= ", mm);
 if(h->l == 2 && fnt2(q[1], zimp, &P, &Q))       // F; by P->Q; G;
 {
  if(9) ipp("hnbybyeq:implication, F= ", F, " by= ", B, " q[1]= ", q[1]);
  if(conjunct(P,F)) goto M1;
  // error("hnby: P is not a conjunct of F= ", F, " P= ", P);
  nonconjunct = true;
  M1: if(!byel(Q,&a,&b,&vars_are_cons,&dpat)) error("hnbybyeq: not equality Q, F= ", F, " B= ", B, " Q= ", Q);  
  if(nonconjunct)
  {
   sbst s;
   if(!s.instance(F,a, vars_are_cons,dpat)) error("hnbybyeq:impl: F is not an instance of a, F= ", F, "\nQ= ",Q, "\na= ", a); 
   P1 = s.rep(P, "hnbybyeq");
   if(!inlot(P1)) error("hnbybyeq:impl: P1 is not in lot, F= ", F, "\nP= ",P, "\nP1= ", P1, "\ns= ", &s);
   if(9) ipp("hnbybyeq:impl: success! F= ", F, "\nP= ", P, "\nQ= ", Q, "\nP1= ", P1);
  } // if(nonconjunct)
  if(isbe(F, a, b, G, vars_are_cons,dpat)){ r = true; goto ret; }
  error("hnby: implication: isbe: wrong by-element B, \nF= ", F, "\nG= ", G, "\nB= ", B);
 }  // if(h->l == 2 && ...)
 if(Ints(q[k], &v1)) --k;              // v1: the occurrence for isbe;
 for(i=1; i < k; i++)                  // yes, <, not <=, case "=" for isbe: see below;
 {
  y = q[i]; typ(y);
  if(Ints(y)) continue;                // the number of the occurrence skipped, see the next statement;
  if(Ints(q[i+1], &v)); else v = 0;    // empty assign. statement;
  if(99) ipp("\nhnbybyeq:+for q[i]= ", y, "\nTotal: A= ", A, " v= ", v, " i= ", i);
  if(y==zAxab || y==zRed || y==zBred)  // ??? Axab can be replaced with Red ???
  { 
   z = rep2i(A,y,y,zel0,zel0,v);       // ??? dpat ??? zel0: in in V1(instance) vars are vars (not cons) 
   if(z == A) error("hnbybyeq: Axab: not changed \nA= ", A, "\nby(i)= ", y, "\nF= ",F, "\ni= ", i);
   A = z; goto M; 
  } // if(y==zAxab || y==zRed): reduction of "x in abterm";
  if(y==zAssocinve) error("hnbybyeq: Associnve can only be last in by, \nA= ", A, "\nby(i)= ", y, "\nF= ",F, "\ni= ", i);
  if(isst(y,&y1))  // isst:4 hnbybyeq
  { 
   ipp("hnbybyeq: after 1st isst: y= ", y, "\ny1= ", y1);
   if(comp(y1)){ ipp("hnbybyeq: changing y to y1, F= ", F, " y= ", y, " y1= ", y1); y = y1; } 
  } // if(isst(y,&y1))
  if(!byel(y, &a, &b,&vars_are_cons,&dpat)) error("hnbybyeq: by(i) is not equality, F= ", F, "\nA= ", A, " by(i)= ", y, " i= ", i);
  // if(qabterm(a) || dterm(a)) pall = true;
  z = rep2i(A, a, b, vars_are_cons,dpat,v); 
  if(z == A)
  {
   ipp("hnbybyeq: not changed, F= ", F, "\nA= ", A, "\nby(i)= ", y, " i= ", i);
   error("hnbybyeq: not changed, a= ", a, "\nb= ", b, "\nvars_are_cons= ", vars_are_cons);
  } // if(z == A)
  if(mm) ipp("hnbybyeq: changed A= ", A, " by ", y, "\n to ", z);
  A = z;
  M: if(9) ipp("\nhnbybyeq: -for A= ", A, " i= ", i);
 } // end for i
 y = q[k];     // k = h->l - 1;
 // if(y == zAxab){ r = isb(A, G, &zAxab, 1); goto ret; } // G is reduction of abterm A; , &zAxab, 1// comm-ed.4.23.20
 /*
 if(y==zAssocinve)
 {
  linassocinve(A); iar = ilinassoc; p = false;
  for(j=0; j<=ilinassoc; j++) ar[j] = linassoc[j];
  linassocinve(G);
  if(iar != ilinassoc)
  { 
   ipp("hnbybyeq: Associnve : iar != ilinassoc : \nF= ", F, "\nG= ", G, "\niar= ", iar, " ilinassoc= ", ilinassoc);
   goto ret;   // change ??? goto M ???
  }  
  for(j=0; j<=iar; j++) if(!req(y=linassoc[j],y1=ar[j]))
  {
   ipp("hnbybyeq: Associnve : wrong: \nF= ", F, "\nG= ", G, "\ny1= ", y, "\ny= ", y);
   goto ret;
  } // for j
   r = true; goto ret;
 } // if(y==zAssocinve)
*/
 // mm=1;
 if(isst(y,&y1))
 { 
  if(comp(y1))
  { 
   ipp("hnbybyeq: after 2nd isst: y= ", y, "\ny1= ", y1); 
   y = y1; 
  } // if(comp(y1))
 } // if(isst(y,&y1)) // isst:3 hnbybyeq
 if(y==zAssocinve || y==zAxab || y==zRed){ a = y; b = y; vars_are_cons = zel; } // zel for axab,...;
 else if(!byel(y, &a, &b,&vars_are_cons,&dpat)) error("hnbybyeq: by(i) is not equality after redimp,y, F= ", F, "\nA= ", A, " by(i)= ", y, "\ni= ", i);
 r = isbe(A, a, b, G, vars_are_cons,dpat,v1); // compare F and G by modulo a=b
 ret: if(9) ipp("-hnbybyeq F= ", F, " r= ", r, " mm= ", mm); 
 return r;
}; // end hnbybyeq

/*   bool isb(elem F,elem G, elemp qq, int k)       // F; by (qq,k); G; not used: 4.23.20;
{
 bool r=false; assert(k);
 if(9) ipp("+isb F= ",F,"\nG= ",G," qq[0]= ", qq[0], " k= ", k);
 sbst s;  elem y, y1; // int m,m1; headp h,g1; elemp q,w;
 achs f(F) ; achs f1(G);     // = new achs(F) = new achs(G)
 
 while(f.iach >= 0 && f1.iach >= 0)
 {
  elem V = f.curvert(); elem V1 = f1.curvert();
  if(mm) ipp("\nisb: while: V= ", V, "\nV1= ", V1, " s= ", &s);
  if(V == V1)                              // ??? existx ???
  {
   if(V==zall || V==zexist || V==zexist1)  // ??? abt ???
   {
    y = f.topach().e; y.i = 1;     // y = vname(f.topach().e, f.topach().h);   
    y1 = f1.topach().e; y1.i = 1;   // y1 = vname(g.topach().e, g.topach().h);      
    s.adds(y1,y);
   } //  if(V==zall ...)
   goto Nxt;
  } // if(V == W) 

  // m = mel(V,&h,&q);
  // m1 = mel(V1,&g1,&w);
  if(s.eqt(V, V1) || s.congr(V,V1,qq,k)) 
  {
   f.next1(); f1.next1();   // next1: goto the right brother or up
   if(mm) s.psbs("next1");
   // s.size = save;
   continue; 
  } // if(s.eqt(V,V1) || ...)
  // goto ret;
  Nxt: f.next(); f1.next();
 } // end while
 r = (f.iach == f1.iach);  // .p ?? place
 if(9) ipp("-isb F= ",F, " G= ", G, " r= ",r);
 return r;
} // end isb
*/

  bool assdot3(elem V, elem V1, elem W)      // checking that V is P1.(P2.P3) and V1 is P1.P2 and P3==W; 
{                                            // the theorem Q.(Q1.Q2) = (Q.Q1).Q2 is still unproved ???
 bool r= false; elem P1,P2,P3,Q1,Q2;
 if(mm) ipp("+assdot3 V= ", V, " V1= ", V1, " W= ", W);
 r = fnt22r(V,zdot,zdot, &P1,&P2,&P3);
 if(r==false){ if(mm) ipp("assdot3: not fnt22(V,zdot,zdot,...), V= ", V, " V1= ", V1);  goto ret; }
 r = fnt2(V1,zdot, &Q1, &Q2);
 if(r==false){ if(mm) ipp("assdot3: not fnt2(V1,zdot,,...), V1= ", V1, " V= ", V);  goto ret; }
 r = P1==Q1;
 if(r==false){ if(mm) ipp("assdot3: P1!=Q1, V= ", V, " V1= ", V1, "\nP1= ", P1, " Q1= ", Q1);  goto ret; }
 r = P2==Q2;
 if(r==false){ if(mm) ipp("assdot3: P2!=Q2, V= ", V, " V1= ", V1, "\nP2= ", P2, " Q2= ", Q2);  goto ret; }
 r = P3==W;
 if(r==false) if(mm) ipp("assdot3: P3!=W, V= ", V, " V1= ", V1, "\nP3= ", P3, " W= ", W);   // goto ret; }
 ret: if(mm) ipp("-assdot3 V= ", V, " V1= ", V1, " W= ", W, " r= ", r);
 return r;
} // end bool assdot3;

  bool eqdot(elem z, elem Q1, elem W)        // checking that z = Q1.W or(Q1(W));
{                                            // z is Q1.W; z "is" rep(Q1,HostMod);
 bool r=false; elem Q,M,M0,M1,M1a,V,V1,SQ1,S1,a; att a1,iw=0; sbst s;   
 if(9) ipp("+eqdot z= ", z, "\nQ1= ", Q1, "\nW= ", W, " mm= ", mm);
 achs f(z) ; achs f1(Q1);     // = new achs(F) = new achs(G)
 s.HostMod(Q1,W);               // computing Host[] and Mod[];
 if(fnt2(W,zcol,&a)){ ipp("eqdot: type conversion term W= ", W, " changing to a= ", a); W = a; }
 while(f.iach >= 0 && f1.iach >= 0)
 {
  V = f.curvert(); V1 = f1.curvert(); ++iw;
  if(mm) ipp("\neqdot:while: V= ", V,"\nV1= ", V1, " iw= ", iw);
  if(assdot3(V,V1,W)) goto Nxt1;
  if(s.Addsqt(V,&f,V1,&f1)) goto Nxt;             // ??? comp(V1) ??? Addsqt found that V==V1;
  a1 = s.method(V1, &M1, &M0);                      // { if(comp(V1)) goto Nxt1; 
  if(a1==0)                                       // V1 is not a method;
  {      // ! L10 := *@mSS.GrH = *@mSS | (H*H);   is THmSS.H; // subgr :: ! THmSS := *(mSS).Gr = *(mSS)|(P[H]#P[H]);
   // if(mm) ipp("eqdot:while: a1==0,  V= ", V,"\nV1= ", V1, " iw= ", iw);
   if(V==V1) goto Nxt1;
   if(vterm(V,&Q,&M))           // ??? other vterms ???
   {
    if(mm) ipp("eqdot:while:a1==0:(vterm(V,&Q,&M),  V= ", V,"\nV1= ", V1, " iw= ", iw);
    if(Q==V1 && M==W) goto Nxt1;
    if(vterm(V1, &Q1, &M1a) && Q==Q1)   // V1 = *(mSS).Gr, V = *@mSS.GrH;  // GrH = Gr.H;
    {
     if(mm) ipp("eqdot:vterms:V(Q,M),V1(Q1,M1a), M= ", M, " M1a= ", M1a, " valHM(M1a)= ", s.valHM(M1a));
     if(M==M1a || M == s.valHM(M1a)) goto Nxt1;    // M =Gr.H, M1a = Gr; HostMod = subgr:H; valHM(M1a) = Gr.H;
     f.next(); f1.next();                        // go to the depth of V,V1;
     if(mm) ipp("eqdot: going to the depth of V, V1, V= ", V, " V1= ", V1);
     if(f.curvert()==zdot){ f.next(); if(mm) ipp("eqdot: skipping dot in f"); }     // skipping possible dot;
     if(f1.curvert()==zdot){ f1.next(); if(mm) ipp("eqdot: skipping dot in f1"); }  // skipping possible dot;
     goto Nxt1;                                  // skipping Q, Q1: they are equal;  
    } // if(vterm(V1,...)
    if(Q==V1 && M==M1) goto Nxt1;   // ??? rework ??? 10/19/20
    ipp("eqdot: V=Q.M, Q!=V1 || M!=W, Q= ", Q, "\nM= ", M, "\nM1= ", M1, "\nV1= ", V1, " W= ", W);
    goto ret;
   } // if(vterm(V,&Q,&M)),  below V is not a vterm(Q,M));
   if(comp(V) && comp(V1)) goto Nxt;
   ipp("eqdot: V1 is not a method & V != V1, z= ", z, "\nV= ", V, "\nV1= ", V1);
   goto ret;
  } // if a==0)
  // assert(a1==1 || a1==2);      // a==1: VS-method; 
 
  if(a1 == 1)
  { 
   if(mm) ipp("eqdot:while: a1==1,  V= ", V,"\nV1= ", V1, " iw= ", iw);
   if(req(V,M1)) goto Nxt1;           // was(9.07.21) V==M1; M1 is the valm from HostMod for a very simple method
   if(vterm(V,&Q,&M) && Q==V1 && M==W) goto Nxt1;
   ipp("eqdot: V1 is a very simple method, but V != M1, z= ", z, "\nV= ", V, 
              "\nV1= ", V1, "\nM1= ", M1); goto ret;  // W = ImG, 
  } // if(a==1); 
                                  // a==2: NVS-method;
  if(a1 != 2){ ipp("eqdot: wrong a, z= ", z,  "\nV= ", V, " V1= ", V1, " a1= ", a1); goto ret; }
  if(vterm(V,&Q,&M))              // && Q==V1)     //  && M==W) goto Nxt1;
  {
   if(mm) ipp("eqdot:a==2:vterm(V,&Q,&M): V= ", V, "\nV1= ", V1, "\nQ= ", Q, "\nM= ", M); //, "\nW= ", W);
   if(Q != V1)
   {
    if(!vterm(V1,&Q1,&M1)) 
      error("eqdot vterm(V,&Q, &M) but Q != V1 & !vterm(V1,&Q1,&M1), V= ",V,"\nV1= ",V1,"\nQ= ", Q,"\nM= ", M);
    if(Q != Q1) error("eqdot: Q != Q1, V= ", V, "\nV1= ", V1, "\nQ= ", Q, "\nQ1= ", Q1);
    goto Nxt;  // ??? will be correct only if V and V1 are both dot terms or are both adt terms; 
   } // if(Q != V1)
   
   S1 = scopeden(V1);
   M1 = s.valHostMod(S1);
   if(M1==zel || M1 != M) error("eqdot: S1 := Scopeden(V1) in Host, but M1 := valHostMod(S1) is wrong, \nV= ",
     V, "\nV1= ", V1, "\nQ= ", Q, "\nM= ", M, "\nM1= ", M1, "\nS1= ", S1);
   goto Nxt1;
  } // if(vterm(V,&Q,&M))
  SQ1 = scopeden(Q1); S1 = scopeden(V1);
  if(mm) ipp("eqdot:a==2: not vterm(V); V= ", V, "\nV1= ", V1, "\nQ1= ", Q1, "\nSQ1= ", SQ1, "\nS1= ", S1);
  if(V==V1) error("eqdot: V==V1: V must be a dot term V1.W, V1= ", V1, " W= ", W);
  // if(V==V1 && SQ1==S1)
  // { 
  //  ipp("eqdot: V==V1, z= ", z,"\nV= ",V," V1= ",V1,"\nSQ1= ",SQ1," S1= ",S1); 
  //  goto Nxt1; 
  // } // if(V==V1 && SQ1==S1
  goto Nxt;                               // continue comparing;
  Nxt1: f.next1(); f1.next1(); continue;  // next1: goto the right brother or up
  Nxt:  f.next(); f1.next();              //  Nxt: 
 } // end while
 r = (f.iach == f1.iach);  // .p ?? place
 ret: if(!r){ f.prach("f, z= ",z); f1.prach("f1, Q= ", Q); }
 if(9) ipp("-eqdot z= ", z, "\nQ1= ", Q1, "\nW= ", W, "\nr= ",r); // chiMod("-eqdot", -1);  // iMod = -1;
 return r;
} // end eqdot

 bool eqadt(elem Q, elem J, headp h, elemp q)      // Q; is J;  where h->adt == 1; // J = Q(...) or Q = val(Q)
{
 bool r = false; elem a,b,d,d1,P,M,S,S1,V,V1,T = q[0]; headp g; elemp w; int i,dsp, iw=0, hl = h->l; // savemm=mm,
 bool axrefl = iseq(T, &a,&b) && a==b;  sbst s;
 // mm=1;
 if(mm) ipp("\n+eqadt Q= ", Q, "\nJ= ", J, "\nT= ", T );
 if(!h->adt) error("eqadt: J is not adt-term, Q= ", Q, " J= ", J);
 if(fnt2(Q,zA,&d,&P) && !fnt2(T,zA))
 {
  if(mm) ipp("eqadt:Q:A[d,P]: changing Q to P, Q= ", Q, " P= ", P);     // 99: replace later with mm;
  Q = P;
 } // if(fnt2(Q,zA,&d,&P) && ...)
 achs f(Q); achs f1(T);
 S = scopeden(T);
 while(f.iach >= 0 && f1.iach >= 0)
 {
  V = f.curvert(); V1 = f1.curvert(); ++iw;
  S1 = scopeden(V1);
  if(mm) ipp("eqadt:while: V= ", V, "\nV1= ", V1, "\nS= ", S, "\nS1= ", S1, " iw= ", iw);
  // if(mm){ f.prach("f"); f1.prach("f1"); }                    // iw==1: no sense to compare with T;
  if(s.Addsqt(V,&f,V1,&f1) || eqex(V,V1) || iw==1) goto Nxt;    // 0. Trivial subs, ... //  || iw==1 2022.11.25 ???
  // if(axrefl && f1.acteach(&j).p==2 && j==0){ ipp("eqadt:axrefl T= ", T, " V1= ", V1); goto M; }  // to avoid if(S==S1);
  if(S1==zel)                                                   // 1. root names
  { 
   if(V==V1) goto Nxt;
   ipp("eqadt: cause: S1==zel, but V != V1,  Q= ", Q, "\nJ= ", J, "\nV= ", V, " V1= ", V1);
   goto ret;
  } // if(S1==zel)
  
  if(S1==zel1) goto M1;                                  // 2. unnamed V1, continue comparing;
  
  d1 = htbv(V1);
  if(d1 != zel && DinD(d1,S, &dsp))                      // 3. V1 is a very simple method of S;
  {
   i = dsp + V1.i; M = q[i];                             //i = dsp + V1.i -1: -1 was removed, because q[0] was not counted;
   if(mm) ipp("eqadt: V1 is a very simple method of S, V1= ", V1, "\nS= ", S, "\nd1= ", d1, " M= ", M, " i= ", i); 
   if(V == M) goto Nxt1;
   ipp("eqadt: cause: V1 is a very simple method of S, but V != M,  Q= ", Q, "\nJ= ", J, "\nV= ", V,
                                  "\nV1= ", V1, " M= ", M, " i= ", i);  goto ret;
  } // if(d1 != zel && ...)
  if(S1==S)                                              // 4. V1 is a S-method; V must be V1(q1, ... , qk);
  {
   if(mm) ipp("eqadt: 4. V1 is a S-method; V must be V1(q1, ... , qk); \nV1= ", V1, "\nV= ", V, " S1= ", S1); // V is V1(.q.)
   if(mel(V, &g, &w) != pfs) //  || h->l != g->l)             // || w[0] != V1)
   {
    ipp("eqadt: cause: V1 is a S-method, but mel(V) != pfs, is not V1(q1, ... , qk), \nQ= ", Q, "\nV= ", V, "\nV1= ", V1);
    goto ret;
   } // if(mel(V, &g, &w) != pfs ...)
 
   if(w[0] != V1) 
   {
    goto Nxt;     // continue comparing;
   } // if(w[0] != V1)

   if(h->l != g->l)
   {
    ipp("eqadt: cause: V1 is a S-method, but different # args(V,V1), Q= ", Q, "\nJ= ", J, "\nV= ", V,"\nV1= ", V1);
    goto ret;
   } // if(h->l != g->l)
   if(mm) ipp("eqadt:before for: comparing args(V) with args(V1), V= ",  V,  " V1= ", V1); 
   for(i=1; i < hl; i++) if(w[i] != q[i])
   {
    ipp("eqadt: cause: V1 is a S-method, but: w[i] != q[i], Q= ", Q, "\nJ= ", J, "\nV= ", V,"\nV1= ", V1, " i= ", i);
    goto ret;
   } // for(i=1)
   goto Nxt1;
  } // if(S==S1)
  
  M1: if(mm) ipp("eqadt V1 is not a method, Q= ", Q, "\nV= ", V, " V1= ", V1);
  if(comp(V) && comp(V1)) goto Nxt;         // continue comparing;
  ipp("eqadt: cause: one from V,V1 is simple,  Q= ", Q, "\nV= ", V, " V1= ", V1);
  goto ret;
  Nxt1: if(mm) ipp("Nxt1"); f.next1(); f1.next1(); continue;  // next1: goto the right brother or up
  Nxt:  if(mm) ipp("Nxt");f.next(); f1.next();              //  Nxt: 
 } // while(f.iach >= 0 && ...)
 r = (f.iach == f1.iach);  // .p ?? place
 if(!r)
 {
  ipp("eqadt: cause: f.iach != f1.iach, Q= ", Q, "\nV= ", V, " V1= ", V1);
  f.prach("f, Q= ", Q); f1.prach("f1, J= ", J);
 } // if(!r)      
 ret: if(mm) ipp("-eqadt Q= ", Q, "\nJ= ", J, " r= ", r, " iw= ", iw);     // mm=savemm;
 return r;
} // end  bool eqadt;

  bool isbe(elem F,elem A, elem B, elem G, elem d0, elem dpat, ats occur)   // F; by A=B; G; is,by,equal;
{  // search in F for each V, if V is an instance of A,simultaneously movinng in G,then compare s.B and V1;
 bool r=false, found=false; char* str; elem V,V1,D,Q,M; // R0 = root(A); // att a; if B==zel then G is T from T.A;  
 sbst s; headp h,h0,g; elemp q,q0,w; int hl,mA,save,iz=0, savemm=mm; att m, occ=0; elem y,x; //  R0=root(A);  
 //if(check(F.ad, stad1))  mm=1;
 if(9) ipp("\n+isbe F= ",F,"\nG= ",G,"\nA= ", A, "\nB= ", B, "\nd0= ", d0, "\ndpat= ", dpat, " iconvar= ", iconvar, " mm= ",mm); // " occur= ", occur);
 mA = mel(A,&h,&q);
  achs f(F) ; 
  achs f1(G);     // z = F, z1 = F1, but s.Addsqt(V1,&f1,V,&f1), so in x:x1;
 if(F==A && G==B){ if(9) ipp("isbe: F==A && G==B !!!, F= ", F, "\nG= ", G); r = true; goto ret; } 
 
	while(f.iach >= 0 && f1.iach >= 0)     // comparing F and G;
 {
  V = f.curvert(); V1 = f1.curvert(); ++iz;    // 
  // elem R = root(V);    elem R1 = root(V1);
  // if(R != R1){ if(mm) ipp("isbe:while: R != R1, V= ",V,"\nV1= ", V1, "\nR= ", R,"\nR1= ", R1); goto MiVA; }
  if(mm){ ipp("\nisbe:while: V= ",V,"\nV1= ", V1, // "\nR= ", R,"\nR1= ", R1, 
            "\nf.iach= ", f.iach, "  f1.iach= ", f1.iach, " iz= ", iz); s.psbs("isbe:while"); } // if(mm)7
  // if(equal(V,V1)){ found = true;  goto Nxt1; }    // commented on 9.28.20: see dd.d;
		if(s.Addsqt(V1,&f1,V,&f) || V==V1 || V==zE && V1==zEx) goto Nxt1;  //  1.  V==V1
  // if(eqex(R,R1) || R1 == s.vals(R)){ if(V==A) goto Found; goto Nxt; } // below V != V1; // ... || V==V1, not V==V1 ||                  
  save = s.size;
		// if(mm && iz==stad2)  // 2. Then we have to check if A is a special name:
  // mm=mm;               //  Axab,Red,Associnve,Red("f", "dot", "&", "F"),  
		if(A==zAxab)                                                   // 2.1. Axab
  { 
   if(mm) ipp("isbe:Axab  V= ",V,"\nV1= ", V1);
   if(inabt(V,&x,&D) && (occur==0 || ++occ == occur))
			{
			// save = s.size;
			 found = true;
    B = s.redinab(V,x,D); s.size = save;
    if(B==V){ ipp("isbe:Axab: cause: no reduction of V= ", V, " s= ", &s); goto ret; }
    goto Eqt_V1_B;
   } // if(inabt(V,&x,&D) && ...)
  } // if(A==zAxabif(A==zAxab ...)
 
  if(A==zRed)   // bool isst(elem z, elem* main, elem* red)      // 2.2. Red
 	{
		 if(mm) ipp("isbe:Red: F= ", F, "G= ", G );
		 if(isst(V, &y) && (occur==0  || ++occ == occur))               // isst:2  isbe // replace isst(V,&Q,&y) && req(y,V1)
	 	{
		  if(mm) ipp("isbe:Red: after isst, V= ", V, "\ny=  ", y, "\nV1= ", V1);
			 if(mm && V.ad==stad)
    mm=mm; save = s.size; 
    found = true;
			 if(s.eqt(V1,y, d0)){ s.size = save; goto Nxt1; }
    ipp("isbe:Red: cause: wrong Red-term V= ", V, "\nval(V)  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
    s.psbs(); goto ret;     // ret: r=0;
   } // if(isst(V, &B) && ...)
  } // if(A==zRed)
 
	if(A==zAssocinve)                                              // 2.3. Associnve
	{
	 if(mm) 
  ipp("isbe:zAssocinve  V= ",V,"\nV1= ", V1);
  if(mel(V,&g,&w)==pfs && groupmltinve(w[0]))  
  {
   r = eqAssocinve(V,V1); // found = true;
   if(r){ found = true; goto Nxt1; }      // goto Nxt1;
   if(9) ipp("isbe: cause: not eqAssocinve(V,V1), V= ", V, "\nV1= ", V1);
   goto ret;
  } // if(mel(V,&g,&w)==pfs ...)
 } // if(A==zAssocinve)
	                                   
 if(mA==pfs && q[0]==zRed)                                      // 2.4. Red("f", "dot", "&", "F")
 {
  str = strval(q[1]);    hl = h->l;
  
		if(strcmp(str,"free")==0)                                     // 2.4.1 Red("f")
  { 
   if(hl != 3) error("isbe: wrong Red(\"f\",m),F= ", F,  "\nG= ", G, "\nA= ",A, " hl= ", hl);
   y = freered(V,intval(q[2]));  // f-reduction // ??? will work only with V = F, V1 = G; ???
   r = s.eqt(V1,y); 
   if(!r) ipp("isbe: cause: wrong free-term V= ", V, "\ny  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
   else { h->t = truth;  found = true; }  // ??? mktr, wlot(A); // was h->t = truth; 6.2.19;
   goto ret;
  } // if(strcmp(str,"free")==0)
  
  if(strcmp(str,"dot")==0)                                     // 2.4.2 Red("dot")
  { 
   if(hl != 2) error("isbe: wrong number of args in Red(\"dot\"), F= ", F,  "\nG= ", G, "\nA= ",A);
   if(!vterm(V,&Q,&M)) error("isbe: F is not a dot(or adt) term,  F= ", F,  "\nG= ", G); 
   r = eqdot(V1,Q,M);
   if(r){ h->t = truth; found = true; goto ret; }
   error("isbe: F is not a dot(or adt) term,  F= ", F,  "\nG= ", G);
  } // if(strcmp(str,"dot")==0)

		if(strcmp(str,"&")==0)                                       // 2.4.3 Red("&", k)
  {
   if(hl != 3) error("isbe: wrong number of args in Red(\"&\", k), F= ", F,  "\nG= ", G, "\nA= ",A, "\nhl= ", hl);
  // str = strval(q[1]);
  // if(strcmp(str,"&") != 0) error("isbe: wrong str (not &),V= ",V, "\nV1= ",V1, " A= ",A, "q[1].ad= ",q[1].ad); 
   if(!fnt2(V, zconj)) goto Nxt;        // ??? comp(V) && comp(V1) ???
   found = true;
   y = redconj(V,intval(q[2]));         // &-reduction
   if(s.eqt(V1,y)){  h->t = truth; found = true; s.size = save; goto Nxt1; }   // if(s.eqt(V1,y, d0)) goto Nxt1;
   ipp("isbe:Red(&,m) : cause: wrong special term V= ", V, "\ny  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
   s.psbs(); goto ret;
  } // if(strcmp(str,"&")==0) 

  if(strcmp(str,"F") == 0)                                      // 2.4.4 Red("F"): F[d,Q](...)
  { 
   if(mm) ipp("isbe: +Red(\"F\") V= ", V, "\nA= ", A);
			if(mm)
   mm=mm;
   if(m=mel(V, &h0, &q0) != pfs) goto Nxt;                   
			if(fnt2h(q0[0],zF,&g,&w))                                      // q0[0] = F[d,Q]
			{
			 if(mm) ipp("isbe:Red(\"F\"): before redAF, V= ", V, "\nV1= ", V1); // "\ny=  ", y,
    y = redAF(V,h0,q0,w);
    if(mm) ipp("isbe:Red(\"F\"): after redAF, V= ", V, "\ny=  ", y, "\nV1= ", V1);
			 // if(mm && V.ad==stad)
    // mm=mm;
    if(s.eqt(V1,y, d0)){ s.size = save; found = true; goto Nxt1; }
    ipp("isbe:Red(\"F\"): cause: wrong F-term V= ", V, "\ny  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
    s.psbs(); goto ret;     // ret: r=0
   } // if(fnt2h(q[0],zF,&g,&w))
  } // if(strcmp(str,"F")==0) 
 } // if(mel(A,&h,&q)==pfs ...)

  if(mm) ipp("isbe:while: end of 1.special names(Axab,Red, ... \nV= ", V, "\nV1= ", V1, " iz= ",iz); // "\nR= ", R, "\nR1= ", R1,
  // if(eqex(R,R1) || R1 == s.vals(R)){ if(V==A) goto Found; goto Nxt; }                       // composite R, R1 ???
 
  save = s.size;    // if(9) ipp("isbe:while after eqex mm= ", mm);      
  // if(mm){ s.psbs); 
  // ipp("isbe:while: R != R1, checking R is instance of A, \nV= ", V, "\nV1= ", V1,"\nR= ", R,"\nR1= ", R1, "\nA= ", A); }
  // if(mm) f.prach("f: isbe:while: found: comp(R), R= ", R); // if(comp(R)) goto Nxt;
  // if(comp(R) && s.instance(R,A,d0,zel0,&f))
  // {
  // if(s.eqt(R1,B,d0)){ found = true; f.next(); f1.next();  goto Nxt1; }   // f.next();
  // else if(mm) ipp("isbe: not eqt(R1,B)\nV1= ", V1, "\nR1= ", R1, "\nB= ", B, " s= ", &s);
  // } else if(mm) ipp("isbe: not comp(R) or not instance(R,A)\nV= ", V, "\nR= ", R, "\nA= ", A, " s= ", &s);
  // if(R != R0)    // temp: use also f !!!
  // { 
  //  if(9) ipp("isbe: R:root(V) != R0:root(A), V= ", V, "\nR= ", R, "\nV1= ", V1, "\nA= ", A, "\nR0= ", R0);
  //  if(comp(V) && comp(V1)){ s.size = save;  goto Nxt; }  // continue comparing, there is still hope; 
  //  if(9) ipp("isbe: cause:  R != R0: V is not an instance of A, V= ", V, "\nV1= ", V1, "\nA= ", A); goto ret;
  // } // if(R != R0)
  s.size = save;
  // if(mm) f.prach("f:  isbe:while: V != V1");
  if(mel(V)==abt && mel(V1)==abt && mel(A)==abt)          // ???
  {
   if(99) error("isbe: mel(V)==abt && mel(V1)==abt && mel(A)==abt: before s.eqt(V,V1), \nV= ", V, "\nV1= ", V1, "\nA= ",A);
   if(s.eqt(V,V1)) goto Nxt1;
  } // if(mel(V)==abt && mel(V1)==abt && mel(A)==abt)
  if(mm) ipp("\nisbe: V != V1: checking s.instance(V,A,d0,zel0,&f), \nV= ", V, "\nV1= ", V1, "\nA= ",A);
  if(s.instance(V,A,d0,dpat,&f)) goto Found;  // MiVA:  // s.instance can change s.size, so  s.size = save in next line;
  /*                                              commented on 2022.02.17
  if(comp(V)) a = f.iach-1; else a = f.iach;
  for(i=a; i>=0; i--)                             // it is possible double work of s.instance;
  {
   s.size = save; V = (f.ach)[i].e; V1 = (f1.ach)[i].e;  // int bvqt(V): write bv(V) into st, r = number(bv(V))
   s.removebvars(V);   // was  if(i==0) s.size = 0; 
   save = s.size;
   if(9) ipp("isbe: changed V= ", V, "\nV1= ", V1, "\ns.size= ", s.size, " save= ", save);
   if(s.instance(V,A,d0,zel0,&f)) goto Found; 
  } // for(i=f.iach)
  */
  if(mm) ipp("isbe: !s.instance(V,A,...): continue comparing V with V1, V= ", V, "\nV1= ", V1, "\nA= ", A, " iz= ", iz);
  if(comp(V) && comp(V1)){ s.size = save;  goto Nxt; }  // continue comparing, there is still hope;
  if(9) ipp("isbe: cause: V or V1 is simple,  V is not an instance of A, \nV= ", V, "\nV1= ", V1, "\nA= ", A);
  goto ret;                                             // no hope, because V or V1 is simple; 
  Found:  found = true;
  if(mm) ipp("\nisbe:found an instance V of A= ", A, "\nV= ", V, "\nB= ", B, " s= ", &s);   // was mm;
  if(occur!=0 && ++occ != occur)
  {
   if(9) ipp("\nisbe: V is an instance of A, but occur != occ, so Nxt1,  F= ", F, "\nV= ", V, 
              "\nA= ", A,  "\noccur= ", occur, " occ= ", occ);
   s.size = save;  goto Nxt1;
  } // if(occur!=0 && ++occ != occur)                                         // 2: sign of eqt(V1, B)
  Eqt_V1_B: if(mm) ipp("isbe: checking s.eqt(V1,B), \nV1= ", V1, "\nB= ", B); // was s.eqt(V1,B): 2022.01.16
  if(s.eqt(V1,B,d0,dpat, 2)) {  s.size = save; goto Nxt1; }  // || s.eqt(V1,V): see EqProof TfreeAimp1; F3:
  if(mm) ipp("isbe: checking(???) s.eqt(V1,V), \nV1= ", V1, "\nV= ", V);  // ?????
  if(s.eqt(V1,V)){ ipp("isbe:s.eqt(V1,V) finished, \nV1= ", V1, "\nV= ", V);  s.size = save; goto Nxt1; }          
  if(V==F)  // see EqProof -Texp2: F1 := x*x;  by -Texp1;               // ! Texp1 := A[a:elg, a^1 = a];             
  {         //                     F2 := x^1 * x^1;    //  a was matched with x*x but F2 is not (x*x)^1;
   ipp("isbe: not eqt(V1,B), but V==F, so goto Nxt, F= ", F, "\nV= ", V, "\nV1= ", V1, "\nB= ", B, " s= ", &s);
   s.size = 0;  goto Nxt;
  } // if(V==F)
  if(9) ipp("isbe: cause: not eqt(V1,B): \nF= ", F, "\nV= ", V, "\nV1= ", V1, "\nB= ", B, " s= ", &s); 
  goto ret;
  Nxt1: f.next1(); f1.next1(); continue;
  Nxt: f.next(); f1.next();
 } // end while
 r = found && (f.iach == f1.iach);
 if(!found) ipp("isbe: A was not found in F or A is wrong, F= ", F, "\nA= ", A, " r= ", r," iz= ", iz); 
 ret: if(!r || mm)
 {  
  s.psbs(); 
  f.prach("f: F= ", F);
  f1.prach("f1: G= ", G); 
  ipp("-isbe F= ", F, "\nG= ", G, "\nA= ", A, "\nB= ",B,"\nr= ",r," iz= ", iz, " savemm= ", savemm);
  // if(f.iach==f1.iach && f.iach > 0)   // temp !!! rework !!! 2022.01.27
  // { 
  //  f.pach(); f.ach[f.iach].p = -1;    V = f.curvert(); 
  //  f1.pach(); f1.ach[f1.iach].p = -1; V1 = f1.curvert();
  //  ipp("isbe: r=0, tried f.pach(), f1.pach(), V= ", V, "\nV1= ", V1);
  //  ++iz; goto MiVA;
  // } //  if(f.iach==f1.iach && f.iach > 0)
 } // if(!r || mm)
   mm=savemm; return r; // was if(mm || !r
} // end isbe
                                                 // isbe: is by equality, isbd: is by def: z is a model of d;
  bool isbd(elem F,elem d, elem z, elem G)       // F; by d.1=z(1), ... , d.k=z(k); G;
{                                                // prf: case 13: Q; is A[d, Q2](Q3 := z in d)
 if(mm) error("+isbd: F= ", F, " d= ", d, " z= ", z, " G= ", G);  // changed ipp to error on 6.5.20(research)
 achs f(F) ; achs g(G); bool r=false; // = new achs(F) = new achs(G)
 int i,k; elemp q;
 if(!seqv(z, &k, &q)) error("isbd: not sequence z= ", z); // k = h->l - 1
 if(ldev(d) != k) error("isbd: wrong lengths, d= ", d, " z= ", z);
 while(f.iach >= 0)
 {
  elem V = f.curvert(); elem W = g.curvert();
  if(req(V, W)) goto Nxt;
  if(!dname(V, d, &i)) goto ret;                    // x == d ++ i, mel(d) == abt
  if(req(q[i], W)) { f.next1(); g.next1(); continue; }
  goto ret;  // return false;
  Nxt: f.next(); g.next();
 } // end while
 r = true;
 ret: if(mm) ipp("-isbd: F= ", F, " G= ", G, " r= ", r); 
} // end isbd


/*   void mktrp(elem z) // make true the formula z (add code if root(z) is &)
{
 headp h; elemp q; // bool b;
 if(mm) ipp("+mktrp z= ", z);
 if(mktr(z, &h, &q))                // composite
 {
  // if(q[0] == zexc) b = mktr(q[1],&h,&q);
  // if(q[0] == yasop) mktr(q[2], &h, &q);
 } // if
 if(mm) ipp("-mktrp z= ", z);
} */ // end void mktrp(elem z) 	   

   void byimp(elem x1, elem x, elem x2)      //x1;  byimp x:=(Q1 -> Q2); x2; 
{                    // x1 is s.instance of(Q2); R = s.rep(Q1); must: req(R,x2);
 elem Q1,Q2,R; headp g; elemp w; sbst s;
 if(9) ipp("+byimp: x1= ", x1, " x= ", x, " x2= ", x2); 
 if(!fnt2h(x, zimp, &g, &w)) error("byimp: not implication  x= ", x);
 Q1 = w[1]; Q2 = w[2]; 
 if(!s.instance(x1,Q2)) error("byimp: x1 is not an instance  Q2= ", Q2, " x1= ", x1, " x= ", x, " x2= ", x2);
 R = s.rep(Q1, "byimp");
 if(9) ipp("byimp1: R= ", R);
 if(isst(R)) R = redst(R);                // isst:1 byimp
 if(9) ipp("byimp2: R= ", R);
 // R = redsp(R);
 // if(mm) ipp("byimp:after redsp R= ", R);
 if(!req(R, x2)){s.psbs("byimp"); error("byimp: (R:=s.rep(Q1)) ~= x2, \nx1= ", x1, "\nx= ", x, "\nx2= ", x2, "\nR= ", R); }
 if(proofdepth) wrdep(x1,x2,x);    // q[1] is Q1 -> Q2;
 if(9) ipp("-byimp: x2= ", x2, " R= ", R); 
} // end void byimp

   elem prf(elem z, headp hh, elemp qq)  // Proof(goal; Q0; ... , Qm);
{
 int iii, m,save = iconvar,ditt,saveitt=ptt->itt,savemm=mm;        // see elem x=zel; below;
 elem x1=zel,x11, x2=zel,t1=zel,t2=zel,y,c1,c2; elem goal = qq[1]; // goal: the current goal; // x11,x1,x,x2;
 elem goal2, goal_init = goal; sbst s;                    // goal_init: the initial goal; // goal2: the last formula;
 headp h,g; elemp q,w;  bool save_wasassume = wasassume; att savet = hh->t; hh->t = 0; // b1,b2,
 // if(check(goal.ad, stad2)) mm=1;  
 if(mel(goal,&h) != pfs) error("prf: wrong( goal= ", goal);
 h->t = 0;
 if(9) ipp("+prf: goal= ",goal," proofdepth= ",proofdepth," iconvar= ",iconvar," mm= ",mm," ilot= ",ilot," idep= ", idep);
 compdc(goal, "prf"); 
 ++proofdepth;
 if(mm) ipp("+prf qq[3]= ", qq[3]);
 int saveilot = ilot; int saveidep = idep; elem savegoal = goal; int k;
 int lproof = hh->l;
 if(lproof <= 2) error("prf: empty proof: goal= ", goal);
 elem x=zel;          //goal;     // error should use global variable in err() - to continue work!
 elem t=zel;          // typ(goal);    // or better: if first symbol in first par-er is blank, then continue
 if (typ(goal) != zbool) error(" prf: goal is not a formula, goal = ", goal);
 int iconj = 0;    // iii = 2; commented on 9.15.19
 for(iii=1; iii < lproof; iii++)         // main loop;
 {
  if(9) ipp("prf:+for: iii= ", iii);
  x11 = x1; x1 = x; x = qq[iii];         // x is the current, x1 is the previous;
  t1 = t; t = typ(x);                    // t is the type of the current, x1 is the type of the previous;  
  if(iii > 1) pntu->wrp(iii);            // ach[iach].p = iii;  
  // if(check(x.ad, stad1)) //  && iii==stad1)
  // mm=1;
  if(9) ipp("prf:iii, x= ", x, "\niii= ", iii, " ilot= ", ilot, " mm= ", mm); 
  if(mm) prlot("prf:iii");
  if(t == zel) error("prf: wrong type of x, \ngoal= ", goal,  "\nx1= ",x1, " x= ", x);
  
  if(x == zassume){ hnassume(x1, &goal); continue; }       // x1; assume;
  t = typ(x, &h, &q);  // if smel(x) then h == 0;
  if(mm) ipp("prf: type of x= ", x, " is t= ", t);
  if(mm && (h==0)){  ipp("typ: simple x= ", x, " t= ", t);  continue; }
  // if(iii < lproof-1){ x2 = valdexc(qq[iii+1]);  t2 = typ(x2); }
  if(mm) ipp("prf: complex x= ", x, " t= ",t);
  if(t == zassume){ hnassume1(q[1], &goal); continue; }  // assume(x); x is bvar;
 
  if(t == zby)                 // x === by(z1, ... , zk);
  {                            // x1; x; x2;
   if(mm) ipp("prf: +by:x1= ",x1, " x1a= ", x1a, " t1= ", t1);
   if(!istrbyis(x,h,q)) error("prf: by(...) is not true, goal= ", goal, "\nby(...)= ", x); // add on 2021.09.08
   if(iii >= lproof-1) error("prf:by: iii >= lproof-1: goal_init= ", goal_init, " x1= ", x1, "\nx= ", x, 
                                         " iii= ", iii, " lproof= ", lproof); 
   // if(t1 != zbool && t1 != zis && t1 != zbyeq && x1 != zassume)
   //  error("prf: not formula before by, formula =", x1, ", t1= ", t1);
   if(t1==zis || t1==zbyeq || x1==zassume) x1 = x1a; // x1a: formula before is or byeq or assume; x1a = qq[iii-2];
   else if(t1 != zbool) error("prf: not formula before by, formula =", x1, ", t1= ", t1);
   x2 = qq[iii+1];
   hnby(x1,x,h,q,x2);
   // if(istr(x1)) mktr(x2);    // ??? alredy in hnby
   // if(istr(x2)) mktr(x1);    // ??? alredy in hnby
   if(proofdepth)
   { 
    if(isrt(x2,zis,&w,&g)){ if(comp(w[1]) ) wrdep(x1,x,w[1]); else wrdep(x1,x);}
    else { wrdep(x1,x,x2); wrdep(x2,x,x1); }
   } // if(proofdepth)
   if(mm) ipp("prf: -by");
   continue;
  } // end if zby	   
  // if(simple(x)) error("prf: simple(x);  x1= ", x1, " x= ", x, "\nz= ", z); // ??? TEMPORARY: type byeq(}... is not byeq;
  
  if(t == zbyeq)              // x1; x === byeq(z1, ... , zk);  
  {   
   x1a = x1;
   if(x1.ad==stad2)
   mm=mm;
   if(!hnbyeq(x1,x,h,q)) error("prf: wrong byeq x, x1= ", x1, " x= ",x, "\nz= ", z); 
   continue;
  } // end if zbyeq

  if(t == zbyimp)      //x1; x := byimp(Q1 -> Q2); x2; // x1 follows from x2, due (Q1 -> Q2);
  {                    // x1 is s.instance of(Q2); R = s.rep(Q1); must: req(R,x2);
   if(iii == lproof-1) error("prf: byimp: wrong(last) byimp, \ngoal= ", goal, "\nx1= ", x1, "\nx= ", x);
   x2 = qq[iii+1];
   if(typ(x2) == zel) error("prf:byimp: wrong x2,  \ngoal= ", goal, "\nx1= ", x1, "\nx= ", x, "\nx2= ", x2);
   byimp(x1, q[1], x2);  // mm in byimp
   continue;
  } // if(t == zbyimp)
 
  if(t == zis)
  {
   if(mm) ipp("prf:is: x1= ", x1, " x1a= ", x1a);
   x1a = x1;
   if(t1 == zby) continue;   // hnby already handles this is;
   // if(t1 != zbool) error("prf: not formula before is, formula =", x1): hnis wll check !!!
   hnis(x1, q[1], " prf:is ");
   continue;
  } // end if zis

  if(t == zfrom)              // x == from(q1);
  {                           // x1; x;  must: q1 -> x1;
   if(t1 != zbool) error("prf: not formula before from, formula =", x1);
   y = trm2(zimp, q[1], x1, zbool); // ? used fixed place in tabt
   if(Taut(y) || seektrimp1(q[1], x1)) goto M;
   error("prf:M1; from(Q1): Q1->M1 not true, M1= ",x1," Q1= ",q[1]);
   M:  if(proofdepth) wrdep(x1,q[1]);
   continue;
  } // end if zfrom

  if(t == zwith)              // x == with(q1);
  {                           // x1; with(q1); x2;
   assert(iii < lproof-1);
   x2 = qq[iii+1];
   t2 = typ(x2);
   if(x1 == zassume || fnt1(x1,zis)) x1 = x1a;
   if(mm) ipp("prf:with: x1= ", x1, "\nq[1]= ", q[1], "\nx2= ", x2);
   if(t2 != zbool) error("prf: not formula after with, formula =", x2);
   bool b = hnexcwith(x2,x1,q[1]);    
   if(!b) error("prf:with= ", q[1], "\nbefore with= ", x1, "\nafter with= ", x2); //  M2; M1 & Q1->M2 not true, M1= ",x1," Q1= ",q[1], " M2= ", x2);
   if(proofdepth) wrdep(x2,x1,q[1]);
  } // end if zwith
 } // end for(iii=1)

 goal2 = (root(x)==zis || root(x)==zbyeq)? x1: x;      // last formula; // make a separate function Lastformula(q,iii) ???
 if(!req(goal2, goal))             // G0 := c in perm;    by Axdconj; LcAFN & F0; // goal = c in perm
 {
  if(root(x1)==zby) goal2 = x11;   // x11,x1,x;  && istr00
 } // if(!req(goal2, goal)
 if(mm) ipp("prf: goal= ", goal, " last formula goal2= ", goal2 ); // b3 = true;
 /*
 if(isrt(goal2,zis, &w) && (w[1]==zTaut || w[1]==zStaut)) goal2 = zel;
 if(iconj != 0) error("prf: end of proof: wrong iconj, qq[1]= ", qq[1], " iconj= ", iconj);
*/
 k = saveidep+1;                        // // k: beginning in dep for z; 
 if(indep(goal,k) || fnt2(goal,zconj, &c1, &c2 ) && indep(c1,k) && indep(c2,k)) goto Mcldep; 
 prdep(goal);
 error("prf: no goal in dep, goal= ", goal, "\ngoal_init= ", goal_init);  // ??? general case ??? 11.10.20

 Mcldep: m = cldep(goal, saveidep+1);  // inlist uses req, inList: does not; // was cldep(goal_init, 2023.01.23
 if(m)
 {
  prdep(goal);
  prlot("if(m)");
  // error("prf: not proved goal= ", goal, "\ngoal_init= ", goal_init, 
  //      "\ngoal2= ", goal2, ", number of unproved formulas= ", m);
 } // if(m)           // true(goal) or true(goal2) & goal2=goal // indep(goal) 
 if(!istr00(goal,"prf-m")  && (!istr00(goal2,"prf-m") || ! req(goal,goal2)) )  // 2023.02.12 left only !istr00(goal,"prf-m") 
  error("prf: !istr00(goal) && (!istr00(goal2) || !req(goal,goal2)), \ngoal= ", goal, // restored 2023.03.28 (proof LHinvGr);
     "\ngoal_init= ", goal_init, "\ngoal2= ", goal2);
 if(--proofdepth == 0) wasassume = false;
 mktr(goal_init);  
 if(mm) ipp("prf:mktr(goal), goal= ", goal);   //  " b1= ", b1, " b2= ", b2);
 goal = savegoal;
 if(mm) prlot("-prf");
 chilot("-prf, saveilot ", saveilot); // ilot = saveilot; 
 idep = saveidep;
 if(proofdepth > 0) wrdep(goal_init, ztrue); // wlot(goal_init); because mktr(goal_init) is below; commented on 7.17.20: z is Proof
 // if(goal != goal_init) mktr(goal); 
 iconvar = save; ditt = ptt->itt - saveitt; // hh->t = savet: see mktr above;
 if(ditt > maxdittp){ maxdittzp = goal_init; maxdittp = ditt; } ;
 mm=savemm; wasassume = save_wasassume;
 if(9) ipp("-prf:SUCCSESS: goal_init= ",goal_init,"\ngoal= ", goal," wasassume= ", wasassume," idep= ",idep, " mm= ", mm);
 return zProof;  // no ret label allowed: because of proofdepth;
} // end elem prf
                                               // ada: address of a, was aa;aab at start: a, at finish: b;
 int cprf(elemp agoal, elemp qq, int first, int last1, elemp ada, elemp ab )    // common part prf and eqprf;
{                                                                // x:current element, t: its type; x1 - previous x;
 int r= -1, iii; elem goal= *agoal, x= zel, t= zel, x1,t1,x2,t2,y,a,b; // a= ada? *ada:zel999, b= ab? *ab:zel999; 
  headp h,g; elemp q,w; bool wasmn= false; 
 if(99) ipp("+cprf goal= ", goal, "\nqq[first]= ", qq[first], " first= ", first, " last1= ", last1);
 if(mm) prlot("cprf:iii");
 typ(qq[1]);
 if(mm) ipp("cprf:after typ: qq[1]= ", qq[1]);
 if(fnt1(qq[1],zmnbool, &goal))   // when goal changes, also try to change a, b;
 { 
  wasmn = true; 
  if(mm) ipp("cprf qq[1]= ", qq[1], " goal= ", goal, " wasmn= ", wasmn);
 } //  if(fnt1(qq[1],...)

 if(iseq(goal, &a, &b)) { if(wasmn) swap(&a,&b); } else { a = zel; b = zel;  };

 for(iii= first; iii < last1; iii++)         // assume loop;
 {
  x1 = x; x = qq[iii]; typ(x);                // x is the current, x1 is the previous;
  hint = zel; hintstr = " ";
  if(99) ipp("cprf:for ass, goal= ",goal,"\nqq[iii](x)= ",x, "\na= ",a, "\niii= ",iii, " ilot= ",ilot, " mm= ",mm);
  if(iii < last1-2 && mystring(qq[iii+1],"hint")) { hint = qq[iii+2]; if(99) ipp("cprf:hint x= ", x, " hint= ", hint); }
                                                
  if(req(a, x))           // looking for F1;
  { 
   if(mm) ipp("cprf:found a=b or a==b : goal= ", goal, "\na= ", a, "\nb= ", b, " x= ",x);
   // if(wasmn) swap(&a, &b);
   r = iii; *ada = a; *ab = b; goto ret; 
  } // if(eqp && ...)

  t1 = t; t = typ(x, &h, &q);          // t is the type of the current, x1 is the type of the previous;  
  if(iii > 1) pntu->wrp(iii);          // ach[iach].p = iii;  
  if(t==zel) error("cprf: wrong type of x, \ngoal= ", goal,  "\nx1= ",x1, " x= ", x);
  
  if(x == zassume)         // { hnassume(x1, t1, iii, last1, qq, goal); continue; }       // x1; assume;
  {
   hnassume(x1, &goal);
   if(mm) ipp("cprf:assume: goal changed to goal= ", goal);
   // goal = *agoal; 
   if(iseq(goal,&a,&b)) { if(wasmn) swap(&a,&b); } else{ a = zel; b = zel; }
   continue;          // x1e = x1m; t1e = t1m; continue; 
  } // if(x==zassume) 
  
  t = typ(x, &h, &q);  // if smel(x) then h == 0;
  if(mm) ipp("cprf: type of x= ", x, " is t= ", t);
  if(mm && (h==0)){  ipp("typ: simple x: no action, x= ", x, " t= ", t);  continue; }
  if(mm) ipp("cprf: complex x= ", x, " t= ",t);
  
  if(t == zassume)             // { hnassume1(q[1], goal); continue; }  // assume(x); x is bvar;
  {
   hnassume1(q[1], &goal);
    if(mm) ipp("cprf:assume1: goal changed to goal= ", goal);
   // goal = *agoal; 
   if(iseq(goal,&a,&b)){ if(wasmn) swap(&a,&b); } else{ a = zel; b = zel; }
   continue; 
  } // if(t==zassume)

  if(t == zby)                 // x === by(z1, ... , zk);
  {                            // x1; x; x2;
   if(mm) ipp("cprf: +by:x1= ",x1, " x1a= ", x1a, " t1= ", t1);
   if(!istrbyis(x,h,q)) error("cprf: by(...) is not true, goal= ", goal, "\nby(...)= ", x); // add on 2021.09.08
   if(iii >= last1-1) error("cprf:by: iii >= lproof-1: qq[1]= ", qq[1], " x1= ", x1, "\nx= ", x, 
                                         " iii= ", iii, " last1= ", last1); 
   if(t1==zis || t1==zbyeq || x1==zassume) x1 = qq[iii-2]; // qq[iii-2]: formula before is or byeq or assume;
   else if(a==zel1 && t1 != zbool) error("cprf: not formula before by, formula =", x1, ", t1= ", t1); // zel1: in prf;
   x2 = qq[iii+1];
   hnby(x1,x,h,q,x2);
   if(proofdepth){ if(isrt(x2,zis,&w,&g)) wrdep(x1,x,w[1]); else { wrdep(x1,x,x2); wrdep(x2,x,x1); } }  // see prf. 01.31
   if(mm) ipp("cprf: -by");
   continue;
  } // end if zby	   
  // if(simple(x)) error("cprf: simple(x);  x1= ", x1, " x= ", x, "\nz= ", z); // ??? TEMPORARY: type byeq(}... is not byeq;
  
  if(t == zbyeq)              // x1; x === byeq(z1, ... , zk);  
  {   
   if(!hnbyeq(x1,x,h,q)) error("cprf: wrong byeq x, x1= ", x1, " x= ",x, "iii= ", iii); 
   continue;
  } // end if zbyeq

  if(t == zbyimp)      //x1; x := byimp(Q1 -> Q2); x2; // x1 follows from x2, due (Q1 -> Q2);
  {                    // x1 is s.instance of(Q2); R = s.rep(Q1); must: req(R,x2);
   if(iii == last1-1) error("cprf: byimp: wrong(last) byimp, \ngoal= ", goal, "\nx1= ", x1, "\nx= ", x);
   x2 = qq[iii+1];
   if(typ(x2) == zel) error("cprf:byimp: wrong x2,  \ngoal= ", goal, "\nx1= ", x1, "\nx= ", x, "\nx2= ", x2);
   byimp(x1, q[1], x2);  // mm in byimp
   continue;
  } // if(t == zbyimp)
 
  if(t == zis)
  {
   if(mm) ipp("cprf:is: x1= ", x1);
   if(t1 == zby) continue;   // hnby already handles this is;
   // if(t1 != zbool) error("cprf: not formula before is, formula =", x1): hnis wll check !!!
   hnis(x1, q[1], " cprf:is ");
   continue;
  } // end if zis

  if(t == zfrom)              // x == from(q1);
  {                           // x1; x;  must: q1 -> x1;
   if(t1 != zbool) error("cprf: not formula before from, formula =", x1);
   y = trm2(zimp, q[1], x1, zbool); // ? used fixed place in tabt
   if(Taut(y) || seektrimp1(q[1], x1)) goto M;
   error("cprf:M1; from(Q1): Q1->M1 not true, M1= ",x1," Q1= ",q[1]);
   M:  if(proofdepth) wrdep(x1,q[1]);
   continue;
  } // end if zfrom

  if(t == zwith)              // x == with(q1);
  {                           // x1; with(q1); x2;
   assert(iii < last1-1);
   x2 = qq[iii+1];
   t2 = typ(x2);
   if(x1 == zassume || fnt1(x1,zis)) x1 = x1a;
   if(mm) ipp("cprf:with: x1= ", x1, "\nq[1]= ", q[1], "\nx2= ", x2);
   if(t2 != zbool) error("cprf: not formula after with, formula =", x2);
   bool b = hnexcwith(x2,x1,q[1]);    
   if(!b) error("cprf:with= ", q[1], "\nbefore with= ", x1, "\nafter with= ", x2); //  M2; M1 & Q1->M2 not true, M1= ",x1," Q1= ",q[1], " M2= ", x2);
   if(proofdepth) wrdep(x2,x1,q[1]);
  } // end if zwith
 } // end for(iii= first)
 ret: // if(goal != *agoal){ ipp("cprf: goal != *agoal, goal= ", goal, " *agoal= ", *agoal, " mm= ", mm); *agoal = goal; } 
      if(ada) *ada = a; if(ab) *ab = b;
      *agoal = goal;
      if(mm) ipp("-cprf *agoal= ", *agoal,"\nqq[1]= ", qq[1], " r= ", r);
      return r;
} // end void cprf

    elem eqprf(elem z, headp hh, elemp qq)  // z = EqProof(goal; Q0; ... , Qm);
{                                           // no internal proofs in EqProof(...)???
 int iii,k,ditt,saveitt=ptt->itt, saveilot=ilot, saveidep = idep, save=iconvar, savemm=mm;
 bool save_wasassume = wasassume; wasassume = false;
 elem x=zel, x1,x2,t,t1,t2,a=zel,b=zel;   // x1e, t1e were x1a, t1a; 
 elem goal = qq[1],  goal2 = goal; // goal2: mn-stripped, for wrden;
 headp g; elemp w,w1; bool wasmn = false; 
 typ(goal); dc=zel; idc=0;
 if(fnt1(goal2, zmnbool, &x1)) goal2 = x1;
 if(9) ipp("\n+eqprf z= ", z, "\ngoal= ",goal, " goal2= ",goal2, " wasassume= ",wasassume, " ilot= ", ilot, " mm= ", mm );
  ++proofdepth; typ(goal);
 // if(wasassume) *pfhis << "\nwasassume= " << wasassume;
 //if(ilot != -1) *pfhis << "\nilot= " << ilot;  
 // if(typ(goal,&h,&q) != zbool) error("eqprf: goal is not formula,goal= ", goal); 
 // if(fnt1(goal,zmnbool,&q)){ goal = q[1];  wasmn = true; }
 // compdc(goal, "eqprf");    // decompose goal into (dc,gdc, ...); P1&P2 -> Q => (dc=P1&P2, gdc=Q, ...);
 // if(!iseqmn(goal,&a,&b)){ a = zel; b = zel; }
 // int saveilot = ilot; int saveidep = idep; // elem savegoal = goal;
 int lproof = hh->l;
 x1 = qq[2];  // t1 = typ(x1);  // i = 2;
 //  below goal is not mn-stropped;
 k = cprf(&goal, qq, 2, lproof, &a, &b);          // ab=0:  called from prf; // after cprf goal is not used !!!
 if(k<0) error("eqprf: no initial formula, qq[1]= ", qq[1], "\ngoal= ",goal, " a= ", a, " b= ", b); 
 if(!req(qq[k], a)) error("eqprf: wrong initial formula a: !req(qq[k] \nz= ", z, "\ngoal= ",goal, 
           "\nqq[k]= ", qq[k], " a= ",a, " b= ", b);
 x2 = qq[lproof-1]; 
 t = typ(x2); if(t == zel) error("eqprf: wrong x2= ", x2);
 if(!req(x2,b)) error("eqprf: wrong b or the last in proof,\ngoal= ",goal,"\nb= ", b, "\nqq[last]= ", x2);
 if(mm)
 {
  ipp("eqprf: main loop, qq[1]= ", qq[1], "\ngoal= ", goal, "\nk= ", k, " lptoof= ", lproof);
  if(mm) prlot();
 } // if(mm)

 for(iii=k; iii<lproof-1; iii+=2)    // main loop;
 {
  x1 = qq[iii]; 
  if(99) ipp("eqprf:iii main: for i=k, x1= ", x1, " iii= ", iii); // , " istqab= ",istqab);
  // if(stad != 0 && x1.ad==stad) mm=1;
  t1 = typ(x1);    // if(t1 == zel) error("eqprf: wrong x1= ", x1);
  x = qq[iii+1]; t = typ(x,&g,&w);
  if(t != zby && t != zadd) error("eqprf: not by or add:\ngoal= ", goal , "\nx= ", x);
  x2 = qq[iii+2]; t2 = typ(x2);
  if(t == zadd)
  {
   // if(i == 1) error("hnbybyeq: add: i==1, \nF= ", F, "\nG= ", G); 
   if(typ(w[1]) != zbool) error("eqprf: add: not formula in add(w[1]= \nw[1]= ", w[1], " iii= ", iii); 
   if(typ(x1) != zbool) 
      error("eqprf ", qq[1], " add: not formula x1 before add),\nx1= ", qq[iii-1], " iii= ", iii);
   if(!istr0(w[1])) error("eqprf: add: not true: \nw[1]= ", w[1]); 
   if(!fnt2h(x2,zconj,&g,&w1))
      error("eqprf ", qq[1], " add: not conjunction after add(w[1]), \nx2= ", x2, " iii= ", iii); 
   if(!req(x1,w1[1]))
      error("eqprf ", qq[1], " add: x1 != x2.1, \nx1= ", x1, "x2.1= ", w1[1], " iii= ", iii); 
   if(!req(w[1], w1[2])) 
      error("eqprf ", qq[1], " add: (w[1] in add) != x2.2, \nw[1]= ", w[1], "\nx2.2= ", w1[2], " iii= ", iii); 
   continue;
  } // if(t == zadd)
  if(!hnbybyeq(x1,x,g,w,x2)) 
    error("eqprf: wrong by-element x,\ngoal= ",goal, "\nx1= ",x1, "\nx= ",x, "\nx2= ",x2, " qq[1]= " , qq[1]);
  if(!istr0(x)) error("eqprf: not true formula in by:x, goal= ", goal, "\nx1= " , x1, "\nx2= ", x2, "\nx= ", x);
 } // end for(iii)
 chilot("-eqprf, saveilot ", saveilot);  // ilot = saveilot; 
 idep = saveidep; --proofdepth; wasassume = save_wasassume;
 mktr(goal2); if(hhh) ipp("eqprf: after mktr: iach= ", pntu->iach, " wasassume= ", wasassume);
 if(proofdepth > 0){ wrdep(goal2, ztrue); wlot(goal2,"eqprf"); }  // ??? replace ztrue with zEqProof ???
 iconvar = save; ditt = ptt->itt - saveitt;
 if(ditt > maxditteqp){ maxdittzeqp = goal; maxditteqp = ditt; } ;
 if(9) ipp("-eqprf: goal= ", goal, " goal2= ", goal2); mm=savemm;
 *pfhis << "\nwasassume= " << wasassume;
 *pfhis << "\nilot= " << ilot;  
 return zEqProof;     //  no ret label allowed: because of proofdepth;
} // end elem eqprf

  void trtr(elem z, elem y)   // transfer truth from z to y //  H1 := A*A = A;  is LH6.A;   z = LH6;
{
 headp h, g;
 if(mm) ipp("+trtr z= ", z, " y= ", y);
 if(mel(z,&h) != pfs){ ipp("trtr: wrong pfs z= ", z, " y= ", y); goto ret; }  /// ???
 if(mel(y,&g) != pfs){ ipp("trtr: wrong pfs y= ", y, " z= ", z); goto ret; }  /// ???
 if(Truth(h)){ /*if(wasassume) wlot(y, "trtr_h->t"); else */ g->t = h->t; }   // ??? 11.10.20 05.06.21(removed else);
 else if(inlot(z)) wlot(y,"trtr_inlot");
 ret: if(mm) ipp("-trtr z= ", z, " y= ", y);
} // end void trtr

  void mktr0(elem z, att t) // make true the formula z, tr = truth3, for use before typa;
{                           // used only in topt (cthms(): calculating thms;
 headp h; elemp q;
 if(mm) ipp("+mktr0 z= ", z);
 if(wasassume) error("mktr0: wasassume, z= ", z);
 if(mel(z,&h,&q) != pfs){ ipp("mktr0: not pfs, z= ", z); goto ret; }
 if(h->t) goto ret;  // error("mktr0: wrong h->t(not zero), z= ", z, "h->t= ", h->t);
 h->t = t; 
 if(mm) ipp("mktr0: making true, z= ", z);
 if(h->l == 3 && (q[0]==zA || q[0]==zall)) mktr0(q[2],t);
 ret: if(mm) ipp("-mktr0 z= ", z);
} // void mktr0

  void mktr(elem z, att tr)                // make true the formula z
{                                          // r=true: z is composite and not in lot;
 headp h=0,g; elemp q,w; char* s; elem x,t; int save = mm;   elem P1,P2,P3;
 // elem art[lsteq];     // maybe, zexc and yasop should be skipped ! // #define lsteq 256
 if(z.ad==stad2)
  mm=mm; // , pntu->prach("mktr");
 if(mm) ipp("\n+mktr z= ", z, " ilot= ", ilot, " wasassume= ", wasassume, " tr= ", tr, " mm= ", mm);
 if(fnt1(z,zis)) goto ret; 
 // m = mel(z,&h,&q);
 // if(!comp(m)){ ipp("mktr: simple z= ", z); goto ret; }
 // if((t = h->tp) != zbool) error("mktr: not formula z= ", z, " t= ", t); 
 if((t = typ(z,&h,&q)) != zbool) error("mktr: not formula z= ", z, " t= ", t); 
 if(h==0)
 { 
  if(z != ztrue && z != zfalse)  
     ipp("mktr: h==0 && z != ztrue && z != zfalse), z= ", z);
 } // if(h==0)
 else if(h->tel != pfs) error("mktr: not pfs, z= ", z);
 if(wasassume)
 {
  wlot(z, "mktr:wasassume");            // ??? z == true ??? q[0]==zmnbool: don't write ??? 2.2.20
  if(h==0) goto ret;
  if(h->l==2){ if(q[0]==zmnbool) wlot(q[1],"zmnbool"); goto ret; } // q[1] is of type bool;
  if(h->l==3)
  {
   if(q[0]==zA || q[0]==zall) goto ret; 
   if(q[0]==zexistx || q[0]==zexist1x || q[0]==zEx) mktr(q[2]);  
  } // if(h->l==3)
  goto ret;
 } // if(wasassume)
 if(h==0){ ipp("mktr:h==0 but no assume, z= ", z);   goto ret; }
 if(h->t == truth){ ipp("mktr: already h->t == truth), z= ", z, " h->t= ", h->t); goto ret; }
 //  if(h->t1){ if(9) ipp("mktr: already mktr worked: h->t1==1, z= ", z); goto ret; }
 //  else h->t1 = 1;                                 // t1==1: mktr already mktr worked;
 // } // if(h!=0 && Truth(h))
 h->t = truth; ++numthm;   // total number of theorems;  // !!! add ++numthm in prf, else ???
 if(fnt22l(z,zimp,zconj, &P1,&P2,&P3))  ptt->wrthmsic(z.ad);  // P1,P2,P3 are not used;
 // if(h->name != noname) 
 ptt->wrthm(z);         // writing z into tabt and den
 if(h->l == 3 && q[0]==zin && (s = Name(z)))  // named z, s=Name(z), not==,Name(z) used only for comp.terms!
 {
  x = q[1]; t = q[2]; // k = strlen(s);
  if(mm) ipp("mktr: named: x in  t, z= ", z, " s= ", s);
  if(isproptail("_type", s))   // ! L_type := x in t; must change typ(x) to t;
  {
   if(simple(mel(x,&g,&w))) error("mktr: cannot change type of a simple x, z= ",z," x= ", x);
   if(9) ipp("mktr: changing type of x= ", x,  " from g->tp= ", g->tp, " to t= ", t);
   g->tp = t;  // clad[x.m]->tabt[x.ad]->tp = t;
   if(9)  ipp("mktr: changed type of x= ", x, " to t= ", t, "\ng->tp= ", g->tp); 
            //  "\nclad[x.m]->tabt[x.ad]->tp= ", clad[x.m]->tabt[x.ad]->tp, " x.ad= ",  x.ad);
   // if(x.ad == 4413) error("mktr:4413, z= ", z, "\nx= ", x, "\nt= ", t);
  } // if(isproptail("_type", s))
 } // if(h->l == 3 && q[0]==zin)

 if(h->l==2){if(q[0]==zmnbool) mktr(q[1],tr); goto ret; }
 if(h->l==3)                                                                       // x in A & f in fn(A,B) & f(x) ...
 {                              // q[0]==zexist || q[0]==zexist1  added on 2022.11.08: was error:f(x) in typ(q[2]);
  if(q[0]==zA || q[0]==zall || q[0]==zexistx || q[0]==zexist1x || q[0]==zexist || q[0]==zexist1  || q[0]==zEx)
    mktr(q[2],tr);
  else if(q[0]==zconj){ mktr(q[1],tr); mktr(q[2],tr); }
  else if(q[0]==zin && fnt1(q[2],zP,&x)) mktr(trm2(zincl,q[1],x,zbool),tr);   // q[1] in P[x] == q[1] <: x;  
  else if(q[0]==zin && fnt1(q[2],zP1,&x))                 // q[1] in P1[x] == q[1] ~= {} & q[1] in P[x];
       { mktr(trm2(zneq,q[1],zemp,zbool),tr); mktr(trm2(zin,q[1],trm1(zP,x,zset),zbool),tr); }
 } // if(h->l==3)
 ret: if(mm) ipp("-mktr z= ", z, " ilot= ", ilot, " savemm= ", save); mm=save;    // return r;
} // end void mktr

    bool Taut(elem z) 
{
 bool r = (smpb(z) == ztrue); bool save = wasassume; wasassume = false; // to prevent writing to lot;
 if(mm) ipp("+Taut z= ", z); 
 if(r) mktr(z);
 if(mm) ipp("-Taut z= ", z, " r= ", r); wasassume = save;
 return r; 
} // end Taut(f)

    bool htaut(elem Q, elem J)   // handling tautologies and set tautologies
{                                // Q : formula to be checked, J = zTaut or zStaut;
  elem r; bool r1 = false; int k=0;
  if(mm) ipp("+htaut Q= ", Q, " J= ", J);
  if(J == zStaut && !horn(Q)){ ipp("htaut: not Horn formula Q= ", Q); goto ret; }
  r = smpb(Q,true,&k);
  if(r != ztrue){ ipp("htaut: not a tautology, Q= ", Q, " k= ",k); goto ret; }
  // mktr(Q);   // 7.10.21
  r1 = true;
  ret: if(mm) ipp("-htaut Q= ", Q, " J= ", J, " r= ", r1);
  return r1;
} // end bool htaut(elem Q, elem J)

    bool byel(elem y, elem *a, elem *b, elem* vars_are_cons, elem* dpat)  
{                           // vars_are_cons: normally: zel0,  y: if A[ in y,  zel9: y is an equality and in lot;
 bool r = false; headp h; elemp q; elem P, y0=y,y1=y; att i=0; // y1: y, peeled from possible -;
 bool wasdp=false;   // d  found in A[d, P];  d is an abt-term; or y0 is p->a==b
 bool wasmn=false, pat=false;
 if(mm) ipp("\n+byel y= ", y); 
 if(mm) prlot("+byel");
 if(y.ad==stad2)
 mm=mm;
 if(typ(y)==zel) error("byel: wrong y= ", y);
 *vars_are_cons = zel0; *dpat = zel0;
 if(y0==zRed || y0==zAxab || y0==zBred){ *a = y0; *b = y0; goto ret; } // y0: unpeel part of y;
 if(mel(y0, &h, &q) != pfs) 
                            error("byel: not pfs, y= ", y);
 if(q[0]==zRed) h->t = truth;  // see below: if(h->v) y0 = valrt(y0,h,q);
 if(q[0]==zmnbool)             // peel off - ;
 { 
  wasmn = true; y0 = q[1]; y1 = y0;    // - was peeeled off;
  if(mel(y0, &h, &q) != pfs) error("byel:zmnbool: y0: not pfs, y= ", y, "\ny0= ", y0);
 } // if(q[0]==zmnbool)

 pat = h->at;
 if(pat) *dpat = scopeden(y0);
 if(h->v)
 { 
  P = valrt(y0,h,q);
  if(comp(P))                               // otherwise error("byel: end while: simple y0, y= ", y, "ny0= ", y0);
  {
   if(mm) ipp("byel:v: changing y0= ", y0, "to new y0= ", P);
   y0 = P; *vars_are_cons = y0;
  } // if(comp(P))
 } // if(h->v)

 if(proofdepth==0 && !Truth(y0)) error("byel: proofdepth==0 && !Truth(y0), y= ", y, "\ny0= ", y);
 
 while(mel(y0,&h,&q)==pfs)                  // y0 : current unpeeled part of y;
 {
  if(mm) ipp("byel:while y= ", y, "\ny0= ", y0, " i= ", i);
  if(q[0]==zeq || q[0]==zequ)                // 1. a=b or a==b; final: everyting peeled off;
  {                                          // calculating vac
   if(mm) ipp("byel:final y= ", y, "\ny0= ", y0); // inlot:false: not look in lot for A[d,P],such that y0 is an inst of P;
   if(inlot(y0, false)) y1 = zel9; // if(99) ipp("byel:inlot(y0):zel9, y= ", y, " y0= ", y0); }   
   if(wasdp) if(*vars_are_cons == zel0) *vars_are_cons = y1;            // see valrt above;
   if(wasmn){ *a = q[2]; *b = q[1]; } else{ *a = q[1]; *b = q[2]; }
   r = true; goto ret;
  } // 1.  if(q[0]==zeq || q[0]==zequ)
  
  if(h->l != 3) ipp("byel: h->l != 3, y= ", y, "\ny0= ", y0, " hl= ", h->l); // assert(h->l==3); 

  if(q[0]==zimp)                             // 2. p -> a=b;
  {
   if(mm) ipp("byel:imp:y0, y= ", y, " y0= ", y0);
   // if(!inlot(q[1])) error("byel:imp, q[1](y0) is not in lot, y= ", y, "\ny0= ", y0, " q[1]= ", q[1]);
   if(!iseq(q[2])) error("byel:imp, q[2] is not an equality(or equivalence), y= ", y, " y0= ", y0, " q[2]= ", q[2]);
   y0 = q[2]; wasdp = true; continue;
  } // if(q[0]==zimp)

  if(q[0]==zall){ y0 = q[2]; continue; }     // 3. y0: All(x,P);  // peel off All;

  if(q[0]==zA)                               // 4. y0: A[d,P];    // peel off A[;
  { 
   if(mm) ipp("byel:A[, y= ", y, "\ny0= ", y0);
   if(!Dterm(q[1])) error("byel:zA:q[1]: not abt, y= ", y, " y0= ", y0); // ??? if(!pure,clean,only_type_ax(q[1)
   // if(wasd) error("byel: currently embedded A[d, ...A[d1,  not allowed; later vac = [d,d1,...], \ny= ", y);
   // d = q[1]; 
   // if(fnt2(q[2],zimp,&P,&Q) && inlot(P,true,d)) y0 = Q;  // A[d, P->Q];  // ??? true: try false ??? 11.23.20
   // else{ y0 = q[2]; if(mm) ipp("byel:zA:else y0 = q[2]; y0= ", y0); }
   wasdp = true; y0 = q[2]; continue; 
  } // if(q[0]==zA)

  if(99) ipp("byel: q[0] is not eq,equ,imp, All,A[, y= ", y, " y0= ", y0);
  if(wasmn) error("byel: wrong mnbool,y= ", y, "\ny0= ", y0);
  *a = y0; *b = ztrue; 
  if(wasdp) *vars_are_cons = y;        // if(wasd) *vars_are_cons = d;   // move out the loop;
  r = true; goto ret;
 } // while(m=mel(y0,...)
 if(99) error("byel: end while: simple y0, y= ", y, "ny0= ", y0);
 ret: if(mm) ipp("-byel y= ", y, " y0= ", y0, "\n*a= ", *a, "\n*b= ", *b, 
                 "\n*vars_are_cons= ", *vars_are_cons, "\ndpat= ", *dpat, " r= ", r);
      return r;
} // end byel

   ats linconj(elem z, elemp* aconjuncts)    // linearization of conjunction // returns # of conjuncts;
{
 ats r,r1,r2; headp h; elemp q; ats static depth=0, iconjuncts = 0;  elem static conjuncts[lconjuncts];         // lconjuncts = 40;
 ++depth; if(mm) ipp("+linconj z= ", z, " depth= ", depth );
 if(fnt2h(z,zconj,&h,&q))
 { 
  r1 = linconj(q[1],aconjuncts); if(mm) ipp("linconj q[1]= ", q[1], " iconjuncts= ", iconjuncts, " r1= ", r1); 
  r2 = linconj(q[2], aconjuncts); if(mm) ipp("linconj q[2]= ",q[2], " iconjuncts= ", iconjuncts, " r2= ", r2);
  goto ret;
 } // if(fnt2h(z
 else
 {
  conjuncts[iconjuncts] = z; if(mm) ipp("linconj:else: z= ", z, " iconjuncts= ", iconjuncts);
  if(++iconjuncts >= lconjuncts) error("linconj: too big iconjuncts= ", iconjuncts);
  ret:  *aconjuncts = conjuncts; r = iconjuncts; 
  if(mm) ipp("-linconj z= ", z, " conjuncts[0]= ", conjuncts[0], "  iconjuncts= ",  iconjuncts, " r= ", r); --depth;
  if(depth==0) iconjuncts = 0;
  return r;
 } // else
} // end void linconj(elem z)

   void wrassocinve(elem z)    // write z into linassoc;
{
 elem x, last = ilinassoc < 0 ? zel : linassoc[ilinassoc];
 if(mm) ipp("+wrassocinve: z= ", z, " ilinassoc= ", ilinassoc);
 if(groupe(z)){ ipp("wrassocinve: z = e skipped, z= ", z); goto ret; }
 x = groupinvarg(z);
 if(x != zel && req(last,x))   // last, z=inv(last);
 {
  ipp("wrassocinve: last, inv(last) skipped, z= ", z, " last= ", last); 
  --ilinassoc; goto ret;
 }
 x = groupinvarg(last);
 if(x != zel && req(x,z))      // last=inv(z), z; 
 { 
  ipp("wrassocinve: inv(z), z skipped, z= ", z, " last= ", last); 
  --ilinassoc;  goto ret;
 }
 if(++ilinassoc >= maxvars)
  error("wrassocinve: overflow of linassoc, z= ", z, " ilinassoc= ", ilinassoc);
 linassoc[ilinassoc] = z;
 ret: if(mm) ipp("-wrassocinve: z= ", z, " ilinassoc= ", ilinassoc);
} // void wrassocinve(elem z)
  
    void linassocinve(elem z)  // linearization and simplification of z;
{                             // output: linassoc[maxvars], ilinassoc: last occupied;
 elem f=zel; headp h; elemp q; int static count = 0;
 if(mm) ipp("+linassocinve: z= ", z);
 if(++count == 1) ilinassoc = -1; 
 int m = mel(z,&h,&q);
 if(m==pfs && h->l == 3)
 {
  if(f==zel && groupmlt(q[0])) f = q[0];
  if(f != zel){ linassocinve(q[1]); linassocinve(q[2]); goto ret; } 
 } // if(m==pfs ...)
 wrassocinve(z);               // write z into linassoc;
 ret: if(--count < 0) error("-linassocinve: count < 0, z= ", z, "\ncount= ", count);
 if(mm)
 {
  ipp("-linassocinve: z= ", z, " ilinassoc= ", ilinassoc);
  for(int i=0; i <= ilinassoc; i++) prp("\n", linassoc[i], pfhis);
 }
} // end void linassocinve

   void makevarcon(elem z)  // make vars as cons: add all free vars from z to convar; 
{                           // also, if z: x in t, add x; (most used such a term in assume;
 int i,k; elem x,z1=z,Q,M,d,cs, L[maxvars];  int k1,k2,k3; elem L1[maxvars], L2[maxvars], L3[maxvars];
 if(mm) ipp("+makevarcon: z= ", z, "iconvar= ", iconvar);
 // if(fnt2(z1, zin, &x,&t)){ wrlist(x, convar, &iconvar, maxvars);  z1 = t; }
 if(vterm(z1, &Q, &M)) z1 = M; 
 if(mm) prlist("+makevarcon convar= ", convar, iconvar);                                            //   L2(local bvars);
 k = freenames(z1,L,maxvars, L1, &k1, L2, &k2, L3, &k3);  // L: free vars, L3: nonlocal bvars; not used: L1(others),
 for(i=0; i<=k; i++)
 {
  x = L[i];
  if(mm) ipp("makevarcon: free var x written to convar, x= ", x);
  wrlist(x, convar, &iconvar, maxvars);
 } // for(i)
 cs = pntu->ndcol();               // current scope;
 for(i=0; i<=k3; i++)
 {
  x = L3[i];
  d = htbv(x);
  if(cs != zel && DinD(d, cs))
  { 
   if(mm) ipp("makevarcon: nonlocal bvar x was not written to convar, z= ", z, " cs= ", cs, "\nd= ", d, " x= ", x);
   continue;
  }  // if(curscope != zel && DinD(d, curscope))
  if(mm) ipp("makevarcon: nonlocal bvar x written to convar, z= ", z, " cs= ", cs, "\nd= ", d, " x= ", x,
            " iconvar= ", iconvar);
  wrlist(x, convar, &iconvar, maxvars);
 } // for(i)
 
 if(mm) prlist("-makevarcon convar= ", convar, iconvar);
 if(mm) ipp("-makevarcon: z= ", z, "iconvar= ", iconvar, " k= ", k);
 if(mm) pntu->prach("makevarcon");
} // end void makevarcon

  ats tt::find2(elem f, elem g) // f,g: rootnames: f(g...), find beginning r in thms f(g...) theorems;
{
 ats r= -1; // att b,b1,c,x,i; elem T1,f1,g1;
 if(mm) ipp("+find2: f= ", f, " g= ", g);
 /* b = indthms[f];   // b: begining of (f,g)-theorems in thms;
 if(b==emptt) error("tt::find2: wrong f= ", svad(f), " g= ", svad(g));
 for(i=f+1; indthms[i]==emptt && i<=ithms; ++i);  // skipping empty places in indthms;
 c = i - 1;                             // c: index of the last (f,g)-theorem in thms;
 if(mm) ipp("find2: b= ", b, " c= ", c);
 while((x=c-b) >= 1)
 {
  b1 = b + x/2;                         // b1 is the middle of [b,c]
  T1 = elm(mym, 0, thms[b1]);
  rootnames(T1, &f1, &g1);              // T1 = f1(g1...)
  if(f1 != f) error("find2: f1 != f, f= ", f, " f1= ", f1, " g= ", g);
  if(g1 < g){ b = b1 + 1; goto Wend; }  // g1 is before (f,g)-segment; r is in second half;
  if(g1==g){ c = b1; goto Wend; }       // g1 is in (f,g)-segment; r is in first half;
  c = b1 - 1;      // g1 > g;           // g1 is after (f,g)-segment;
  Webd: if(mm) ipp("find2:Wend: T1= ",T1," b= ", b, " c= ", c, " b1= ", b1 ); 
  if(c-b == x) error("find2:Wend: no change: T1= ",T1," b= ", b, " c= ", c, " b1= ", b1 ); 
 } // end while
 if(x==0) r = b; else r = -1;
*/
 return r;
} // end ats find2

/*   bool conv(elem z)     // mel(z) == con or mel(z) == var,?bvar && z is in convar;
{
 int m = mel(z);
 bool r = (m==con || (m==var || m==bvar) && inlist(z,convar,iconvar)); // ???m==bvar???
 return r;
}  // end bool conv(z)

  void hnassume(elem x1, elem t1, int i, int lproof, elemp qq, elem* agoal)        // x1; assume;
{
 elem d,P,Q,goal = *agoal; bool lastassume; int j,n; 
 if(mm) ipp("+hnassume x1= ", x1, " goal= ", *agoal, " iconvar= ", iconvar);
 wasassume = true; 
 if(t1 != zbool) error("hnassume: not a formula before assume, x1= ", x1);
 x1a = x1; wlot(x1,"hnassume:1");
 makevarcon(x1);
 lastassume = true;                  //---------------------------- calculating lastassume (for the conjuncts case)
 for(j=i+2,n=0; j < lproof && n < lookaheadassume; j++,n++)
 if(qq[j]==zassume)
 { 
  if(mm) ipp("hnassume: not last assume, x1= ", x1, " j= ", j);
  lastassume = false; break;
 }  // if(qq[j]==zassume) // ------------finished calculating lastassume;
 M0: if(mm) ipp("hnassume:M0 x1= ", x1, " goal= ", goal);
 if(fnt2(goal,zA,&d,&Q))          // --------1.1 goal is A[d,Q];
 {
	 if(mm) ipp("hnassume:goal is A[d,Q], d= ", d, " Q= ", Q, " x1= ", x1); 
  if(Dax(x1,d))   // ,&k))
  {
   wlot(x1,"hnassume:2");
   if(lastassume) // || typeax(x1,d,k) != zel)
   {
    if(mm) ipp("hnassume changing goal from goal= ", goal, " to new goal= ", Q); 
    goal = Q;          // there can be many dax-axioms for A[d,Q], so lastassume is necessary;
   } // if(lastassume || ...)
   goto ret;                         //  continue;
  } // if(Dax(x1,d))
  goal = Q; goto M0;                 // x1 is not an axiom in d;
 } // if(fnt2(goal,zA,&d,&Q))        // ------- end 1. goal is A[d,Q];
 if(fnt2(goal,zimp,&P,&Q))           // --------1.2 goal is P->Q;
 {
	 if(mm) ipp("hnassume:goal is P->Q, P= ", P, " Q= ", Q, " x1= ", x1, " lastassume= ", lastassume); 
  if(conjunct(x1,P))                 // there can be many conjuncts in P, so lastassume is necessary;
  {
   wlot(x1,"hnassume:3");
   if(lastassume) goal = Q;
   goto ret;                         //  continue;
  } // if(conjunct(x1,P))
  goal = Q; goto M0;                  // x1 is not a conjunct in P;
 } // if(fnt2(goal,zimp,&P,&Q))      // ------- end 2. goal is P->Q; 
 if(isneg(x1,goal))                  // ------- 1.3 Proof by reductio ad absurdum, only in Proof, not in EqProof!!!
 {
  wlot(x1,"hnassume:4");
  goal = zfalse;
  if(mm) ipp("hnassume: goal = false ", goal);
  goto ret;                        //  continue;
 } // if(isneg(x1,goal))             // ------- end 3.Proof by reductio ad absurdum
 error("hnassume: wrong assume = ", x1, " theorem= ", qq[1], " goal= ", goal);
 ret: *agoal = goal;
     if(mm) ipp ("-hnassume x1= ", x1, " goal= ", goal);
} // end  hnassume(x1,...)
*/
  void compdc(elem goal, char* place)                   // computing dc,gdc,kdc,pdc,idc for goal;
{
 headp h; elemp q;
 if(mm) ipp("+compdc goal= ", goal, " place= ", place);
 if(mel(goal, &h, &q) != pfs || h->l != 3)
     { ipp("compdc: not pfs || h-> != 3, goal= ", goal, " place= ", place); goto ret0; }
 // dc = q[1]; gdc = q[2]; idc = 0;            // idc: the number of last handled axiom or conjunct;
 if(q[0]==zimp)
 { 
  pdc = false; kdc = 1;                     // pdc = false: dc is a conjunct; kdc==1: dc is a singular disjunct;
  if(fnt2(q[1],zconj)) kdc = 99;            // little sense to know the correct value;
  dc = q[1]; gdc = q[2]; idc = 0;
  goto ret;
 } // if(q[0]==zimp)
 
 if(q[0] == zA)    // error("compdc: q[0] != zA, goal= ", goal, " q[0]= ", q[0]);
 {
  pdc = true; kdc = 99;                      // little sense to know the correct value;
  dc = q[1]; gdc = q[2]; idc = 0;
  goto ret;
 } // if(q[0] == zA)
 // if(q[0]==zor) ??? P or Q == ~P -> Q;
 ret0: if(99) ipp("compdc: goal is not zimp or zA, dc= zel, gdc=zel, goal= ", goal);
 dc = zel; gdc=zel;
 ret: if(mm) ipp("-compdc goal= ", goal, " dc= ", dc, "\ngdc= ", gdc, " kdc= ", kdc, " pdc= ", pdc, " idc= ", idc);
} // end void compdc

  int indc(elem F)                                     // number F in dc, 1: idc, 0: is not in dc)
{
 int r=0;
 if(mm) ipp("+indc F= ", F, " dc= ", dc, " pdc= ", pdc);
 if(pdc){ if(Dax(F,dc)) r = 1; goto ret; }
 if(conjunct(F,dc)) r = 1;
 ret: if(mm) ipp("-indc F= ", F, " dc= ", dc, " pdc= ", pdc, " r= ", r);
      return r;
} // end int indc(elem F)
   
  void hnassume(elem F, elemp agoal)
{
 int k;   // the number of F in dc;
 int n=0; // to discover cycling in M: ... goto M;
 elem goal = *agoal;
 if(mm) ipp("+hnassume F= ", F, " goal= ", goal, " dc= ", dc, "\ngdc= ", gdc, " pdc= ", pdc, " kdc= ",kdc, " idc= ", idc);
 x1a = F; wlot(F,"hnassume:1");
 makevarcon(F);
 wasassume=1;
 if(isneg(F,goal))                  // ------- 1.3 Proof by reductio ad absurdum, only in Proof, not in EqProof!!!
 {
 // wlot(F,"hnassume:isneg");
  goal = zfalse;
  dc = zel;                         // any other assumes are impossible;
  if(mm) ipp("hnassume: goal = false ", goal);
  goto ret;                
 } // if(isneg(x1,goal))             // ------- end 3.Proof by reductio ad absurdum
 // error("hnassume: wrong assume = ", x1, " theorem= ", qq[1], " goal= ", goal);

 M: if(dc==zel)
 {
  compdc(goal, "hnassume");
  if(dc==zel) error("hnassume: this goal cannot have assume's, goal= ", goal);
 } // M:
 k = indc(F);
 if(k==0) // new assume: F is not in dc; impossible for first assume in proof; possible for multi dc (kds > 1);
 {
  if(mm) ipp("hnassume:k==0,F= ",F, " goal= ",goal, " dc= ",dc, "\ngdc= ",gdc, " pdc= ",pdc, " kdc= ",kdc, " idc= ",idc);
  compdc(goal, "k==0");
  if(++n > 10)  error("hnassume: check assume's (++n > 10), F= ",F," goal= ",goal," dc= ",dc,"\ngdc= ",gdc," pdc= ",pdc," kdc= ",kdc," idc= ",idc," k= ",k); 
  goto M;
 } // if(k==0)
 if(mm) ipp("hnassume: k!=0, F= ",F," goal= ",goal," dc= ",dc,"\ngdc= ",gdc," pdc= ",pdc," kdc= ",kdc," idc= ",idc," k= ",k); 
 // if(k<=idc || k>kdc) error("hnassume: k<=idc || k>kdc, F= ",F," goal= ",goal," dc= ",dc,"\ngdc= ",gdc,
 //                           " pdc= ",pdc," kdc= ",kdc," idc= ",idc," k= ",k); 
 if(idc==0)        // first assume for this dc;
 {
  if(mm) ipp("hnassume: idc==0, F= ",F," goal= ",goal," dc= ",dc,"\ngdc= ",gdc," pdc= ",pdc," kdc= ",kdc," idc= ",idc," k= ",k); 
  wrdep(goal, gdc); // wlot(F, "hnassume:idc=0");
  goal = gdc;
  idc = 1; // if(kdc==1) compdc(goal,"kdc==1"); else idc = 1;
  goto ret;
 } // if(idc==0)   // just below: F is not first assume in this dc;
 if(mm) ipp("hnassume: idc!=0, F= ",F," goal= ",goal," dc= ",dc,"\ngdc= ",gdc," pdc= ",pdc," kdc= ",kdc," idc= ",idc," k= ",k);
 idc = k;
 // wlot(F," not first assume for dc");  // no if(k==kdc) because compdc() will be executed when handling the next assume;
 ret: *agoal = goal;
 if(mm) ipp("-hnassume F= ", F, "\ngoal= ", goal, "\ndc= ", dc, "\ngdc= ", gdc, " pdc= ", pdc, " kdc= ",kdc, " idc= ", idc,
                               " wasassume= ", wasassume);
} // end elem hnassume(elem F)

   void hnassume1(elem x, elem* agoal)                 // assume(x); x is bvar;
  {  
   elem goal = *agoal; headp g; elemp w; ats a;
   if(mm) ipp("+hnassume1 x= ", x, ", goal= ", goal);
   // wasassume= true; // not a direct proof           // commented 2022.09.27
   // wrlist(x, convar, &iconvar, maxvars);
   if(!fnt2h(goal,zall,&g,&w)) error("hnassume1: goal is not an All-formula, goal= ",goal);
   if(!boundvar(x, &a)) error("hnassume1: not bounded var x= ", x, ", goal= ", goal);            // ??? Ats ???
   if(Ats(w[1]) != a) error("hnassume1: assume(y): different bvars in x= ", x, ", and in goal= ", goal);
   compdc(w[2], "hnassume1");          // w[2] is the new goal;
   wrdep(goal, w[2]);
   *agoal = w[2]; 
   if(mm) ipp("-hnassume1 x= ", x, ", goal= ", goal, " *agoal= ", *agoal, "\ndc= ", dc, " gdc= ", gdc);
  } // end void hnassume1(elem x, elem* agoal)      // assume(x); x must be bvar;

   bool hnbyeq(elem x1, elem x, headp h, elemp q)  // x1; x: byeq(z1, ... ,zk);
{
 bool r= false; headp g; elemp w; elem x1a = x1; int savemm=mm;
 // if(stad != 0 && x.ad==stad) mm=1;
 if(!istrbyis(x,h,q)) error("hnbyeq: byeq(...) is not true, x1= ", x1, "\nbyeq(...)= ", x);
 if(mm) ipp("+hnbyeq: x1= ", x1, " x= ", x);
 if(fnt2h(x1,zall,&g,&w)) x1 = w[2]; // x1; x;  .. //x1 = All(x,A=B), A[d,A=B]; x1 == A=B;
 else if(fnt2h(x1,zA,&g,&w)) x1 = w[2]; 
 if(!iseq(x1, &w)){ ipp("hnbyeq:error: not eqv before byeq, eqv = ",x1); goto ret; }
 if(! hnbybyeq(w[1],x,h,q,w[2])){ ipp("hnbyeq: wrong by-element = ", x, " x1= ", x1); goto ret; }
 if(proofdepth) wrdep(x1a,x);   // x1 depend on x, i.e. on z1, ... , zk;
 r = true;
 ret: if(mm) ipp("-hnbyeq: x1= ", x1," x= ", x); mm=savemm;
      return r;
} // end bool hnbyeq(elem x1, elem x)

   void tt::wrthmsic(att i)  // write i into thmsic;
{
 if(++ithmsic >= lthmsic) error("wrthmsic:overflow: ithmsic= ", ithmsic);
 thmsic[ithmsic] = i;
} // end void wrthmsic(att i)

/*   att stprf(elem V, elem A, elem* B, ats occur, att* occ )   // r=0: ret(error), r=1: Eqt_V1_B, r=2(Nxt1): checked B,
{   
 att r=0, mA,hl;  elem x,D,Q,M; headp h; elemp q;  char* str; *B = zel;
 if(mm) ipp("+stprf V= ", V, " A= ", A);
 if(A==zAxab && inabt(V,&x,&D) && (occur==0 || ++occ == occur))
 { 
  s.size = 0;                // found = true;
  *B = s.redinab(V,x,D); 
  if(B==V){ ipp("stprf:Axab: cause: no reduction of V= ", V, " s= ", &s); goto ret; }
  goto ret1;                 // goto Eqt_V1_B;
 } // if(A==zAxabif(A==zAxab ...)
 
 if(A==zRed)   // bool isst(elem z, elem* main, elem* red)
	{
		 // if(9) ipp("isbe:Red: F= ", F, "G= ", G, );
  found = true;
		// if(isst(V, &B) && (occur==0  || ++(*occ) == occur))               // replace isst(V,&Q,&y) && req(y,V1)
		{
		 if(mm) ipp("stprf:Red: after isst, V= ", V, "\nB=  ", *B, "\nV1= ", V1);
			if(mm && V.ad==stad)
   mm=mm;
   goto ret1;              // goto Eqt_V1_B; // if(s.eqt(V1,y, d0)) goto Nxt1;
   ipp("isbe:Red: cause: wrong special term V= ", V, "\ny  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
   s.psbs(); goto ret;     // ret: r=0;
  } // if(isst(V, &B) && ...)
 } // if(A==zRed)
 
 mA = mel(A,&h,&q);
 if(mA==pfs && q[0]==zRed)
 {
  str = strval(q[1]); hl = h->l;
  if(strcmp(str,"f")==0)
  { 
   if(hl != 3) error("isbe: wrong Red(\"f\",m),F= ", F,  "\nG= ", G, "\nA= ",A, " h->l= ", h->l);
   *B = freered(V,intval(q[2]));  // f-reduction
    // r = s.eqt(V1,y); 
   h->t = truth;    // ??? mktr, wlot(A); // was h->t = truth; 6.2.19;
   goto ret1;
  } // if(strcmp(str,"f")==0)
  
  if(strcmp(str,"dot")==0)                // Q.M = G;   // F is Q.M or Q(M);
  { 
   if(hl != 2) error("isbe: wrong number of args in Red(\"dot\"), F= ", F,  "\nG= ", G, "\nA= ",A);
   if(!vterm(V,&Q,&M)) error("isbe: F is not a dot(or adt) term,  F= ", F,  "\nG= ", G); 
   if(eqdot(V1,Q,M)){ h->t = truth; goto ret2; }
   error("stprf: F is not a dot(or adt) term,  F= ", F,  "\nG= ", G);
  } // if(strcmp(str,"dot")==0)

  if(strcmp(str,"&")==0)                // Q1 & Q2 == Q1, if Q1 -> Q2; // by Red("&, 1);
  {                                     // Q1 & Q2 == Q2, if Q2 -> Q1; // by Red("&, 2);
   if(hl != 3) error("isbe: wrong number of args in Red(\"&\", k), F= ", F,  "\nG= ", G, "\nA= ",A, "\nhl= ", hl);
   if(strcmp(str,"&")==0)    
   if(!fnt2(V, zconj)) goto Nxt;        // ??? comp(V) && comp(V1) ???
   found = true;
   y = redconj(V,intval(q[2]));         // f-reduction
   if(s.eqt(V1,y)){  h->t = truth;  goto ret2; }   // if(s.eqt(V1,y, d0)) goto Nxt1;
   ipp("stprf:Red(&,m) : cause: wrong special term V= ", V, "\ny  =", y, "\nV1= ", V1, "\nF= ", F, "\nG= ", G); 
   s.psbs(); goto ret;
  } // if(strcmp(str,"&")==0)
  error("stprf::Red(f,...), F= ", F, "\nA= ", A, "\nG= ", G);
 } // if(mel(A,&h,&q)==pfs ...)

 if(A==zAssocinve && mel(V,&g,&w)==pfs && groupmltinve(w[0]))
 {
  r = eqAssocinve(V,V1); // found = true;
  if(r){ found = true; goto ret2; }      // goto Nxt1;
  if(9) ipp("isbe: cause: not eqAssocinve(V,V1), V= ", V, "\nV1= ", V1);
  goto ret;
 } // if(A==zAssocinve)
 ret1: r = 1; goto ret;
 ret2: r = 2; 
 ret: if(mm) ipp("-stprf V= ", V, "\nA= ", A, " B= ", *B, " r= ", r);
      return r;
} // end stprf
*/
// end file prf.cpp