
// ismd.h  11/22/99 06/15/00 07/25/00 08/09/00 9/25/00 12/08/00 01/26/01
// 02/07/01
int istrue(elem z);                  
//int istr(elem z, int flag_inlot = 1, int flag_eqvl = 1);                  
// void mktr(elem z, int p);
int istruer(elemp a, int l, elemp q);  // q refers at *-1 !
// int iset(elem z); in adl.h
int ismd(elem d, elemp q);        // q refers at *-1 !
int ismdp(elem z, elem d, elem p = ztrue);  // z in {d, p}
int fit(elem z, elem t, elem d = zel, elemp q = 0); // q refers at *-1 !
int sinc(elem a, elem b);   // a <= b
int nonempty(elem z);       // z is nonempty
int nonemptyfun(elem z, elem a);    // a is nonempty domain of the function z
int istruer(elemp a, int l, sbst s);  // 07/04/96
// int lev(elem z);
elemp adrm(elem d, elem z);   // addres of model
// elem model(elem d, elemp q);  // q points to M (not M-1) !!!
elem stm(elem d);   // standard model (x1 or [x1, x2, xk])