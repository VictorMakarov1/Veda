#include "lib.h"  // 11/21/97 12/09/99  10/27/00 11/06/00 12/13/0 
#include "achs.h"
#include "sbs.h" 
#include "tt.h"
att mel(elem z, headp *h=0, elemp *q=0, int place=0);
#include "typ.h"
bool dclname(elem z, headp* ah=0, elemp* aq=0, ats* a=0);  //  z is d.i & d is dcl[a, ..., t]
#include "elem.h"
// #include "adl.h"   // not working, so the next lines;
bool fnt22l(elem z,elem,elem, elem* P1, elem* P2, elem* P3);  // (P1 f1 P2) f2 P3
#include "myio.h"    
#include <time.h>                             
#include "err.h"
#include "assert.h"
#include "tran.h"
#include "etc.h"               // typedef unsigned char modsize;
#include "prf.h"
#include "lot.h"
#include <stdio.h>  // #include <iostream>
// #include <thread>  fatal error C1083: Cannot open include file: 'thread': No such file or directory

// #include <windows.h>   
// #include <windowsx.h>  
// #include <mmsystem.h>

int ieul,irul;                 // lib.h: #define iclad ieul;
att curm;                      // current module (allm[curm]);
ats idubscount;
int count;                     // (ats = int) for detecting looping
char* allm[maxmod] = {0};           
att eul[maxmod];               // extended used list, contains module numbers: transitive closed used list for current module 
int rul[maxmod];               // transitive closed reverse used list for some module
int irr[maxmod];               // index(last occupied) for rr[m];
int rr[maxmod][maxmod];        // direct reverse used list
tt*  clad[maxmod];             // clad[m] : pointer to tt-object for module #m;
// bool wrongmod[maxmod];         // wrong module numbers: not contained in eul; see hbin;
int iallm, oldiallm; 
// int kht = 10;   // the size of ht = kht*itt;
int lsm;         // the last number of standard module,currently 2: 0_bool, 1_boolp, 2: rezerv;
att lview;       // how long to seek theorems
att lasttt;      // last address in tabt, taken from dd.d; currently(8.30.21) 65530;
att maxits;      // size of ts, taken from dd.d; currently 5000;
att lden;        // size of den, taken from dd.d; currently 10000;
att laden;       // size of aden, initially maxits+1; currently 5000;
att llot,ldep,lst;
int lstr;        //  max size of st in rep;
att lthms;       // length or thms; taken from dd.d; currently 5000;
int lpol = 100;  // smp
intp  pol; 
int lhis;   // maximum length of history (.his) file in megabytes;
int maxc;   // maximal complexity (see int cmpl) of terms to write into lot;
int maxDj;   // maximal number of tries in findtabt;
int ippcount; // count of all calls to ipps; (used like maxfilehis size)
int maxipp ; // maximum for ippcount; must: ippcount * 100000 < Maxipp;
int Maxipp ; // Maxipp = maxipp * 100000;
int sumDj;   // sum of all tries in findtabt;
int numthm;  // total number of theorems in module;
int maxl;    // maximal size of v-line;
int its = -1;
int counterrmsg = -1;          // #define maxerrmsg 100 in lib.h
int errlines[maxerrmsg];
char* errmsgs[maxerrmsg]; 
int oldits, oldiall;
int notterm; // for nstr(in term adel must not change nstr)
// int beg_impconj;               // beginning of (->,&) segment in thms;  int => ats ???
// int end_impconj;               // end of (->,&) segment in thms;
// int beg_rimpin;                // beginning of (<-,in) segment in thms;
// int end_rimpin;                // end of (<-,in) segment in thms;
// int beg_equin;                 // beginning of (==,in) segment in thms;
// int end_equin;                 // end of (==,in) segment in thms;
// int beg_exist, end_exist;      // beginning and end of (Exist)- segment in thms;
int countctruth;               // count of ctruth (declared, but unproved) theorems;
float grand_total_time;        // the sum of total times for each handled module;
extern int mergecount;         // merging count (in findtabt)
extern int glexcount;          // lexem count ( in glex )
extern int findcount;          // number of searches in findtabt
extern int badelem;            // number of bad elements in tabt: used in tt::futt;
extern int zeltype;            // number of zel types in tabt: used in tt::futt;
extern int countbadthms;       // number of bad theorems in tabt: used in tt::futt;
extern int wlot_not_writing;   // count of too big terms for writing to lot;
extern int idep;               // index of dep: see prf;
tt* ptt;
char dirname[kdirname];        // "d:\victor\veda\debug\veda.exe kdirname = 100
char dirname1[kdirname];       // d:\victor\veda\ 
char fname[kdirname];          // module name M
char prname[kdirname];         // name for printing in rnam (before fname);
char source[kdirname];         // d:\victor\veda\M 
char namefhis[kdirname];       // name of history file (e.g., 0_bool.his) 
char* sbin[lsbin];             // binary symbols, lsbin defined in tran.h (16)
char* sun;                     // unary symbols;
int pait;  
char** ts;
char* countts;
char* tabs;
char** strvalue;
bool errprint = false;
bool nowlotinf;                // dont use wlotinf (curm=0 & REL was not passed);
// double totalt;                 // total time;
ofstream* pfmainhis;           // main history 
ofstream* pfhis;               // history (main or local)
ofstream* pftbt;               // pointer for futt (file for tabt)
ifstream* pfin;                // source file (d:\victor\veda\M.v)f
ofstream * pfprp;
clock_t start_clock; //  end_clock;
// int snampl;             // ??? not needed ???
elem zel,yasop,zfn,zFn,zifn,zsfn,zbfn,zafn,zA,zE,zEx,zE1,zF,zR,zU,zneq,zeps,zdclb,zP,zP1,zseg,zel999; 
elem zby,zwith,zfrom,zis,zbyeq,zbyimp,zassume,zTaut,zStaut,zInstance,zWitness, zexc;
elem zdisjoint, zsb,znequ,zabterm,zNotAxiom,zcrlf,zif,zor,zdom,zim,zRep;
elem yat,zat,zvith,zdp,zint,zseq,zSEQ,zdebug,zAFN,zFFN,zffn,zFNtypes,zfntypes,zS,zII,zdconj,zfinabterm;
elem ymn,ydcl,yre,yassume,yab,zdot,zrel,zSEQ1,zseq1,zlast,zempseq,ztypeaxiom,zcomp,zinv,zplint,zmltint; 
elem zmnbool,zmnint,zmnint1,znat1,znatm,zset,zset1,zfinset,zany,zAxab,zBred,zRed,zrimp,zFN,zREL,zbegin;
elem zall,zbool,zconj,zdis,zrestr,zeq,zequ,zexist,zexist1,zexistx,zexist1x,zfalse,zif2,zimp,znot,ztrue;
elem zel0,zel1,zel9,zin,znin,zxor,zxor3,zvariable,zbvar,zincl,zun,zinter,zemp,zNI,zsetdif;
elem zAssocinve,zgroup,zelg,zadd,zanyd,zrecdef,zdbsl,zfnsetbool,last_y1,last_y; 
elem hint;      // a theorem to help prove a hard formula in simr;
elem maxf;    
att maxcountf;  // for cthms:
att adimp,adenconj,addis,adequ,adnot,adeq,adneq, adin, adincl;  
achs* pntu;
char* hintstr; // hint string - any string in module or proof scope;
// elem Tdefs = elm(ints, 0, 1);
// elem Tsetdefs = elm(ints, 0, 2);
elem TPstring = elm(ints, 0, 3);
float avDj;  // average Dj;
elemp varsp;
int ilot;
elemp lot;
elemp st;                // main stack
ats* stdepth_pars;
ats depthst;
elemp steq, wst1;
int proofdepth = 0;
bool wasassume = false;

extern int chnis, cAssocinve,ctrue,cStaut,cTaut,cAxab,ctypeaxiom,cRed,cTautP,cInstance,cWitness,cWitness_E,cadt_gt1,cvterm,
           cmnbool,cexc,cisst_y0,cw0_Taut_Staut,cimp,cMimp,cAll,cAllm,cAllimp,cA,cAimp_equ,cAModel,cw0_eq_equ,cM10;

elemp dep, dep1, dep2;  // dep3;
bool fnt2(elem z, elem f, elemp p1=0, elemp p2=0);   // in adl.cpp
bool qterm(headp h);                                 // in adl.cpp
float r_time;

float ttime(char* s)
{
 time_t end_clock = clock();
 r_time = float (end_clock - start_clock) / float(CLOCKS_PER_SEC) ; 
 // *pfhis << "\nttime:"<<s<<" end_clock= "<< end_clock<< " r_time= "<<r_time;
 return r_time;
}
                                  // ??? make the below files like fubs.chr ???
char* arspms[] = {"var", "by", "is",  "with", "byeq", "byimp", "add", "*end*" }; // special multiple symbols
char* arlpus[] = {"!", "!!", "*end*"};  // low priority unary symbols (!. !!)
char* arpostfix[] = {"!", "-", "*end*"};     // postfix symbols, was also "?";
char* bnames[] = {"A","E","Ex","E1","R","U","F","dcl","P","P1","S","II", "*end*"};
char* dcltypes[] = {"bool","any","set","class","bvar","variable","is","by","byeq",
                    "from","with","assume","axiom","*end*"}; 
// char* sm[lsm] = {"0_bool","1_quant"} // {"snam", "int", "seq"};

int wrts(char* s);
ats adcl;                       // 0
ats avar;                       // 1
ats aAll;                       // 2
ats aExist;                     // 3
ats aExist1;                    // 4
ats aExistx;
ats aExist1x;
ats aProof;                     // 5
ats aEqProof;                   // 6
ats asuppose;                   // 7
ats adclb;
ats aAb;                         // A[
ats avariable;
ats asop;
ats aterm;
ats aabterm;
ats aclass;
ats aset;
ats aany;
ats abool;
ats adcol;                      // double colon
ats adot;
ats aat;                        // @
ats aeps;
ats aabt;
ats aREL1;
ats aplint,amltint,amnbool,amnint,amnint1,aanyd;
att aexc;
att adexc;
ats aexc1;
ats aexc2; 
ats anot; 
ats anot1; 
ats aby;
ats adconj;   
ats aopb;     // [
ats aend;     // end 
ats arestr; 
elem zsuppose;
elem ycol;
elem zcol;
elem zdcol;
elem zProof;
elem zEqProof;
elem zopsqbr;            // elm(247,91,0)
elem znat; 

double time_trm, time_bdef, time_sortden, time_rnam, time_topt, time_cthms, time_typa;

extern char ops[256];
extern char cont[];
extern int maxditt, maxdittp, maxditteqp, maxditt1,maxdittadd; 
extern elem maxdittz;         // for terms in typseq: see typ: maxz = y1, ditt is max;  
extern elem maxdittzp;        // for proofs
extern elem maxdittzeqp;      // for eqproofs
extern elem maxdittz1;        // for all other terms
extern elem maxdittzadd;      // for addtabt
extern elem maxdittlastseq;   // lastseq for maxdittz1
extern int maxd;          // if(ditt>maxd) then print y1, ditt 
extern int sbstcount;
// extern int tead;       // term address: for debugging printing in typ; // now in lib.h
att stad, stad1, stad2, endpait;   // stop addresses: for stopping in debugger;
// extern int lnad;          // length of nad;
extern int icont;
extern elem sp1,s,s0,ycomma,abtermp;
extern ats acrlf;
int prt(char* s);
void inops();
void trm(); 
void typa(elem z);

// bool wrongm(att m, tt** ap){ tt* p = clad[m]; bool r = (p==0); if(ap) *ap = p; return p; }

   void	main(int argc, char* argv[])
{
 int i, j=0, k=0; char s[kdirname];  char c; unsigned short u, u1; zel999 = elmint(999);
 //headp* hst;  hst =(headp*) st;  cout << '\a'; // Beep(1000,500) not working; cin >> c;
 try{  zel.m = emps; ptt=0;
 start_clock = clock();
 grand_total_time = 0;
 if(strlen(argv[0]) >= kdirname)
	 cout << "\nERROR: main: too big argv[0]= " << argv[0],exit1();
 strcpy(dirname1, argv[0]);   // d:\victor\veda\Debug\veda.exe
 for(i=0; dirname1[i]; i++) if(dirname1[i] == '\\') j=k,k=i;
 if(k<2 || j==0) cout << "\nERROR: main k= " << k << " j= " << j;	 
 dirname1[k+1] = 0;           // d:\victor\veda\Debug\ 
 strcpy(dirname, dirname1);
 dirname[j+1] = 0;          // d:\victor\veda\ 
 cout << "\nargv[0]= " << argv[0];
 cout << "\ndirname= " << dirname << "\ndirname1= " << dirname1;
 // k = filesize("0_bool.v");          // file size in bytes;
 // cout << " k= " << k; 
 // error("Main: k= ", k);
 
 strcpy(s, dirname); strcat(s, "main.his");
 static ofstream fmainhis(s,ios::out);
 // elem testelm1 = elm(0,1, 1); unsigned* ptestelm1 = (unsigned int*) (&testelm1); 
 // elem testelm2 = elm(0,1, 2); unsigned* ptestelm2 = (unsigned int*) (&testelm2); 
 // elem testelm3 = elm(0,1, 3); unsigned* ptestelm3 = (unsigned int*) (&testelm3);
 // char selem[] = {'1','1','2','3','0'}; unsigned* pselem = (unsigned*)(&testelm);
 //*pselem = * (unsigned*)(&testelm);
 if(!fmainhis.is_open()) cout<<"\ncannot open file "<<s,exit1();
 pfmainhis = &fmainhis; 
 pfhis = pfmainhis; maxipp = 1; Maxipp = 100000; // because maxipp was not read yet !!!
 ipp("Opened file fmainhis ", s);
 i = sizeof(elem); j = sizeof(void*); 
 cout<<"\nsizeof(head)= " << sizeof(head) << " sizeof(elem)= "<<i<<
       " sizeof(eden)= "<<sizeof(eden)<<
    " sizeof(unsigned short)= "<<sizeof(unsigned short)<<" sizeof(void*)= "<<j;
 *pfmainhis<<"\nsizeof(head)= " << sizeof(head) << " sizeof(elem)= "<<i<<
             " sizeof(eden)= "<<sizeof(eden)<<
    " sizeof(unsigned short)= "<<sizeof(unsigned short)<<" sizeof(void*)= "<<j<<
    " all1but31= "<<all1but31;
//    "\nelm(0,1,1) = "<< *ptestelm1<<"  "<< unsvalelm(elm(0,1,1))<<
//    "\nelm(0,1,2) = "<< *ptestelm2<<"  "<< unsvalelm(elm(0,1,2))<<
//    "\nelm(0,1,3) = "<< *ptestelm3<<"  "<< unsvalelm(elm(0,1,3));
// pfmainhis->close(); 
//  exit1();
//  error("stop"); // see err.cpp not working
 
  // mycopy(); // 0_bool.v => 0_bool_new.v line by line replacing Proof(T; => Proof T; and so on; DEAD END !!!
 if(i != 4 || i != j)
 {
  cout << "\nERROR: main: wrong size of elem= "<<i<<" or size of void="  << j<<"\n"<<"\n";
  *pfmainhis << "\nERROR: main: wrong size of elem= "<<i<<" or size of void="  << j<<"\n";
  pfmainhis->close(); 
  exit1();
 } // if(i != 4 || i != j)

  if(all1but31 & 1) 
 {
  cout << "\nERROR: main: wrong all1but31= "  << all1but31<<"\n"<<"\n";
  *pfmainhis << "\nERROR: main: wrong all1but31= "  << all1but31<<"\n"<<"\n";
  pfmainhis->close(); 
  exit1();
 } // if(i != 4 || i != j)
 u = -1; u1 = u + 1; 
 cout << "\nu= -1, u= "<< u << " u+1 = "<< u1 << "\n\n";
 *pfmainhis << "\nu= -1, u1= u+1, u= "<< u << " u+1= "<< u1 << "\n\n";
 // end = 10000000;
 // double  totalt = (double) (end - start) / (double) CLOCKS_PER_SEC ;
 // cout<<"\nfinish: start= " <<start<<" end= " << end << " CLOCKS_PER_SEC= " << CLOCKS_PER_SEC << " totalt= "<<totalt;
 // *pfmainhis<<"\nfinish: start= " <<start<<" end= " << end << " CLOCKS_PER_SEC= " << CLOCKS_PER_SEC << " totalt= "<<totalt;
 //  pfmainhis->close();
 // error("main:test");
 // for(i=0; i<1000; i++){arr[i] = fylloc(99999999); cout << "\n\n Allocated 99999999,i= " << i;}  // cin >> c;}
 // pfmainhis->close();
 rfallm(); // read allm from allm.txt 
 strcpy(s, dirname); strcat(s, "d.d");
 ifstream fstd(s, ios::in | ios::nocreate);
 if(!fstd.is_open()) error("main: cannot open file d.d= ", s);
 ipp("Opened file d.d ", s);
 
 fstd >> c >> fname >> pp>>aa>>bb>>cc>>dd>>ee>>ff>>gg>>hhh>>jj>>kk>>mm>>nn>>oo>>rrr>>sss>>ttt>>uu>>vv>>ww>>yy>>zz;  // module name (snam)
 fstd.getline(s, kdirname);  // skipped EOL after zz;
 fstd.getline(s, kdirname);  // skipped line

 fstd>>lasttt>>maxits>>lden>>ldep>>llot>>lsm>>lview>>lst>>lstr>>lthms>>lhis>>maxipp>>maxc>>maxd>>maxl>>tead>>pait;   
 fstd>>stad>>stad1>>stad2>>endpait>>prname;  lhis = lhis * 1000000; Maxipp = maxipp * 100000;
 
 cout <<"\nfname= "<<fname<<" p"<<pp<<"a"<<aa<<"b"<<bb<<"c"<<cc<<"d"<<dd<<
	     "e"<<ee<<"f"<<ff<<"g"<<gg<<"h"<<hhh<<"jj"<<jj<<"k"<<kk<<"m"<<mm<<"n"<<nn<<"o"<<oo<<"r"<<rrr
      <<"s"<<sss<<"t"<<ttt<<"u"<<uu<<"v"<<vv<<"w"<<ww<<"y"<<yy<<"z"<<zz;

 cout << "\nlasttt= "<<lasttt<<" maxits= "<<maxits<<" lden= "<<lden<<" ldep= "<<ldep
	  <<" llot="<<llot<<" lsm="<<lsm<<" lview="<<lview<<" lst="<<lst<<" lstr="<<lstr<<" lthms="<<lthms
   <<" lhis="<<lhis<<" maxipp="<<maxipp<<" maxd="<<maxd<<" maxl="<<maxl<<" tead="<<tead<<" pait="<<pait
   <<"\nstad="<<stad<<" stad1= " <<stad1<<" stad2= " <<stad2 << " endpait= "<<endpait << " prname="<<prname;

 *pfmainhis <<"\nfname= "<<fname<<" p"<<pp<<"a"<<aa<<"b"<<bb<<"c"<<cc<<"d"<<dd<<
	 "e"<<ee<<"f"<<ff<<"g"<<gg<<"h"<<hhh<<"jj"<<jj<<"k"<<kk<<"m"<<mm<<"n"<<nn<<"o"<<oo<<"r"<<rrr
  <<"s"<<sss<<"t"<<ttt<<"u"<<uu<<"v"<<vv<<"w"<<ww<<"y"<<yy<<"z"<<zz;

 *pfmainhis << "\nlasttt= "<<lasttt<<" maxits= "<<maxits<<" lden= "<<lden<<" ldep= "<<ldep
	 <<" llot="<<llot<<" lsm="<<lsm<<" lview="<<lview<<" lst="<<lst<<" lstr="<<lstr<<" lthms="<<lthms
  <<" lhis="<<lhis<<" maxipp="<<maxipp<<" maxc="<<maxc<<" maxd="<<maxd<<" maxl="<<maxl<<" tead="<<tead<<" pait="<<pait
  <<"\nstad="<<stad<<" stad1= " <<stad1<<" stad2= " <<stad2<< " endpait= " << endpait <<" prname=" << prname;
 //  if(ww){ remproofs(); exit(1); };  moved to trans;
 if(lasttt > maxlltt)   // maxlltt is actually last occupied;
 {
  cout << "\nERROR: lasttt > maxlltt, lasttt= " << lasttt << " maxlltt= " << maxlltt;
  *pfmainhis << "\nERROR: lasttt > maxlltt, lasttt= " << lasttt << " maxlltt= " << maxlltt;
  pfmainhis->close(); exit(1);
 } // if(lasttt > maxlltt) 
 laden = maxits+1;
 rfts(); 
 if(pp) for(i=0; i <= its; i++) 
 {
  cout << "\n"<<i << ' ' << ts[i];
  *pfmainhis << "\n"<<i << ' ' << ts[i];
 }
 
 ifstream fubs("fubs.chr", ios::in | ios::nocreate);    // for glex
 if(!fubs.is_open()) error("Tran: cannot open file ", s); 
 
 for(i=0; i<lsbin; i++)
 {
  if(rstr(&fubs,s,80)) error("Tran: error in file fubs.chr");
  sbin[i] = clon(s);
  if(pp) ipp("i, sbin[i]= ", i, sbin[i]);
 } // for(i)

 if(rstr(&fubs, s, 80)) error("Tran: wrong sun in fubs.chr");
 sun = clon(s);                   // unary symbols just after binary ones;
 ipp("tran: sun= ", sun);

 if(9) ipp("main: before trans ");   // 1 finished part 1
 
 adcl = wrts("dcl");            // 0
 avar = wrts("var");            // 1
 aAll = wrts("All");            // 2
 aExist = wrts("Exist");        // 3
 aExist1 = wrts("Exist1");    
 aExistx = wrts("Existx");     // 4
 aExist1x = wrts("Exist1x");
 aProof = wrts("Proof");        // 5
 aEqProof = wrts("EqProof");    // 6
 asuppose = wrts("suppose");    //
 adclb = wrts("dcl[");
 acrlf = wrts("{");
 aAb = wrts("A[");
 aabt = wrts("abt");
 avariable = wrts("variable");
 asop = wrts(":=");
 aterm = wrts("term");
 aabterm = wrts("abterm");
 aset = wrts("set");
 aclass = wrts("class");
 aany = wrts("any");
 abool = wrts("bool");
 adcol = wrts("::");    // double colon
 acol = wrts(":");  
 adot = wrts(".");
 aat = wrts("@");
 aeps = wrts("eps");
 aREL1 = wrts("REL1");
 adconj = wrts("&&");
 amnbool = wrts("mnbool"); 
 aplint = wrts("plint");
 amltint = wrts("mltint");
 amnint = wrts("mnint");
 amnint1 = wrts("mnint1");
 aopb = wrts("[");
 aanyd = wrts("anyd");
 aexc = wrts("!");
 adexc = wrts("!!");
 aexc1 = wrts("exc1");
 aexc2 = wrts("exc2");
 aend = wrts("end");           // end Proof T; // end EqProof T;
 anot = wrts("~");
 anot1 = wrts("not1");
 aby = wrts("by");
 arestr = wrts("restr");
 opp = elm(gpc,'(',0);         // openning  parenthesis
 opb = elm(gpc,'[',0);         // openning  bracket
 opc = elm(gpc,'{',0);         // openning  curly brace 
 // clpar = elm(clp,')',0);    // closing parenthesis
 comma = elm(gcom, ',',0);     // comma
 semicolon = elm(gcom, ';',0); // semicolon 
 mid = elm(ubs, prt("|"), wrts("|"));     // | 
 yexc = elm(ubs, prt("!"), wrts("!"));    // ! exclamation mark
 ydexc = elm(ubs, prt("!!"), wrts("!!"));  // !! double exclamation mark
 ymn = elm(ubs, prt("-"), wrts("-"));     // - minus
 yvar = elm(ident,0,avar);                // var special multiple symbol
 ysuppose = elm(ident, 0, asuppose);
 yassume = elm(ident, 0, wrts("assume")); zassume = yassume;
 zpostfix = elm(ident, 0, wrts("postfix"));
 yasop = elm(ubs,prt(":="),asop);  // 2 = prt(":=")
 ycomma = elm(gcom, ',',0); // ydclb = elm(ident,0,adclb);
	yre = elm(ident, prt("|"), wrts("|"));  // elm(253,15,8)
 ydcl = elm(ident,0,adcl);
 abtermp = elm(ident, 0, wrts("abt"));    // abterm parenthesis
 //  makezelm();                          // moved to trans;
 zel = elm(emps,0,emps);
 zopsqbr = elm(gpc,91,0);            // elm(247,91,0)
 zel0 = elmint(0);
 zel1 = elmint(1);
 zel9 = elmint(9);                   // used in byel: var_are_cons = zel9: sign of inlot;
 extern char ops[256];

 pol   = (intp) fylloc("pol", lpol * sizeof(int));             // polish notation: used in cr: smpb;
 varsp = (elemp) fylloc("varsp", lvarsp * sizeof(elem));         // also used in cr:smpb;
 lot = (elemp) fylloc("lot", (llot+1) * sizeof(elem));         // local truths;
 st = (elemp) fylloc("st", lst * sizeof(elem));               // main stack in pars;
 //stdepth_pars = (ats*) fylloc("stdepth_pars", lst * sizeof(ats)); // main stack in pars;
 strvalue = (char**) fylloc("strvalue", maxnstr * sizeof(char*));
 dep = (elemp) fylloc("dep", ldep * sizeof(elem));   // dependencies in prf
 dep1 = (elemp) fylloc("dep1", ldep * sizeof(elem));
 dep2 = (elemp) fylloc("dep2", ldep * sizeof(elem));
 // dep3 = (elemp) fylloc("dep3", ldep * sizeof(elem));
 inops();               // initialization of ops
//  pfmainhis->close();
 for(i=0; i <maxmod; i++) clad[i] = 0;
 trans(fname);
 pfhis = pfmainhis;
 if(its != oldits) wfts();
 wfallm();                            // append fallm
 if(9) ipp("main: before post ");
 post(curm);
 *pfhis << "\nSUCCESS! main: grand total time= " << grand_total_time; 
	cout << "\nSUCCESS! main: grand total time= " << grand_total_time;     cout << "\n\n";
	cout << "\a" << "\a" << "\a";
 ipp("Closed file fmainhis ", "main.his");
 pfmainhis->close();
} // end try
 // catch(int e) { ipp("main: catched e= ", e); }
 catch(...)
 {
  cout << '\a';    // beeping
  if(prognum==numtrm) prstcont("catch");
  else pntu->prach("\n\ntran:catch");
  ipp("\nTran: an ERROR was catched\n");
  cout << "\n" << curtime();
  cout << "\n\n\n\nError: pfhis= "<< pfhis;
  // cin >> c;
  cout << "\n\n\n\n";
  *pfhis << "\n" << curtime();
  // pfhis->close();
  myexit();
  return;
  // cin >> c;
 } // end catch

/*
 // double  totalt = (double) (end - start) / (double) CLOCKS_PER_SEC ; // ttime;
 float totalt = ttime("success");
 if(badelem==0) cout<<"\n\nSUCCESS! finished tran fname= " << fname << " root="<<ptt->root<<"  itt="<<ptt->itt;
 else cout<<"\n\nBADELEMS! finished tran fname= " << fname << " root="<<ptt->root<<"  itt="<<ptt->itt;
 cout << " \ntotal time(sec) = "<<totalt; // << "rawdate = " << rawdate(fname);
 cout<<"\ntime: "<<curtime();
 
 if(badelem==0) *pfhis<<"\n\nSUCCESS! finished tran fname= " << fname <<
  	       " root="<<ptt->root<<"  itt="<<ptt->itt<<"  mergecount= "<<mergecount;
 else *pfhis << "\n\nBADELEMS! finished tran fname= " << fname <<
  	       " root="<<ptt->root<<"  itt="<<ptt->itt<<"  mergecount= "<<mergecount;
 *pfhis << " \ntotal time(sec) = "<<totalt ; 
 *pfhis<<"\ntime: "<<curtime();
 pfhis->close();
 cout << '\a';    // beeping
	*/
} // end main

   void trans(char* M)     // translate M.v into M.ved;
{
 char s[kdirname]; int i;  // char c; 
 start_clock = clock();  sbstcount = 0;
	ipp("+trans module= ", M); 
	nstr = -1; counterrmsg = -1; ilot = -1; numthm = 0; ist = -1; depthst = -1;  idep = -1;
 maxditt = 0; maxditt1 = 0; maxdittp=0; maxditteqp = 0; maxdittadd = 0; maxDj = 0; sumDj = 0;
 maxdittz = zel;  maxdittz1 = zel; maxdittzp = zel; maxdittzeqp = zel; maxdittzadd = zel;
 maxdittlastseq = zel; wrlot_c = 0;
 wlot_not_writing = 0;
 /*zA = elm(ident,0,wrts("A["));
 zE = elm(ident,0,wrts("E["));
 zE1 = elm(ident,0,wrts("E1["));
 zF = elm(ident,0,wrts("F["));
 zR = elm(ident,0,wrts("R["));
 zU = elm(ident,0,wrts("U["));
 zS = elm(ident,0,wrts("S[")); 
 */
 zabterm = elm(ident,0,aabterm);
 zel = elm(emps,0,0);
 ofstream* save = pfhis; pftbt = 0; nowlotinf = false;
 // strcpy(source, dirname); strcat(source, M);
 
 // open file M.his
 strcpy(s, M);   // strcpy(s, source);  
 strcat(s, ".his");
 strcpy(namefhis, s); 
 
 ofstream fhis(s);
 if(!fhis.is_open()) error("cannot open file ", s);
 ipp("trans: Opened in curr.dir file ", s);  // Debug ?
 pfhis = &fhis;
 
 ipp("trans, dirname= ", dirname);
*pfhis <<"\nfname= "<<fname<<" p"<<pp<<"a"<<aa<<"b"<<bb<<"c"<<cc<<"d"<<dd<<
	 "e"<<ee<<"f"<<ff<<"g"<<gg<<"h"<<hhh<<"jj"<<jj<<"k"<<kk<<"m"<<mm<<"n"<<nn<<"o"<<oo<<"r"<<rrr
  <<"s"<<sss<<"t"<<ttt<<"u"<<uu<<"v"<<vv<<"w"<<ww<<"y"<<yy<<"z"<<zz;

 *pfhis << "\nlasttt= "<<lasttt<<" maxits= "<<maxits<<" lden= "<<lden<<" ldep= "<<ldep
	 <<" llot="<<llot<<" lsm="<<lsm<<" lview="<<lview<<" lst="<<lst<<" lstr="<<lstr<<" lthms="<<lthms
  <<" lhis="<<lhis<<" maxipp="<<maxipp<<" maxc="<<maxc<<" maxd="<<maxd<<" tead="<<tead<<" pait="<<pait
  <<"\nstad= "<<stad<<" stad1= " <<stad1<<" stad2= " <<stad2 << " endpait= " << endpait <<" prname=" << prname<<
 "\nCurrent time: "<<curtime();

 strcpy(source, M);
 strcpy(s, M);  strcat(s, ".v");
 if(99) ipp("+trans: input v-file s= ", s);  
 ifstream fin1(s, ios::in | ios::nocreate);          // source file .v;
 if(!fin1.is_open()) error("cannot open file ", s);
 if(99) ipp("trans: Opened file ", s);
 pfin = &fin1;
 if(99) *pfhis <<"\ntrans M= " << M << " sun= " << sun;       // main.his
 if(zz==7){ remproofs(pfin, s); exit(1); };
 if(zz==8){ checkcnt(); exit(1); };
 hbin(M);   // handling beginning of in file (module name and use list);
 if(curm == 0) nowlotinf = true;                         // nowlotinf = false; after REL; see aREL;
 ipp("trans: curm = ", curm, " nowlotinf= ", nowlotinf);
	makezelm();                        // make z-constants of the form elm(ident,...) or elm(ubs, ...)
 prognum = numtrm; 
 trm();    // creating abstract syntactic tree
 //if(its != oldits) wfts();
 //ptt->futt(M);           // write tabt;
 //exit(1); // error("trm: TEST");
 elem Root = elm(curm, 0, ptt->root);
 achs u(Root);
 pntu = &u;
 //if(curm != 0) clad[0] -> mzcn();     // 0 - the initial module (0_bool.v or previously snam.v)
 prognum = numbdef; u.bdef();           // ptt->bdef();
 // error("bdef: TEST");
 prognum = numsortden; ptt->sortden();
 // error("sortden: TEST");
 prognum  = nummzcn; 
 Mzcn();                                // if(curm == 0) clad[0] -> mzcn();  // ??? why not ptt ???
 u.init(Root); 
 prognum = numrnam; u.rnam(); // error("stop rnam");
 // error("rnam: TEST");
 prognum = numtopt;  ptt->topt();
 prognum = numcthms; ptt->cthms();
 // error("topt: TEST");
 u.init(Root);  
 prognum = numtyp;  typa(Root);
 ptt->wtt(M);            // write ved-file;
 ptt->futt(M);           // write tabt;
 ptt->fprp(M);           // den was written by bdef;
 ptt->uden();            // write den, because topt changed den.
 if(counterrmsg >= 0)
 {
  cout << "\nThere are warning messages: counterrmsg= "<<counterrmsg;  
  *pfhis << "\nThere are warning messages: counterrmsg= "<<counterrmsg;  
 } // if(counterrmsg >= 0)
 if(counterrmsg >= maxerrmsg) counterrmsg = maxerrmsg-1;
 for(i=0; i <= counterrmsg; i++)
 {
  cout << "\nline: "<<errlines[i]<<' '<<errmsgs[i]; 
  *pfhis << "\nline: "<<errlines[i]<<' '<<errmsgs[i]; 
 }  // for(i)
 finish("\nSuccess! finished ", M);
 // if(badelem){ cout << "\nNO success: badelem= " << badelem<<"\n\n\n---"; *pfhis << "\nNO success:badelem= " << badelem; }
 pfhis = save; 
 beep(3);                  // beeping: cout << '\a'; 3 times
 ipp("-trans M= ", M);
} // end trans

   void hbin(char* M)  // handling of beginning of in
{
 int i,j;  charp p,t1,t2; ppp = 0; // char s[kdirname]; // int static count = 0;
 // if(++count == 2)
 // mm=mm;
 ipp("+hbin source= ", source, " M= ", M);
 if(pfin->eof()) ipp("hbin: eof fin");
 if(rwcm(pfin, cont, 100)) error("tran:hbin waits module ", cont);
 // module M;
 t1 = strtok(cont, " ");  // t1 = "module"   // 	cont	0x00524b58 "﻿module"
 p = strstr(cont,"module");
 if(p==0) 
  error("hbin: no name \"module\", cont= ", cont);  // replace ipp with error
 p += strlen("module");
 t2 = strtok(0, ";");  // t2 =  M;
 if(strcmp(t1, "module"))
  ipp("hbin: no name \"module\" ,cont= ", cont, " t1= ", t1);
 if(strcmp(M, t2)) error("hbin: wrong module name ", t2, " M= ", M);
 curm = wallm(clon(t2));
 ipp("hbin: curm= ", curm);
 // use list
 if(rwcm(pfin, cont, 100)) error("tran:hbin waits use line, cont= ", cont);
  p = strstr(cont,"use");
 if(p==0)
   ipp("hbin: no \"use\" keyword, cont= ", cont); // replace ipp with error
 t1 = strtok(cont, " ");
 if(strcmp(t1, "use")) ipp("tran:hbin waits use,  cont= ", cont); 
 // ipp("replace strtok on an own procedure!source= ", source);
 j = 0; 
 while(t1)
 {
  bool p = false;
  t1 = strtok(0, " ,");  // name or "," or ";"
  if(t1 == 0) break;
  if(9) ipp("hbin: while(t1) t1= ", t1);  
  if(t1[0] == ';')  break; 
  int ilast = strlen(t1)-1;
  if(t1[ilast] == ';') {t1[ilast] = 0; p = true; }
  ++j;
  if(j >= maxmod) error("tran:hbin: used list is too big,j,maxmod= ", j);
  eul[j] = wallm(clon(t1));
  if(9) ipp("hbin: written to eul[j], j= ", j, " eul[j]= ", eul[j]);
  if(p) break;
 } // end for(i)
 ieul = j;
 if(9) ipp("hbin: kuselist= ", ieul);
 ptt = new tt(lasttt,ieul, lden, laden);
 ptt->mym = curm;
 clad[curm] = ptt; // iclad = 0; see below iclad = j;
 // lnad = sizett/2;
 // pttmod1 = new tt(lnad, 1, 1, laden);   // 1: was lden; prime terms are not definitions;
 // pttmod1->mym = maxmod1;
 // clad[maxmod1] = pttmod1; // iclad = 0; see below iclad = j;
 ipp("hbin curm= ", curm, " ptt= ", int(ptt), " ieul= ", ieul);
 if(9) ipp("hbin M1, source= ", source);
 ptt->kuselist = ieul;
 // ptt->uselist[0] = curm;           // was clon(&fname[0]);
 eul[0] = curm;
 // if(iclad > 0 && snampl == 0) error("tran:hbin no snam ");
  
 cout << "\nhbin: not extended used list eul, ieul= " << int(ieul) <<"\neul = ";
 *pfhis << "\nhbin: not extended used list eul, ieul= " << int(ieul) <<"\neul = ";
 for(i=0; i <= ieul; i++)
 { 
  ptt->uselist[i] = eul[i];
  cout << int(eul[i])<<' '; 
  *pfhis << int(eul[i])<<' ';
 } // end for(i)
 
 ipp("extending eul, ieul= ", ieul);   // clad[eul[i]] = rtt(allm[eul[i]);
 for(i=1; i <= ieul; i++)              // eul[0] = curm;
 {
  int m = eul[i];
  tt* p  = rtt(allm[m]);  
  clad[m] = p;
  ipp("tran:hbin extending used list for m= ", m);
  int k = p->kuselist;
  ipp("tran:hbin: p->kuselist = ", k);
  for(j=1; j <= k; j++)
  {	  
   modsize_t m1 = p->uselist[j];
   if(rtfm(allm[m1]) > rtfm(allm[m])) 
	   error("Tran:hbin: wrong modification time ", rtfm(allm[m1]));
   for(int k=0; k <= ieul; k++) 
	   if(m1 == eul[k]) goto Found;
   if(++ ieul >= maxmod)            // Not found
			   error("Tran:hbin: too big ieul= ", ieul);
   eul[ieul] = m1;
   Found: ;                         // check next j
  } // end for(j=1)
 } // end for(i=1)
 cout << "\nhbin:  extended used list eul, ieul= " << int(ieul) <<"\neul = ";
 *pfhis << "\nhbin:  extended used list eul, ieul= " << int(ieul) <<"\neul = ";
 for(i=0; i <= ieul; i++)
 { 
  int m = eul[i];
  cout << m <<' '; 
  *pfhis << m <<' ';
 } // end for(i)
 cout<<"\nsource = "<<source;
 *pfhis<<"\nsource = "<<source;
  myclock("finished hbin ");
} // end hbin

   void post(int m)              // m has been just changed
 {                                     // so must be rr[m]
 int i,j,k; tt* p; // char c;          // rr[m] - modules influenced by m
 ipp("+post m= ", m);                  // rr[0] = all modules
 //cout << "\npost sm = " << sm;       // rr[1]
 //cin >> c;
 //m = findallm(sm);
 irul = -1;
 for(i=0; i<maxmod; i++) irr[i] = -1;
 ipp("post: 1 compute rr, iallm= ", iallm);  // Step 1 does not depend on m
 for(i=0; i <= iallm; i++)             // module i; use m1;
 {                                     // i in rr[m1];
  p = clad[i];                         //  if m1 was changed, i must be also changed
  if(p == 0) p = rtt(allm[i]);         // ??? may not exist
  k = p->kuselist;
  ipp("post k,kuselist= ", k, " for module i= ",i);
  for(j=1; j<=k; j++)
  {
   modsize_t m1 = (p->uselist)[j];    // sm1 used in i;
   wrr(m1,i);                         // add i to rr[m1]
  } // end for(j)
 } // end for(i)
 cout << "\npost: Array rr[allm][], rr[m] - modules to retranslate after changing m\n";
 *pfhis << "\npost: Array rr[allm][], rr[m] - modules to retranslate after changing m\n";
 for(i=0; i <= iallm; i++)
 {
  cout <<"\n"<<i<<')';
  *pfhis <<"\n"<<i<<')';
  for(j=0; j<=irr[i]; j++){ cout << ' '<< int(rr[i][j]); *pfhis << ' '<< int(rr[i][j]); }
 } // end for(i)
 irul = irr[m];
 ipp("post: 2. write rr[m] into rul (reverse used list), irul= ", irul, " m= ", m);
 cout << "\nFile rul: \n"; *pfhis <<"\nFile rul: \n";
 for(i=0; i<=irul; i++)     
 {
  rul[i] = rr[m][i];     // m directly influences rr[m]  m
  cout << int(rul[i]); *pfhis << int(rul[i]);
 }
 // ipp("3 Transitive closure of rul, irul= ", irul);
 // for(i=0; i <= irul; i++)
 //  for(j=0; j <= irr[i]; j++)  // add rr[i] to rul
 //  wrul(rr[i][j]);
 cout << "\n   rul: Modules to retranslate (reverse used list):\n";
 *pfhis << "\n   rul: Modules to retranslate (reverse used list):\n";
 for(i=0; i<=irul; i++) { cout<< int(rul[i])<<' '; *pfhis<< int(rul[i])<<' '; }
 ipp("4 Translation of rul, irul= ", irul);
 for(i=0; i <= irul; i++) trans(allm[rul[i]]);
 ipp("-post m= ", m);
} // end void post(m)

   void wrr(int m, int n)    // add n to rr[m]
{
 if(pp) ipp("+wrr m n ", m, n);
 for(int i=0; i<=irr[m]; i++)
  if(rr[m][i] == n) goto Found;  
  // NotFound:
 if(++irr[m] >= maxmod) error("tran: wrr: wrong irr, m= ",m, " irr[m]= ", irr[m]);
 rr[m][irr[m]] = n;
 Found: if(pp) ipp("-wrr m n ", m, n);;
}  // end wrr(m,n)

   void wrul(int m)   // add m to rul reverse used list
{
 if(pp) ipp("+wrul m irul", m, irul);
 for(int i=0; i<=irul; i++)
  if(rul[i] == m) goto Found;
 // NotFound: 
  if(++irul >= maxmod) error("tran: wrul: wrong irul, sm= ", allm[m], " irul= ", irul);
  rul[irul] = m;
 Found: if(pp) ipp("-wrul m irul ", m, irul);
}  // end wrul(m)

   modsize_t findallm(char* s)   // find s in allm
{
 if(aa) ipp("+findallm s= ", s);
 modsize_t i,r; r = -1;
 for(i = 0; i <= iallm; i++)
 {	 
  if(9) ipp("findallm allm[i]= ", allm[i], " i= ", i);
  if(strcmp(s, allm[i]) == 0) { r = i; break; }
 }
 if(aa) ipp("-findallm r= ", r);
 return r;
} // end findallm(s)

	modsize_t wallm(char* s)  // write s into allm, return place in allm;
{
 int j,k;
 if(aa) ipp("+wallm s= ", s);     // if(pp): because wallm can be in loop
 for(j=0; j <= iallm; j++) // extm[0] = 0 !!!!!
  if(strcmp(allm[j], s) == 0) { k = j; goto M; }  // already in extm
 k = ++iallm; 
 if(k >= maxmod) error("rdem: wrextm too many external modules k= ", k);
 allm[k] = s; 
 M: if(aa) ipp("-wallm k= ", k);
    return k;
} // end wallm

   void rfallm()       // read file allm.txt (all modules)
{
 char s[kdirname]; int j;
 strcpy(s, dirname); strcat(s, "allm.txt");
 ipp("+rfallm");
 ifstream fallm(s);
 if(!fallm.is_open()) error("cannot open file ", s);
 ipp("Opened file allm= ", s);
 iallm = -1;
 while(iallm < maxmod)
 { 
  if(fallm.eof()) goto M;
  ++iallm;
  fallm >> j >> s;
  cout <<'\n' << j << ' ' << s;
  *pfhis <<'\n'<< j << ' ' << s;
  if(iallm != j) error("rfallm: iallm != j ", iallm, j);
  allm[iallm] = clon(s);
 }
 error("too big allm, iallm= ", iallm, " maxmod= ", maxmod);
 M: oldiallm = iallm;
	ipp("-rfallm iallm= ", iallm);
} // end void rfallm()

   void wfallm()       // append to file allm.txt
{
 char s[kdirname]; int j;
 strcpy(s, dirname); strcat(s, "allm.txt");
 *pfmainhis << "+wfallm oldiallm= " << oldiallm;
 ofstream fallm(s, ios::app);
 if(!fallm.is_open()) cout<<"\ncannot open file "<<s,exit1();
 ipp("Opened file (app) allm= ", s);
 for(j=oldiallm+1; j <= iallm; j++)
 { 
  fallm << '\n'<< j <<' '<< allm[j] ;
  cout << '\n'<< j << allm[j];
  *pfmainhis <<'\n'<< j << allm[j];
 }
 fallm.close();
 *pfmainhis << "-wfallm iallm= " << iallm;
} // void wfallm()


      void print_stparinst()
{
 /* *pfhis << "\n\nPrinting stparinst, istparinst= " << istparinst;
 for(int i=0; i<=istparinst; i++)
 {
  *pfhis<<"\n"<<i<<") "; prp(stparinst[istparinst], pfhis); 
  prp("\n     ", stparinst1[istparinst], pfhis);
 } // for(i) */
} // end print_stparinst()

   void rfts()            // read ts from file "tstabs.txt"
{
 int j,k; char qm = '"';
 char s[kdirname]; 
 strcpy(s, dirname);  strcat(s, "tstabs.txt"); 
 if(aa) ipp("+rfts s= ", s);
 ifstream fts(s, ios::in | ios::nocreate);
 if(!fts.is_open()) error("cannot open file ", s);
 ipp("rfts: Opened file ",s);
 // fts >> sits >> its >> sktabs >> ktabs;
 // if(strcmp(sits, "its")) error("rfts: waiting for \"its\", get ", sits);
 // if(its > maxits) error("rfts: too big its= ", its, " maxits=", maxits);
 // if(strcmp(sktabs, "ktabs")) error("rfts: waiting for \"ktabs\", get ", sktabs);
 // if(ktabs > maxktabs) error("rfts: too big its= ", its, " maxktabs=", maxktabs);
 ts = (charp*) fylloc("ts", (maxits+1)*sizeof ts);  // char** ts;
 countts = (char*) fylloc("countts", (maxits+1)*sizeof ts);  // char* countts;
 its = -1;
 while(its < maxits)
 { 
  // fts->getline(s, ssize);
  fts >> j;           //  readpstr(
  s[0] = fts.get();    // (s,kdirname,qm);   // qm = '"';
  if(s[0]==' ') s[0] = fts.get(); 
  if(s[0]==qm)
  { 
   fts.getline(&s[1],kdirname-1,qm); 
   k = strlen(s);
   s[k] = qm; s[k+1] = 0;
  } // if(s[0]==qm)
  else{ fts.putback(s[0]); fts >> s; }   // fts.putback(s[0]);
  if(fts.eof()) goto M;
  ++its;
  if(aa) cout <<'\n' << j <<' '<< s;
  if(aa) *pfhis <<'\n'<< j <<' ' << s;
  if(its != j) error("rfts: its != j ", its, j);
  ts[its] = clon(s);
 }
 error("rtfs: too big its, its= ", its);
 M: oldits = its;
 fts.close();
 if(aa) ipp("-rfts s,its= ", s,its);
} // end void rfts();

 void wfts()           // write ts to file "tstabs.txt"
{
 char s[kdirname];
 strcpy(s, dirname);  strcat(s, "tstabs.txt"); 
 if(pp) ipp("+wfts s= ", s);
 // if(its == itsold) { ipp("wfts: its = itsold ", its); goto ret; }
 ofstream fts(s, ios::out | ios::nocreate);
 if(!fts.is_open()) error("cannot open file ", s);
 ipp("wfts: Opened file ",s);
 // fts << "its " << its << " ktabs " << ktabs << '\n';
 for(int i=0; i <= its; i++) 
	 fts << i << ' ' << ts[i] << '\n';
 fts.close(); oldits = its;
 if(pp) ipp("-wfts s= ", s);
} // end wfts()

	 void makezelm()        // make z-constants of the form elm(ident,...) or elm(ubs, ...)
{
	*pfhis << "\n+makezelm: making z-constants of the form elm(ident,...) or elm(ubs, ...)";
	cout << "\n+makezelm: making z-constants of the form elm(ident,...) or elm(ubs, ...)";
	zdclb = elm(ident,0,adclb);
 zall = elm(ident,0,aAll); 
 zexist = elm(ident,0,aExist); 
 zexist1 = elm(ident,0,aExist1);
 zexistx = elm(ident,0,aExistx);
 zexist1x = elm(ident,0,aExist1x);
 zcrlf = elm(ident,0,acrlf);
 zA = elm(ident,0,aAb); 
 zE = elm(ident,0,wrts("E[")); 
 zEx = elm(ident,0,wrts("Ex[")); 
 zE1 = elm(ident,0,wrts("E1[")); 
 zF = elm(ident,0,wrts("F[")); 
 zR = elm(ident,0,wrts("R[")); 
 zU = elm(ident,0,wrts("U[")); 
 zS = elm(ident,0,wrts("S["));  // zI
 znatm = elm(ident,0,wrts("natm"));  
 zcol = elm(ubs, prt(":"), wrts(":")); ycol = zcol; 
 zat = elm(ubs, prt("@"), aat);  yat = zat;   // @
 zdot = elm(ubs, prt("."), adot);
 zdcol = elm(ubs, prt("::"), adcol);          // :: ??? prt ???
 zdconj = elm(ubs, prt("&&"), adconj);        // &&
 zin = elm(ident,0,wrts("in"));       // ??? precedence ???
 yfn = elm(ident,0,wrts("fn"));       // fn special multiple symbol ???
 yif = elm(ident,0,wrts("if"));       // if special multiple symbol
 zby = elm(ident,0,wrts("by"));       // by special multiple symbol
 zbyeq = elm(ident,0,wrts("byeq"));   // byeq special multiple symbol
 zis = elm(ident,0,wrts("is"));
 zwith = elm(ident,0,wrts("with"));
 zdebug = elm(ident,0,wrts("debug"));
 zProof = elm(ident, 0, aProof);
 zEqProof = elm(ident, 0, aEqProof);
 zabterm = elm(ident,0,aabterm);
} // end makezelm

  void finish(char* s, char* M)        // printing total time and other statistics for module M;
{
if(s[1]=='S'){                         // s = "\nSuccess ..."
 *pfhis << "\n\nhnis-counts:\n"
        <<"\nchnis= "<<chnis
        << "\ncadt_gt1= "<<cadt_gt1
        << "\ncA,cAimp_equ= "<<cAimp_equ
        << "\ncAll= "<<cAll
        << "\ncAllimp= "<<cAllimp
        << "\ncAllm= "<<cAllm
        << "\ncAModel= "<<cAModel
        << "\ncAssocinve= "<<cAssocinve   // is Associnve;
        << "\ncAxab= "<<cAxab             // is Axab;
        << "\ncexc= "<<cexc               // is P ! Q;       not used;
        << "\ncInstance= "<<cInstance     // is Instance(P)
        << "\ncisst_y0= "<<cisst_y0       // ???????
        << "\ncimp= "<<cimp               // ?????? must val-part handle;
        << "\ncM10= "<<cM10<<"\n"
        << "\ncMimp= "<<cMimp             // ?????????
        << "\ncmnbool= "<<cmnbool         // is -E, E := A=B;
        << "\ncRed= " <<cRed              // is Red;
        << "\ncStaut= "<<cStaut           // is Staut;
        << "\ncTaut= "<<cTaut             // is Taut;
        << "\ncTautP= "<<cTautP           // is Taut(P)
        << "\nctrue= "<<ctrue             // is true;
        << "\nctypeaxiom= "<<ctypeaxiom   // is typeaxiom;
        << "\ncvterm= "<<cvterm           // is Q.M  or is Q(M);
        << "\ncw0_eq_equ= "<<cw0_eq_equ
        << "\ncw0_Taut_Staut= "<<cw0_Taut_Staut  // ??????????  val(Taut(P)) = P, so it is impossible
        << "\ncWitness= "<<cWitness       // is Witness(z);  // All(x,P(x));
        << "\ncWitness_E= "<<cWitness_E;  // is Witness(z);  // E[d,P]; 
 }      // if(s[0]=='S'){
 avDj = float(sumDj)/findcount; // end = clock();
 // static double  totalt = (double) (end - start) / (double) CLOCKS_PER_SEC ;
 float totalt1 = ttime("finish");  // (double) (clock() - start) / (double) CLOCKS_PER_SEC ;
	grand_total_time += totalt1;
 // cout<<"\nfinish: start_clock= " <<start_clock << " CLOCKS_PER_SEC= " << CLOCKS_PER_SEC << " totalt1= "<<totalt1;
 cout<<"\n\n"<<s<<" trans, Module= " << M <<
	   " root="<<ptt->root<<"  itt="<<ptt->itt<< "  count of errmsg= "<< ++counterrmsg;  // because counterrmsg = -1
 prp("\nmaxdittz= ", maxdittz); cout << "\nmaxditt= " << maxditt;
 prp("\nmaxdittzp= ", maxdittzp); cout << "\nmaxdittp= " << maxdittp;
 prp("\nmaxdittzeqp= ", maxdittzeqp); cout << "\nmaxditteqp= " << maxditteqp;
 prp("\nmaxdittz1= ", maxdittz1); cout << "\nmaxditt1= " << maxditt1;
 cout << "\nmaxDj= " << maxDj;
 cout << "\navDj= " << avDj;
 cout << "\nmergecount= " << mergecount;     // merge count in findtabt
 cout << "\nfindtabt count= " << findcount;   // number of calls of findtab
 cout << "\nnumthm= " << numthm;
 cout << "\nippcount= " << ippcount;
 cout << "\nmaxcountf= " << maxcountf;
 prp("\nmaxf= ", maxf);
 cout << "\ntime_trm= " << time_trm <<
 "\ntime_bdef= " << time_bdef <<
 "\ntime_sortden= " << time_sortden <<
 "\ntime_rnam= " << time_rnam <<
 "\ntime_topt= " << time_topt <<
 "\ntime_cthms= " << time_cthms <<
 "\ntime_typa= " << time_typa <<
 "\nithms= " << ptt->ithms <<
 "\nalm= " << alm<<
"\n#badelems= " << badelem <<
"\n#zeltypes " << zeltype <<
 "\ncountctruth= " << countctruth <<
	"\nglexcount= " << glexcount <<
 "\nwlot_not_writing= " << wlot_not_writing; // <<
 prp("\n\nlast_y1= ", last_y1);
 prp("\nlast_y= ", last_y);
 cout << " \ntotal time(sec) = "<<totalt1<< // << " count = "<<count; 
 "\nCurrent time: "<<curtime();    // << "rawdate = " << rawdate(fname);
// *pfhis<<"\nfinish: start_clock= " <<start_clock << " CLOCKS_PER_SEC= " << CLOCKS_PER_SEC << " totalt1= "<<totalt1;
 *pfhis<<"\n\n"<<s<<" trans, Module= " << M <<
	       " root="<<ptt->root<<"  itt="<<ptt->itt << "  count of errmsg= "<<counterrmsg<<"\n";
 prp("\nmaxdittz= ", maxdittz, pfhis); *pfhis << "\nmaxditt= " << maxditt; 
 prp("\nmaxdittzp= ", maxdittzp, pfhis); *pfhis << "    maxdittp= " << maxdittp;
 prp("\nmaxdittzeqp= ", maxdittzeqp, pfhis); *pfhis << "  maxditteqp= " << maxditteqp;
 prp("\nmaxdittz1= ", maxdittz1, pfhis); *pfhis << "\nmaxditt1= " << maxditt1;
 *pfhis << "\nmaxDj= " << maxDj;
 *pfhis << "\navDj= " << avDj;
 *pfhis << "\nmergecount= " << mergecount;     // merge count in findtabt
 *pfhis << "\nfindtabt count= " << findcount;   // number of calls of findtabt
 *pfhis << "\nnumthm= " << numthm;
 *pfhis << "\nippcount= " << ippcount;
 *pfhis << "\nithms= " << ptt->ithms;
 *pfhis << "\nmaxcountf= " << maxcountf;
 prp("\nmaxf= ", maxf, pfhis);
 prp("\nmaxdittlastseq= ", maxdittlastseq, pfhis);
 prp("\nmaxdittzadd= ", maxdittzadd, pfhis);
 *pfhis << "\nmaxdittadd= " << maxdittadd;
 *pfhis << "\nbadelem= " << badelem;
 *pfhis << "\n#zeltypes " << zeltype;
 *pfhis << "\ncountbadthms= " << countbadthms;
 *pfhis <<"\nwlot_not_writing= " << wlot_not_writing;
 *pfhis << "\ntime_trm= " << time_trm<<
 "\ntime_bdef= " << time_bdef<<
 "\ntime_sortden= " << time_sortden<<
 "\ntime_rnam= " << time_rnam<<
 "\ntime_topt= " << time_topt<<
 "\ntime_cthms= " << time_cthms<<
 "\ntime_typa= " << time_typa<<
//  " \ntotal time(sec) = " << totalt << // << " count = "<<count; 
 "\nalm= " << alm<<
 "\ncountctruth= " << countctruth<<
	"\nglexcount= " << glexcount;
 prp("\n\nlast_y1= ", last_y1, pfhis);
 prp("\nlast_y= ", last_y, pfhis);
 *pfhis << "\nCurrent time: " << curtime() <<    // << "rawdate = " << rawdate(fname);
 "\ntotal time(sec) = " << totalt1; // << " count = "<<count;
 *pfmainhis << "\ntotal time(sec) = " << totalt1; 
 // *pfhis<<"\nCurrent time: "<<curtime()<<"\n\n\n\n\n";
  if(badelem)
   { cout<< "\n\nERROR: badelem= " << badelem<<"\n\n---"; *pfhis << "\n\nERROR: badelem= " << badelem<<"\n\n---"; }
  // else { cout<< "\n\nbadelem= " << badelem<<"\n\n---"; *pfhis << "\n\nbadelem= " << badelem<<"\n\n---"; }
  pfhis->close();
  pfhis = pfmainhis;    // pfmainhis->close(); 
 // if(pftbt) pftbt->close();
 cout << '\a';    // beeping
} // end finish

inline att curmad(elem z){ att r = emptt; if(z.m==curm) r = z.ad; return r; }

 bool bigterm(headp h)
{
 elemp q = &(h->son[0]); int hl = h->l;  bool r = hl > 8 || q[0]==zProof || q[0]==zEqProof; int i;        // ??? 8: name it !!!
 if(!r && q[0]==opb) for(i=0; i<hl; i++) if(fnt2(q[i],zdcol)){ r = true; break; }
 return r;
} // end bool bigterm;

headp* tabt1;    //  tabt1 = tabt, if freespace >= itt1-part; else it is a more complicated case;
att itt0; // initial value of itt;
//int hst[1000]; //  = (int*) st;  // for forward terms, like L1 & L2 in proofs;
// eliminate pfs ??? 5.12.19
att rad[twoexp16], rad1[twoexp16]; // reverse addresses, rad[n]==i : tabt[i]->sons contain itt1-address;

 void tt::topt()  // term optimization // att tt::sz1(){ return itt + 1; } // att  tt::sz2(){ return lltt+1 - itt1; }
{                                      // att  tt::szfs(){ return itt1-itt-1; } 
 att a,ad,hl,i,j, k1=sz1(), k2=sz2(), kfs=szfs(), k3=k1+k2; elem z; int i2; headp h; elemp q; // emptt == 65535
 bool p; int savemm = mm;  // sz1 = itt + 1, sz2 = lltt+1 - itt1; szfs = itt1-itt-1;
 *pfhis << "\n+topt lltt= "<<lltt<<" itt= "<<itt<<" itt1= "<<itt1<<" k1(itt+1)= "<<k1<<" k2(65531-itt1)= "<<k2
        <<" k1+k2= "<<k3<<" kfs(itt1-itt-1)= "<<kfs<< "\nsimple case: kfs-k2>=0, kfs-k2= "<< kfs-k2;
  cout << "\n+topt itt= "<<itt<<" itt1= "<<itt1<<" k1= "<<k1<<" k2= "<<k2<<" k1+k2= "<<k3<<" kfs= "<<kfs;
 *pfhis << " \ntabt[0]= "<<int(tabt[0]); cout << " \ntabt[0]= "<<int(tabt[0]);
 int k = sizehar * sizeof(att);  ist = -1;  itt0 = itt;
 mergecount = 0;                                 // merge count in findtabt
 findcount = 0;                                  // number of calls of findtabt
 // har = (att*) fylloc("topt:har", k);             // sizeof(att) = 2;
 //ipp("topt: har allocated, full size(for fylloc) of har= ", k);
 // for(i2=0; i2 < sizehar; i2++)
 // har[i2] = emptt;  // emptt = 65535, sizehar = 65536 * 4 * 2;
 nad = (att*) fylloc("nad", (twoexp16) * sizeof(att));            // (lltt+1) *
 for(i=0; i <= lltt; i++)
 { 
  nad[i] = emptt;         // new address;
  rad[i] = emptt;         // reverse address for tabt 
  rad1[i] = emptt;        //                 for son (rad[i], rad1[i]): reverse address for i;
 } // for(i=0;            // 
 tabt1 = tabt;
 if(k2 > kfs)    // ok, free space fits for itt1..lltt;
    ipp("topt: not imp.yet, k2 > kfs, k2= ", k2, " kfs= ", kfs);

 ipp("topt1: at first we have to compute rad and rad1, root= ", root, " itt= ", itt, " itt1= ", itt1);
 for(i=0; i<=root; i++)
 {
  h = tabt[i]; 
  if(h==0) error("topt:topt1: h=tabt[i]==0, i= ", i);
  q = &(h->son[0]); 
  hl = h->l;
  p = true;
  for(j=0; j<hl; j++) 
  {
   a = curmad(q[j]);                                        // if big a then save i,j in rad, rad1
   if(a != emptt && a >= itt1 )
   { 
    if(mm) ipp("topt1:  rad[a]=i; rad1=j, a= ", a, " i= ", i, " j= ", j);
    rad[a] = i; rad1[a] = j;  p = false;        // p: was no big addres, saved i,j in rad[a], rad1[a];
   } //
  } // for(j)
 // if(p && !defname(q[0]) && !bigterm(h)) findtabt(hl,q,'h',i);  // ??? 4: name ! // && h->name == noname
 } // for(i)
 if(mm) ipp("finished topt1, printing rad, rad1, lltt= ", lltt);
 if(mm) *pfmainhis<<"\n i   rad   rad1\n";
 if(mm) for(i=0; i<=lltt; i++) *pfmainhis<<"\n"<<i<<' '<<rad[i]<<' '<<rad1[i];

 ipp("topt2. main part: merging from itt1..lltt to 0..itt, root= ", root, " itt= ", itt, " ff= ", ff);
 for(i=lltt; i >= itt1; i--)  //  i = lltt;  while(i >= itt1) 
 {
  h = tabt1[i]; // ff = (i==stad1); mm = ff; zz = ff;
  if(mm || i==stad2) ipp("topt2: tabt1[i]= ", elm(mym,0,i), " h->tp= ", h->tp,  " i= ", i, " h->adt= ", h->adt);
  if(writt(i)) error("writt: forward term = ", elm(mym,0,i));       // i - forward term;  ??? no forward terms ???
  /*{
   if(++ist >= 1000) error("writt: ++ist >= 1000, ist= ", ist, " lst= ", lst);
   hst[ist] = i; 
   if(9) ipp("topt: writing i to hst, i= ", i, " j= ", j);
  } // if(writt(h, ...)
  */
  //if(--i == itt1-1) i = itt0;     // was i=itt0, skipping former free space; going to fixed terms;
 } // while(i)
 
 ipp("topt3: hashing tabt[0..itt], itt= ", itt, " ff= ", ff);
 for(i=0; i<=root; i++)
 {
  if(i==stad2)
  mm=mm;
  h = tabt[i]; q = &(h->son[0]); hl = h->l;
 if(!defname(q[0]) && !bigterm(h)) findtabt(hl,q,'h',i);  // ??? 4: name ! // && h->name == noname
 } // for(i)

 ipp("topt4. now we have to change den, iden= ", iden," ist= ", ist);
 for(i=0; i<=iden; i++)
 {
  z = den[i]->inn;
  if(z.m == mym && (ad = z.ad) >= itt1)
  {
   a = nad[ad];
   if(a == emptt) error("topt: nat[ad] cannot be emptt in den->inn, z= ", z, " i= ", i);
   (den[i]->inn).ad = a; 
  } // if(z.m == mym && (ad = z.ad) > itt1)  // in den
  z = den[i]->scope;
  if(z.m == mym && (ad = z.ad) >= itt1)
  {
   a = nad[ad];
   if(a == emptt){ errmsg("topt: nat[ad] cannot be emptt in den->scope, z= ", z, " i= ", i); continue; }
   (den[i]->inn).ad = a; 
  } // if(z.m == mym && (ad = z.ad) > itt1)  // in den
 } // for(i=0; i<=iden; i++)
 ipp("topt: final free space(itt1-itt-1) in tabt= ", itt1-itt-1, " itt1= ", itt1, " itt= ", itt);
 itt1 = lltt+1; // lltt = itt;   //  itt1 = lltt+1: for futt; 
 if(zz==1)
 {
  ipp("topt: printing har to main.his");
  *pfmainhis<<"\n\nPrinting har:  ptt= "<< int(ptt)<<" har\n ";
  for(i2=0; i2 < sizehar; i2++) 
    *pfmainhis<<"\n"<<i2<<' '<<ptt->har[i2]<<';';
  pfmainhis->close();
 } // if(zz)
 time_topt = myclock("-topt finished ");  mm = savemm;
} // end topt
	 
  bool tt::writt(att i)                        // write h-term into first part(itt) of tabt, 
{ //  calculating nad ; returns true, iff i points to a forward term; itt0 - to check itt1-address
 att a,ad,j,hl1,i1,j1;  elem z,x; bool r = false;  // i >= itt1 == i-term comes from itt1-part, #i;
 headp h1, h = tabt1[i]; elemp q1,q = &(h->son[0]); int hl = int(h->l), k=hl;  // necessary to use findtabt;
 if(zz==1 || ff || i==stad2) 
    ipp("+writt: h->tp= ", h->tp, " i= ", i, " itt= ", itt, " itt1= ", itt1, " h->atd= ", h->adt);
 if(h->tel == pfs && Abt(q[0])) error("+writt:h->tel == pfs && Abt(q[0]), elm(mym,0,i)= ", elm(mym,0,i), "/ni= ", i);
 if(h->adt) k = -k;
 for(j=0; j<hl; j++)   // at first we have to replace every big address ad on nad[a]
 {
  z = q[j];
  if(z.m==mym && (ad = z.ad) >= itt1)  // && z.i==0  curmad(z) ??? curm ???
  {
   a = nad[ad];
   if(a == emptt)
   {
    error("writt: forward term z= ", z, " i= ", i, " j= ", j, " ad= ", ad);
    r = true;  goto ret;
   } // if(a == emptt)
   q[j].ad = a;  // because terms in tabt are topologically ordered from lltt to itt1:
  } // if(z.m==mym && z.i==0) //  all sons of i-term  were be written into tabt early of i- term;
 } // for(j=0)                // and therefor were be already handled and written into nad;
 a = findtabt(k,q);           // k = hl or k = -hl,if adt;  a - new place for i-term in tabt1;
 nad[i] = a;
 h1 = tabt1[a];
 x = h1->son[0];
 if(x==yat || x==zat || x==ycol) h1->tp = zel1;    //omitted  T@d, x:X,  to prevent false zel types in futt;
 if(ff || i==stad2) ipp("findtabt: new address a, new tp= ", h1->tp, " a= ", a); //  " q= ", q, k-1); 
 i1 = rad[i]; j1 = rad1[i];   // (i1,j1) - place in tabt1, containing big address;
 if(i1 != emptt)
 {
  if(j1==emptt) error("writt: it is impossible: i1 != emptt && j1==emptt, i= ", i, " i1= ", i1, " j1= ", j1);
  h1 = tabt[i1]; q1 = &(h1->son[0]); hl1 = h1->l;
  if(mm) ipp("writt: changing tabt1 i1= ", i1, " j1= ", j1, " a= ", a);
  q1[j1].ad = a;
  for(j=j1+1; j < hl1; j++)   // checking, if big addresses left:
  {
   a = curmad(q1[j]);
   if(a != emptt && a >= itt1) goto ret;
  } // for(j=j1+1; ...)
  if(h1->tel == pfs && Abt(q1[0]))
     error("writt: Abt(q1[0]),elm(mym,0,i)= ",elm(mym,0,i),"\nelm(mym,0,i1)= ",elm(mym,0,i1),"\ni= ",i," i1= ", i1);
  if(!bigterm(h1) && h1->tel != abt && !allex1(q1[0])) findtabt(hl1, q1, 'h', i1);    //  only har [hash] = i1; the good term is in tabt1 already;
  goto ret;
 } // if(i1 != emptt ... )
 if(j1!=emptt) error("writt: it is impossible: i1 == emptt && j1!=emptt, i= ", i, " i1= ", i1, " j1= ", j1);

 ret: if(zz==1 || i==stad2) 
    ipp("-writt new h->tp= ", h->tp, " q[0]= ", q[0], " i= ", i, " r= ", r);
 return r;
} // end bool writt(headp h, ...);

   int comparthms(const void* p1, const void* p2) 
{
 att k1 = *(att*)p1; att k2 = *(att*)p2; 
 att* pthms = ptt->thms; att pmym = ptt->mym;
 // att k1 = pthms[*P1]; att k2 = pthms[*P2]; 
 elem z1 = elm(pmym,0,k1); elem z2 = elm(pmym,0,k2);
 int r = cmpt(z1,z2);
 return r;
}  // end comparthms

  void tt::sortthms()
{
 // if(pp)cout<<"sortden"<<iden;
 // int i,n,n1; // elem x; // char c
 qsort(thms,ithms+1,sizeof(att),comparthms);
} // end void tt::sortthms()

  void tt::wrthms(att a)
 { 
  headp h = tabt[a];
  if(a > itt) error("wrthms: wrong a>itt, a= ", a, " itt= ", itt);
  if(++ithms >= lthms) error("cthms: too big ithms= ", ithms, " lthms= ", lthms);
  thms[ithms] = a; 
  // if(9) ipp("wrthms: a= ", a, " ithms= ", ithms);
 } // end void tt::wrthms(att i)

 void tt::cthms()                  // calculating thms;
{
 att i,k,tr; ats m,a; headp h; elemp q; elem z,f1,f=zel; ats indthms_comp= -1; bool wasidubs=false;
 if(9) ipp("+cthms: mym= ", mym);  ats countf=0;    bool wasnotidubs = false; 
 idubscount = 0; maxcountf=0;  // ithms = -1;  ithmsic = -1;  // moved to tt::tt;
 // thms = (att*) fylloc("thms", lthms * sizeof(att));        // moved to tt::tt;
 // thmsic = (att*) fylloc("thmsic", lthmsic * sizeof(att));  // moved to tt::tt; lthmsic: see lib.h #define lthmsic 1000
 // indthms = (att*) fylloc("indthms", (lden) * sizeof(att)); // moved to tt::tt; 
 if(9) ipp("calculating thms");
 for(i=0; i<root; i++)
 {
  h = tabt[i]; tr = h->t;
  if(tr==truth3)                    // was: if(tr==truth || tr==ctruth)
  {
   wrthms(i);
   z = elm(mym,0,i);
   if(mel(z,&h,&q) != pfs) error("cthms: not formula z= ", z, " i= ", i); 
   if(h->l==3 && q[2].m==mym && (q[0]==zA || q[0]==zall))
   {
    if(mel(q[2])==pfs){ mktr0(q[2],tr); wrthms(q[2].ad); }
   }
  } // if(tabt[i]->t != 0)
 } // for(i) 
 sortthms();     // sorting thms in an ascending order
 if(uu) *pfhis<< "\nPrinting thms: i  :  thms[i]\n";      // printing thms;
 beg_impconj = -1;  end_impconj = -1;
 beg_equin = -1;  end_equin = -1;
 beg_rimpin = -1;  end_rimpin = -1;
 beg_exist = -1; end_exist = -1;
 for(i=0; i<=ithms; i++)
 {
  k = thms[i]; h = tabt[k]; f1 = f; f = h->son[0]; a = h->name; h->name = noname;
  if(f != f1 && i != 0)
  {
   if(countf > maxcountf){ maxcountf = countf; maxf = f1; }
  if(uu) *pfhis << " countf= "<<countf;  countf = 0;
  } // if(f != f1 ...)
  if(uu) *pfhis<<"\n\n"<<i<<":"<<k<<" "<<(a == -1? "****": vts(a)); 
  if(uu) prp(" ", f, pfhis); ++countf;
  if(uu) prp("\n", elm(mym,0,k), pfhis); h->name = a;
 } // for(i)
 if(uu) *pfhis<<"\nmaxcountf= "<<maxcountf; if(uu) prp(" maxf= ",maxf,pfhis);
 if(9) ipp("calculating indthms");
 // for(i=0; i<lden; i++) indthms[i] = emptt;   // ??? iden ??? // moved to tt::tt();
 for(i=0; i<=ithms; i++)
 {
  k = thms[i]; z = elm(mym,0,k); f = zel;  // f: to catch transition;
  // if(mm) ipp("cthms:indthms: z= ", z, " i= ", i, " k= ", k);
  if(mel(z,&h,&q) != pfs) error("cthms:indthms: not formula z= ", z, " i= ", i); 
  checkseg(i, zimp, zconj, &beg_impconj, &end_impconj);
  checkseg(i, zrimp, zin, &beg_rimpin, &end_rimpin);
  checkseg(i, zequ, zin, &beg_equin, &end_equin);
  checkseg(i, zexist, zel, &beg_exist, &end_exist);
  if(idubs(q[0])) 
  {
   if(wasnotidubs) error("cthms:indthms: idubs after notidubs, z= ", z, " i= ", i);
   ++idubscount; wasidubs = true; continue;  // idubses are not in indthms;
  } // if(idubs(q[0]))
  wasnotidubs = true;
  m = mel(q[0]);
  if(comp(m))
  {
   if(indthms_comp == -1) indthms_comp = i;
   continue;
  } // if(comp(m))
  if(q[0] != f)
  {
   f = q[0];                      // i: beginning of a new f-segmet
   a = fdenz(f);                  // ??? f is composite ???
   if(a != -1) indthms[a] = i;
  } // if(q[0] != f)
 } // for(i)
 *pfhis << "\n   cthms: calculatig thms: end for(i)\n\n";
 *pfhis << "\nbeg_impconj= "<<beg_impconj<<" end_impconj= "<<end_impconj;
 *pfhis << "\nbeg_rimpin= "<<beg_rimpin<<" end_rimpin= "<<end_rimpin;
 *pfhis << "\nbeg_equin= "<<beg_equin<<" end_equin= "<<end_equin;
 *pfhis << "\nbeg_exist= "<<beg_exist<<" end_exist= "<<end_exist;
 // printing indthms;
 if(9) *pfhis<< "\nidubscount= "<<idubscount;
 if(9) *pfhis<< "\n\nPrinting indthms: i  :  k:=indthms[i] : f(z) : z = elm(mym,0,thms[k])\n";
 for(i=0; i<lden; i++)           // ??? iden ???
 {
  k = indthms[i];         // k points to thms;
  if(k==emptt) continue;
  z = elm(mym,0,thms[k]);  
  *pfhis<<"\n"<<i<<":"<<k<<":"<<vts(den[i]->a); if(9) prp(":",z,pfhis);
 } // for(i)
 if(9) *pfhis<<"\n"<<"indthms_comp= " << indthms_comp;
 time_cthms = myclock(" cthms finished ");
 if(9) ipp("-cthms: maxf= ", maxf, " maxcountf= ", maxcountf, " ithms= ", ithms, " idubscount= ", idubscount);
} // end void tt::cthms()

 void tt::checkseg(att i, elem f1, elem f2, ats* beg, ats* end)
{
 int k = thms[i]; elem nexti,P1,P2,P3, z = elm(mym,0,k); // f = zel;  // f: to catch transition;
 if(mm) ipp("+checkseg: z= ", z, " i= ", i, " k= ", k);
 // if(mel(z,&h,&q) != pfs) error("cthms:indthms: not formula z= ", z, " i= ", i); // P1,P2,P3 are not used.
 if(f2==zel && fnt2(z,f1) || f2!=zel && fnt22l(z,f1,f2,&P1,&P2,&P3))  // P1&P2 -> Q;   f1: ->, f2: & ; 
 {   //  bool fnt22l(elem z,elem f1,elem f2, elem* P1, elem* P2, elem* P3) // z = f1(f2(P1,P2),P3)
  if(*beg == -1)
  {
   *beg = i; 
   ipp("checkseg: found beginning of (f1,f2)-segment in thms, f1= ", f1, " f2= ", f2, " beg= ", *beg);
  } // if(*beg == -1)
  else // *beg != -1: we are inside of (f1,f2)-segment
  {
   if(i==ithms) goto M;                   // i is the last;
   nexti = elm(mym,0, thms[i+1]);
   if(f2==zel && !fnt2(nexti,f1) || f2!=zel && !fnt22l(nexti,f1,f2,&P1,&P2, &P3))   // P1,P2,P3 are not used.
   {
   M: *end = i;
   ipp("checkseg: found end of(f1,f2)-segment in thms,f1= ",f1," f2= ",f2," beg= ",*beg," end= ", *end); 
   } // if(i==ithms || ...) 
  } // else, if(*beg == -1)
 } // if(fnt22l(z,f1,f2))
} // ebd void checkseg

 bool tt::chinthms(elem x, elem t) // check (x1 in t <- P1) is in thms, s.instance(x,x1), inlot(s.rep(P1)); 
{
 bool r = false; elem x1,t1,P1,Q,T; int i; sbst s;
 if(mm) ipp("+tt::chinthms x= ", x, " t= ", t); 
 if(beg_equin < 0 || beg_equin > ithms || end_equin < 0 || end_equin > ithms || end_equin < beg_equin)
    error("tt::chinthms:  wrong(one of) beg_equin,end_equin, x= ", x, " t= ", t, 
          " beg_equin= ", beg_equin, " end_equin= ", end_equin, " mym= ", mym); 
 for(i=beg_rimpin; i<=end_rimpin; i++)
 {
  T = elm(mym,0,thms[i]);
  if(!fnt22l(T,zrimp,zin,&x1,&t1,&P1)) 
     error("chinthms: T is not (x1 in t1 <- P1),T= ",T,"\nx1= ",x1," t= ",t," P1= ",P1);
  if(t1==t && s.instance(x,x1))
  {
   Q = s.rep(P1, "tt::chinthms_1");
   if(inlot(Q))
   {
    ipp("chinthms:rimp: Success! x in t == Q in thms, x= ", x, " t= ", t, " Q= ", Q); 
    r = true; goto ret;
   } // if(inlot(Q))
  } // if(t1==t && ... )
 } // for(i)
 ret: if(mm) ipp("-tt::chinthms x= ", x, " t= ", t, " r= ", r); 
      return r;         
} // end bool tt::chinthms;

// end tran
