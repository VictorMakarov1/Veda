// 11/11/99 12/09/99 12/16/99 03/28/00 5/13/00 5/27/00 7/12/00
#include "lib.h"  // 11/29/00 12/00/04 12/20/00 02/22/01 03/09/01 01/01/16
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h" 
#include "typ.h" 
#include "elem.h"
#include "lot.h"
// #include "ismd.h"
#include "term.h"
#include "cr.h"
#include "myio.h"
#include "err.h"
#include "etc.h"
#include "assert.h"

extern int hhh, kk, mm, rrr, yy, zz, iwst1,  prcause;
extern elemp wst1;
extern elem opb,yfn,zpostfix;
extern tt* pttmod1;
int isynv;
int depth_hgt = 0;
int rhgt = 0;    // r for hgt;

elem clond(elem d);

 inline bool older(elem y, elem z){ return y.m == z.m && y.ad > z.ad; }
 inline bool abtbvarM(elem V, elem V1, elem M, elem T) // M is a model of T; V1 is a T-abtbvar, V must be equal to M[V1.i];
   { elem d; if(9) ippelm("+abtbvarM V= ", V, " V1= ", V1); return abtbvar(V1,&d) && d==T && req(V, valm(M,V1.i)); } 
 
 bool dcld(headp h, elem* ad)     // not used ???
{
 bool r; elem a = h->son[0]; 
 r = (Dcl(a) && h->l == 4 && mel(h->son[2])==abt);   // dcl[id, A:set, fn(A,A)] : dcl[id,fn(A:set, fn(A,A))];
 if(r && ad) *ad = h->son[2]; 
 return r;
} // end bool dcld

 bool dterm(headp h, elem* ad)
{	 
 bool p, r = false; headp g; elemp w; elem a = h->son[0], a1 = h->son[1], d = zel;  att m, hl = h->l;
 // if(a == elm(0,1,64) && a1.ad==6885)
                   // if(hl < 3 || prognum >= numrnam && hl != 3)
 //  mm=mm;                                // error("dterm: h->l != 3, f= ", a, "\na1= ", a1, " hl= ", hl);
 if(rrr) ipp("+dterm:h a= ", a, " a1= ", a1);
 p = (bdname(a) || a==zdcol || a==zdconj ||  a==yfn || a==zfn) && hl==3;   // ??? fn(d,B) ???
 if(!p) goto ret1; 
 m = mel(a1,&g, &w);
 if(m==abt || m==pfs && w[0]==zdconj ){ r = true; d = a1; goto ret1; }
 if(m==pfs && a==zdcol && hl==3 && w[0]==zdot) d = a1;  // for use in seard(rnam) // && mel(w[1])==abt
 ret1: if(ad) *ad = d; 
 if(rrr) ipp(" -dterm:h d= ", d, " p= ", p, " r= ", r);
 return r;
} // end dterm(h) ;

 bool dterm(elem z, elem* ad, headp* ah)  // ??? wrong check: h->l !=3: see dterm(h);
{
 bool r = false; headp h; elem d1;
 if(mm && kk) ipp("+dterm z= ", z);
 if(mel(z,&h)!=pfs || h->l != 3) goto ret;
 r = dterm(h, &d1);
 if(r){ if(ad) *ad = d1; if(ah) *ah = h; }
 ret: if(mm && kk) ipp("-dterm z= ", z, " r= ", r);
 return r; 
} // end dterm(z)

bool dterm2(elem z, elem* ad, headp* ah)  // because dterm(h) is incorrect for R[d,f]
{
 bool r = false; headp h; elemp q; elem a;
 if(mm) ipp("+dterm2 z= ", z);
 if(mel(z,&h,&q)!=pfs || h->l != 3) goto ret;
 a = q[0];
 r = (bdname(a) || a==zdcol || a==zdconj || a==yfn || a==zfn) && h->l == 3;   // ??? fn(d,B) ???
 if(r){ if(ad) *ad = q[1]; if(ah) *ah = h; }
 ret: if(mm) ipp("-dterm2 z= ", z, " r= ", r);
 return r; 
} // end dterm2(z)


//  elem scopeterm(elem z)                         // not used
//  {
//   elem d, r=zel; 
//   if(allex1(z) && z != zexistx || Abt(z)) r = z;               // ???  
//   else if(dterm(z,&d)) r = d;
//   return r;
//  } // elem scopeterm(elem z)

  int hgt(elem z)
{
 int r=1,i,k; headp h; elemp q; int static depth=0;  ++depth;
 if(mm && kk) ipp("+hgt z= ", z); 
 int m = mel(z,&h,&q); int hl;
 if(simple(m) || q[0]==zanyd) goto ret;
 hl = h->l;
 // if(q[0]==zdot){ assert(hl==3); k = hgt(q[1]); if(k > r) r = k; goto ret; } 
 for(i=beg(m,h); i<hl; i++)
 {
  k = hgt(q[i]);
  if(k>r) r = k;
 } // for(i)
 ++r;
 ret: if(mm && (kk || depth==1)) ipp("+-hgt z= ", z, "\nr= ", r);    --depth;
 return r;
} // end ats hgt(elem z)

/*
 int hgt1(elem z);

   int hgt(elem z) // only for use in smp!!! 9/18/97
{
 int r; 
 depth_hgt = 0; rhgt = 0;
 try { r = hgt1(z); }
 catch(...)
 {
	 ipp("hgt: exception: z= ", z, " maxdepth= ", maxdepth);
	 return maxdepth;
 }
 return r;
} // end hgt
 
    int hgt1(elem z) // only for use in smp!!!
{
 if(pp) ipp("hgt1 z= ", z); 
 int i,m,x=0; headp h; elemp q; 
 if(++ depth_hgt >= maxdepth) 
    error(" hgt1 overflow of depth_hgt= ", depth_hgt);
 m = mel(z, &h, &q);
 if(m == con || m == var || m == bvar) goto ret;
 for(i = kmain(h); i<int(h->l); i++,q++)
   if(depth_hgt > rhgt)  rhgt = depth_hgt;
 ret: if(--depth_hgt < 0) error("hgt1: depth_hgt < 0, z= ", z, " depth_hgt = ", depth_hgt);
 return rhgt;
}
*/   
	int cmpl(elem z)  // complexity of z: number of all simple names in z; //  + triple number of Q-names;
{                  // now cmpl(z) = hgt(z)
 int r = hgt(z);                // int k,r, save = ist; k=0;
 if(mm) ipp("+-cmpl z= ", z, " r= ", r);    // , " ist= ", ist);
 //if(ist < -1 || ist >= lst)
 // error("cmpl: overflow of ist, z= ", z, " ist= ", ist);
 // simt(z);
 // for(i=save; i<=ist; i++) if(Qname(st[i])) ++k;
 // r = (ist - save) + k*3; ist = save;
 // if(mm) ipp("-cmpl: z= ", z, " r= ", r);   //, " k= ", k);
 return r;
} // end cmpl

   elem devc(elem x) // definition for a variable(or const) x, see also elem htbv(elem z) and elem nami(elem z, int i)
{
 if(hhh) ipp("+devc x= ", x);
 if(x.i == 0) errorelm("devc: wrong x= ", x);
 elem r = x; 
 r.i = 0;
 if(mel(r) != abt) error("devc: not definition r= ", r);
 if(hhh) ipp("-devc r= ", r);
 return r;
} // end devc   

   int freenames(elem z, elem ar[], int maxsizear, elem ar1[], int* lastar1, elem ar2[], int* lastar2,  // and bounded names
    elem ar3[], int* lastar3, elem ar4[], int* lastar4, sbst* s)
{   // result:  ar: free vars, ar1: others ,ar2: local bvars ar3: nonlocal bvars,  ar4: methods, using iMod from s; 
 int iar = -1, iar1 = -1, iar2 = -1, iar3 = -1, iar4 = -1, savemm=mm; headp h; elemp q; att m;
 elem V; achs f(z);  bool p; // headp h; elemp q;  //,p1=false; // , s=scopeden(z);
 if(mm&&kk) ipp("+freenames z= ", z, " maxsizear= ", maxsizear);  //  " scopeden(z)= ", s,
 while(f.iach >= 0)
 {
  V = f.curvert();
  if(mm && kk) f.prach("freenames");
  if(mm && kk) ipp("freenames:while V= ", V);  // && !f.varin(V) removed from the below line on 5.1.20
  m = mel(V,&h,&q);
  if(m==var) // || boundvar(V) && !f.bvarin(V)) //  && !bvarinstqab(V))
    { wrlist(V,ar,&iar, maxsizear); goto Nxt; }
  // if(freevar(V)) wrlist(V,ar,&iar, maxsizear);  // changed on 4.30.20;
  // if(comp(V) && ar1 != 0){ wrlist(V,ar1,&iar1, maxsizear); goto Nxt; }
  if(m==bvar) // wrlist(V,ar2,&iar2, maxsizear); // if(boundvar(V));
  {
   p = f.bvarin(V);   //  || DinD(htbv(V),s); // p1 = bvarinstqab(V);    // V - a local bvar
   if(mm && kk){ f.prach("after p");  ipp("freenames: after p, z= ", z, " V= ", V, " p= ", p); } // , " p1= ", p1); }
   if(p){ if(ar2 != 0) wrlist(V,ar2,&iar2, maxsizear); }  
   else{ 
   if(ar3 != 0)  wrlist(V,ar3,&iar3, maxsizear); 
   if(ar4 != 0 && s != 0 && s->method(V)) wrlist(V,ar4,&iar4, maxsizear); 
   } // else{
   goto Nxt;
  } // if(boundvar(V)) // below V is composite;
   if(ar4 != 0 && s != 0 && s->method(V)) wrlist(V,ar4,&iar4, maxsizear); 
  /*if(h->adt)
  {
   if(99) ipp("freenames: V is an adt term Q(...) skipping Q, z= ", z, " V= ", V, " f.topach().p= ", f.topach().p);
   f.ach[f.iach].p = 0; goto Nxt;
  } */ // if(h->adt)                            // && !dclname(V) added on 2022.12.27 // removed on 2023.02.01
  if(ar1 != 0) wrlist(V,ar1,&iar1, maxsizear); // goto Nxt; } /*comp(V) && */
  // if(dclname(V) && ar3 != 0) wrlist(V,ar3,&iar3, maxsizear);
  // if(mel(V,&h,&q)==abt && h->name != noname) f.next1(); else f.next(); // || comp(V) && host(V) != zel ???
  Nxt: f.next();    // 7.10.20
 } // end while(f.iach >= 0)
 if(lastar1) *lastar1 = iar1;
 if(lastar2) *lastar2 = iar2;
 if(lastar3) *lastar3 = iar3;  //  ar: free vars, ar1: others ,ar2: local bvars ar3: nonlocal bvars;
 if(lastar4) *lastar4 = iar4;
 if(mm && kk) prlist("-freenames: free vars: ar= ", ar,iar);
 if(mm && ar1 != 0 && kk) prlist("-freenames: others: ar1= ", ar1, iar1);
 if(mm && ar2 != 0 && kk) prlist("-freenames: local bvars ar2= ", ar2, iar2);
 if(mm && ar3 != 0 && kk) prlist("-freenames nonlocal bvars: ar3= ", ar3, iar3);
 if(mm && ar4 != 0 && kk) prlist("-freenames nonlocal bvars: ar4= ", ar4, iar4);
 if(mm) ipp("-freenames z= ", z, " iar= ", iar, " iar1= ", iar1, " iar2= ", iar2, " iar3= ", iar3, " iar4= ", iar4);
 return iar;  // iar: last occupied;
} // end int freenames
 
    bool goodimp(elem z, elem* a, elem* b)   // z is A->A1 & freenames(A1) <: freenames(A);
{
 bool r; elem A=zel, A1=zel; // int i,k,k1; ,L[maxvars],L1[maxvars];
 r = fnt2(z,zimp,&A,&A1);
 /*if(r)
 {
  k = freenames(A,L,maxvars);
  k1 = freenames(A1,L1,maxvars);
  // L1 <: L
  for(i=0; i<=k1; i++)
   if(!inlist(L1[i],L,k)){ r = false; break; } // a1 nin A -> ~(A1 <: A);
 } */ // if(r)
 *a = A; *b = A1;
 return r;
} // end goodimp

    int vrit(elem z)   // variables in term
{
 if(pp) ipp("+vrit z = ", z);
 int i,m,r=1; headp h; elemp q;
 m = mel(z,&h,&q);
 if(m == con) goto ret0;
 if(m == var) goto ret;
 //if(h->v) return 1;    // later! 4/19/97
 for(i=0; i<int(h->l); i++)
  if(vrit(q[i])) { /* h->v =1; */ goto ret; }
 ret0: r = 0;
 ret:  if(pp) ipp("-vrit r = ", r);
      return r;
} // end vrit

    void simt(elem z)         // , int p) // 0:con&var, con: only cons, var: only vars
{                            // used only in names, which is used in intersect, which is not used; 
 if(mm) ipp("+simt z = ", z, " ist= ", ist);
 int i, m, hl; headp h; elemp q;
 m = mel(z, &h, &q); 
 if(simple(m) || m==abt && h->name != noname)       // if(m==con || m==var || m==bvar)
 {
 // if(p == m || p == 0)
 // {
   if(hhh) ipp("simt: writing z= ", z, " ist= ", ist);
   wrst(z);
 // } // if(p)
  goto ret;
 } // if(m)
 if(m==pfs && q[0]==zdot){ simt(q[1]); goto ret; }
 if(comp(m)){ hl = h->l; for(i=beg(m,h); i<hl; i++) simt(q[i]); }
 ret:  if(mm) ipp("-simt ist = ", ist);
} // end simt

    bool interm(elem x, elem z)   // elem x in term (or def) z
{
 bool r = true;  int i, k, m; headp h; elemp q; int static depth=0;
 if(mm && (depth==0 || kk)) ipp("+interm z= ", z, "\nx= ", x);
 if(z == zel)
  error("interm: wrong zel, x= ", x, " z= ", z);
  ++depth;
 if(req(x,z)) goto ret;
 if(htbv(x) == z) goto ret0;        // x is a z-bvar (i.e. x is not z
 m = mel(z, &h, &q);
 if (m==var || m==con || m==bvar) goto ret0;   // simple(m)
 // if(m == abt && varc(x) && devc(x) == z) return 0;     // ??? was pdf
 //??? 11/29/00 ??? x can be complex, contain d-names!!!
 k = smel(q[0])? kmain(h)+1 : 0;                                // was pdef
 for(i=k; i < int(h->l); i++)
 {
  if(interm(x, q[i])) goto ret;
 } // for(i=k; ...)
 ret0: r = false;
 ret: if(mm && (depth==0 || kk)) ipp("-interm z= ", z, "\nx= ", x, " r= ", r); --depth;
 return r;
} // end interm

  bool dinterm(elem d, elem z)  // d in term z:  A[d,P], All(x, A[d,P], A[d1, A[d,P]], ...
{
 bool r=false; headp h; elemp q;
 if(mm) ipp("+dinterm d= ", d, " z= ", z);
 if(mel(z,&h,&q) != pfs || h->l != 3) goto ret;
 if(q[0]==zall) goto ret1;
 if(q[0] != zA) goto ret;
 if(q[1]==d){ r = true; goto ret; }
 ret1: r = dinterm(d, q[2]);
 ret: if(mm) ipp("-dinterm d= ", d, " z= ", z, " r= ", r);
 return r;
} // end bool dinterm

  bool DinD(elem Dx, elem D, int* ds )    // Dx in D: Dx=D or D is Dx && Z or D is D1 && Dx or ...
{                                         // ds:: displacement of Dx in D;
 bool r = false; headp h; elemp q; att m; static int dpth=0; static int dsp=0;
 if(mm) ipp("+DinD Dx= ", Dx, " D= ", D);
 if(dpth==0){ dsp = 0; if(ds) *ds = 0; }
 ++dpth;
 if(Dx==zel || Dx==zel0 || Dx==zel1 || D==zel1) goto ret;
 if(Dx==D) goto ret1;
 m = mel(D,&h,&q);
 if(m==abt){ dsp += kmain(h);  goto ret; }
 if(m != pfs || q[0] != zdconj || h->l != 3){ ipp("DinD: D: not &&: Dx= ", Dx, "\nD= ", D); goto ret; }
 if(Dx==q[1] || ds==0 && Dx==q[2]) goto ret1;   // d && P or d && d1;
 r = DinD(Dx, q[1], ds) || DinD(Dx, q[2], ds);
 ret: if(mm) ipp("-DinD Dx= ", Dx, "\nD= ", D, " r= ", r, " ds= ", ds==0? 999: *ds); 
 --dpth;  return r;
 ret1:  r = true;  if(ds) *ds = dsp; goto ret; 
} // end bool DinD

  bool DinA(elem Dx, elem A)    // Dx in A := All(x, A[d1,A[d2, ... A[dk, a = b] ... ][
{
 bool r = false; headp h; elemp q; elem A1 = A;
 if(mm) ipp("+DinA Dx= ", Dx, " A= ", A);
 while(mel(A1,&h,&q)==pfs && h->l==3)
 {
  if(q[0]==zeq || q[0]==zequ) goto ret;
  if(q[0]==zall || q[0]==zimp){ A1 = q[2]; continue; }
  if(q[0]==zA){ if(DinD(Dx, q[1])){ r = true; goto ret; } else{ A1 = q[2]; continue; } }
  ipp("DinA: not =,==,All,->,A[, Dx= ", Dx, " A= ", A, " A1= ", A1); goto ret;
 } // while(mel(A1, ...)
 ret: if(mm) ipp("-DinA Dx= ", Dx, "\nA= ", A, " r= ", r);
 return r;
} // end bool DinD

  bool Varbvar(elem z, elem d0, elem dpat)        // bvar z is var;
{
 bool r= false; elem dz= htbv(z);
 if(mm) ipp("+Varbvar z= ", z, " d0= ", d0, "\ndpat= ", dpat, " dz= ", dz);
 if(Allbvar(z)){ r = true; goto ret; }
 if(!abtbvar(z)) goto ret;
 if(DinA(dz,d0)){ r = true; goto ret; }
 if(Dterm(d0) && DinD(dz,d0)){ r = true; goto ret; }
 if(Dterm(dpat) && DinD(dz,dpat)) r = true;
 ret: if(mm) ipp("-Varbvar z= ", z, " d0= ", d0, "\ndpat= ", dpat, " r= ", r);
 return r;
} // end bool Varbvar

   bool bvarfree(elem Q, elem z)     // z is free from Q-bvars
{
 bool r = false; int i,k,m; headp h; elemp q;
 if(mm&&sss) ipp("+bvarfree Q= ", Q, "\nz= ", z);
 if(!qabterm(Q)) error("bvarfree: not qabterm Q= ", Q, " z= ", z);
 m = mel(z, &h, &q);
 if(m==var || m==con) goto ret0;        // z is bvarfree from Q
 if(m==bvar){ if(htbv(z) == Q) goto ret; goto ret0; }
 k = m==abt? kmain(h)+1:0;                      
 for(i=k; i < int(h->l); i++)
 {
  if(!bvarfree(Q, q[i])) goto ret;
 }
 ret0: r = true;
 ret: if(mm&&sss) ipp("-bvarfree Q= ", Q, "\nz= ", z, "\nr= ", r);
 return r;
} // end bool bvarfree

   elem trm1(elem f,elem x,elem t)
{
 if(mm) ipp("+trm1 f= ", f, "\nx= ", x, " t= ", t);
 head h; elem a[2]; 
 // h.tel = pfs; h.t = 0; h.postfix = 0; h.adt = 0; h.l = 2; h.ln = maxnstr; h.name = -1;
 inith(&h, pfs, 2, t, maxnstr);
 a[0] = f; a[1] = x;  h.tp = t; 
 elem r = elma(curm, ptt->wtrm(h, a));   //  &a[0]) //was clad[0]->
 if(mm) ipp("-trm1 f= ", f, " x= ", x, " r= ", r);
 return r;
}

   elem trm2(elem f, elem x, elem y, elem t, att n) // ??? scp ???
{
 if(mm) ipp("+trm2 f= ",f, "\nx= ",x,"\ny= ",y, "\nt= ", t, " n= ", n);
 head h; headp g; elemp w; elem a[3]; elem r; int nst=maxnstr, m = curm; // tt* pnt = ptt;
 if(f.ad==stad1 && x.ad==stad2)
 mm=mm;
 if(prognum==numtrm) nst = nstr;
 inith(&h, pfs, 3, zel, nst);          // 3: hl
 a[0] = f; a[1] = x; a[2] = y; h.tp = t;
 if(prognum==numtrm) r = elma(m, ptt->wrtt(pfs, 3, a, n, istscp , false));  // false: nonfixed;
 else r = elma(m, ptt->wtrm(h, &a[0], n, t));
 if(mm){ ipp("-trm2 f= ", f, " r= ", r); if(mel(r,&g,&w) != pfs) error("trm2: r is not pfs-term, r= ", r);
         ipp("-trm2 tp= ", g->tp);  } 
 return r;
}

/*   elem trm2t(elem f, elem x, elem y, elem t)   // not used, 9.14.22
{
 elem r;
 if(mm) ipp("+trm2t: f= ",f, " x= ",x," y= ",y);
 if(istr2c(f,x,y)) r = ztrue; else r = trm2(f,x,y);
 if(mm) ipp("-trm2t f= ",f, " x= ",x," y= ",y, " r= ", r);
 return r;
} */ // elem trm2t

   elem trm3(elem f,elem x,elem y,elem z,elem t)
{
 if(mm&&sss) ipp("+trm3 f= ",f, " x= ",x," y= ",y," z= ",z);
 head h; elem a[4]; elem r;
 // h.tel = pfs; h.t = 0; h.postfix = 0; h.adt = 0; h.l = 4;  h.ln=999; h.tp = t; h.name = -1;
 inith(&h, pfs, 4, zel, maxnstr);
 a[0] = f; a[1] = x; a[2] = y; a[3] = z;
 r = elma(curm,ptt->wtrm(h, &a[0]));
 if(mm&&sss) ipp("-trm3 f= ", f, " r= ", r);
 return r;
} // elem trm3

   elem trmk(int k, elem* ps, int pfsabt)          // k: size of ps;
{
 if(mm) ipp("+trmk ps= ", ps, k);      // {cout<<"\ntrmk:"<< k<<' '; prp(ps[0]); }
 head h; elem r;
 // h.tel = p; h.t=0; h.postfix = 0; h.adt = 0;  h.l=k; h.tp=zel; h.ln=nstr;
 inith(&h, pfsabt, k, zel, nstr);
 r = elma(curm, ptt->wtrm(h,ps));
 if(mm) ipp("-trmk r= ", r);
 return r;
} // end trmk

   elem trmk1(elem v, int k, elem* ps)          // k: size of ps(including unused ps[0]);
{
 elem r; elem ar[maxvars];
 if(mm) ipp("+trmk1 v= ", v, " ps[0] is not used,  ps= ", ps, k-1);      // {cout<<"\ntrmk:"<< k<<' '; prp(ps[0]); }
 ar[0] = v;
 for(int i=1; i<k; i++) ar[i] = ps[i];
 r = trmk(k,ar);
 if(mm) ipp("-trmk1 r= ", r);
 return r;
} // end trmk1

  elem trmh(head h, elemp a)
{
 if(mm) ipp("+trmh a[0]= ", a[0], " a[1]= ", a[1], " a[2]= ", h.l<3? zel999: a[2]);
 // clear h.v, ... ? h->t ? h.lth, ...
 elem r =  abtallex1(a[0])? ptt->wrtt(h,a): elma(curm, ptt->wtrm(h,a));
 if(mm) ipp("-trmh a[0]= ", a[0], " a[1]= ", a[1], " a[2]= ", h.l<3? zel999: a[2], " r= ", r);
 return r;
} // elem trmh

  elem trmseq(int k, elem* q)      // making r = [q[0], q[1], ... , q[k-1] ];
{
 elem r; int i; elem ar[maxvars];
 if(mm) ipp("+trmseq q[0]= ", k>0? q[0]:zel999, " k= ", k);
 if(k+1 >= maxvars) error("trmseq: k+1 >= maxvars, q[0]= ",q[0], "\nq[1]= ", q[1], "\nq[2]= ", q[2], " k= ",k);
 ar[0] = opb;
 for(i=1; i<=k; i++) ar[i] = q[i-1];
 r = trmk(k+1,ar);
 if(mm) ipp("-trmseq r= ", r, " k= ", k);
 return r;
} // end elem trmseq;

  elem reproot(elem z, elem y)
{ 
 elem r=zel; att i; headp h; elemp q;  elem ar[maxvars];
 if(mm) ipp("+reproot z= ", z, " y= ", y);
 if(mel(z,&h,&q) != pfs) error("reproot: wrong (not pfs) z= ", z);
 if(h->l >= maxvars) error("reproot: h->l >= maxvars, z= ", z, " h->l = ", h->l, " maxvars= ", maxvars);
 ar[0] = y;
 for(i=1; i < h->l; i++) ar[i] = q[i];
 r = trmk(h->l, ar);
 if(mm) ipp("-reproot z= ", z, " y= ", y, " r= ", r);
 return r;
} // elem reproot(elem z, elem y)

 elem corr(elem x1, achs* f, achs* f1, sbst* s)       // find r in f that corresponds x1 in f1; else zel;
{
 elem r=zel,r1, d,d1,rd,rd1; int i;  each el; headp h;
 if(mm){ ipp("+corr x1= ", x1); if(s) s->psbs("corr"); }
 if(s)
 {
  r = s->vals(x1);
  if(r != zel)
  { 
   r1 = s->vals(r); 
   if(r1 != zel)
   {
    ipp("corr: r1 != zel, making for isbe r=r1, x1= ", x1, " r= ", r, " r1= ", r1, " s= ", s);
    r = r1;
   } // if(r1 != zel)
  } // if(r != zel)
  if(r != zel) goto ret;   
 } // if(s)

 if(f1->bvarin(x1,&i,&d1))                   // p==true:qabterm(All, ...), p==false: dterm(A[, ...);
 {
  el = f->ach[i]; h = el.h;
  if(!dterm(el.e,&d)) d = el.e;                
  rd = root(d); rd1 = root(d1);              // d1 = htbv(x1); 
  if(!eqex(rd, rd1)) // eqex: return x==y || x==zexist && y==zexistx || x==zexistx && y==zexist;
  { 
   f->prach("f"); f1->prach("f1"); 
   ipp("corr: not congr f,f1, \nd= ",d,"\nd1= ", d1,"\nx1= ",x1);        // was error 2022.11.16
   goto ret;
  } // if(!eqex(rd, rd1))
  if(h==0) error("corr: h=0 in f, x1= ", x1, " d= ", d);
  // if(!p) d = h->son[1];                    // A[d,P], ...
  r = nami(d,x1.i); // goto ret;
 } //  if(f1->bvarin(x1,&i,&p))
 ret: if(mm) ipp("-corr x1= ", x1, " r= ", r);
 return r;
} // end elem corr
                                                                   //eqbvs: used only in sbst::instance and req;
 ats eqbvs(elem V, achs* f, elem V1, achs* f1, sbst* s, att peqt)  // 0: V != V1, 1: OK, 2: unknown; 
{                                                  // 1: V==V1 or V,V1 are congr. bvars
 ats r = 2; int i,k,k1;  elem x,a,a1,b,b1,v1,d; elemp Qx,Qx1; // bool p; // r = 2: unknown; // mm=0;
 // if(V==zel) && V1 == zel) error("eqbvs: V==zel) && V1 == zel, V= ", V, "\nV1= ", V1);
 if(mm&&kk){ ipp("+eqbvs: V= ", V, "\nV1= ", V1, " peqt= ", peqt); if(s) s->psbs("eqbvs"); }
 if(mm&&kk) ippelm("+eqbvs:ippelm: V= ", V, "\nV1= ", V1);
 // p = s->Addsqt(V,f,V1,f1);                       // eqbvs used in Rnam: via req; so s && ...
 if(s && s->Addsqt(V,f,V1,f1)){ r = 1; goto ret; }  // 1.1 Addsqt
 if(eqex(V,V1) || reqdot(V,V1)){ r = 1; goto ret; } // 1.2 eqex(V,V1) || reqdot(V,V1)
 v1 = valrt(V1);                                    // here V != V1;
 if(V==v1) { r = 1; goto ret; }                     // 1.3 valrt
 if((a=pvar(V,&Qx,&k)) != zel) //  && (a1=pvar(V,&Qx1,&k1!=zel) && a==a1 && k==k1)
 {                             // WAS an ERROR when istr2eq was placed in eqbvs: vals did not work; 
  if(mm) ipp("eqbvs: formal term V= ", V, "\nV1= ", V1);
  a1 = pvar(V1,&Qx1,&k1);
  if(a1==zel) goto ret;
  if(k != k1){ if(mm) ipp("eqvbv:pvar(V,V1):k != k1: r = 0,V= ", V, " V1= ", V1) ; r = 0; goto ret; }  //
  if(a != a1){ if(mm) ipp("eqvbv:pvar(V,V1):a != a1: V= ", V, " V1= ", V1) ; if(k) r = 0; goto ret; }
  /*
  if(mm) ipp("eqbvs: both V,V1 are pvars, V= ", V, "\nV1= ", V1, " a= ", a, " a1= ", a1, " k= ", k, " k1= ", k1);
  if(k != k1)
  {
   ipp("eqbvs: both V,V1 are pvars, cause: k != k1, V= ",V, "\nV1= ",V1, " a= ",a, " a1= ", a1, " k= ", k, " k1= ", k1); 
   r = 0; goto ret;
  } // if(k != k1)
  */
  for(i=1; i <= k; i++)
  {
   b = Qx[i]; b1 = Qx1[i];
   if(mm) ipp("eqbvs:for args of formal terms, V= ", V, " b= ", b, " b1= ", b1);
   if(b==b1 || s && s->vals(b) == b1){ /*if(s) s->adds(a1,a);*/ r = 1; goto ret; }  // was s->vals(b1) == b), s->adds(a1,a)
   if(corr(b1,f,f1,s) != b) { r = 0; goto ret; } // 0.1 corr(b1,f,f1,s) != b // else { r = 1; goto ret; }  // ??? 2022.10.31
  } // for(i)
  r = 1; goto ret;                              // 1.4 pvar
 } // if((a=pvar(V,&Qx,&k)!=zel && ...)
 if(dclname(V) && V!=zemp && V!=zfalse && V!=ztrue && dclname(V1))  // was ||, 8.25.20
 { 
  if(mm&&kk) ipp("eqbvs: dclname(V) && dclname(V1), V= ", V, " V1= ", V1); 
  r = 0;  goto ret;                             // 0.2 dclname(V) && dclname(V1), V != V1;
 } // if(dclname(V) && ...)
 if(V.i != V1.i || V.i==0) goto ret;                        // r==2; case1: V1 is var; 
 d = htbv(V);
 if(d==zel){ if(mm) ipp("eqbvs:  (d=htbv(V))=zel, V= ", V, " d= ", d); }
 else if(!f->seekd(d)) goto ret;                            // host of V is not in f; // 2022.11.21;
 x = corr(V1,f,f1,s);                                       // x==zel if V1 is not in f1
 if(x==V){ r = 1; goto ret; }                   // 1.5 corr(V1) = V            
 if(f1->bvarin(V1))
 {
  r=0;                                          // 0.3 local bvars V,V1,must be paired
  if(mm&&kk) 
  { 
   ipp("eqbvs: cause: local bvars V,V1,must be paired, \nV= ", V, " V1= ", V1, " x= ", x); 
   f->prach("f"); f1->prach("f1"); 
  } // if(mm)
 } // if(f1->bvarin(V1))
 ret: if(mm&&kk) ipp("-eqbvs: V= ", V, "\nV1= ", V1, " r= ", r); 
 return r;
} // ats eqbvs

	   bool req(elem z,elem z1, sbst* s0) // , elem* av, elem* av1)      // F; by A=B; G;
{
  bool r = false; elem V=zel,V1=zel,y=zel, y1=zel,t1,t2; headp h,h1; elemp q,q1; 
 int m,m1,k,k1,iq=0,savemm=mm, savekk=kk; ats a; sbst s;  int static dpth=0;
 att zm = z.m, z1m = z1.m;
 ++dpth; if(s0) kk=1;
 if(mm && kk) 
  ipp("\n+req z= ", z, "\nz1= ", z1); if(s0) s0->psbs("+req:s0");
 if(mm && kk) ippelm("+req z= ", z, " z1= ", z1);  
 if(wrongm(zm) || wrongm(z1m) || emptpl(z) || emptpl(z1) )
 {
  r = (z==z1);
  if(mm && kk) ippelm("req: possible error: strange z or z1, z= ", z, " z1= ", z1); goto ret; 
 } // if(wrongm(zm) ...)     //   elem Abt1(elem d)     // if(d is {x; x in t} return t else zel;
 if(eqex(z, z1)) { r = true; goto ret; }   // if(z==z1 || z==zexist && z1==zexistx ...)
 // V = Abt1(z); if(V != zel && V==z1){ r = true; goto ret; }  // {x; x in t} = t;
 // V1 = Abt1(z1); if(V1 != zel && V1==z){ r = true; goto ret; }
 m = mel(z,&h,&q); m1 = mel(z1,&h1,&q1);   
 if(m==pfs && m==m1 && h->l != h1->l)
 {                                                                 // ??? no checking adt ???
  r = reqdot(z,z1);
  goto ret;                                          // r == false ( h->l != h1->l );
 } // if(m==m1 && h->l != h1->l)
 if(m == m1 && (m == pfs || m == abt)) 
 {
  achs f(z); achs f1(z1); 
  while(f.iach >= 0 && f1.iach >= 0)
  {
   V = f.curvert(); V1 = f1.curvert(); ++iq;
   if(mm && kk) ipp("req:while: V= ", V, "\nV1= ", V1, " iq= ", iq);
   a = eqbvs(V, &f, V1, &f1, s0);
   if(a == 1){ f.next1(); f1.next1(); continue; } // goto Nxt1;  // ? named V or V1 ?
   if(a == 0){ if(mm && kk) ipp("req: cause: eqbvs = 0, V= ", V, "\nV1= ", V1,  " s= ", &s);  goto ret; }
   m = mel(V,&h,&q); m1 = mel(V1,&h1,&q1); // mel,comp, ==, ... use valn, adl: not ? or a default param in mel, ...
   if(mm && kk) ipp("req:while: m= ", m, " m1= ", m1, " var= ", var);
   if(m != m1)
   {
    if(m==abt)
    { if(Abt2(V, &t1, &t2) && m1==pfs && q1[0]==zdp && h1->l==3 && t1==q1[1] && t2==q1[2]) goto Nxt1; goto Er1; } 
    if(m1==abt)
    { if(Abt2(V1, &t1, &t2) && m==pfs && q[0]==zdp && h->l==3 && t1==q[1] && t2==q[2]) goto Nxt1; goto Er1; } 
    Er1: if(mm) ipp("req: cause: m != m1: V= ", V, "\nV1= ", V1,  " s= ", &s); goto ret;
   } // if(m != m1)
   if(m==con || m==var)
   {
	   if(mm) ipp("req: cause: m == m1 || m==con || m==var: V= ", V, "\nV1= ", V1,  " s= ", &s);
    goto ret;
   } // if(m==con || m==var)
   if(m == bvar)          // here m == m1
   {
    assert(V.i); 
    assert(V1.i);
    if(mm && kk) ippelm("req:bvar: V= ", V, " V1= ", V1); 
    y1 = s.vals(V1);
    if(mm && kk) ipp("req:bvar:y= s.vals(V1), V= ",V, " V1= ", V1, " y1= ", y1);
    if(y1==V) goto Nxt;
    if(s0)
    { 
     y = s0->vals(V);  // y1 = s0->vals(V1);  // ??? explain, why V, not V1;
     if(99) ipp("req:s0:y=s0->vals(V1), V= ", V, "\nV1= ", V1, "\ny= ", y, " s0= ", s0);
     if(y==V1){ if(99) ipp("req:s0:y=V1!, V= ", V, "\nV1= ", V1); goto Nxt; }  // if(y1==V)
    } // if(s0)
   	if(mm) ipp("req: cause: bvar: V= ", V, "\nV1= ", V1, " y1= ", y1, " s= ", &s);
   	goto ret;
   } // if(m == bvar), below V,V1 are composite
   if(h->l != h1->l)
   {
	   r = reqdot(V,V1);
    if(!r && mm) ipp("req: cause: h->l != h1->l: V= ", V, "\nV1= ", V1, " s= ", &s);
   	goto ret;
   } // if(h->l != h1->l)
   k = kmain(h); k1 = kmain(h1);
   if(k!=k1)                           //  || q[0] != q1[0])
   {
    // if(mm && kk) ipp("req: k!=k1 || q[0] != q1[0], q[0]= ", q[0], " q1[0]= ", q1[0], " k= ", k, " k1= ",k1);
    // if(mm && kk) s.psbs("req: k!=k1 || q[0] != q1[0]");
    // if(k==k1 && (mel(q[0])==bvar) goto Nxt;
    // if(use_equal && equal(q[0],q1[0])){ f.next1(); f1.next1(); continue; }
    if(mm && kk){ ipp("req: cause: k!=k1: V= ", V, "\nV1= ", V1, " k= ", k, " k1= ", k1); s.psbs("k!=k1"); }
    goto ret; 
   } // if(k!=k1)
   // for(i=1; i <= k; i++)                  // if(k==0) goto Nxt; (for skipped);
   // {
   //  y = V; y.i = i; y1 = V1; y1.i = i;    // vname !!!
   // s.adds(y1,y); 
   // } // for(i)
   Nxt: f.next(); f1.next();   goto Endwhile;            // default: true: skipbv
   Nxt1: f.next1(); f1.next1();
   Endwhile: ; } // end while
  r = (f.iach == f1.iach);
 } // if(m == m1)
 ret: --dpth;  
 if(mm&&kk) ipp("-req z= ", z, " z1= ", z1, "\nr= ", r);  mm=savemm; kk=savekk;
 return r;
} // end req

   bool reqdot(elem z, elem z1)           // Q.M == Q(M) or Q(M)==Q.M;
{
 elem Q,M,M1; bool r, p1, p2 = false;
 if(mm && kk) ipp("+reqdot z= ", z, " z1= ", z1);
 p1 = fnt2(z,zdot,&Q,&M) && fnt1(z1,Q,&M1) && req(M,M1);          // z: Q.M, z1: Q(M1), req(M,M1);
 if(!p1) p2 = fnt2(z1,zdot,&Q,&M1) && fnt1(z,Q,&M) && req(M,M1);  // z1: Q.M1, z: Q(M), req(M,M1);
 r = p1 || p2;
 if(mm && kk) ipp("-reqdot z= ", z, " z1= ", z1, " r= ", r, " p1= ", p1, " p2= ", p2); // r = true
 return r;
} // bool reqdot(elem z, elem z1)

	   bool bad1(elem z,elem z1)      // to avoid recursion: g(x) -> g(g(x)); 
{                                                    // r == -1 means z == z1 
 elem V,V1,y,y1; headp h,g; elemp q,w; int i,m,m1,k,k1; sbst s;
 if(hhh) ipp("+bad1 z= ", z, "\nz1= ", z1); bool r = false;  // r is iKL;
 if(z==z1) goto ret;  
 m = mel(z); m1 = mel(z1);
 // if(m==bvar || m1==bvar) 
 //  error("req: bvar in the beginning z= ", z, " z1= ", z1);
 if(m == m1 && (m == pfs || m == abt)) 
 {
  achs f(z); achs f1(z1); 
  while(f.iach >= 0 && f1.iach >= 0)
  {
   V = f.curvert(); V1 = f1.curvert();  // valdexc(
   if(hhh) ipp("bad1: while: V= ", V, "\nV1= ", V1);
   if(V == V1 || V==zexist && V1==zexistx) goto Nxt;  // ? named V or V1 ?
   m = mel(V,&h,&q); m1 = mel(V1,&g,&w); // mel,comp, ==, ... use valn, adl: not ? or a default param in mel, ...
   if(m==m1 && m==pfs && g->l == 2 && q[0]==w[0] && V==w[1])  // V is g(x), V1 is g(g(x));
   {
    ipp("bad1: found bad pair: V= ", V, " V1= ", V1, "\nz= ", z, " z1= ", z1);
    r = true; goto ret;   // ??? add additional checks: right brothers of V and V1 must be equal
   } // if(m==m1 && m==pfs && g->l == 2 ... )
   if(m != m1 || m==con || m==var) goto Nxt;
   if(m == bvar)          // here m == m1
   {
    assert(V.i); 
    assert(V1.i);
    if(hhh) ippelm("bad1: bvar: V= ", V, "V1= ", V1); 
    y = s.vals(V1);
    if(hhh) ipp("bad1: bvar: V= ",V, " V1= ", V1, " y= ", y);
    if(y == V) goto Nxt; goto ret;
   } // end if(m == bvar), below V,V1 are composite
   if(h->l != g->l) goto ret;
   k = kmain(h); k1 = kmain(g);
   if(k != k1 || q[0] != w[0]) goto ret; 
   for(i=1; i <= k; i++)                  // if(k==0) goto Nxt; (for skipped);
   {
    y = V; y.i = i; y1 = V1; y1.i = i;    // vname !!!
    s.adds(y1,y); 
   } // for(i)
   Nxt: f.next(); f1.next();   // default: true: skipbv
  } // end while
  // r = (f.iach == f1.iach);
 } // if(m == m1)  
 ret: if(hhh) ipp("-bad1: z= ", z, "\nz1= ", z1, " r= ", r);
 return r;
} // end dif


/*   int aseq(elem z1, elem z2)
{
 if(mm && kk) ipp("+aseq: z1= ", z1, " z2= ", z2); // , " iwst1= ", iwst1);
 int i, r = 0;
 Asst y1(z1);
 Asst y2(z2);
 if(y1.ilist == y2.ilist && y1.ilist > -1)
 {
  r = 1;
  for(i = 0; i <= y1.ilist; i++) 
   if(y1.list[i] != y2.list[i] ) { r = 0; break; }
 } //if(y1.ilist ...)
 if(mm && kk) ipp("-aseq: z1= ", z1, " z2= ", z2, " r= ", r);
 return r;
} // end aseq
*/

   bool seqv(elem z, int* ak, elemp* aq, headp* ah)  // see isseq // q points to opb;
{
 headp h; elemp q; bool r = false;
 // if(mm) ipp("+seqv: z= ", z, " opb= ", opb);  // ??? ippelm ??? recursion in prpt;
 if(mel(z, &h, &q) != pfs) goto ret;
 if(q[0] != opb) goto ret;
 if(ak) *ak = h->l - 1;
 if(ah) *ah = h;
 if(aq) *aq = q;
 r = true;
 ret: // if(mm) ipp("-seqv: r= ", r);
     return r;
} // end bool seqv

   bool tupl(elem z, int* ak, elemp* aq, headp* ah)  // see isseq
{
 headp h; elemp q; bool r = false;
 if(mm) ipp("+tupl: z= ", z);  // ??? ippelm ???
 if(mel(z, &h, &q) != pfs) goto ret;
 if(q[0] != zopsqbr) goto ret;    // [ : elm(247,91,0), make as { (dcl[[, ... ] ???
 if(ak) *ak = h->l - 1;
 if(ah) *ah = h;
 if(aq) *aq = ++q;  // q[0] == zopsqbr)
 r = true;
 ret: if(mm) ipp("-tupl: r= ", r);
     return r;
} // end bool tupl

 /*  Asst::Asst(elem z)
{
 headp h; elemp q;
 if(mm && kk) ipp("+Asst: z= ", z);
 ilist = -1; f = zel;       // 0 in istr means " no calls of inlot in istr!
 if(mel(z, &h, &q) == pfs && istr(trm1(zAssoc, q[0], zbool))) // istr1
 {
  f = q[0];
  assl(z);
 } // if(mel...)
 if(mm && kk) ipp("-Asst: z= ", z, " f= ", f, " ilist= ", ilist);
} // end  Asst::Asst

   void Asst::assl(elem z)
{
 headp h; elemp q;
 if(mm && kk) ipp("+assl z= ", z, " f= ", f, " ilist= ", ilist);
 if(smel(z, &h, &q))
 {
  if(++ilist > llist) error("assl: overflow of ilist = ", ilist, " llist= ", llist);
  list[ilist] = z;
 }
 else 
 if(q[0] == f && h->tel == pfs)
 {
  assl(q[1]);
  assl(q[2]);
 }   
 if(mm && kk) ipp("-assl z= ", z, " f= ", f, " ilist= ", ilist);
} // end assl
*/

   int isrt(elem z, elem r, elemp* w, headp* g )
{      // r is root of z
 if(mm && kk) ipp("+isrt z,r=", z, r); 
 headp h=0; elemp q=0;
 int m = mel(z,&h,&q);
 if(m != pfs) return 0; 
 if(w) *w = q;
 if(g) *g = h;
 if(q[0] != r) return 0;
 return h->l;
}  // end isrt

  bool isispr(elem z)     // z is is(J) or Proof(T; ...) or EqProof(T: ...); ??? name(z)==T ???
{
 headp h; elemp q;
 bool r = mel(z,&h,&q)==pfs && (q[0]==zis || q[0]==zbyeq || q[0]==zby || q[0]==zProof || q[0]==zEqProof);
 return r;
} // bool isispr(elem z)

  bool isproof(elem z, elem* goal) // z is Proof(goal; ...) or EqProof(goal; ...);
{
 headp h; elemp q; 
 bool r = (mel(z,&h,&q)==pfs && (q[0]==zProof || q[0]==zEqProof));
 if(r && goal) *goal = q[1];
 return r;
}  // end bool isproof

   int isrtv(elem z, elem r)  // return var(r) || isrt(z, r);
{
 headp g; elemp w; int m;
 m = mel(z, &g, &w);
 return m == var || m == pfs && w[0] == r;
} // isrtv
   
   elem vard(elem d, int k) // see nami
{
 int l = ldev(d);
 if(l == 0) error("vard: not definition d= ", d);
 if( k < 1 || k > l) error("vard: wrong k, d= ", d, " k= ", k);
 elem z = d;
 z.i = k; // z.vc = 1;
 return z;
} // end vard
 
   int subt(elem z, bool vars )  // subterms of z in st  // vars means: including var and cons
{                    // result: beginning of subterms in st
 if(mm && kk) ipp("+subt z=", z, " vars= ", vars);
 headp h; elemp q; int i,hl; bool p; int static depth; int static save;
 if(ist < -1 || ist >= lst) error("+subt overflow of  ist= ", ist);
 if(depth == 0) save = ist+1;
 if(++depth >= maxdepth) error("subt: big term z= ", z);
 for(i = save; i <= ist; i++)
  if(st[i] == z) goto ret;
 p = smel(z, &h, &q);
// if(/*isdf(z) && */ strlen(NameT(z)) )
 {
   if(pp) ipp("subt: no subterms for named definition or term= ", z);
   goto ret;
 }  
 if(!p || vars) wrst(z); // vars means: including var and cons
 if(p) goto ret; 
 hl = h->l;
 for(i=0; i<hl; i++) subt(q[i], vars);
 ret: if(--depth < 0) error("subt: depth<0, z= ", z); 
      if(ist < -1 || ist >= lst) error("-subt overflow of  ist= ", ist);
      if(mm && kk) ipp("-subt z= ", z, " save= ", save);
      return save;
} // end subt

/*   void freet(elem z, elem ar[], int* lastar) // elem ars[], ats* lasts) // free composite subterms in art,simple in arv;
{                                            // size ar is lsteq
 headp h; elemp q; int i,m,hl; // elem x; //  bool r=true;
 static int dpth=0, iar;  // static ats iS = -1; static elem S[maxvars];
 if(9 && dpth==0) ipp("+freet z= ", z, " dpth= ", dpth);
 ++dpth; //  && depth==0
 if(z==opb) goto ret;
 if(dpth == 1) iar = -1; 
 m = mel(z,&h,&q);
 if(m==var || constm(z.m)) goto ret; // free vars, int, char, string constants skipped;
 if(dpth > 1) wrlist(z,ar,&iar,lsteq);     // the theorem itself will be not written;
 if(m==con || m==abt || m==pfs && qbdname(q[0]) || abtbvar(z))  goto ret;  // cons???,external Qterms are free subterms;
 if(m==bvar && root(htbv(z))==zexistx) goto ret;  
 if(m != pfs) error("freet: wrong m, z= ",z, " m= ", m); 
 hl = h->l;   // here z is composite;
 for(i = 0; i<hl; i++) freet(q[i], ar, lastar);  // r was true, see above;
 ret: if(--dpth < 0) error("freet: --dpth < 0, z= ", z, " dpth= ", dpth);
      *lastar = iar;
      if(9 && dpth==0) ippq1("-freet z, z= ", z, " ar= ", ar, iar+1); //  && depth==0
} // end bool freet(elem z, ... )
*/

 void freet(elem z, elem ar[], int* lastar) // elem ars[], ats* lasts) // free subterms are in ar; 7.20.20
{                                            // maximal size ar is lsteq  // lsteq = 256;
 headp h,g; elemp q,w; int i,j,m,m1,hl=0; elem d; //  bool r=true;
 static int dpth= -1, iar, iNF;  static elem A[maxvars]; static elem NF[maxvars]; //A: active terms; NF: not free terms;
 if(z.ad==stad2)
  mm=mm;
 if(mm && dpth == -1) ipp("+freet z= ", z, " dpth= ", dpth);   // && dpth == -1
 if(++dpth >= maxvars) error("freet: overwlow of A, z= ", z, " dpth= ", dpth);
 A[dpth] = z;
 if(dpth == 0){ iar = -1; iNF = -1; }
 if(z==opb) goto ret;
 m = mel(z,&h,&q);
 if(mm && kk) ipp("freet: m=mel(z,...), z= ", z, " m= ", m);
 if(comp(m)) hl = h->l;                                  //  bool constm(att m){ return m==ints || m==strng || m==chara; }

 if(m==var || constm(z.m)) goto ret;                     // free vars, int???, char?, string? constants skipped;
 if(m==con) goto Write_free_term; 
 if(m==bvar)
 {          // bool dterm1(elem z, elem d){headp h; elemp q; return z==d || mel(z,&h,&q)==pfs && bdname(q[0]) && q[1]==d; } 
  d = htbv(z);
  for(i=dpth; i>=0; i--)                                 // looking for z in A;  // B = A,E,F, ...
  if(dterm1(A[i],d)) goto Found;  // write A-terms into NF;         // d can be All(x,P(x)), Exist(x,...),... or B[d,P];
  if(mm && kk) ipp("freet: not found z in A, z= ", z, "\nA= ", A, dpth);  // Not found z in A;
  if((m1=mel(d,&g,&w))==abt || m1==pfs && w[0]==zexistx) goto Write_free_term;  // abtbvar can be separated; in this case it considered as a constant;
  if(mm) ipp("freet: separated qbvar, z= ", z, " d= ", d, "\nA= ", A, dpth); goto ret; // qbvars cannot be sepatated (All,Exist, Exist1
  Found: if(mm && kk) ipp("freet: Found z in A, z= ", z, " i= ", i,"\nA= ", A, dpth);
  for(j=dpth; j > i; j--) wrlist(z,NF,&iNF,maxvars);       // writing not free terms to NF;
         goto ret;
 } // if(m==bvar)
 if(m!=pfs && m!=abt) error("freet: wrong m, z= ", z, " m= ", m);
 if(h->name != noname && dpth > 0) goto Write_free_term;   // named terms are always free terms ???
 if(mm && kk) ipp("freet: going into depth, z= ", z);
 for(i=beg(m,h); i < hl; i++)   // inline int beg(int m, headp h){ int r=0; r = kmain(h)+1; return r; } 
  freet(q[i],ar,lastar);
  if(inlist(z,NF,iNF)) goto ret;                                 // not free terms skipped;
 Write_free_term: if(dpth>0){ if(mm && kk) ipp("freet: writing to ar,z= ", z); wrlist(z,ar,&iar,lsteq); }                      // #define lsteq 256 
  ret: if(--dpth < -1) error("freet: --dpth < 0, z= ", z, " dpth= ", dpth);
       if(dpth == -1) *lastar = iar;
      if(mm && dpth == -1 && kk) ipp("-freet z= ", z, " ar= ", ar, iar);  // && dpth == -1
} // end bool freet(elem z, ... )

   att inteq(elem z, elem a, elem b)    // intersection all free terms in z with equation a=b: r=1: a in z, 2:b in z, 0:else
{
 att r = 0; elem ar[maxvars]; int lastar;
 if(mm) ipp("+inteq z= ", z, " a= ", a, " b= ", b);
 freet(z,ar,&lastar); 
 if(inlist(a,ar,lastar)) r = 1;
 else if(inlist(b,ar,lastar)) r = 2; 
 if(mm) ipp("-inteq z= ", z, " ar = ", ar, lastar);
  return r;
}  // end  att inteq(elem z, ...)

   int fsynv(elem z, elem ar[maxsynv])  // find synt vars of z => ar
{ 
 headp h; elemp q;
 if(mm&&sss) ipp("+fsynv z= ", z); 
 int m = mel(z, &h, &q);
 if(m==pfs || m==abt) for(int i=kmain(h); i < int(h->l); i++) fsynv(q[i], ar);
 else // simple z
 {
  if(syntvar(z))
  {
   if(++isynv >= maxsynv) error("fsynv: too many synt vars in z= ", z, " isynv= ", isynv);
   ar[isynv] = z;
  } // if(syntvar(z))
 } // else simple z
 if(mm&&sss) ipp("-fsynv z= ", z, " isynv= ", isynv);
 return isynv;
} // int fsynv

   void names(elem z, elem a[], int la)  // names of z -> a
{                                        // used only in intersect, but intersect is not used;
 if(pp) ipp("+names z= ", z, " ist= ", ist);
 error("names: not used");
 int i, j, ia = -1, save = ist; elem y;
 if(ist < -1 || ist >= lst)
  error("+names overflow of ist, z= ", z, " ist= ", ist);
 simt(z);
 if(pp) ipp("names (after simt)  ist= ", ist);
 for(i = save+1; i <= ist; i++)
 {
  y = st[i];
  if(int(y.m) == ints /* || y.m == cn*/)  continue;
  // if(int(y.m) == snampl && mel(y) == con) continue;
  for(j=0; j <= ia; j++) 
   if(y == a[j]) goto M;
  if(++ia + 1 >= la) error("names: overflow ia= ", ia);
  a[ia] = y; 
  if(pp) ipp("names: adding y= ", y, " ia= ", ia);
  //ipp("names: ist = ", ist);
  M: ;
 } // for(i)
 a[++ia] = zel;
 assert(ia < la);
 ist = save;
 if(ist < -1 || ist >= lst)
  error("-names overflow of ist, z= ", z, " ist= ", ist);
 if(pp) ipp("-names z= ", z, " ist= ", ist);
} // end names

   int intersect(elem z, elemp q) // one of names of z in q 
{
 if(pp) ipp("+intersect z= ", z, " q[0]= ", q[0]);
 elem nms[lnms]; int i, j, r=0; 
 names(z, nms, lnms);
 for(i=0; nms[i] != zel; i++, assert(i < lnms) )
  for(j=0; q[j] != zel; j++, assert(j < lnms) )
   if(nms[i] == q[j]) { r = 1; goto ret; } 
 ret: if(pp) ipp("-intersect z= ", z, " r= ", r);
      return r;
} // end intersect       

   int dinn(elem d, elemp q)      // a d-name is in names q
{
 if(pp) ipp("+dinn d= ", d, "q[0]= ", q[0]);
 int i, r=0;
 for(i=0; q[i] != zel; i++, assert(i < lnms) )
  error("dinn: commented devc");
  // if(varc(q[i]) && devc(q[i]) == d) { r = 1; goto ret; }
 if(pp) ipp("-dinn d= ", d, " r= ", r);
 return r;
} // end dinn

/*   int TrueFormula(elem p)  // p.t = truth 
{
 if(pp) ipp("+TrueFormula p= ", p);
 int r; headp h;
 r = (p == ztrue || mel(p, &h) == pfs && Truth(h));  // (h->t == truth));  ;
 if(pp) ipp("-TrueFormula r= ", r);
 return r;
} // end TrueFormula

 elem nega(elem z)
{
 if(mm)ipp("+nega z= ", z);
 if(typ(z) != zbool) error("nega: wrong type z= ", z);
 elem r = z;
 if(r == zfalse) { r = ztrue; goto ret; }
 if(r == ztrue)  { r = zfalse; goto ret; }
 r = trm1(znot, z, zbool); 
 ret: if(mm) ipp("-nega z= ", z, " r= ", r);
 return r;
}  // end nega

   elem parent(int i)  // 1: parent, 2: grandparent, ...
{
 if() ipp("+parent i = ", i, " ptt->iach= ", ptt->iach);
 ptt->prch();
 elem r;
 int k = ptt->iach - i; 
 if(k < 0) 
 {
  ipp("parent: wrong i= ", i, " iach= ", ptt->iach);
  r = zel;
 }
 else r = (ptt->ach)[k].e;
 if() ippelm("-parent r= ", r, r);
 return r;
} */ // parent  

   int vart(elem md, elem d) // md is a variable or a composite term
{
 if(pp) ipp("+vart: md= ", md, " d= ", d);
 int k = ldev(d);
 if(k <= 0) error("vart: wrong d= ", d);
 int r = (k != 1 && !seqv(md));
 if(pp) ipp("-vart r= ", r);
 return r;
} // end vart

   int LocTerm(elem z)   // Local term - contains invisible variables in term
{
 /*if(pp) ipp("+LocTerm z = ", z);
 int i, m, r=0; headp h; elemp q;
 if(smel(z, &h, &q, "LocTerm"))
  { if(varc(z) && froot(q) == 0) r = 1; }  // invisible == non root
 else // z is composite
 for(i=0; i<int(h->l); i++)
  if(LocTerm(q[i])) { r = 1; break; } // end for(i), else
 if(pp) ipp("-LocTerm r = ", r);
 return r; */
 error("LocTerm z= ", z);
 return 0;
} // end LocTerm

/*   bool qterm(headp h) // Quantification term: All(x,P), Exist(x.P), Exist1(x,P)
{
 assert(h->l == 3);
 elem z = h->son[0];
 return z == zall || z == zexist || z == zexist1;
}  // end bool qterm

   int bsons(headp h)             // beginning of sons 
{
 int r;
 if((int(h->tel) != abt)) return 0;
 r = h->son[0].i;              // h->son[0].i contains the number of variables;
 assert(r < int(h->l));
 return r;
} // end  int bsons(headp h)

   bool cmpr(elem F, elem T, elem A, elem B)  // compare F and T by modulo A=B
{  // not used, see: isbe                    // used in handling "F; is Sbe(F,T,A,B);"
 int b,b1; elemp q; elemp q1; headp h; headp h1; bool r=false; // and in "F; by A=B; T;"
 if(mm&&sss) ipp("+cmpr F= ", F, " T= ", T, "A= ", A);
 if(F==T || F==A && T==B || F==B && T==A){ r = true;  goto ret;} // (1)
 if(!smel(F,&h,&q) && !smel(T,&h1,&q1))
 {
  if(h->tel != h1->tel || h->l != h1->l) goto ret;
  b = bsons(h); b1 = bsons(h1);
  if(b != b1) goto ret;
  for(int i=b; i < int(h->l); i++)
   if(!cmpr(q[i],q1[i],A,B)) goto ret;
  r = true;  goto ret;;
 } // end if(!smel)
 ret: if(mm&&sss) ipp("-cmpr B= ", B, " r= ", r);
 return r;     // if F is simple, then F must be A and T=B (or F=B and T=A); 
} // end bool cmpr // if F=A and T=B then from negation(1) & T ~= B); contradiction
*/

  bool dname(elem x, elem d, int* ai)  // x == d ++ i, mel(d) == abt
{
 bool r;
 if(mel(d) != abt) return false;
 if(x.i == 0) return false;
 *ai = x.i; x.i = 0;
 r = (x == d);
 return r;
} // end bool dname

  elem root(elem z, headp* ah, elemp* aq)  // if z is composite f(...), {...} then f, else z
{
 elem r=z; headp h; elemp q;
 int m = mel(z, &h, &q);
 if(comp(m))
 {
  r = q[0];
  if(ah) *ah = h;
  if(aq) *aq = q;
 } // if(comp(m))
 else{ if(ah) *ah = 0; if(aq) *aq = 0; }
 return r;
} // root

   elem  Axabt(elem d, headp g, elemp w)  // Full (conjunction of all axioms) Axiom of d; 
{
 att i,k = kmain(g), gl = g->l; elem y, r = ztrue;
 if(mm) ipp("+Axabt d= ", d, " k= ", k, " gl= ", gl);
 for(i=k+1; i<gl; i++)
 {
  y = w[i];
  if(typ(y) == zbool && (i==gl-1 || w[i+1] != zNotAxiom))
  {
   if(i==k+1) r = y; 
   else r = trm2(zconj,r,y,zbool);
  } // if(typ(w[i]) ... )
 } // for(i=k+1)
 if(mm) ipp("-Axabt d= ", d, " r= ", r);
 return r;
} // end Axabt;

   elem AllExAE(elem z, headp h, elemp q) // z=A[{x;P}, Q] => All(x, P->Q); c='A' or c='E';
{
 elem P,Q,Q1,y,f,f1,r,d = q[1]; headp g; elemp w; ats i,k; att n; att ar[maxvars]; sbst s;
 if(mm) ipp("+AllExAE z= ", z);                          //  was ipp; 2023.03.11, was error; 2023.03.27
 assert(h->tel==pfs && h->l==3 && (q[0]==zA || q[0]==zE));
 if(mel(d,&g,&w) != abt) error("AllExAE: not abt term, z= ", z);
 k = kmain(g);
 P = Axabt(d,g,w);
 if(mm) ipp("AllExAE:P: z= ", z, "\nP= ", P);
 if(q[0]==zA){ f = zall; f1 = zimp; } else{ f = zexist; f1 = zconj; }
 Q = trm2(f1,P,q[2],zbool);
 if(mm) ipp("AllExAE:Q: z= ", z, "\nQ= ", Q);
 if(k >= maxvars1) error("AllExAE: too big k, z= ", z, " k= ", k, " maxvars1= ", maxvars1);
 for(i=1; i<=k; i++)   // ar[0] not used;
 {
  n = ptt->newtt("AllExAE");     // n= 29527
  filltabt(n);  // ptt->tabt[n] = ptt->tabt[0];   // to avoid errors in printing;
  ar[i] = n; 
  s.adds(d+i, elm(curm,1,n));
 } // for(i)
 Q1 = s.rep(Q, "AllExAE_1");
 if(mm) ippelm("AllExAE:Q1= ", Q1);
 for(i=k; i>0; i--)
 {
  // if(Q1.ad == ar[i]) error("AllExAE: Q1.ad == ar[i], z= ", z, "\nQ1= ", Q1, "\nar[i]= ", ar[i]);
  y = trm2(f,w[i],Q1,zbool,ar[i]);
  if(mm) ipp("AllExAE:y: z= ", z, " y= ", y, " i= ", i, " ar[i]= ", ar[i]);
  Q1 = y;
 } // for(i=k)
 r = y;
 if(mm) ipp("-AllExAE z= ", z, " r= ", r);
 return r;
} // end elem AllExAE

   bool vterm(headp h, elemp Q, elemp M)   //valued term Q(M) or Q.M: has value field
{ 
  elemp q = &(h->son[0]); int p = (h->tel==pfs && q[0]==zdot);  bool r = p>0 || h->adt;  // , savemm=mm
 if(mm&&kk) ipp("+vterm: Q= ", q[p], " M= ", q[p+1], " int(Q)= ", int(Q), " int(M)= ", int(M), " r= ", r);
 if(r){if(Q) *Q = q[p]; if(M) *M = q[p+1];  }
 if(mm&&kk) ipp("-vterm: Q= ", Q==0? zel999: r?*Q:zel999, " M= ", M==0? zel999: r?*M:zel999, " r= ", r); // mm = savemm;
 return r;
} // end bool vterm(headp h,...)

  bool vterm(elem z, elemp Q, elemp M)   //valued term Q(M) or Q.M: has value field
{
 bool r = false; headp h; 
 if(mm&&kk) ipp("+vterm: z= ", z);
 if(comp(z)){ mel(z,&h); r = vterm(h,Q,M); }
 if(mm&&kk) ipp("-vterm: z= ", z, " r= ", r);
 return r;  
} // end bool vterm(elem z, ...)
            
  void recdef(elemp q, int i, att hl1) // q[i-1] = dcl[f,fn(d,B)], q[i] = recdef; d1 = remd(d,m); m: # of nat in d; 
{   // q[i+1] = !! Axf0 := A[d1, f(x,0) = b(x)]; q[i+2] = !! Axpw1 := A[d, f(x,n+1) = F(f(x,n), x)];
    // q[i+3] = ! Lpw0 := A[d1, b(x) in B] or b in B; q[i+4]! Lpw1 := A[d, f(x,n) in B -> f(x,n+1) in B];
 if(i <= 0 || i > hl1-4) error("recdef: wrong i= ", i, " hl1= ", hl1);
 elem af,B,d,dA,d2,f,fx0,fxn1,bx,n,n1,x1m=q[i-1], x1=q[i+1], x2=q[i+2], x3=q[i+3], z1,z2; // , x4=q[i+4],fxn,y1,y2;
 int kd,kdA,hdl; headp g,hd,hdA; elemp w,qd,qdA;
 if(9) ipp("+recdef, q[i-1]= ", x1m, " i= ", i, " hl1= ", hl1);
  
 // 1. checking x1m is dcl[f,fn(d,elg)];
 if(x1m==zpostfix) x1m = q[i-2];            // n! 
 if(!fnt22r(x1m,zdclb,zfn,&af,&d,&B)) error("recdef: x1m is not dcl[f,fn(d,B)], x1m= ", x1m);
 f = nami(x1m,1);                           // f from dcl;
 if(mel(d,&hd,&qd) != abt) error("recdef: d is not abt, x1m= ", x1m, " d= ", d);
 // m = findnat(d,&hd);                   // m : the number of first nat-bvar in d; 0: if no nat-bvars;
 // if(m==0) error("recdef: wrong d in x1m: no nat-bvar, x1m= ", x1m, " d= ", d);  
 kd = kmain(hd); hdl = hd->l;
 if(hdl != kd*2 + 1) error("recdef: not normal abt term d= ", d, " kd= ", kd, " hdl= ", hdl); // abt+names+type axioms;
 if(typabtvar(d,hd,qd,kd) != znat) error("recdef: the last bvar in d is not nat_bvar, x1m= ", x1m, " d= ", d);
 // m = kd; 
 // d1 = remd(d,kd);                       // d1 = x:elg; 
 if(9) ipp("recdef: finished part 1, d= ", d, " f= ", f, " kd= ", kd);
 
 // 2. checking x1=q[i+1] is !!Axf0 := A[d1, f(x,0) = b(x)]; or !!f(0) = b;
 if(mel(x1,&g,&w) != pfs || g->l != 3 || !Truth(g)) error("recdef: x1=q[i+1] is not an axiom, x1= ", x1);
 if(w[0]==zA)
 { 
  dA = w[1];
  if(mel(dA, &hdA,&qdA) != abt || (kdA = kmain(hdA)) != kd-1) 
     error("recdef: wrong dA in x1: is not abt or wrong kd, x1= ", x1, "\ndA= ", dA, " kd= ", kd);
  if(!prefd(dA,hdA,qdA,d,hd,qd)) 
      error("recdef: dA is not a prefix of d in x1= ", x1, " dA= ",dA, "\nd= ", d, " kdA= ", kdA, " kd= ",kd);
  if(int(hdA->l) != kdA*2 + 1) error("recdef: not normal abt term dA= ",dA, " kdA= ", kd, " hdA->ll= ", hdA->l);  
  if(fnt2(w[2],zeq,&fx0,&bx)) goto M; 
  error("recdef: wrong A-axiom x1= ", x1);
 } // if(w[0]==zA)
 if(w[0]!=zeq) error("recdef:not zA and  not equality  in x1= ", x1); 
 fx0 = w[1]; bx = w[2];   
 M: if(!chterm(fx0,dA,kd-1,f,zel0)) 
      error("recdef: wrong term fx0= ", fx0, " f= ", f, " d= ", d, " bx= ", bx);
 if(9) ipp("recdef: finished part 2, dA= ", dA, " d= ", d, " fx0= ", fx0, " bx= ", bx);
  
 // 3. checking x2=q[i+2] is !! Axpw1 := A[dpw, fxn1: pw(x,n+1) = fxn2: pw(x,n) * x];
 n = nami(d,kd);                                                            // nat-bvar
 n1 = trm2(zplint,n,zel1,znat);
 if(mel(x2,&g,&w) != pfs || g->l != 3 || w[0] != zA || !Truth(g))
                 error("recdef: x2=q[i+2] is not an A-axiom, x2= ", x2);
 if((d2=w[1]) != d) error("recdef: d2 != d in x2= ", x2, "\nd2= ", d2, " d= ", d);
 if(!fnt2(w[2],zeq,&fxn1,&z2)) 
   error("recdef: not equality in w[2]: x2= ", x2, "\nw[2]= ", w[2], " fxn1= ", fxn1, " z2= ", z2 );
 if(!chterm(fxn1,d,kd-1,f,n1)) 
       error("recdef: wrong term fxn1= ", fxn1, " f= ", f, " d= ", d, " bx= ", bx);
 // check z2: each occ-nce of f must be f(X,n)!!!!!!!!!!!!!do it!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 if(!chfint(z2,f,d,kd-1,n)) error("recdef: no subterm f(x,n) in z2= ", z2, " f= ", f, " d= ", d, " n= ", n, " kd= ", kd);  
 if(9) ipp("recdef: finished part 3, x2= ", x2, " d2= ", d2, " d= ", d, " fxn1= ", fxn1, " z2= ", z2);
 
 // 4. checking x3=q[i+3] is ! Lpw0 := e in elg; (b(x) is free from x)   //  common case: A[x:elg, b(x) in elg];
 if(mel(x3,&g,&w) != pfs || g->l != 3 || g->t != ctruth)
     error("recdef: wrong(not pfs or g->l != 3 or g->t != ctruth) x3=q[i+3], x3= ", x3);
 if(w[0]==zA)
 {
  dA = w[1];
  if(mel(dA, &hdA,&qdA) != abt || (kdA = kmain(hdA)) != kd-1) 
     error("recdef: wrong dA in x3: is not abt or wrong kd, x3= ", x3, "\ndA= ", dA, " kd= ", kd);
  if(!prefd(dA,hdA,qdA,d,hd,qd)) 
      error("recdef: dA is not a prefix of d in x3= ", x3 ," dA= ",dA, "\nd= ", d, " kdA= ", kdA, " kd= ",kd);
  if(int(hdA->l) != kdA*2 + 1) error("recdef: not normal abt term dA= ",dA, " kdA= ", kd, " hdA->ll= ", hdA->l);  
  if(fnt2(w[2],zin,&z1,&z2)) goto M1; 
  error("recdef: wrong(not in) A-axiom x3= ", x3);
 } // if(w[0]==zA)
 if(w[0]!=zin)  error("recdef:not zA and  not in-formula  in x3= ", x3);
 {
  z1 = w[1]; z2 = w[2];   
  M1: if(z1 != bx || z2 != B) 
   error("recdef: wrong term 'z1 in z2': z1 != bx or z2 != B in x3= ",x3, " z1= ",z1," z2= ",z2 , " bx= ", bx," B= ", B);
  if(9) ipp("recdef: finished part 4, x3= ", x3, " z1= ", z1, " z2= ", z2 , " bx= ", bx, " B= ", B);
 } // if(fnt2(x1,zeq,&f0))

 // 5. checking x4=q[i+4] is ! Lpw1 := A[dpw, pw(x,n) in elg -> pw(x,n+1) in elg]; // not needed;
 /*if(mel(x4,&g,&w) != pfs || g->l != 3 || w[0] != zA || g->t != ctruth)
     error("recdef: wrong(not pfs or g->l != 3 or not zA or g->t != ctruth) x4=q[i+4], x4= ", x4);
 if(w[1] != d) error("recdef: wrong d in x4= ", x4);
 if(!fnt2(w[2],zimp, &z1, &z2)) error("recdef: not implication in x4= ", x4);
 if(!fnt2(z1,zin, &fxn,&y2)) error("recdef: not in-formula in z1 in implication in x4= ", x4, " z1= ", z1);
 if(!chterm(fxn,d,kd-1,f,n)) error("recdef:  wrong term fxn in x4= ", x4, " fxn= ", fxn);
 if(y2 != B) error("recdef:  wrong term y2(not B) in x4= ", x4, " y2= ", y2, " B= ", B);
 if(!fnt2(z2,zin, &y1,&y2)) error("recdef: not in-formula in z2 in implication in x4= ", x4, " z2= ", z2);
 if(y1 != fxn1)
   error("recdef: wrong(not fxn1) y1 in in-formula in z2  in x4= ", x4, "\nz2= ", z2, "\ny1= ", y1, "\nfxn1= ", fxn1);
 if(y2 != B) error("recdef:  wrong term y2(not B) in in z2 in x4= ", x4, "\nz2= ", z2, "\ny2= ", y2, "\nB= ", B);
 if(9) ipp("recdef: finished part 5, x4= ", x4, " fxn= ", fxn, "\nfxn1= ", fxn1 , " bx= ", bx, " B= ", B);
 */
} // end void recdef

   int findnat(elem d, headp* ah)   // find first nat-bvar in d;
{
 int r,i,k; headp h; elemp q;
 if(9) ipp("+findnat d= ", d);
 if(mel(d,ah,&q) != abt) error("findnat: not abt, d= ", d);
 h = *ah; k = kmain(h);
 for(i=1; i<=k; i++) if(typabtvar(d,h,q,i)==znat){ r = i; goto ret; }
 r = 0;
 ret: if(9) ipp("-findnat d= ", d, " r= ", r);
      return r;
} // end int findnat(elem d)

  bool chterm(elem z,elem d, int kd, elem f, elem b) // z is f(d_1, ..., d_k,b)
{
 bool r;  int i; headp h; elemp q; elem x;
 if(9) ipp("+chterm z= ", z, " d= ", d, " f= ", f, " b= ", b, " kd= ", kd);
 r = (mel(z,&h,&q)==pfs && q[0]==f);
 if(r==false) goto ret;
 for(i=1; i<=kd; i++)
 {
  x = nami(d,i); 
  if(q[i] != x)
  {
   ipp("chterm: cause: q[i] != x= ", x, " q[i]= ", q[i], " b= ", b, " i= ", i);
   r = false; goto ret;
  } // if(q[i] != x)
 } //  if(r) for(i=1)
 if(q[kd+1] != b) error("chterm: cause: last arg in z is not b, z= ", z, " b= ", b, " kd= ", kd);
 ret: if(9) ipp("-chterm z= ", z, " r= ", r);
      return r;
} // end bool chterm

   bool prefd(elem d1, headp h1, elemp q1,elem d, headp h, elemp q)   // d1 is a proper prefix of d;
{
 bool r=false; elem t,t1; int i, kd1 = kmain(h1), kd = kmain(h);
 if(kd1 >= kd){ipp("prefd: cause: kd1 >= kd, d1= ", d1, "\nd= ", d, " kd1= ", kd1, " kd= ", kd); goto ret; }
 for(i=1; i<=kd1; i++) 
 {
  if(q1[i] != q[i]){ ipp("recdef: cause q1[i] != q[i]), d1= ", d1, "\nd= ", d, " i= ", i); }
  t1=typabtvar(nami(d1,i),h1,q1,i); 
  t=typabtvar(nami(d,i),h,q,i);
  if(t != t1){ ipp("recdef: different types d1= ", d1, " t1= ", t1, "\nd= ", d, " t= ", t, " i= ", i); goto ret; } 
 } // for(i) 
 r = true;
 ret: return r;
} // end bool prefd

  bool chfint(elem z, elem f, elem d, int kd1, elem n)  // subterm f(X,n) is in z2;
{
 bool r = false; headp h; elemp q; int i, m, hl; static int count = 0;
 if(9) ipp("+chfint z= ", z, " count= ", count);
 if(simple(m = mel(z,&h,&q))) goto ret;
 hl = h->l;  
 if(m==pfs && q[0]==f && chterm(z, d, kd1, f, n)){ r = true; ++ count; goto ret; }
 for(i = kmain(h)+1; i < hl; i++)
 { 
  r = chfint(q[i], f, d, kd1, n);
  // if(r==true) ++ count;     // already was ++ count in chfint(q[i], ... )
 } // for(i)
 r = count > 0;
 ret: if(9) ipp("-chfint z= ", z, " count= ", count, " r= ", r);
 return r;
} // end bool chfint

 bool fanyd(elem V1, elemp d)  // checking that V1 = f(^d), typ(f) = fn(d,B);
{
 bool r; headp h; elemp q; elem B,d1,d2,t;
 if(mm) ipp("+fanyd V1= ", V1);
 r = mel(V1,&h,&q)==pfs && h->l==2 && fnt1(q[1],zanyd,&d1) && fnt2(t = typ(q[0]),zfn,&d2,&B) && d1==d2; 
 if(mm) ipp("-fanyd V1= ", V1, " r= ", r);
 return r;
} // end bool fanyd(elem V1, elemp d)

  bool checkterm(elem z) // checks term after rep2i,now checks only for strange bvars, not related to z;
{                                    
 bool r=true; headp h; ats a; achs f(z) ; int static count = 0;
 ++count; if(ww) ipp("+checkterm z= ", z, "\ncount= ", count);  
 if(count==stad2)
 mm=mm;  
 while(f.iach >= 0)
 {
  elem V = f.curvert(); 
  if(V.ad==stad1) ipp("checkterm:13525: z= ", z, "\nV= ", V); 
  if(!boundvar(V,&a,&h) || h->tel==abt && h->name != noname) goto Nxt; // z is not a bvar or htbv(z) is a named abt term; 
  if(f.bvarin1(V)) goto Nxt;
  if(ww) f.prach("checkterm");
  if(ww) ipp("checkterm: a strange bvar(not in ach) V in z= ", z, "\nV= ", V);
  r = false;    // goto ret;  // return false;
  Nxt: f.next(); 
 } // end while
 // r = true;
 if(ww) ipp("-checkterm \nz= ", z, "\nr= ", r); 
      return r;
} // end bool checkterm(elem z);

  elem strip(elem z, elem f)   // strip(f(f(x)), f) = x;
{
 elem r = z;
 while(fnt1(r, f, &r));
 return r;
} // end elem strip

   bool ground(elem z)        // z is a ground term (not containing free vars);
{ 
 bool r = true; headp h; elemp q; int i,m;
 if(mm) ipp("+ground z= ", z); 
 m = mel(z, &h, &q);
 if(comp(m)) 
  for(i=beg(m,h); i < int(h->l); i++)
  {
   r = ground(q[i]);
   if(r==false) goto ret;
  } // for(i=beg(m,h)...);
 else if(m==var) r = false;   // simple z
 ret: if(mm) ipp("-ground z= ", z, " r= ", r);  
     return r;
} // end bool ground(elem z)  

 elem typeth(elem z, elem* at)   // type theorem for a named term z: Lnamez_type := z in t;
{
 elem r = zel, T,x,t; int a,k; tt* pnt; char* s; char ar[maxvars];   // #define maxvars 100
 if(mm) ipp("+typeth z= ", z); 
 if(simple(z)) error("typeth: simple(z), z= ", z);
 s = strnamet(z);
 if(strcmp(s,"***")==0) goto ret;    // no name for z;
 strcpy(ar,"L"); strcat(ar,s); strcat(ar,"_type");
 a = findts(ar);
 if(a==emptyts) goto ret;            // no type theorem with name Lnamez_type;
 pnt = clad[z.m];  assert(pnt != 0);
 k = pnt->firstad(a);
 if(k == -1){ ipp("typth name of z in ts, but not in den, z= ", z, " s= ", s, " a= ", a); goto ret; }
 T = pnt->den[k]->inn;
 if(!fnt2(T,zin,&x,&t) || x != z){ ipp("typeth: wrong T, z= ", z, " T= ", T); goto ret; }
 r = T;  *at = t;
 ret: if(mm) ipp("-typeth z= ", z);
 return r;
} // end elem typeth(elem z, elem* at)

/*  bool bad1(elem y, elem z)  // dif(y,z) = ( g(x), g(g(x)) );
{
 elem K[maxvars], L[maxvars];
 if(mm) ipp("+bad1: y= ", y, " z= ", z);
 int k = dif(y,z,K,L);
 bool r = (k==0 && iter(K[0], L[0]));
 if(mm) ipp("+-bad1: y= ", y, "\nz= ", z, " r= ", r);
 return r;
} // end  bool bad1

  bool iter(elem y, elem z)  // y is g(x), z is g(g(x));
{
 elem t; int m1, m2; bool r; headp h,g; elemp q,w;
 // if(older(y,z)){ t = y; y = z; z = t; }
 m1 = mel(y,&h,&q); m2 = mel(z,&g,&w);
 r = (m1==m2 && m1==pfs && g->l == 2 && q[0]==w[0] && y==w[1]);
 if(mm) ipp("+-iter: y= ", y, "\nz= ", z, " r= ", r);
 return r;
} // end  bool iter
*/

// end Term.cpp
