// 11/11/99 // 8/22/00 10/17/00 11/01/00 12/25/00 01/08/00 02/07/01
#include "lib.h"   // 5/27/01
#include "typ.h" 
#include "sbs.h"
#include "tt.h"
#include "adl.h"  
#include "elem.h"
#include "df.h"
#include "cr.h"
// #include "ismd.h"
#include "clos.h"
#include "truf.h"    
#include "term.h"
#include "err.h"
#include "assert.h"
#include "topt.h"

extern int hhh, mm,  prcause, progress;
extern elem ymaid;

   elemd::elemd(elem z) : elemh(z)      // new ldev
{
 if(pp) { *pfhis<<"\n+elemd z= "; pelm(z, pfhis); }
 int j; elemp w;
 elemh::elemh(z);                    // calculated h,q
 thisd = z;
 isdef = 0; 
 km = 0; kax = 0; kaxth = 0; // ss = 0;
 if(nohq || h->tel != pdf)
 {
  //if(hhh) ipp("-elemd kt=0, z= ", z);
  return; // not def
 }
 if(thisd.i == 0) isdef = 1; else  thisd.i = 0;
 elemdef* qdef = (elemdef*) q;
 km   = qdef->km;
 kaxth  = h->l - 1 - km - km;   // number of axioms&theorems
 if(kaxth < 0) error("elemd: kaxth= ", kaxth);
 modn = qdef->modn;
 dv   = qdef->fdv;
 dcl  = qdef->fdcl;
 pmodn = clad[thisd.m];

 pn = q + 1;  // 1 : def;
 pt = pn + km;
 pa = pt + km;
 
 kpar = 0; par[0] = zel; par[1] = zel;
 if(isrt(pa[0], zmaid, &w) || isrt(pa[0], ymaid, &w))
 { 
  kpar = 1; par[0] = w[1];
 }
 // the same for d1 ! d2
 for(j=0; j < kaxth && pa[j] != zel; ++j);
 kax = j;
 for(j=0; j < km; j++)
   if(pn[j].m != cn)error("elemd:not name in definition", z);
 // !!!!!!!!!!!! INSERT: compute par, kpar !!!!!!!!!!!!!!!!
 //if(1) ipp("-elemd thisd = ", thisd, " ks= ", ks);
 if(pp) *pfhis<<"\n-elemd kax="<<kax<<" km= "<<km;
}; // end elemd::elemd

   elem elemd::field(char* s)   // element-field for s
{
	error("elemd::field");
 elem r = thisd; char* s1;
 //if(hhh) ipp("+field: s= ", s);
 //if(hhh) ipp("field: thisd= ", thisd);
 if(km == 0) error("field :not definition thisd= ", thisd);
 for(int i=0; i<km; i++)
 {
  if(pn[i].m != cn) error("nomd: not cn thisd,i=", thisd, i);
  s1 = pmodn->vts(pn[i].ad);
  if(strcmp(s1, s) == 0)
  {
   r.i = i+1; r.namt = 0;
   goto ret;
  } // end if(strcmp
 } // end for i
 r = zel;
 ret: //if(hhh){cpp("-field r= ", r);pelm(r, pfhis); }
 return r;
} // end elemd::field

   elem elemd::namd(char* s)  // element-field or method for s
{
 if(hh) ipp("+elemd::namd, s= ", s);
 error("elemd::namd");
 elem r = field(s); elem a; int i;
 if(r != zel) goto ret;
 /* now search among "axioms"
 for(i=0; i<kam; i++)
 {
  a = pa[i];
  if(a.namt && strcmp(NameT(a), s) == 0){ r = a; goto ret; }
  elemd da(a);
  if(da.km == 0) continue;
  r = da.field(s);
  if(r != zel) goto ret;
 } // end i
 */
 r = zel;
 ret: if(hh) ipp("-namd, r= ", r);
 return r;
} // end namd

   elem elemd::namd(ats a)  // element-field or method for ats a
{
 char* s = ptt->vts(a); 
 return namd(s);
}  
 
/*
   void elemd::sbs(elem z)  // substitution (x1->z1, ...)
{
 //if(1) ipp("+elemd::sbs: thisd= ", thisd, " z= ", z);
 elem x = thisd; headp h; elemp q; int i;
 int k =sizeof(int) + sizeof(elem) * lsbst; 
 ss = (sbst) fylloc(k); ss->i = 0;
 if(kt == 1)
 {
  x.i = 1;
  adds(&ss, x, z);
  goto ret;
 } // kt == 1
 if(adel(z, &h, &q) || h->tel != psq || h->l != km) goto ret;
 for(i=0; i < km; i++)
 {
  x.i = i+1; 
  adds(&ss, x, q[i]);
 }  // end  calculating s, now calculate r = z1 in t1 & ... zk in s(tk)
 ret: chsb(ss);
      if(pp) ipp("-elemd::sbs ss->i= ", ss->i);
} // end 
  
   elem elemd::frm(elem z) // formula "z in t & ax1(z) & ... & axk(z) 
{
 if(1) ipp("+frm thisd= ", thisd, " z= ", z);
 elem a, r, d, t, y; headp h; elemp q; int i;
 sbs(z);     // calculate ss
 if(kt == 1)
 {
  r = trm2(zin, z, pt[0], zbool);
  goto Axioms;
 } // kt == 1
 if(adel(z, &h, &q) || h->tel != psq || h->l != km) 
 {
  r = zfalse;
  goto ret;
 }
 r = trm2(zin, q[0], pt[0], zbool);  // z1 in t1
 for(i=1; i < km; i++)
 {
  t = rep(pt[i], ss);            // t = ss(ti)
  y = trm2(zin, q[i], t, zbool); // y = "zi in s(ti)
  r = trm2(zconj, r, y, zbool);  // r = z1 in t1 & ... & zi in s(ti)
 } // end i, calculating r = z1 in t1 & ... & zk in s(tk)
 Axioms:     // r = r & ss(ax1) & ... & ss(axka)
 for(i=0; i < kax; i++)
 {
  a = pa[i];
  if(typ(a) != zbool) continue;
  y = rep(a, ss); 
  r = trm2(zconj, r, y, zbool);
 } // end i, Axioms
 ret: if(1) ipp("-frm: r= ", r);
      return r;
} // end frm

    char* elemd::strd()  // string for definition (numbers of bool types)
{
 if(hhh) ipp("+strd: thisd= ", thisd);
 int i, k=0; static char s[10]; // 10 - max length of d-rule
 if(km >= 9) error("strd: big rule thisd= ", thisd);
 for(i = 1; i < km; i++)
  if(pt[i] == zbool) s[k++] = '0' + i + 1;
 s[k] = 0; 
 if(hhh) ipp("-strd: s= ", s);
 return s;
} // end strd

   int elemd::IsMethod(elem z) // z is a field or method of thisd
{
 if(hhh) ipp("+IsMethod: thisd= ", thisd, " z= ", z);
 elem x; int i, r=1;
 if(z.i == 0) goto ret0;
 x = z; x.i = 0;
 if(x == thisd) goto ret;
 for(i=0; i < kam; i++) if(pa[i] == x) goto ret;
 ret0: r = 0;
 ret: if(hhh) ipp("-IsMethod: r= ", r);
      return r;
} // end IsMethod      

   void elemd::meit(elem z)   // MEthods (incl. fields) of thisd in z
{
 if(hhh) ipp("+meit: thisd= ", thisd, " z= ", z);
 int i; elem t; headp h; elemp q; elemp w; int static depth;
 if(++depth > maxdepth) error("meit: recursive term z= ", z," depth= ",depth);
 if(smel(z, &h, &q, "simd"))
 {
  if(IsMethod(z)) wrst(z); // repeatitions are possible!!!
  goto ret;
 }
 if(q[0] == zRepeat)
 {
  t = typ(z);
  if(isrt(t, zM, &w) && w[1] == thisd) wrst(z); 
  goto ret;
 }
 if(q[0] == zmdot) { meit(q[1]); goto ret; }
 for(i=0; i<int(h->l); i++) meit(q[i]);
 ret: if(--depth<0) error("meit: depth<0, depth= ", depth);
} // end meit */

   elem elemd::pref(elem z, elem m) // Prefixes methods of thisd in z by m
{
 error("pref: rework!!!");
 return zel;
 /*if(hhh) ipp("+pref z= ", z, " m= ", m);
 if(hh) ipp("+pref thisd= ", thisd);
 elem x,r; int i, save = ist;
 sbst s = nulls("+pref");
 meit(z);                // methods(d) in z
 for(i=save+1; i<=ist; i++)
 {
  x = trm2(zmdot, m, st[i]);
  adds(&s, st[i], x);
 } // end i
 ist = save; z.namt = 0;
 r = rep(z, s, 1);
 if(hhh) ipp("-pref r= ", r);
 syfree(s, "-pref");
 return r; */
}  // end pref


 elem elemd::dcatf(elem x, elem z1) // catenation of thisd and x
{                         // ???simple x???10/3/97
 int i,save;  headp h1; elemp q1; elem z;
 if(9) ipp("+dcatf: x= ", x, " z1= ", z1);
 if(isdef == 0) error("dcatf(!)left part is not a definition thisd=", thisd);
 save = ist; 
 wrst(elmdef(km, dv, modn)); //  top = def-element
 for(i=0; i<km; i++) wrst(pn[i]); 
 for(i=0; i<km; i++) wrst(clon(pt[i]));
 wrst(ptt->trm1e(ymaid, thisd)); // axiom maid(thisd)
 for(i=0; i < kax; i++)
  if(isrt(pa[i], zmaid) || isrt(pa[i], ymaid)) wrst(pa[i]);    // axioms of thisd
  else wrst(clon(pa[i]));
 wrst(clon(x));                               // axxiom x  ???clon(x)???
 z = fseg(ist-save, pdf); ist = save; 
 if(mel(z, &h1, &q1, "dcatf" ) != pdf) error("dcatf: wrong z= ", z);
 if(9) ipp("-dcatf: r= ", z, " z1= ", z1);
 return z;
} //end dcatf

 elem elemd::dcatd(elem x, elem z1) // catenation of thisd and x
{                         // ???simple x???10/3/97
 int i,save;  headp h1; elemp q1; elem z;
 if(mm) ipp("+dcatd: x= ", x);
 if(isdef == 0) error("dcatd(!)left part is not a definition thisd=", thisd);
 elemd d(x);
 if(!d.isdef) error("dcatd: not definition x= ", x);
 if(thisd.m != 0) error("elemd::dcatd: currently m>0 is wrong, thisd= ", thisd);
 save = ist; //h1 = ptt->tabt[thisd.a];
 if(modn != d.modn)error("dcatd: different modn x= ", x);
 wrst(elmdef(km + d.km, dv, modn)); //top = def-element
 for(i=0; i<km; i++) wrst(pn[i]); 
 for(i=0; i<d.km; i++) wrst(d.pn[i]); 
 for(i=0; i<km; i++) wrst(pt[i]);
 for(i=0; i<d.km; i++) wrst(d.pt[i]);
 for(i=0; i < kax; i++) wrst(pa[i]);   // axioms of thisd
 for(i=0; i < d.kax; i++) wrst(d.pa[i]); // axioms of d
 z = fseg(ist-save, pdf); ist = save; 
 if(mel(z, &h1, &q1, "dcatd" ) != pdf) error("dcatd: wrong z= ", z);
 if(mm) ipp("-dcatd: r= ", z);
 return z;
} //end dcatd
 
 elem elemd::clond(headp* h, sbst* s) // cloning of thisd ( * s), h = h(clon) 
{
 error("clond");
 return zel;
}

   int elemd::IstrueAx(elemp q)    // used in typ
{                              // M = q[1], q[2], ...
 if(mm)ipp("+IstrueAx kax= ", kax);
 if(mm && kax) ipp("+IstrueAx q[1]= ", q[1]);
 elem r, y, z; int i, k = 1;
 for(i=0; i < kax; i++)
 {
  y = pa[i];
  if(typ(y) != zbool) continue;  // changed 8/11/97
  //if(9) ipp("IstrueAx: axiom y before rep, \n  y= ", y);
  z = repq(y,  thisd, q); //, FOR_CRED); 
  //if(9) ipp("IstrueAx: checking axiom z= ", z, "\n   y= ", y);
  //if(!istrue(z)) return 0;
  //r = reduce(z);
  //if(9) ipp("IstrueAx: axiom checked z= ", z, " r= ", r);
  //if(r == ztrue) continue; 
  //if(r == zel)
  //{
  // ipp("IstrueAx: Axiom is trivially true, ax= ", z);
  // continue;
  //}
  //ipp("IstrueAx (not true, z= ", z, " r= ", r);
  //k = 0;
  //break;
 } // for(i)
 if(mm) ipp("-IstrueAx r= ", k);  
 return k;
}  // end IstrueAx

   int elemd::Edp(elem edp)    // checking edp is E[d, p] - validation of d1 
{
 if(9) ipp("+Edp edp= ", edp);
 elem p; elemp w; int i, save, r=0;
 if(!isrt(edp, zexist, &w))
  { ipp("Edp: not E[d, p], edp= ", edp); return 0; }
 elemd d1(w[1]); p = w[2];
 sbst s(w[1], thisd);
 if(gg) s.psbs("Edp:s=");
 if(km != d1.km) 
 {
  ipp("Edp: km != d1.km, d1= ", w[1], " km= ", km, " d1.km= ", d1.km); 
  goto ret;
 }
 if(kax -1 != d1.kax) 
 {
  ipp("Edp: kax -1 != d1.kax, d1= ", w[1], " kax= ", kax, " d1.kax= ", d1.kax); 
  goto ret;
 }
 save = prcause; prcause =1;
 for(i=0; i < km; i++)
  if(!req(pt[i], s.rep(d1.pt[i])))  
  {
   ipp("Edp: pt[i] != d1.pt[i], d1= ", w[1], " pt[i]= ", pt[i], " d1.pt[i]= ", d1.pt[i]); 
   goto ret;
  }
 for(i=0; i < kax -1; i++)
  if(!req(pa[i], s.rep(d1.pa[i])))  
  {
   ipp("Edp: pa[i] != d1.pa[i], d1= ", w[1], " pa[i]= ", pa[i], " d1.pa[i]= ", d1.pa[i]); 
   goto ret;
  }
 if(!req(pa[kax-1], s.rep(p)))
 {
  ipp("Edp: pa[kax-1] != p, d1= ", w[1], "\n pa[kax-1]= ", pa[kax-1], "\n p= ", p); 
  goto ret;
 }
 r = istr0(edp);
 if(r == 0) ipp("Edp: not true formula edp= ", edp);
 ret: prcause = save;
      if(9) ipp("-Edp r= ", r);
      return r;
} // elemd::Edp

   void elemd::hax()       // assigning truth to axioms
{
 if(gg) ipp("+hax thisd= ", thisd, " kax= ", kax, " iach= ", ptt->iach);
 for(int j=0; j < kax; j++)
 {               // ??? inconsistent d in d::def[... ??? 12/25/00
  if(ptt->iach == 2 && (ptt->ach[1]).h->son[0] == zdcol) sigt(pa[j]);
  if(ptt->iach == 1) sigt(pa[j]);
  else if(iclad != 0) wlot(pa[j], "hax", thisd, elmint(j) );
 }
//  if(ptt->iach == 1) h -> t = truth; commented on 6.2.19;
 if(gg) ipp("-hax");
} // end hax
  
   elemd:: ~elemd()
{
 //ipp("elemd::~elemd is working thisd= ", thisd);
 //if(ss) myfree(ss);
}

   elem elmdef(int km, int fdv, int modn, int fdcl, int fset)
{
 elem r;
 elemdef* p = (elemdef*) &r;
 p->m    = def;
 p->km   = km;
 p->fdv  = fdv;
 p->modn = modn;
 p->fdcl = fdcl;
 p->fset = fset;
 return r;
} // end elmdef 

  int km(elemp q)
{
 if(q->m != def) error("km: q->m != def, q->m= ", (int)q->m);
 return ((elemdef*)q)->km;
}  // end kt

  int fdv(elemp q)
{
 if(q->m != def) error("fdv: q->m != def, q->m= ", (int)q->m);
 return ((elemdef*)q)->fdv;
}  // end fdv

  int fdcl(elemp q)
{
 if(q->m != def) error("fdcl: q->m != def, q[0].m= ", (int)q[0].m);
 return ((elemdef*)q)->fdcl;
}  // end fdcl

  int fset(elemp q)
{
 if(q->m != def) error("fset: q->m != def, q[0].m= ", (int)q[0].m);
 return ((elemdef*)q)->fset;
}  // end fset

  int froot(elemp q)
{
 if(q->m != def) error("froot: q->m != def, q[0].m= ", (int)q[0].m);
 return ((elemdef*)q)->froot;
}  // end froot


   int ldev(elem d, elemp* pn, elemp* pt, elemp* pa, int* kax) // wrong if
{                                         // kt = 0, rework!
 headp h; elemp q; int j;                       // 11/11/97
 if(adel(d, &h, &q) || h->tel != pdf || d.vc) return 0; 
 if(d.i) error("ldev: wrong d=  ", d);
 int k = km(q);
 if(pn) *pn = q + 1;    // 1 : def-element!
 if(pt) *pt = *pn + k;
 if(pa)
 {
  *pa = q + k + k + 1;    // 1 : def-element!
  for(j=0; j + k + k + 1 < h->l && (*pa)[j] != zel; ++j); 
  if(kax) *kax = j;
 } // if p
 return k;
} // end ldev

   int ldeva(elem d, elemp* pa, int* kax , int* kaxth)
{ 
 headp h; elemp q; int j;
 if(adel(d, &h, &q) || h->tel != pdf || d.vc) return 0; 
 if(d.i) error("ldev: wrong d=  ", d);
 int k = km(q);
 *pa = q + k + k + 1;    // 1 : def-element!
 for(j=0; j + k + k + 1 < h->l && (*pa)[j] != zel; ++j); 
 *kax = j;
 if(kaxth) *kaxth = h->l - k - k - 1; // 1 - for def0!
 return k;
} // end ldeva

 int isdf(elem z, elemp* w) 
{
 headp h; elemp q;
 if(adel(z, &h, &q) || h->tel != pdf || z.vc) return 0;
 if(z.i) error("isdf: wrong z= ", z);
 if(w) *w = q;
 return 1;
} // end isdf

/*  int D_dcl(elem d)
{
 elemp q; elem t;
 if(!isdf(d, &q)) return 0;
 //if(typ(d) != Tdefs) error("D_dcl: wrong type, d= ", d, " type = ", typ(d));
 return fdcl(q) && fdv(q);
} // end D_dcl
*/
    elem clond(elem d)
{
 sbst s;
 return s.repd(d, 1);
} // end clond

    elem clond(elem d, headp* h, sbst* s)
{
 if(hh) ipp("+clond d= ", d);
 int i,t,p=1; elem d1,f,y; elemp q; headp g; elemp w;
 if(adel(d, &g, &w) || g->tel != pdf)
   error("clond: not dv or def d= ", d);
 for(i=0; i<s->size; i += 2)
  if(ElemInTerm(s->body[i], d)) { p = 0; break; }
 if(p) return d; // d does not contain any variable from s
 s->psbs("clond");
 error("clond: rework d= ", d); /*
 d1 = newp(g->l, h, &q);
 f  = w[0]; t = f.d.modn; q[0] = w[0]; q[0].d.modn = 0;
 kt = f.d.kt;
 for(i=1; i <= kt; i++)
 {
  y = w[i]; 
  if(y.m != cn) error("adl/daep not cn! y = ", y);
  y.a = ptt->wr(clad[t]->vts(y.a));
  q[i] = y;
  d.i = i; d1.i = i;
  adds(s, d, d1);
 }
 d1.i = 0;
 if(hhh){ psbs(*s, "clond "); ipp("=s, clond"); }
 for(i=kt+1; i<int(g->l); i++) q[i] = rep(w[i], *s);
 if(hhh) ipp("-clond d1= ", d1);
 */
 return zel;
} // end clond

/*   int dfex(elem d, headp h, elemp q, elem z)
{
 if(1) error("+dfex(rework!(11/23/97)) d,z=", d, z);
 int i,k; headp h1; headp g; elemp w; elemp q1;
 iwst1 = -1;        // was ist = 0
// if(adel(z,&g,&w,"dfex") || g->t != truth|| w[0] != zexist) return 0;
 if(mm && kk) cpp("dfex+ d,z= ", d, z);
 if(adel(w[1], &h1, &q1)) error("dfex: adel d,z=", d, z);
 k = q[0].i;
 if(pp) cpp("dfex k=",k);
 if(q1[0].m != def) error("dfex: q1[0].m=", int(q1[0].m));
 if(k != int(q1[0].i))  return 0;
 if(int(h1->l) != 2*k+1) error("dfex: h1->l=", int(h1->l));
 //for(i=1; i<=k; i++)
 // if(q1[i] != q[i]) return 0;
 if(iwst1<-1 || iwst1 >= lst) error("dfex: wrong iwst1 ",iwst1);
 wst1[++iwst1] = d; wst1[++iwst1] = w[1];
 for(i=k+1; i<=2*k; i++)
  if(!hml(q[i], q1[i], 1))  return 0;
 if(int(h->l) != 2*k + 2) error("dfex temporarily h->l=", int(h->l));
 if(!hml(q[2*k + 1], w[2], 1)) return 0;
 if(pp) cpp("-dfex d,z=", d, z);
 return 1;
} // end dfex

     elem dfax(elem x)   // first axiom  // 7/7/96
{
 if(1) error("dfax rework x= ", x);
 elemp pn; elemp pt; elemp pa; int k, ka, pvc;
 //k = ptt->ldev(x,&pvc, &pn, &pt, &ka, &pa);
 if(k == 0 || pa == 0) error("dfax: no axioms x= ",x);
 return pa[0];
} // end dfax
  
   elem daep(elem dx, elem dy, elem p, elem* p1) // s=yi->yi(x1,...,xm)
{  // def for A[dx,E[dy,p]] =
   // def[yk:fn(dx,rep(t,s));rep(Q,s)|rep(P,s)];
 int i,j,k,m,t,kt; elem f,d,y,z; sbst s = nulls("daep");
 headp h; headp g; headp g1; elemp q; elemp w; elemp w1;
 if(1)error("daep: rework1: make a method in elemd");
 if(ii){prp("\ndaep dx= ",dx);prp(" dy=",dy); cpp(" p=",p); }
 //m = ptt->ldev(dx);    // 9/13/96
 if(mel(dx) != pdf) error("daep: wrong def dx= ", dx);
 if(adel(dy, &g, &w) || g->tel != pdf)
   error("daep: wrong def dy= ", dy);
 d = newp(g->l+1, &h, &q);
 //f  = w[0]; t = f.d.modn; q[0] = w[0]; q[0].d.modn = 0;
 //kt = f.d.kt;
 for(i=1; i <= kt; i++)
 {
  y = w[i]; y.a = ptt->wr(clad[t]->vts(y.a));
  q[i] = y;
  dy.i = i; d.i = i;
  z = newp(m+1, &g1, &w1); // d = new yi
  w1[0] = d;               // z = yi(x1, ... ,xm)
  for(j=1; j<=m; j++)
  {
   dx.i = j; w1[j] = dx;   //  dx = xj
  }
  adds(&s, dy, z);          // s = {yi -> yi(x1,...,xm)}
 }
 d.i = 0; dx.i = 0;
 if(pp){ psbs(s, "daep"); cpp("=s, daep"); }
 k = 2*kt;
 for(i=kt+1; i <= k; i++)
   q[i] = trm2(zfn, dx, rep(w[i], s));
 for(i=k+1; i<int(h->l); i++) q[i] = rep(w[i],s);
 q[g->l] = rep(p, s);  *p1 = q[g->l];
 if(ii) cpp("-daep d= ", d);
   syfree(s,"daep"); return d;
} // end daep 

   elem devc(elem x) // definition for a variable(or const) x
{
 if(hh) ipp("+devc x= ", x);
 if(x.vc == 0 || x.i == 0) errorelm("devc: wrong x= ", x);
 elem r = x; 
 r.vc = 0; r.i = 0;
 if(mel(r) != abt) error("devc: not definition r= ", r);
 if(hh) ipp("-devc r= ", r);
 return r;
} // end devc   

   int numvc(elem x) // number of a variable (or const) x in def
{
 if(pp) ipp("+numvc x= ", x);
 if(x.vc == 0 || x.i == 0) errorelm("numvc: wrong x= ", x);
 return x.i;
} */ // end numvc

   int Consistent(elem d1)  // d1 is a consistent definition
{
 if(mm) ipp("+Consistent d1= ", d1);
 int i, r = 1; elem a, z; elemp w;
 if(!isdf(d1)) error("Consistent: not def ", d1);
 elemd d(d1);
 if(d.h->t != truth) 
 {              
  if(iclad == 0) error("Consistent: iclad=0, d1= ", d1);//goto handleax;
  ipp("Consistent: checking types d1= ", d1);
  for(i=0; i<d.km; i++)
  {
   if(!nonempty(d.pt[i])) 
   {
    ipp("cons: Not nonempty type t= ", d.pt[i]);
    r = 0; goto ret;
   }  
  } // for(i) 
  for(i=0; i<d.kax; i++)
  {
   a = d.pa[i];
   if(typ(a) != zbool) continue;
   if(isrt(a, zall, &w)) a = w[2];
   if(!iseq(a, &w) )
   {
    ipp("Consistent: Wrong axiom form (not eq, equ),a= ", d.pa[i]);
    r = 0; goto ret;
    // check w[1] has the form R(x)
   }
  } // for(i)   
 } // if(h->t != truth);
 handleax: d.hax();
           d.h->t = truth;
 ret: if(mm) ipp("-Consistent r= ", r);
      return r;
} // end Consistent

/* int Relevant(elem d) // d is a root definition or ...
{
 if(pp) ipp("+Relevant d= ", d); 
 elemp q;
 if(!isdf(d, &q)) error("Relevant: not def d= ", d);
 if(froot(q) && Consistent(d)) return 1;
 if(InActiveChainAE(d)) return 1;
 return 0;
} // end Relevant 

 int InActiveChainAE(elem d) // d is in ach or A[d, p] in ach or ...
{
 if(pp) ipp("+InactiveChainAE d= ", d);
 elemp w;
 for(int i = ptt->iach; i>= 0; i--)
 {
  elem z = ptt->ach[i].e;
  if(d == z) return 1;
  if(isrt(z, zall, &w) && w[1] == d) return 1;
  if(isrt(z, zexist, &w) && w[1] == d && Consistent(d)) return 1;
 } // for(i)
 return 0;
} // end InActiveChainAE */

   int fimp(elem z, elem d)  // z is a generic method of d
{
 int r = varc(z) && devc(z) == d || fdent(z, d) || dpar(z, d);
// if(9) ipp("-fimp z= ", z, " d= ", d, " r= ", r);
 return r;
} // end fimp

/*   int varc(elem z)   // z is a var or a con of a definition
{
 int r = z.m <= iclad && z.vc;
 if(pp) ipp("-varc z= ", z, " r= ", r);
 return r;
} */ // end varc

   int dpar(elem z, elem d)  // z has the form "d".g
{
 elemp w;
 int r = isrt(z, zmdot, &w) && w[1].m == strng && strval(w[1]) == NameT(d);
 if(9) ipp("-dpar z= ", z, " d= ", d, " r= ", r);
 return r;
} // end dpar

   int depend(elem z, elem d) // z depends on d
{
 if(pp) error("+depend z= ", z, " d= ", d);  // was ipp
 int r=0, i, ifrn; elemp frn;
 freen(z, &frn, &ifrn);
 for(i=0; i<=ifrn; i++)
  if(Host(frn[i]) == d) { r = 1; break; }
 if(pp) ipp("-depend r= ", r);
 return r;
} // end depend

// end df.cpp

