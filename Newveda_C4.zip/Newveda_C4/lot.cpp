#include "lib.h" 
#include "achs.h"
#include "sbs.h" 
#include "tt.h" 
#include "adl.h"  
#include "typ.h" 
#include "styp.h" 
#include "elem.h"     
#include "eqcl.h"    
#include "cr.h"     
#include "lot.h"
#include "rep.h"
#include "term.h"
#include "prf.h"
#include "err.h"
#include "etc.h"
#include "assert.h"
extern int curtritt,beg_exist,end_exist,proofdepth;
extern elemp lot,dep,dep1,dep2;
extern elem zfinabterm,zcol;
extern bool nowlotinf;     // dont use nowlotinf (curm=0 & REL was not passed);
extern achs* pntu;
// extern ofstream* pfmainhis;
// extern int iard;                                     //  last occupied;
// extern int placeM;
// extern int KM;
// extern elem ard[maxvars];   // d1 && d2 && P              // ard = (d1,d2);
// extern elemp qM;   // current model: z21,z22; 
// extern elemp arM;  // big model: z11, z12, z21,z22; 
// extern int arpM[maxvars];   // places in arM:  -1, 1;     // real place-1;
int wrlot_c = 0;               // wrlot count;
int wlot_not_writing;
bool Taut(elem f);

#define lar 40 
#define maxit 5       // 100 maximum of iterations in simr, move to tran as input;
 struct Cand    // candidate for simplification
{
 elem e;        // the element
 int c;         // the complexity
 bool exp;      // flag: the candidate has been expanded
}; // end cand
Cand cand(elem e, int c, bool exp);   // constructor
Cand ar[lar];
int iar, it, maxdittadd,iD,iDd;        // ,iDD;
elem D[maxsynv];              // (d&&P) && d1 => d,P,d1;  // D contains all d's and P's; maxsynv = 20
elem Dd[maxsynv];             // (d&&P) && d1 => d,d1;    // Dd contains all d's
// elem DD[maxsynv];             // (d&&P) && d1 => d,d1;    // DD contains all D's (every D or d, D is D1 && ...)
int dispDd[maxsynv];          // dispDd[0] = 0, dispDd[i+1] = dispDd[i-1] + kmain(Dd[i-1]); 
// elemp arM;                    // arM = q in ismd;
elem maxdittzadd;
bool fnexp(elem *ay);  // find first unexpanded candidate in ar; true: all expanded;
elem expand(elem z);  // expand z, ;
elem explot(elem z);  // expand z, using lot;
elem wrar(elem x); // insert x into ar before first with larger complexity; true: x is simple;
void prar();       // printing ar

inline bool wlotg(elem z, elem goal){ wlot(z,"wlotg"); return inlot(goal); }   // rework: bool wlot(z,goal); ? raise ?
inline wrD(elem z){ wrlist(z,D,&iD,maxsynv); }
inline wrDd(elem z){ wrlist(z,Dd,&iDd,maxsynv); }
// inline wrDD(elem z){ wrlist(z,DD,&iDD,maxsynv); }

   bool separ(elem z)      // z is separation: begin("text");
{
 headp h; elemp q;
 bool r = mel(z,&h,&q)==pfs && int(h->l)==2 && q[0]==zbegin && q[1].m==strng;
 if(mm && r) ipp("-separ: z= ", z, " r= ", r);
 return r;
} // end separ

   bool ineq(elem z)   //z is x in y or x <: y or x = y or x == y;
{
 headp h; elemp q; bool r;
 if(hhh) ipp("+ineq: z= ", z);
 r = mel(z,&h,&q)==pfs && h->l==3 && q[1]!=q[2] && (q[0]==zin || q[0]==zincl || (q[0]==zeq || q[0]==zequ)); 
 if(hhh) ipp("-ineq: r= ", r);
 return r;
} // end bool ineq(elem z)

  bool In(elem x, elem t)               // checking if x in t;
{
 bool r; elem tx=typ(x); 
 if(mm) ipp("+In x= ", x, " t= ", t, " tx= ", tx);
 r = (tx==t || istr2(zincl,t,tx) || istr2(zin,x,t) ); 
 if(mm) ipp("-In x= ", x, " t= ", t, " r= ", r);
 return r;
}

  bool wrlot(elem z, bool p)             // r==true: already in lot; // p=false: don't check fnt2(z,zconj,&z1,&z2)
{                                        // because wlot will do it;
 bool r = false; int i,c; elem z1,z2;
 ++wrlot_c;                              // wrlot count;
 if(mm) ipp("+wrlot z= ", z, " ilot= ", ilot);
 if(z == zel)  error("wlot: wrong z= ", z);
 if(z.ad==stad2)   // mm && 
  mm=mm;
 c = cmpl(z);
 if(c > maxc){ ippelm("wlot_not_writing: too big z= ", z, " compl= ", c); ++wlot_not_writing; goto ret; }
 for(i= 0; i<=ilot; i++) if(req(lot[i], z)){ r = true; goto ret; }
 if(ilot >= llot) error("wrlot: big ilot,  z= ", z, "\nilot= ", ilot); 
 lot[++ilot] = z;
 if(p && fnt2(z,zconj, &z1, &z2)){ wrlot(z1); wrlot(z2); }
 ret: if(mm) ipp("-wrlot z= ", z, " ilot= ", ilot);
      return r;
} // end wrlot(elem z) 
                                                // WRONG: no istr for g(x,t) !!!  2022.
  void wlotpat1(elem g, elem x, elem t, elem f) // pattern1: g(x,t) & f(t, &t1) -> g(x,t1);
{                                               //  x in t & t <: t1 -> x in t1;  x <: t & t <: t1 -> x <: t1;                                                                                  
  headp h; elemp q; int i; 
  if(mm) ipp("+wlotpat1 g= ", g, " x= ", x, " t= ", t, " f= ", f);  // 99: make mm;
  for(i= 0;i<=ilot; i++)
   if(fnt2h(lot[i], f, &h, &q) && q[1]==t) wrlot(trm2(g, x, q[2], zbool));
  if(mm) ipp("-wlotpat1 g= ", g, " x= ", x, " t= ", t, " f= ", f);
} // end void wlotpat1(zin,x,t,zincl);

   void wlot(elem z, char* place)
{
 elem x,x1,y,A,B,P,t,t1,tz,tt,d,T,z1; headp g; elemp w; int i,m,k; elemp ar; int static count = 0;
 if(z.ad==stad2)
  mm=mm;  
 if(mm) ipp("+wlot z= ", z, " place= ", place, "\nilot= ", ilot, " count= ", count);     bool p;
 if(++count > 20) 
  error("wlot: possible recursion: z=  ", z, " place= ", place, "\nilot= ", ilot);
  // if(count>3) ipp("wlot: count>3, z=  ", z, " place= ", place, "\ncount= ", count);
;
 if(ilot > 60) goto ret;                    // ??? 2022.11.20;  was 50, no warning message; 
 p = fnt2(z,zconj);              
 if(wrlot(z, !p)) goto ret;    // lot[++ilot] = z; // already in lot;
 if(z == zfalse) { ipp("wlot: writing false!"); goto ret; }
 if(fnt12(z,znot,zeq,&A,&B)){ wrlot(trm2(zneq,A,B,zbool)); goto ret; } // 0.1 z := ~(A=B) -> A ~= B;
 // if(z == ztrue) ipp("wlot: z = true");
 if(smel(z,&g,&w)){ if(mm) ipp("wlot: simple z= ", z, " ilot= ", ilot, " count= ", ++count);   goto ret; } // was p
 tz = typ(z);         //  g->tp;   // was typ(z);  4/25/01
 // if(mm) ipp("wlot: z= ", z, " t= ", t);
 if(tz == zel)
 {
  ipp("wlot: no type yet(zel) z= ", z, " tz= ", tz);
  goto ret;                     // z in t & t <: t1 -> z in t1;
 } // if(t == zel)              // typ(t)=P[t1] or typ(t)=P1[t1] -> z in t1;
 if(fnt2(z,zneq, &A, &B) && typ(A)==zabterm && B==zemp)   // z: d ~= {}
 {
  x = trm1(zanyd,A,zany); z1 = trm2(zin,x,A,zbool);        // 0.2  d ~= {} -> anyd(d) in 
  wlot(z1,"wlot: zneq"); goto ret;
 } //  if(fnt2,z,zneq, ...)
 if(fnt2h(z, zconj, &g, &w)){ wlot(w[1], "wlot:&1 "); wlot(w[2], "wlot:&2 "); goto ret; } 
 if(fnt2h(z, zA, &g, &w) && freevar(w[1]) ){ wlot(w[2],"wlot:A");  goto ret; }
 if(fnt2(z, zEx, &d, &x)){ wlot(x,"Ex"); goto ret; }

 if(fnt2(z, zin, &x, &t))  //------------------------1. z: x in t;
 {
  if(mm) ipp("wlot:zin: z= ", z, " x= ", x, " t= ", t);
  // P = defrp(z);            //------------------------1.0  P = defrp(z);
  // if(P != zel) wlot(P, "wlot_P_defrp");
  
  if(fnt1(t,zP,&B))                                 //  1.1.  x in P[B]  (== x <: B)
  {
   wlot(trm2(zincl,x,B,zbool), "wlot:P");   // x in P[B] == x <: B;
   // ar = firsecargthms(zincl,B,1);           // ar: B <: y;
   // for(i=0; (y=ar[i]) != zel; i++)  wrlot(trm2(zincl,x,y,zbool));  //  x <: B & B <: y -> x <: y;
   goto ret; 
  } 
  if(fnt1(t,zP1,&B))                                // 1.2. x in P1[B] == x in P[B] & x ~= {}
  { 
   y = trm1(zP,B,zset);
   wrlot(trm2(zin,x,y,zbool)); // ,"wlot:P1");
   wlot(trm2(zincl,x,B,zbool),"wlot:P1"); 
   wlot(trm2(zneq,x,zemp,zbool),"wlot:P1:neq"); 
   // ar = firsecargthms(zincl,B,1);           // ar: B <: X;
   // for(i=0; (y=ar[i]) != zel; i++)  wrlot(trm2(zincl,x,y,zbool));  //  x <: B & B <: y -> x <: y;  
   goto ret; 
  } // if(fnt1(t,zP1,&B))
  if(fnt1(t, zseq, &B)){ y = trm2(zin,x,zSEQ,zbool); wrlot(y); goto ret; }  // 1.3 x in seq(B) -> x in SEQ;

  if(fnt2(t,zsetdif,&A,&B)){wlot(trm2(zin,x, A,zbool),"wlot:setdif"); goto ret; } // 1.3. x in A--B -> x in A;
  
  if(fnt2(t,zdconj,&B,&P) && typ(P)==zbool)    // 1.4.   x in B && P;
  {
   wrlot(trm2(zin,x,B,zbool));
  if(B==zFN) wrlot(repd(P,B,x));                         // REWORK!!!: not for common case // elem repd(elem z, elem d, elem md;) 
  } // if(fnt2(t,zdconj,&B,&P) ...)
  if(fnt2(t,zseg,&A))                          // 1.5. x in 0..k -> x in nat
  {
   if(typ(A)==znat) wrlot(trm2(zin,x,znat,zbool));
  } // if(fnt2(t,zseg,&A,&B)) 
  tt = typ(t); 
  if(comp(t) && tt==zset){ tt = typthms(t); if(tt==zel) tt=zset; }  // make inline void typt(t,*?tt) ???                 
  m = mel(tt,&g,&w);
  if(m==pfs)                    // t in tt; tt: P[w[1]]; t <: w[1] => x in w
  {
   if(mm) ipp("WLOT: z= ", z, " x= ", x, " t= ", t, " tt= ", tt); // 1.6. x in t & t in P[t1] -> x in t1;
   if(w[0]==zP || w[0]==zP1)
   { 
    wlot(trm2(zin,x,w[1],zbool) ,"WLOT:P:P1");   // was wrlot: 7.30.20
    // if(fntP(w[1],
   // goto ret;
   } // if(w[0]==zP || w[0]==zP1)
  } // if(m==pfs
  if(mm) ipp("wlot: before wlotpat1:replace !!!, z= ", z, " t= ", t); 
  // wlotpat1(zin,x,t,zincl);               // pattern1: g(x,t) & f(t, &t1) -> g(x,t1);
  ar = firsecargthms(zincl,t,1);         // 1.7. z: x in t &  t<: B -> x in B // 1: place of t in t<:B
  for(i=0; (B=ar[i]) != zel; i++)  wrlot(trm2(zin,x,B,zbool)); // wrlot, not wlot to avoid slowness;

  ar = firsecargthms(zeq,t,1);         // 1.8. z: x in t &  t = B -> x in B // 1: place of t in t<:B
  for(i=0; (B=ar[i]) != zel; i++){ wrlot(trm2(zin,x,B,zbool)); goto ret; }; // wrlot, not wlot to avoid slowness;
  // goto ret;
  k = thmbase(t, &ar);                 // 1.9. in wlot: Looking for T: x1 in t == P;
  if(mm) ipp("wlot: case +1.8: z= ", z, " t= ", t, " k= ", k);
  for(i=0; i<k && (T=ar[i]) != zel; i++)
  {
   if(mm) ipp("wlot: case 1.8:for: z= ", z, " t= ", t, " T= ", T);
   if((fnt22l(T,zequ,zin, &x1,&t1,&P) || fnt22l(T,zimp,zin, &x1,&t1,&P)) && t1==t)
   {
    if(x1==x || (mel(x1)==var || Allbvar(x)) && ((t1=tp(x1))==zany || t1==zset || t1==t)) wrlot(rep2(P,x1,x));
   } // if(fnt22...)
  } // for(i=0)
  
  t1 = typtyp(t);
  if(t1 != zel){ P = trm2(zin,x,t1,zbool); wlot(P, "wlot_typtyp"); }

  P = defrp(z);            //------------------------1.10  P = defrp(z);  ??? move out zin ???
  if(P != zel) wlot(P, "wlot_P_defrp");
  goto ret;

 } // if(fnt2(z, zin, &x, &t))

 if(fnt2(z,zincl,&A,&B))          //----------------------------2. z: A <: B;
 {
  y = trm1(zP,B,zset);
  wrlot(trm2(zin,A,y,zbool));     // ,"wlot:P1"); // 2.1 A <: B == A in P[B];
  // wlotpat1(zincl,A,B,zincl);      // 2.2 A<:B & B <: B1 -> A <: B1;            
  ar = firsecargthms(zin,A,2);         // 2: place of A in x in A
  for(i=0; (x=ar[i]) != zel; i++)  wrlot(trm2(zin,x,B,zbool));  // 2.3 z: A<:B & x in A -> x in B;
  ar = firsecargthms(zincl,B,1);           // ar: B <: X;
  for(i=0; (y=ar[i]) != zel; i++)  wrlot(trm2(zincl,A,y,zbool)); // 2.4  z: A<:B & B <:y -> A <: y;
  goto ret;
 } // if(fnt2(z,zincl,&A,&B))
 ar = impequthms(z);            // Look for thms z->P,z==P,P==z and write P into ar;
 if(mm) ipp("wlot:ar0= ", ar[0], "\nar1= ", ar[1], "\nar2= ", ar[2]);
 for(i=0; (B=ar[i]) != zel; i++)
 {
  if(mm) ipp("wlot:+for: ar = impequthms(z),z= ", z,  "\nar[i]= ", B, "\nar[i+1]= ", ar[i+1], "\ni= ", i);
  wrlot(B); // , "B_impequthms");  // was wrlot 6.8.21
  if(mm) ipp("wlot:-for: ar = impequthms(z),z= ", z,  "\nar[i]= ", B, "\nar[i+1]= ", ar[i+1], "\ni= ", i);
 } // for(i=0);
 P = defrp(z);                              // was wrlot
 if(P != zel) wlot(P, "wlot_P_defrp");
 // if(! nowlotinf){ infot(z); inftabt(z); infvith(z); }
 ret: -- count; if(mm) ipp("-wlot z= ", z, "\nilot= ", ilot, " count= ", count); // mm=savemm;
} // end wlot

  void inflot(elem z, int a)   // inference from z + Lot(a); not used, Jan 18, 2019;
 {
  if(mm) ipp("+inflot:  z= ", z, " ilot= ", ilot);
  for(int i=0; i<=a; i++)
  {
   elem y = linf(lot[i], z);    // light infer: all vars in z (and in lot[i]) are cons;
   if(y!=zel) wlot(y,"inflot");          // was wlotinf(y); 12.24.17
  } // for(i,ilot)
  if(mm) ipp("-inflot:  z= ", z, " ilot= ", ilot);
 } // end inflot  

  bool closlot(elem z)              // closure of lot, if found z, break;
{
  int i,j,k = ilot; elem x, yi, yj; bool r = false;
 if(mm) ipp("+closlot ilot= ", ilot);
 for(i=0; i<k; i++)
  for(j=i+1; j<=k; j++)
  {
   yi = lot[i]; yj = lot[j];
   x = linf(yi,yj);
   if(x != zel) wlot(x,"closlot");
   if(req(x,z))
   { 
    if(9) ipp("closlot: found! z= ", z, " lot[i]= ", yi, "\n      lot[j]= ", yj);
    r = true; goto ret; 
   } // if(req(x,z))
  } // for(i,j)
 ret: if(mm) ipp("-closlot z= ", z, " r= ", r, " ilot= ", ilot);
 return r;
}  // end closlot()

  bool sbst::instlot1(elem z,elem ar[maxvars],int* piar)   // a lot[i] is instance of z ;
{
 bool r = true; int i;  elem x; 
 if(mm) ipp("+instlot1: z= ", z, " size= ", size, " ilot= ", ilot);
 for(i=0; i<=ilot; i++)
 {
  x = lot[i];
  if(!inlist(x,ar,*piar) && instance(x,z)) { wrlist(x,ar,piar,maxvars); goto ret; }
 } // for(i)
 r = false; 
 ret:  if(mm) ipp("-instlot1: z= ", z, "\nsize= ", size, " r= ", r); 
       return r;
} // end bool sbst::instlot1(elem z)   void wrlist(elem z, elem ar[], int* iar,  int sizelist) // initially, iar = -1;

  bool sbst::instlot(elem z)    // some conjunction of lot[i] is instance of z ;
{
 bool r; elem z2,z2a,z2a1,z2a2,z1,z1a; int iar = -1;elem ar[maxvars];  // a&b&c&d is ((a&b)&c)&d
 if(mm) ipp("+instlot: z= ", z, " size= ", size, " ilot= ", ilot);
 r = instlot1(z,ar,&iar); if(r) goto ret;         
 if(!fnt2(z,zconj,&z2,&z1)) goto retfalse;  // z = ((a&b)&c)&d
 r = instlot1(z1,ar,&iar);                          // z1 = d
 if(r) r = instlot1(z2,ar,&iar);                    // z2 = ((a&b)&c);
 if(r) goto ret;                            // s.instlot1(z1) is true, s.instlot1(z2) is true;;
 if(!fnt2(z2,zconj,&z2a,&z1a)) goto retfalse;  // z2a = a&b, z1a = c;
 r = instlot1(z1a,ar,&iar);                         // z1 = d
 if(r) r = instlot1(z2a,ar,&iar);          
 if(r) goto ret;                            // 
 if(!fnt2(z2a,zconj,&z2a1,&z2a2)) goto retfalse;  // z2a1 = a, z2a2 = b;
 if(r) r = instlot1(z2a1,ar,&iar) & instlot1(z2a2,ar,&iar); 
 ret: if(mm) ipp("-instlot: z= ", z, "\nr= ", r, " s= ", this);
      return r;
 retfalse: r = false; goto ret;
} // end bool instlot(elem z)  

  bool instA(elem Q, elem d, elem P, elem z)   // s.instance(z,P) & s.ismds(d); Q=A[d,P]
{
 bool r = false; sbst s;
 if(mm) ipp("+instA: z= ", z, " d= ", d, " P= ", P, " Q= ", Q);
 if(s.instance(z,P)) r = s.ismds(d);     // 11.28.19  added true; // removed true on 4.19.20;
 if(mm) ipp("-instA: Q= ", Q, " z= ", z);
 return r;
} // end bool instA

  bool sbst::ismds(elem d)         // all axioms of d are s-true; 
{
 bool r = false; int i; headp h; elemp q;
 if(hhh) ipp("+ismds: d= ", d);
 if(mel(d,&h,&q) != abt) error("ismds: not abterm, d= ", d);
 for(i = kmain(h)+1; i < int(h->l); i++)
  if(!istr0(q[i])) goto ret;              // ??? NotAxiom ??? !istr(axiom(q[i]);
 r = true;
 ret: if(hhh) ipp("-ismds: d= ", d, " r= ", r);
 return r;
}  // end bool sbst::ismds(elem d)

  bool inftabt(elem z, elem goal)   // infer from current tabt and z;
{
 int i; elem a,b,y,Q; bool r=false; sbst s; 
 achs f(z); pntu->copy(&f);
 if(mm){ ipp("+inftabt:  z= ", z, " goal= ", goal); f.prach("+inftabt"); }
 for(i=0; i <= lview; i++)
 { 
  Q = f.prevt(pntu, i);
  if(Q==zel ) break;   //if(separ(Q)) break;  // { p = false; if(T==zel) break; continue; }
  if(hhh) ipp("inftabt: found in tabt true  Q= ", Q, " z= ", z, " i= ", i, " ist= ", ist);
  s.size = 0; 
  if(fnt2(Q,zimp, &a,&b) && s.instlot(a)) wlot(s.rep(b,"inftabt"),"inftabt:Q");
  y = linf(z, Q, true);    // light infer: true: all vars in Q are vars;
  if(y != zel) wlot(y,"inftabt:y");
  if(req(y,goal)){ if(9) ipp("inftabt: found! y= ", y, " z= ", z, " Q= ", Q); r = true; break; }
 } // for(i,itt) 
 if(mm) ipp("-inftabt:  z= ", z, " r= ", r, " ilot= ", ilot, " i= ", i);
 return r; 
} // end void inftabt(elem z)

  void infvith(elem z)    // add to lot, z ! vith;
{
 int i, k; elem y; elemp q;
 if(mm) ipp("+infvith: z= ", z, " ilot= ", ilot);
 if(! seqv(zvith,&k,&q)) error("infvith: wrong vith = ", zvith);   // q points to opb;
 for(i=1; i<=k; i++)
 {
  y = linf(z, q[i], true);    // light infer:  // all vars in z are vars;
  if(y != zel) wlot(y,"infvith");
 } // for(i) 
 if(mm) ipp("-infvith: z= ", z, " ilot= ", ilot);
} // end infvith

  bool intabt(elem z, elem T)      // z is an instance of a global or T-local theorem in tabt ( T :: ...) 
{
 int i; bool r;
 if(mm) ipp("+intabt: z= ", z, " T= ", T, " ist= ", ist);
 for(i=0; i <= ieul; i++)
 {
  r = clad[eul[i]]->intabt(z,T);
  if(r){ ipp("intabt: found: z is an instance of a global or T-local theorem in tabt, \nz= ", z, "\nT= ", T); break; }
 } // for(i)
 if(mm) ipp("-intabt: z= ", z, " T= ", T, " r= ", r);
 return r;
} // end bool intabt

  bool atomt(elem z)      // atomic term ::= simple || sequence || pfs-term if all arguments are atomic terms;
{                         // non-atomic term ::= qabterm || pfs-term if some argument (maybe deep) is non-atomic;
 bool r = false; int i,m; headp h; elemp q;
 if(mm) ipp("+atomt: z= ", z); 
 m = mel(z,&h,&q);
 if(simple(m) || seqv(z) ) goto ret_true;
 if(qabterm(h)) goto ret;                  // r=false
 assert(m==pfs);
 for(i=1; i < int(h->l); i++)
  if(!atomt(q[i])) goto ret;               // r=false
 ret_true: r = true;
 ret: if(mm) ipp("-atomt: z= ", z, " r= ", r); 
      return r;
} //  bool atomt

  bool tt::intabt(elem z, elem T)      // z is an instance of a global or T-local theorem in tabt ( T :: ...) 
{                                      // ??? t unused ???
 bool p1, p = true; int i; elem d,P,Q,R; bool r=false; sbst s;
 achs f(z); pntu->copy(&f);
 if(mm){ ipp("+tt::intabt:  z= ", z, " T= ", T); f.prach("+tt::intabt"); }
 for(i=0; i <= lview; i++)
 { 
  Q = f.prevt(pntu, i); p1 = atomt(Q);  
  if(mm) ipp("tt::intabt Q= ", Q, " i= ", i, " p1= ", p1);
  if(Q==zel) break;    // if(T==zel) break; continue;
  s.size = 0;
  if(s.instance(z, Q))  //  , !p1 ))    // if atom formula, then all bvars are constants; 4.19.20;
  {
   if(99) ipp("tt::intabt: found true Q: instance(z,Q)\nQ= ", Q, " z= ", z); 
   r = true; break;
  } // if(s.instance(...)
  if(fnt2(Q,zimp, &P, &R) &&  s.instance(z,R) && inlot(s.rep(P,"intabt"))) 
  {
   if(99) ipp("tt::intabt: found true imp Q: P->R, s.instance(z,R) & inlot(s.rep(P,\"intabt\") \nQ= ", Q, " z= ", z); 
   r = true; break;
  } // if(fnt(Q,zimp,...)
  if(fnt2(Q,zA, &d, &P) && instA(Q,d,P,z)) 
  {
   if(99) ipp("tt::intabt: found true  Q: A[d,P] && ...), \nQ= ", Q, " z= ", z); 
   r = true; break;
  } // if(fnt(Q,zA,...)
 } // for(i) 
 if(mm) ipp("-tt::intabt:  z= ", z, " mym= ", mym, " r= ", r);
 return r;
} // end void intabt(elem z)

  bool invith(elem z)               // z is an instance of a very imp. theoerem
{
 int i, k; elemp q; bool r = false; sbst s;
 if(mm) ipp("+invith: z= ", z, " ilot= ", ilot);
 if(! seqv(zvith,&k,&q)) error("invith: wrong vith = ", zvith);
 for(i=1; i<=k; i++)
  if(s.instance(z,q[i])){ r = true; break; }
 if(mm) ipp("-invith: z= ", z, " r= ", r);
 return r;
} // end invith

  bool invith2(elem f, elem a, elem b)         // f(a,b) is a very imp. theoerem (later: an instance of!!!)
{
 int i, k; headp g; elemp q,w;  bool r = false; sbst s;
 if(hhh) ipp("+invith2: f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 if(! seqv(zvith,&k,&q)) error("invith2: wrong(not seqv) vith = ", zvith, " f= ", f);
 for(i=1; i<=k; i++)
 {
  if(mel(q[i],&g,&w) != pfs) error("invith2: wrong(not pfs) q[i] = ", q[i], " f= ", f);
  r = (g->l==3 && f==w[0] && a==w[1] && b==w[2]);
  if(r) break;
 } // for(i)
 if(hhh) ipp("-invith2: f= ", f, " r= ", r);
 return r;
} // end invith

/*  void wlotinf(elem z, int it)   // not used. Jan 18, 2019; inftabt(y,true) is wrong;
{
 // if(ilot > 40) return;       //dont use wlotinf, curm = 0 & REL was not passed;
 if(mm) ipp("+wlotinf: z= ", z, " it= ", it, " ilot= ", ilot);
 wlot(z,"wlotinf"); int i,j=ilot; elem y; // headp h; elemp q;
 if(twav(z) || pvar(z) != zel) goto ret;  // twav: term with abt vars; pvar: predicate var
 if(nowlotinf) goto ret;
 for(i=0; i<=it; i++)
 {
  if(j > ilot) break;       // inflot,inftabt, infvith gave nothing;     
  y = lot[j];
  inflot(y,j-1); ++j;       // add to lot, y!lot;
  infvith(y);               // add to lot, y!vith;
  // inftabt(y,true);          // add to lot, y!tabt;    // true: look also for scope = zel;
  if(mm) ipp("wlotinf: -for, z= ", z, " i(it)= ", i, " j(ilot)= ", j);
 } // for(i)
 ret: if(mm){ prlot("-wlotinf "); ipp("-wlotinf: z= ", z, " ilot= ", ilot, " j= ", j); }
}  // end wlotinf
*/

  bool addlot(elem z, elem goal) // , int a, int b) // add to lot linf(lot[i], GT(curr. tabt) + VT(main tabt)); NOT USED !!!
{   // not used, Jan 18, 2019;
 bool r=false; int i,k; elem T; elemp q;
 if(mm) ipp("+addlot: z= ", z, "goal= ", goal, " ilot= ", ilot); 
 // if(a<0 || b>ilot) error("addlot: wrong a,b: \ngoal= ", goal, "\nT= ", T, "\na= ", a, " b= ", b);
 k = thmbase(z, &q);      // in addlot: add to lot T;
 for(i=0; i<k && (T = q[i]) != zel; i++)
  if(addlot1(T,goal)){ r = true; break; }
 if(mm) ipp("-addlot: z= ", z, " goal= ", goal, " r= ", r);
 return r;
} // end addlot

  bool addlot1(elem z,elem goal)         // add to lot linf(lot, z);  7.17,20                                                                                      
{  
 bool r=false; int i, b=ilot; elem x; 
 if(mm) ipp("+addlot1: z= ", z, "goal= ", goal, " ilot= ", ilot); 
 for(i=0; i <= b; i++)         // ??? i <= b;   b = ilot; ???
 {
  x = linf(lot[i],z, true);       // true: vars in z are vars;
  if(x != zel && wlotg(x, goal)){ r = true; break; } // wlotg:  wlot(z,"wlotg"); return inlot(goal)
 } // for(i)
 if(mm) ipp("-addlot1: z= ", z, " goal= ", goal, " ilot= ", ilot, " r= ", r);
 return r;
} // end addlot1

  bool addtabt(elem z)          // add to lot inftabt(lot(i)) for each i; z: goal;
{
 int i,k1,ditt,k = ilot, saveitt = ptt->itt;  bool r=false;
 if(mm) ipp("+addtabt z= ", z, " ilot= ", ilot); // elem z;
 if(mm){ prp("\n--------------------3 +addtabt z= ", z, pfhis); *pfhis<<" itt= " << saveitt; }
 for(i=0; i<=k; i++) if(inftabt(lot[i], z)) 
 {
  if(9) ipp("addtabt: found! lot[i]= ", lot[i], " z= ", z);
  r = true; goto ret;
 }
 k1 = ilot; 
 for(i=k; i<k1; i++) if(inftabt(lot[i], z)) 
 {
  if(9) ipp("addtabt: found1! lot[i]= ", lot[i], " z= ", z);
  r = true; goto ret;
 }
 ret: ditt = ptt->itt - saveitt; 
 if(ditt > maxdittadd){ maxdittzadd = z; maxdittadd = ditt; } 
 if(mm) ipp("-addtabt: z= ", z, " r= ", r);
// { 
//  prp("\n--------------------3 -addtabt z= ", z, pfhis); 
//  *pfhis<<" ditt= " << ditt; 
//  prlot();
// } // if(mm)
 return r;
} // end addtabt()

  elem infeq(elem y, elem z, bool mayvar_in_z)      // all vars in y are constants
{
 elem a,b,r=zel; att m;  // sbst s; 
 if(mm) ipp("+infeq: y= ", y, "\nz= ", z, "\nmayvar_in_z= ", mayvar_in_z);
 if(ineq(z) && iseq(y,&a,&b)) // && (!varabt(a) || mel(b)==abt) )      // ineq(z) == z is x in A or x <: A or iseq(z)
 {                                                                 // d==A : was wrong;
  if(req(a,z)){r = b; goto ret; }  // a==b && a===z -> b; (a==b && a -> b)
  if(req(b,z)){r = a; goto ret; }  // a==b && b===z -> a; (a==b && b -> a)
  // if(iseq(y,&a1,&b1)){if(req(a,a1){   a = y; b = ztrue; } 
  // r = rep2(z,a,b);
  // if(r != z){ wlot(r,"infeq:1"); goto ret; } // was  goto M; }
  m = inteq(z,a,b);
  if(m==1){ r = rep2(z,a,b); goto ret; }
  if(m==2){ r = rep2(z,b,a); goto ret; }
  // if(b != ztrue){ r = rep2(z,b,a); if(r != z) goto ret; }
 } // if(ineq(z)
  if(iseq(z,&a,&b))                       // was: ineq(y) &&
 {                                                   
  if(req(a,y)){r = b; wlot(r,"infeq:2"); goto M1; }  // a==b && a===y -> b; (a==b && a -> b)
  if(req(b,y)){r = a; wlot(r,"infeq:3"); goto M1; }  // a==b && b===y -> b; (a==b && b -> a)
  M1: if(mayvar_in_z)
  {
   r = rep2i1(y,a,b); if(r != y) goto ret;
   r = rep2i1(y,b,a); if(r != y) goto ret;
  }  // if(mayvar)
  else { r = rep2(y,a,b); if(r != y) goto ret; }
 }  // if(ineq(y)...)
 r = zel; 
 ret: if(mm) ipp("-infeq: y= ", y, "\nz= ", z, "\nr= ", r);
      return r;
} // end infeq

  elem linf(elem y, elem z, bool mayvar)        // light infer, all vars in y are cons;
{ // m: false; all vars in z are cons, true: vars can in z; // ~mayvar -> all vars in z are cons;
 elem a,b,A,A1,B,d,P,ax1,t,x,x1,r=zel;  sbst s; bool p;
 if(mm) ipp("+linf: y= ", y, "\nz= ", z, "\nmayvar= ", mayvar);
 // if(ploop(y) || ploop(z)) goto ret;             // ??? rework !!! ploop formula can be used only once !!!
 r = infeq(y,z,mayvar);
 if(r != zel) goto ret;
 r = Adpzind(y,z);        // A[d,P] & z in d -> Rep(d,P,z);
 if(r != zel) goto ret;
 r = Adpzind(z,y);
 if(r != zel) goto ret;    // x in A & A' < B -> x in B' : 
 if(fnt2(y,zin,&x,&A)) 
 {
  if(fnt2(z,zincl,&A1,&B))    // ,false)
  { 
   if(mayvar) p = s.instance(A,A1);  else p = req(A,A1);  
   if(mm) ipp(" linf:(in,incl), A= ", A, " A1= ", A1, " B= ", B, " s= ", &s);
   if(p) r = trm2(zin,x,s.rep(B,"linf1"), zbool); goto ret; 
  } // if(fnt2(z,zincl,&A1,&B))
  if(fnt2(z,zin,&x1,&A1) && fnt1(A1, zP, &t) && req(A,x1) ){ r = trm2(zin,x,t,zbool); goto ret; }
  if(fnt2(z,zA,&d,&P) && abt1(d,&ax1,&x1,&t) && t==A)   // x in A && A[x1:A, P] -> rep2(P,x1,x);
   { r = rep2(P,x1,x); goto ret; }
 } // if(fnt2h(y,zin,&h,&q))
 s.size = 0;
 if(fnt2(z,zin,&x,&A))
 { 
  if(fnt2(y,zincl,&A1,&B) && req(A1,A))                // !req(q[1],w[1]))
    {  r = trm2(zin,x,B,zbool); goto ret; }            // x in A && A1 <: B -> x in B;
  if(fnt2(y,zA,&d,&P) && abt1(d,&ax1,&x1,&t) && t==A)  // x in A && A[x1:A, P] -> rep2(P,x1,x)
    { r = rep2(P,x1,x); goto ret; }
 } // if(fnt2h(z,zin,&x,&A))
 // if(fnt2(y           // A <: B & B1 <: C -> A<:C1;
 if(fnt2(y,zimp,&a,&b) && req(z,a)){ r = b; goto ret; } // a->b && z is a -> b;
 s.size = 0;
 if(fnt2(z,zimp,&a,&b) && (mayvar? s.instance(y,a): req(y,a)) )        // a->b & y is a  -> b';
   { r = s.rep(b,"linf2"); goto ret; }
 r = zel; 
 ret:  if(iseq(y, &a, &b) && req(a,b)) r = zel;
 if(mm && r != zel) ipp("linf: found: y= ", y, "\n z= ", z, "\nr= ", r, " ilot= ", ilot);
 if(mm) ipp("-linf: r= ", r);
 return r; 
} // end elem linf

  elem Adpzind(elem x, elem y)           // x: A[d,P] & y: z in d -> Rep(d,P,z);
{
 elem r=zel,z,P,u,t=zel,d,t1=zel;                // x: ! L11 := A[x_imG, inv_G1(x) in imG];  h(y) in imG; => inv_G1(h(y)) in imG; 
 if(mm) ipp("+Adpzind: x= ", x, " y= ", y); 
 if(Adp(x,&d,&P,&u,&t) && fnt2(y,zin,&z,&t1))  // u= x, t= imG, z= h(y),  t1= imG;
 {
  if(t != zel && req(t,t1)){ r = rep2(P,u,z); goto ret; }
  if(req(d,t1)){ r = repd(P,d,z); goto ret; }   
 } // if(Adp(x,&d,&P,&u,&t) && fnt2(...);
 ret: if(mm) ipp("-Adpzind: x= ", x, " y= ", y, "\nt= ",t, " t1= ", t1, " r= ", r);
      return r;
} // end elem Adpzind(elem x, elem y)
                                        // in lot A[d,P]: Q is instance of P; // NOT USED !!!
  bool inlAdP(elem d, elem P, elem Q)   // A[d,P] & s.instance(Q,P) & s.rep(Axi(d)) -> Q; // not in lot.h ???
{                                       // not in lot.h;     
 bool r = false; int i; elem a; headp h; elemp q; sbst s;
 if(mm) ipp("+inlAdP: d= ", d, "\nP= ", P, "\nQ= ", Q);
 int m = mel(d,&h,&q);
 // if(m != abt && m != var) error("inlAdP: wrong d= ", d, "\nP= ", P, "\nQ= ", Q);
 if(m != pfs) error("inlAdP: wrong d(not pfs), d= ", d, "\nP= ", P, "\nQ= ", Q);
 if(!s.instance(Q,P,d))
  { if(99) ipp("inlAdp: Q is not instance of P= ", P, " Q= ", Q, " d= ", d); goto ret; }   // true: abt bvar in P is var;
 ipp("inlAdp: NOT CHECKING AXIOMS, d= ", d, " P= ", P, " Q= ", Q); r = true; goto ret;
 // below is not used code;
 for(i = kmain(h) + 1; i < int(h->l); i++)
 {
  a = s.rep(q[i], "inlAdP");      // NotAxiom ??? insert later !!! check not adding in rep not necessary terms;
  if(! inlot(a))
  {
   if(mm) ipp("inlAdP: axiom a is not in lot, d= ", d, " Q= ", Q, " a= ", a);
   r = false; break;
  } // if(! inlot(a))
 } // for(i)
 
 ret: if(mm) ipp("-inlAdP: d= ", d, " P= ", P, "\nQ= ", Q, " r= ", r);
 return r;
} // end inlAdP

  bool inlot(elem z, bool p)      // z in lot: p==true: also look for A[d,P], such that z is an instance of P;
{
 bool r = false; elem a,b,y,d0,P; int save = sss; sss = 0; int static rec_count; sbst s;
 if(mm) ipp("+inlot z= ", z, " p= ", p, " ilot= ", ilot);
 if(++rec_count > 50) 
   error("inlot: rec_count > 50, z= ", z, " p= ", p);
 for(int i = 0; i <= ilot; i++)
 {
  y = lot[i]; s.size = 0;
  // if(p && s.instance(y,z,d)) goto ret;   // ??? can be !instance but req ??? 2022.6.23
  if(req(z, y)){ if(mm) ipp("inlot:found y:req, z= ", z, "\ny= ", y, " i= ", i);  goto ret1; }                 // A[d,P] & s.instance(z,P) & s.rep(Axi(d)) -> z; ??? 2022.06.23
  if(p && fnt2(y,zA,&d0,&P))
  {
   if(mm) ipp("inlot:zA, z= ", z, " y= ", y, "\ni= ", i);
   try{
   // saveipp = ippcount;
   if(s.instance(z,P,y)){ if(mm) ipp("inlot:found y:zA, z= ", z, "\ny= ", y, " i= ", i);  goto ret1; } //inlAdP(d0,P,z)) goto ret1;
   } // try{
   catch(char* s){
   cout << "\ninlot:catch s= " << s;
   *pfhis << "\ninlot:catch s= " << s;
   goto ret;
   } // catch(char* s){ 
  } // if(p && fnt2(y,zA,&d0,&P))
 } // for(i)
 if(fnt2(z,zconj, &a,&b) && inlot(a) && inlot(b)) goto ret1; 
 goto ret;
 ret1: r = true;
 ret: if(mm) ipp("-inlot z= ", z, " r= ", r); sss = save;
 if(--rec_count < 0) error("inlot: rec_count < 0, z= ", z, " p= ", p, " rec_count= ", rec_count);
  return r;
} // end inlot

  bool inlot2(elem f, elem a, elem b)    // f(a,b) in lot
{
 if(mm) ipp("+inlot2 f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 int save = sss; sss = 0; headp h; elemp q; int i;
 bool r = true;
 for(i = 0; i <= ilot; i++)
 {
  if(mel(lot[i], &h, &q) != pfs || h->l != 3) continue;
  if(mm) ipp("inlot2: lot[i]= ", lot[i], " i= ", i);
  if(req(f,q[0]) && req(a,q[1]) && req(b,q[2]) )goto ret;
 }
 r = false;
 ret: if(mm) ipp("-inlot2 r= ", r);
      sss = save; return r;
} // end inlot2

   elem inlot2a(elem f, elem a)        // find b, such that f(a,b) in lot, return b;
{
 if(mm) ipp("+inlot2a f= ", f, " a= ", a);
 int save = sss; sss = 0; headp h; elemp q; int i;
 elem r = zel;
 for(i = 0; i <= ilot; i++)
 {
  if(mel(lot[i], &h, &q) != pfs || h->l != 3) continue;
  
  if(req(f,q[0]) && req(a,q[1]) ){ r = q[2]; break; }
 } // for(i)
 if(mm) ipp("-inlot2a r= ", r); sss=save;
 return r;
} // end elem inlot2a

  bool inlot2a2(elem f,elem a, elem f1, elem* b, elem* c)   // find in lot: f(a,f1(*b,*c));
{
 if(mm) ipp("+inlot2a2 f= ", f, " a= ", a, " f1= ", f1);
 int save = sss; sss = 0; headp h; elemp q; int i;
 bool r = false;
 for(i=0; i<=ilot; i++)
 {
  if(mel(lot[i], &h, &q) == pfs && h->l == 3 &&
     req(f,q[0]) && req(a,q[1]) && fnt2(q[2],f1,b,c)){ r = true; break; }
 } // for(i)
 if(mm) ipp("-inlot2a2: r= ", r);
 sss = save; return r;
} // end bool inlot2a2

  bool inlot2eq(elem a, elem b)    // look in lot for a=b, b=a, a==b, b==a;
{
 if(mm){ prlot("+inlot2eq"); ipp("+inlot2eq  a= ", a, " b= ", b, " ilot= ", ilot); }
 int save = sss; sss = 0; headp h; elemp q; int i,k=0; elem x;  
 bool r = true;
 for(i = 0; i <= ilot; i++)
 {
  if(mel(x=lot[i], &h, &q) != pfs || h->l != 3) continue;
  if(mm && kk) ipp("inlot2: lot[i]= ", x, " i= ", i);
  if(q[0]==zeq && ( (k=1, req(a,q[1]) && req(b,q[2])) || (k=2, req(b,q[1]) && req(a,q[2]))) ) goto ret;
  if(q[0]==zequ && ( (k=3, req(a,q[1]) && req(b,q[2])) || (k=4, req(b,q[1]) && req(a,q[2]))) ) goto ret;
 } // for(i)
 r = false;
 ret: if(mm) ipp("-inlot2eq lot[i]= ", x, " k= ", k, " r= ", r);
      sss = save; return r;
} // end inlot2eq

  elem inlot2eq1(elem a)    // find in lot for a=r, r=a, r==a, a==r;
{
 if(mm){ prlot("+inlot2eq1"); ipp("+inlot2eq1  a= ", a, " ilot= ", ilot); }
 elem r = zel, x; int i, save = sss; sss = 0; headp h; elemp q;  
 for(i = 0; i <= ilot; i++)
 {
  if(mel(x=lot[i], &h, &q) != pfs || h->l != 3) continue;
  // if(mm && kk) ipp("inlot2: lot[i]= ", x, " i= ", i);
  if(q[0]==zeq || q[0]==zequ)
  {
   if(req(a,q[1])){ r = q[2]; goto ret; }
   if(req(a,q[2])){ r = q[1]; goto ret; }
  } // if(q[0]==zeq || ...)  
 } // for(i)
 ret: if(mm) ipp("-inlot2eq1 lot[i]= ", x, " r= ", r); sss = save; 
 return r;
} // end inlot2eq1

  bool inloti(elem z, sbst* s)        // find in lot z, using s->instance(lot[i], z);
{
 bool r; int i;
 if(mm) ipp("+inloti z= ", z, " s= ", s);
 for(i=0; i<=ilot; i++) 
 {
  if(mm) ipp("inloti:for z= ", z, "\nlot[i]= ", lot[i], " i= ", i);
  if(s->instance(lot[i], z)) { r = true; goto ret; }
 } // for(i)
 r = false;
 ret: if(mm){ ipp("-inloti z= ", z, " r= ", r); s->psbs(); }
      return r;
} // end bool inloti(elem z, sbst* s)

  void prlot(char* s)
{
 *pfhis << "\n+prlot: "<<s<<" ilot= "<<ilot<<" mm= "<<mm;
 cout << "\n+prlot: "<<s<<" ilot= "<<ilot<<" mm= "<<mm;
 for(int i = 0; i <= ilot; i++)
 {
  *pfhis << "\n\n"<<i;  prp(") ", lot[i], pfhis);
  cout << "\n\n"<<i;  prp(") ", lot[i]);
  // *pfhis << ' '<<lot1[i];
  // prp(" ", lot2[i], pfhis);
  // prp(" ", lot3[i], pfhis);
 } // for(int i) 
 *pfhis << "\n-prlot"; cout << "\n-prlot";
} // end plot

  bool simp2b(elem f, elem a, elem b)      // look in lot for f(x,y); r = istr2eq(a,x) && istr2eq(b,y);
{
 bool r=false; elem T,aT,bT,E= zel,aE,bE,P= zel,aP,bP; bool pa,pb; int i;
 if(mm) ipp("+simp2b f= ", f, " a= ", a, " b= ", b);
 for(i=0; i<=ilot; i++)
 {
  T=lot[i];
  if(fnt2(T,zeq,&aE,&bE)) E = T;             // the simplest case, later: more general cases !!! 2022.09.28;
  // same for incl: fnt2(T,zincl, ...)
  if(!fnt2(T,f,&aT,&bT)) continue;
  if(mm) ipp("simp2b found possible T= ", T, " aT= ", aT, " bT= ", bT, "\ni(lot)= ", i); 
  pa = (aT==a); pb = (bT==b);
  if(pa && pb){ if(mm) ipp("simp2b: found T in lot: f= ", f," a= ", a," b= ", b, "\nT= ", T); r = true; goto ret; } 
  /*
  if(f==zin && pa)
  {
   if(mm) ipp("simp2b:in: look(istr2inst) for bT <: b,  a= ", a, " b= ", b, " bT= ", bT); // x in bT & bT <: b -> x in b;
   if(ptt->istr2inst(zincl,bT,b))
   {
    if(99) ipp("simp2b: istr2inst found truth of T= ", T, "\nf= ", f, " a= ", a, " b= ", b);
    r = true; goto ret;
   } // if(ptt->istr2inst(zincl,bT,b))
  } // if(f==zin && pa)
  */
  if(pa || pb)
  {
   P = T; aP = aT; bP = bT;    // P: Partial goal;
   if(E != zel)
   {
    if(mm) ipp("simp2b E= ", E, " P= ", P);
    if(aP != a && other(aP, aE,bE)==a )
    { 
     if(9) ipp("simp2b: found T in lot with Equality: f= ", f," a= ", a," b= ", b,"\nE= ", E, " T= ", P);
     r = true; goto ret; 
    } // if(aP != a && other ...  
    if(bP != b && other(bP, aE,bE)==b )    // nat != dom(f), other(nat, nat, dom(f)) = dom(f) 
    { 
     if(9) ipp("simp2b: found T in lot with Equality: f= ", f," a= ", a," b= ", b, "\nE= ", E, " T= ", P);
     r = true; // goto ret; 
    } // if(aP != a && other ...   
   } // if(E != zel )
  } 
  if(istr2eq(a,aT) && istr2eq(b,bT))
     { if(9) ipp("simp2b: found T in lot with istr2eq: f= ", f," a= ", a," b= ", b, "\nT= ", T);r = true; goto ret; }
 } // for(i=0);

 // if(r) ipp("simp2b: istr2eq found a=x, b=y, T:f(x,y)= ", T, "a = ", a, " b= ", b, "\ni(lot)= ", i); 
 ret: if(mm) ipp("-simp2b f= ", f, "\na= ", a, "\nb= ",b, "\nr= ", r);
 return r;
} // end  bool simp2b

  bool fit(elem z, elem t, bool hard)  // ??? bool p: for if(t==zFFN && tz==zset) ???
{
 elem x,y,rsimr=zel,t1,tz1, tz0 = typ(z), tz=tz0, t2 = zel, T,Q,M, Qz,Qt,Mz,Mt; // s,sz,
  bool r=true; headp h; elemp q; int saveilot = ilot, saveitt = ptt->itt, k; int static depth=0, fitcount=0;
 ++depth; ++fitcount;
 if(mm)
 { 
  ipp("\n----------+fit: z= ", z, "\nt= ", t, "\ntz= ", tz, "\nilot= ",ilot, " depth= ",depth, " fitcount= ",fitcount); 
  prlot("+fit");  
 } // if(mm)
 if(fitcount==stad2)    // if(stad2 != 0 && z.ad == stad2)
 mm=mm;    
 if(tz==zany){ t1 = typlot(z); if(t1 != zel) tz = t1; }
 if(t==zel || tz==zel) error("fit: wrong t ot tz, z= ", z, " t= ", t, " tz= ", tz);
 if(t==zset || t==zany) goto ret;
 if(req(t,tz)) goto ret;
 if(t==zREL && fntype(tz)) goto ret; 
 if(inlot2(zin,z,t)) goto ret;
 if(istrin1(z,t)) goto ret;
 if(clad[0]->chinthms(z,t)) goto ret;             // ??? remake ??? // the unique application of chinthms;
 if(simp2b(zin,z,t)) goto ret;                    // look in lot for f(x,y); r = istr2eq(a,x) && istr2eq(b,y);
 if(istr2(zincl, tz, t)) goto ret;
 if(istrin(z,t)) goto ret;
 // if(ptt->istr2inst(zin,z,t)) goto ret;
 k = typcmpr1(t,&tz,z);      // // k=1: tz <: t or z in t, k=0: disjoint, k=2: unknown;
 if(k==1) goto ret;         // discovered tz <: t;
 if(k==0) goto ret_false;        // discovered disjoint(t,tz);
 /*
 t1 = Abt1(t); if(t1 != zel) t = t1;
 if(t==zany || req(t,tz)) goto ret;
 if(t==zset) goto ret;                             // ??? any = set ???
 if(z==zemp && (t==zset || fnt1(t,zP))) goto ret;
 if(tz==zany || tz==zset){ t1 = typtlot(z); if(t1 != zel) tz = t1; }
 if(t==zbool || tz==zbool) goto ret1;    // not fit;
 if(t==zint && (tz==znat || tz==znat1 || tz==znatm || isrt(tz, zseg))) goto ret;
 if(t==zint && (inseqv(zFNtypes, tz) || isfnt(tz))) goto ret1; 
 if(fntype(tz) && (t==zFN || t==zREL)) goto ret;
 */
 if(fnt2(t,zdot,&Q,&M) && !fnt2(tz,zdot))                     // need more general approach:
 {                                          // gather (? and store) all information about objects;
  t1 = valrt(t);       // was t1 = vdt(t,Q,M); 1.2.22; 
  if(req(t1,tz)) goto ret;
 } // if(fnt2(t,zdot...)
 if(fnt2(tz,zdot,&Q,&M) && !fnt2(t,zdot))
 {
  tz1 = valrt(t);       // was  tz1 = vdt(tz,Q,M);
  if(req(t,tz1)) goto ret;
 } // if(fnt2(tz,zdot...)
 if(fnt2(t,zcol, &x)){ ipp("fit:t is zcol,changing t to ", x); t = x; }  // ???
 if(t==zfinabterm && finabt(z)) goto ret;
 if(t==zFFN && tz==zset)goto ret_false;
 if(fnt1(t,zP,&t2) && inlot2(zin,z,t2))
  { if(mm) ipp("fit: t=P[t2] & z in t2 -> ~(z in t), z= ", z, " t2= ", t2, " t= ", t); goto ret_false; }
 if(disjoint(t,tz)) goto ret_false;
 if(istr2c(zeq,t,tz) || istr2c(zeq,tz,t) || istr2c(zincl,tz,t)) goto ret;//? rework:istr2c(zincl,tz,t): was in typcmpr
 if(mm)
 {
  if(mm){ prp("\n--------------------2 fit:prlot: z= ", z, pfhis); *pfhis << " itt= "<<saveitt; }
  prlot("+fit");
 } // if(mm)
 // t1 = zel; if(tz==zany || tz==zset){ t1 = typtlot(z); if(t1!=zel) tz = t1; }
 if(req(tz,t) || t==zREL && (fntype(tz) /*|| fntype(ptt->typtabt(z)) */ )) goto ret;  // ??? remove isfnt ???
 if(t==zFN && (tz==zFFN || isfnt(tz))) goto ret;
 if(t==zFFN && fnt2(tz,zffn)) goto ret;
 if(t==zSEQ && (tz==zSEQ1 || isrt(tz, zseq) || isrt(tz, zseq1))) goto ret;
 if(mel(t,&h,&q)==abt && kmain(h)==1 && htbv(z)==t) goto ret;
 if(Dterm(t) && seqv(z, &k, &q) && ismd(t,q,k)) goto ret;
 //  if(istr2(zincl,tz,t) || istr2(zin,z,t)) goto ret;
 //  if(fnt1(t,zP,&A) && fnt1(tz,zP1,&B) && req(A,B)) goto ret;
 //  tz = typtlot(z); if(req(t,tz)) goto ret;
 y = trm2(zin,z,t,zbool);
 // if(tplclos(z,y)) goto ret;        // moved to typcmpr
 // if(addtabt(y)) goto ret;          commented on 7.17.20
 if(closlot(y)) goto ret;
 if(inlot(y)) goto ret;
 T = pntu->ndcol();                   // 2. in fit;
 if(intabt(y,T)) 
 {
  if(9) ipp("fit: intabt discovered truth of y: z in t, z= ", z, " y= ", y, " T= ", T);
  goto ret;   // y: z in t is an instance of a theorem in tabt (uses prevt);
 } // if(intabt(y, T)) 
 /*  commented addlot on 2023.01.06
 if(addlot(t, y))
 {
  if(9) ipp("fit: addlot discovered truth of y: z in t, z= ", z, " y= ", y, " t= ", t);
  // if(typ(z) != zbool) error("fit: something is wrong with addlot: typ(z) != zbool,  
  goto ret;
 } // if(addlot(t, y))
 if(addlot(tz, y))
 { 
  if(9) ipp("fit:tz: addlot discovered truth of y: z in t, z= ", z, " y= ", y, " tz= ", tz); 
  goto ret; 
 } // if(addlot(tz, y))
 */
 // for each T in thms(t): if(fnt2(T,zin,&a,&b) && b = t && s.instance(z,a)) goto ret;
 // if(addlot(y,T,0,ilot)) goto ret; 
 if(9) ipp("\n-----------fit: hard case: z= ", z, "\ntz0= ", tz0, "\ntz= ", tz, "\nt= ", t, " y(z in t)= ", y);
 if(istrdt(y)){ if(9) ipp("fit: istrdt (dt: den tabt) discovered truth of y= ", y); goto ret; }
 if(vterm(z, &Qz,&Mz) && vterm(t, &Qt, &Mt) && Mz==Mt && istr2(zin,Qz,Qt))
 {
  ipp("fit: z, t are vterms, after stripping istr2(zin,Qz,Qt) discovered truth of z in t,\nz= ", z, " t= ",t);
  goto ret;
 }
  prlot("fit: hard case:");
 if(hard){ rsimr = simr(y); r = (rsimr == ztrue); goto ret; }
 ret_false: r = false;
 ret: --depth;
 // { 
 // s = scope(t); sz = scope(tz); 
 // if(s!=sz && sz!=zel1) ipp("fit:+++,s!=sz, t= ",t," tz= ", tz, " s= ", s, " sz= ", sz);
 // } //
 chilot("-fit, saveilot ", saveilot);  // ilot = saveilot; 
 if(mm) ipp("-fit: z= ", z, " t= ", t, "\nrsimr= ", rsimr, " r= ", r, " ilot= ", ilot, " depth= ", depth);
 return r;
} // end fit

   bool Fit(elemp q,elemp w, int k) // fit(q[i], w[i]), i=1,...,k
{
 bool r = false;
 if(mm) ipp("+Fit: k= ", k);  
 for(int i=1; i <= k; i++) if(!fit(q[i], w[i])) goto ret;
 r = true;
 ret: if(mm) ipp("-Fit: k= ", k, " r= ", r);
      return r;
} // end Fit

  bool istr00(elem z, char* place) 
 {
  bool r = false; headp h; elemp q;
  if(mm) ipp("+istr00 z= ", z);
  if(z==ztrue) goto ret1;
  if(z==zfalse){ ipp("istr00 z= false, place= ", place);  if(inlot(z)) goto ret1; goto ret; }
  if(mel(z,&h,&q) != pfs) error("istr00: wrong(not pfs) z= ", z);
  if(h->t == truth || h->t == truth3 || inlot(z)) goto ret1;
  if(q[0]==zconj && istr00(q[1], "istr00.q[1]") && istr00(q[2],"istr00.q[2]")) goto ret1;  // ???h->t = truth; ???mktr??? 5.19.21
  goto ret;
  ret1: r = true;
  ret: if(mm) ipp("-istr00 z= ", z, " r= ", r);
       return r;
 } // end bool istr00(elem z); 

    bool istr0(elem z, elem d)   // look for possible theorem z in lot and thmbase
{
 bool r=false; headp h,g; elemp q,w; att i,k; elem x,T,a,b; // ,d1,P; 
 static int iS = -1; static int dpth=0; static elem S[maxvars]; static int count=0; // S: already handled;
 ++count;
 if(mm) ipp("\n+istr0 z= ", z, " d= ", d, " iS= ", iS, " count= ", count);
 if(z.ad==stad2)
  mm=mm;
 if(dpth==0) iS = -1; ++dpth;
 if(z==ztrue) goto ret1;                                                                   // 1: true
 if(iseq(z,&a,&b) && req(a,b)){ ipp("istr0: z is a=b, and req(a,b), z= ", z); goto ret1; } // 2: a=b
 if(d != zel)                          // d != zel: z = A[d, z];           
 {
  if(mm) ipp("istr0: d!=zel, z= ", z, " d= ", d);
  z = trm2(zA, d, z, zbool);                    // replacing z to A[d,z]; ???
 } // if(d != zel)
 
 if(inlot(z)) goto ret1;                                                                  // 3: inlot(z)
 if(mm) ipp("istr0 z is not in lot, z= ", z);

 if(mel(z,&h,&q) != pfs)   //  && z.m != ints)
 {
  ipp("istr0: wrong mel, z= ", z, " mm= ", mm);
  goto ret0;
 } // if(mel(,,,) != pfs)
 if(Truth(h)){ if(mm) ipp("istr0:Truth(h), z= ", z, " r= ", r);  goto ret1; }                           //was h->t                 

 if(q[0]==zTaut){ r = Taut(q[1]); if(mm) ipp("q[0]==zTaut, z= ", z, " r= ", r); goto ret; }      // 1. Taut(P)
 
 if(q[0]==zmnbool || q[0]==zdot)                   // 2. -P or P.M;
 { 
  r = istr0(q[1]);
  if(r && Truth(q[1])) h->t = truth;
  if(mm) ipp("istr0: q[0]==zmnbool || q[0]==zdot, z= ", z, " r= ", r);
  goto ret; 
 }  // if(q[0]==zmnbool || q[0]==zdot)
 
 if(q[0]==zconj)                                   // 3. P & Q 
 {
  assert(h->l==3); 
  r = istr0(q[1]) && istr0(q[2]);
  if(r && Truth(q[1]) && Truth(q[2])) h->t = truth;
  goto ret;
 } // if(q[0]==zconj)
 
 if(q[0]==zA || q[0]==zall)                        // 4. A[d,P], All(x, P(x))
 {
  r = istr0(q[2]);
  if(r && Truth(q[2])) h->t = truth;
  goto ret;
 } // if(q[0]==zA)

 if(h->adt)                                       // 5. adt
 {
  r = istr0(q[0]); 
  if(r && Truth(q[0])) h->t = truth;
  goto ret;
 }  // if(h->adt)

 if(typ(q[0])==zbool && mel(q[0],&g,&w)==pfs)    // 6. Special terms
 {
  if(w[0]==zimp){ assert(h->l==2); r = istr0(q[0]) && istr0(q[1]); goto ret; }
  if(w[0]==zA)
  { 
   r = istr0(q[0]);    // was istr0(w[2]);  
   goto ret;
  } // if(w[0]==zA)
  if(h->l == 2){ r = istr0(q[0]) & istr0(q[1]); goto ret; }
 } // if(typ(q[0])
 if((q[0]==zby || q[0]==zbyeq || q[0]== zis || q[0]==zadd))  // is true (by,byeq,is,add)(q1,...,q_hl-1);
 { 
  r = istrbyis(z, h, q);
  // if(!r) 
  goto ret; 
 }  //  if((q[0]==zby || ...)    
 if(z.m != curm) goto ret;                   // ??? remove thmbase(h) ??? 8.28.21
 q = thmbase(h);        // in istr0: looking for "z==x" or "x==z" or x -> z or x -> &(...z...) ;
 k = h->lth;
 for(i=0; i<k && (T=q[i]) != zel; i++)         // among theorems(z) can be "z==x" or "x==z" or x -> z or x -> &(...z...) ;
 {
  if(mm) ipp("istr0:thms for z= ", z," T= ", T, " i= ",i);
  if(mel(T,&g,&w) != pfs) error("istr0:thms: not formula T, z= ", z, " T= ", T);
  if(g->l != 3 || ( w[0] != zequ && w[0] != zimp)) continue;
  x = zel;
  if(conjunct(z,w[2])) x = w[1];    // here g->l == 3 && (w[0]==zequ || w[0]==zimp)
  else if(w[0]==zequ && conjunct(z,w[1])) x = w[2]; 
  {
   if(x==zel){if(mm) ipp("istr0:thms: nothing useful for z in T= ", T, " z= ", z); continue; }
   if(wrlist(x,S,&iS,maxvars)){ r = istr0(x); goto ret; }  // ??? rethink !!!
   if(mm) ipp("istr0: x is already in S, z= ", z, " x= ", x); continue;
  } // if(fnt2(Q, ...)
 } // for(i)
 
 ret0: if(mm) ipp("istr0 nothing found in thms, z= ", z, " k= ", k); goto ret; // r = false;
 ret1: r = true;
 ret: if(mm) ipp("-istr0 z= ", z, "\nr= ", r); --dpth;
      return r;
} // end bool istr0(elem z)


/*    bool istr(elem z) // int flag_inlot, int flag_eqvl) // r=1: h->t = truth
{                                                   // r=2: inlot
 bool r=false; headp h,g; elemp q,w; int m,savemm=mm; elem x,y; // r1=0, r2=0; headp g; elemp w; int m1, m2;
 // mm = check(z.ad,stad);  // wrong !!!
 if(mm) ipp("+istr z= ", z);                        // r=3: eqvl
 if(z==ztrue || z==zBred || Ints(z)) { r = true; goto ret; }  // Bred, ints can occurre in by(...);
 if(z==zfalse) { r = inlot(z); goto ret; }
 if(z==zel || z==zRed || z==zAssocinve || z==zTaut || z==zStaut) 
 {
  ipp("istr: wrong z(zel, ..., Taut or Staut), z= ", z); 
  r = true; goto ret;
 } // if(z == zel ...)
 m = mel(z, &h, &q); 
 if(m != pfs && m != var || m==pfs && (q[0]==zProof || q[0]==zEqProof))
 { 
  error("istr: wrong z= ", z); r = true; 
  goto ret;
 } // if(m != pfs && m != var)     // ??? errmsg ???
 if(h->adt){ r = istr(q[0]); goto ret; }
 r = istr0(z);
 if(r) goto ret;
 if(mel(q[0],&g,&w) == pfs)   // q[0] = Exist(x, P), q[1] = a;
 {
  if(w[0]==zA && !fnt2(q[1], zin) || w[0]==zall && typ(q[1]) != zbool) return istr(q[0]); // ??? All(x,P(x))(Q); ???
  if(w[0]==zexist)
  {
   x = nami(q[0],1);
   if(mm) ipp("istr: w[0]==zexist, q[0]= ", q[0], " q[1]= ", q[1], " x= ", x);
   y = rep2(w[2],x,q[1]);
   r = istr(y);
   goto ret;
  } // if(w[0]==zexist)
  r = istr(q[0]) && istr(q[1]); goto ret;
 } //if(mel(z))
 // r = h->t == truth;
 // if(r){ if(hhh) ipp("istr: h->t = truth; z= ", z); goto ret; }  
 if(mm) ipp("istr: common case: before inlot: z= ", z);
/// r = invith(z) || ptt->intabt(z, pntu->ndcol() );   // ??? ptt=> ???
 goto ret;

 ret: if(!r && fnt2h(z,zconj,&g,&w)) r = istr(w[1]) && istr(w[2]);   // ??? 
 if(mm) ipp("-istr z= ", z, " r= ", r);  mm=savemm;
 return r;
} // end istr 
*/
   bool istrbyis(elem z,headp h,elemp q)  // is true (by,byeq,is,add)(q1,...,q_hl-1);
{                                         // taken from istr on 8.27.20;
 bool r=false, b; int i,hl = h->l; headp g; elemp w; // elem d,P;
 if(mm) ipp("+istrbyis z= ", z);
 // assert(q[0] == zby || q[0] == zbyeq || q[0] == zis || q[0] == zadd)
 for(i=1; i < hl; i++)
 {  
  elem a = q[i];
  if(a==zAxab || a==zRed || a==zAssocinve || a==zBred || a.m == ints) continue;  // a.m==ints can be in by(...);
  if(mel(a,&g,&w)==pfs)
  {
   if(g->l == 2)
   {
    // if(w[0]==zmnbool)
    // { 
    //  if(istr0(w[1])) continue; 
    //  ipp("istrbyis: a = -P, P is not true, z= ", z, " a= ", a);
    //  goto ret;
    // } // if(w[0]==zmnbool)
    if(w[0]==zRed) continue; 
   } // if(g->l == 2_
   if(g->l == 3 && w[0]==zexc){ b = istr0(w[1]) & istr0(w[2]); if(b) continue; goto ret; }
   if(g->adt){ b = istr0(w[0]);  if(b) continue; goto ret; }

  } // if(mel(a,&g,&w)==pfs)
  if(!istr0(a)){ if(9) ipp("istrbyis: not true a, z= ", z, " a= ", a);  goto ret; }
 } // for(i)
 r = true; 
 ret:  if(mm) ipp("-istrbyis z= ", z, " r= ", r);
        return r;
} // bool istrbyis

  bool istr2eq(elem a, elem b)        // looking for theorems a=b,a==b,b=a,b==a; 
{
 if(mm) ipp("+istr2eq: a= ", a, " b= ", b); bool r=false; int i,k; elemp q;
 // bool r = istr2c(zeq,a,b) || istr2c(zeq,b,a); //  || istr2c(zequ,a,b) || istr2c(zequ,b,a);
 k = eqthms(a,&q);  // q: list of the equals to a, k == -1: no equals to a;
 for(i=0; i<=k; i++) if(q[i]==b){ r = true; goto ret; }
 r = inlot2eq(a,b);
 ret: if(mm) ipp("-istr2eq: a= ", a, " b= ", b, " r= ", r);
 return r;
} // bool istr2eq(elem a, elem b)

  bool istr2thms(elem f, elem a, elem b)  // looking for the theorem "f(a,b)",using thmbase and instance; // ~ intabt;
{                                         //                           currently req instead of instance;
 bool r; elem T; int i,k; headp h; elemp q, w; 
 elem z = trm2(f,a,b,zbool);                /// ??? no check for bool ???
 if(mm) ipp("+istr2thms: z= ", z, "\nf= ", f, " a= ", a, " b= ", b);
 k = thmbase(a, &w); // in  bool istr2thms(elem f, elem a, elem b)  // looking for the theorem "f(a,b)"
 for(i=0; i<k && (T = w[i])!=zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mel(T,&h,&q)!=pfs || h->t != truth) error("istr2thms: not a theorem T, z= ", z, "\nT= ", T);
  if( h->l != 3 || q[0] != f) continue;
  if(req(z, T)){ ipp("istr2thms: found T, z= ", z, "\nT= ", T, " i= ", i); r = true; goto ret; }
 } // for(i)
 r = false;
 ret: if(mm) ipp("-istr2thms: z= ", z, "\ni= ", i, " r= ", r);
      return r;
} //  bool istr2thms(elem f, elem a, elem b

  bool istrdt(elem z)                  // check if z is true, using den and tabt via thmbase and instance
{
 bool r; headp h; elemp q, w; att m; ats k;  elem R,Q,Q1,Q2, d; sbst s;
 if(mm) ipp("+istrdt z= ", z);
 m = mel(z, &h, &q);
 if(m != pfs) error("istrdt: mel(z) != pfs, z= ", z, " mel= ", m);
 // R = q[0] != zin? q[0] : root(q[2]);
 R = q[0];
 if(q[0]==zin){ R = root(q[2]); goto M; }
 if(q[0]==zeq) R = q[1];
 M: k = thmbase(R, &w);   // in bool istrdt(elem z): check if z is true, using den and tabt via thmbase and instance
 if(k>64) k = 64;                        // 2022.02.01
 for(int i=0; i<k && (Q=w[i]) != zel; i++)
 {
  d = scopeden(Q);
  if(d==zel || d==zel1) d = zel0;                // zel: scope = module;  2022.11.15: add || d==zel1;
  if(s.instance(z,Q,d))
  {
   if(9) ipp("istrdt: Found!!! s.instance(z,Q,d)), z= ", z, " Q= ", Q, "\nd= ", d);
   r = true; goto ret;
  } // if(s.instance(z,Q,d))
  s.size = 0; 
  if(fnt2(Q,zequ,&Q1,&Q2))
  {
   if(99) ipp("istrdt: fnt2(Q,zequ,&Q1,&Q2), z= ", z, " Q= ", Q);
   if(s.instance(z,Q1,d))
   {  
    R = s.rep(Q2,"istrdt:rep(q2)");
    if(istr0(R)){ ipp("istrdt:zequ, istr0 discovered truth of Q2', z= ", z, " Q= ", Q, " Q2'= ", R); r = true; goto ret; }
   } // if(s.instance(z,Q1,d))
   s.size = 0;
   if(s.instance(z,Q2,d))
   {  
    R = s.rep(Q1,"istrdt:rep(Q1)");
    if(istr0(R)){ ipp("istrdt:zequ, istr0 discovered truth of Q1', z= ", z, " Q= ", Q, " Q1'= ", R); r = true; goto ret; }
   } // if(s.instance(z,Q2,d))
  } // if(fnt2(Q,zequ,&Q1,&Q2))
 } // for(int i=0; ...)
 r = false;
 ret: if(mm) ipp("-istrdt z= ", z, " r= ", r);
 return r;
} // bool istrdt(elem z)

  bool istrlh(elem z, elem hint)      // hint is a theorem of the form h1 & ... & hk -> c; use lot and hit to prove z;
 {
  bool r=false; int i, lasthyp; elemp hyp; elem H, concl; sbst s;  
  if(mm) ipp("+istrlh z= ", z, " hint= ", hint);
  if(!parsimp(hint, &hyp, &concl, &lasthyp)){ ipp("istrlh: not imp hint, z= ", z, " hint= ", hint); goto ret; }
  if(!s.instance(z, concl)){ ipp("istrlh: !s.instance(z, concl)), z= ", z, " hint= ", hint, " concl= ", concl); goto ret; }
  for(i=0; i <= lasthyp; i++)
  {
   if(mm) ipp("istrlh:for z= ", z, "\nhyp(i)= ", hyp[i], " i= ", i);
   if(! inloti(H=hyp[i], &s))
    { ipp("istrlh: not inloti(H=hyp[i]), z= ", z, " hint= ", hint, " H= ", H); s.psbs(); goto ret; }  
  } // for(i) 
  r = true;
  ret: if(mm){ ipp("-istrlh z= ", z, " hint= ", hint, " r= ", r); s.psbs(); }
  return r;
 } // end bool istrlh(elem z, elem hint)

  void tt::infer1(elem T)           // for each theorem Q in tabt r = infer2(Q,T);
{
 int i,k=itt; elem Q; headp h;
 if(mm) ipp("+infer1: T= ", T, " mym= ", mym, " ilot= ", ilot);
 if(mym==curm) k = curtritt;
 for(i=0; i <= k; i++)              // a separate list of theorems
 {
  Q = elm(mym, 0, i); h = tabt[i];
  if(Truth(h)) infer(Q,T);     // (h->t == truth)
 } // for(i)
 if(mm) ipp("-infer1: T= ", T, " mym= ", mym, " ilot= ", ilot);
} // end void tt::infer1(elem T)

 // elem infer1(elem T)                 // 

   void tt::infer2(elem Q1, elem Q2)  // wlot(resultant of Q1 and Q2);
{
 int i,k=itt; headp h; elem z, P1, P2, P3, r = zel; sbst s;
 if(mm) ipp("+tt::infer2: Q1= ", Q1, " Q2= ", Q2, " mym= ", mym);
 // if(mym != curm);  // insert search in the List of true P1&P2 -> P3;
 if(mym==curm) k = curtritt;
 for(i=0; i <= k; i++)
 {
  h = tabt[i]; z = elm(mym,0,i); s.size = 0;
  if(Truth(h) && fnt22l(z,zimp,zconj, &P1, &P2, &P3))  // z := P1 & P2 -> P3 // h->t == truth
  {
   if(mm) ipp("tt::infer2: found true implication z= ", z, " mym= ", mym, " ist= ", ist);
   if(!s.instance(Q1,P1)) continue;
   if(!s.instance(Q2,P2)) continue;
   r = s.rep(P3,"infer2"); wlot(r,"infer2");  // wlotinf(r);
  } // if(h->t)
 } // for(i)
 if(mm) prlot("-tt::infer2");
 if(mm) ipp("-tt::infer2: Q1= ", Q1, " Q2= ", Q2, " r= ", r);
} // end  void tt::infer2(elem Q1, elem Q2) 

   void infer(elem Q1, elem Q2)         // is true f(a,b): search in tabt
{
 int i; 
 if(mm) ipp("+infer: Q1= ", Q1, " Q2= ", Q2, " ilot= ", ilot);
 for(i=0; i <= ieul; i++) clad[eul[i]]->infer2(Q1,Q2);
 // r = inlot2(f,a,b);  // !!! search true implication in lot !!! ???
 if(mm) ipp("-infer: Q1= ", Q1, " Q2= ", Q2, " ilot= ", ilot);
} // bool infer

	void wrdep(elem x, elem x1, elem x2) // , char* place)        // x depends on x1,x2: x is true, if x1 and x2 are true; 
{ 
 bool b1, b2; elem y,y1,y2; int i, savemm=mm;
 // if(check(x.ad, stad1)) mm=1;
 if(mm) ipp("+wrdep x= ", x, " x1= ",x1, " x2= ",x2); // , " place= ", place);
 if(99 && x2 != ztrue) ipp("+wrdep x= ", x, " x1= ",x1, " x2= ",x2); 
 if(b1 = istr0(x1)) x1 = ztrue;  
 if(b2 = istr0(x2)) x2 = ztrue;     // next line: was !pntu->inproof(), replaced with proofdepth;
 if(proofdepth==0) error("wrdep: not inside of a proof,x= ", x, " x1= ", x1, " x2= ", x2);
 if(b1 && b2)
 {
  if(mm) ipp("wrdep b1 && b2: also mktr(x), etc., x= ", x, " x1= ", x1, " x2= ", x2);
  mktr(x);
  for(i=0; i<=idep; i++)
  {
   y = dep[i]; y1 = dep1[i]; y2 = dep2[i];
   if(x==y1 && y2==ztrue || x==y2 && y1==ztrue) mktr(y);
  } // for(i=0)
 // goto ret;
 } // if(b1 && b2)   
 if(++idep >= ldep) error("wrdep: too big idep,  x= ", x, " idep= ", idep);
 dep[idep] = x;               // x is not in dep
 dep1[idep] = x1;
 dep2[idep] = x2; 
 // ret:
 if(mm) prdep();
 if(mm) ipp("-wrdep x= ", x, " b1= ", b1, " b2= ", b2, " idep= ", idep);  mm=savemm;
} // end void wrdep

   bool axat(elem d, headp hd, elemp qd, elem x1) // x1 is an axiom of abterm d;
{
 int k = hd->l;
 assert(hd->tel == abt);
 int m = kmain(hd);
 for(int i = m; i < k; i++)
 {
  if(typ(qd[i]) != zbool) continue;
  if(i < k-1 && qd[i+1] == zNotAxiom) continue;
  // check if d is a named term ???
  if(req(x1, qd[i])) return true;
 } // for(int i)
 return false;
} // end bool axat

    bool iset(elem z)              // is a set
{
 elem t;  headp h; elemp q;  bool r=false;
 if(mm) ipp("+iset: z= ", z);
 t = typ(z);
 if(mm) ippelm("iset t= ", t);
 if(t == zel) error("iset: t = zel, z= ", z);
 if(t.m == ints || t == znat)  goto ret; 
 if(t == zset || t == zset1) { r = true; goto ret1;}
 if(mel(t,&h,&q) != pfs) goto ret;
 if(q[0] != zP && q[0] != zP1) goto ret;
 /*if(t == zany) // Hard Case is not needy, type conv.term can be used: set(z)!
 {
  ipp("iset: t = zany, z= ", z);
  goto HardCase;  // ???temp! 12/18/99
 }
 t1 = typ(t);
 if(pp) ippelm("iset t1= ", t1);
 if(t1 == zany)
 {
  ipp("iset: t1 = zany, z= ", z, " t= ", t);
  goto HardCase;
 }
 //if(t1 == Tdefs || t1 == Tsetdefs){ r = 0; goto ret; } 
 //if(t1 != TPClassDef && t1.m == ints){r=0; goto ret;}  // definitions and sys.types are not sets
 k = lev(z);            // 7/26/96
 if(k >= 0) { r = k > 0; goto ret; }
 HardCase:
 ipp("iset: hard case: z= ", z);
 error("iset: commented 2 lines below"); */
 // y = trm2(zin, z, zset, zbool);   //???  12/17/99
 // r = istrue(y);
ret1: r = true; 
ret: if(mm) ipp("-iset z= ", z, ", r= ", r);
 return r;
} // end iset

  void prdep(elem goal)          // printing dep
{
 ipp("+prdep goal =", goal);
 cout<<"\nidep= "<<idep<< "         dep      :     dep1        :        dep2\n";
 *pfhis<<"\nidep= "<<idep<< "         dep      :     dep1        :        dep2\n";
 
 for(int i=0; i<=idep; i++)
 {
  *pfhis<<"\n"<<i;             cout<<"\n"<<i; 
   prp(" : ", dep[i],pfhis);   prp(" : ", dep[i]);
   prp(" : ", dep1[i],pfhis);  prp(" : ", dep1[i]);
   prp(" : ", dep2[i],pfhis);  prp(" : ", dep2[i]);
 } // for(int i)
 cout<<"\n--------end prdep------------------\n";
 *pfhis<<"\n--------end prdep------------------\n";
};  // end prdep

 bool indep(elem z, int k)                         // k: beginning in dep for z;
{
 bool r= false;
 if(mm) ipp("+indep z= ", z, " k= ", k);
 for(int i=k; i <= idep; i++)
  if(req(dep[i],z)) { r = true; break; }
 if(mm) ipp("-indep z= ", z, " k= ", k, " r= ", r);
 return r;
} // bool indep

   int cldep(elem goal, int k)                     // closure of dep, k: beginning in dep for goal
{
 bool bx,by1,by2, p = true; elem x, y1,y2; int i,n=0,m=0,savemm=mm;    // p:continuation 
 // if(goal.ad==stad2) mm=1;
 if(mm) ipp("\n+cldep goal= ", goal," k= ", k, " idep= ", idep);                         // m: #unproved
 if(mm){ prdep(goal); prlot(); }
 while(p)
 {
  p = false; m = 0;  
  if(n > idep-k){ prdep();  error("cldep: n > idep-k goal= ", goal, " n= ", n, " k= ", k, " idep= ", idep); }   
  ++n;    // maximum idep-k + 1 iterations;
  for(i=k; i<=idep; i++)                                  // dep[i] depends on dep1[i], dep2[i]
  {
   if(mm) ipp("\ncldep:for i= ", i, " n= ", n);
   x = dep[i]; y1 = dep1[i]; y2 = dep2[i];
   if(mm) ipp("cldep:for x= ", x, " y1= ", y1, " y2= ",y2);
   bx = istr00(x,"cldep.bx");
   by1 = (y1==ztrue) || istr00(y1,"cldep.by1");
   by2 = (y2==ztrue) || istr00(y2,"cldep.by2");
   if(mm) ipp("cldep bx= ", bx, " by1= ", by1, " by2= ", by2);
   if(!bx && by1 && by2){ mktr(x); p = true;  continue; } 
  } // for(i)
 } // while(p)
 m = 0;
 for(i=k; i<=idep; i++)
 {
  x = dep[i];
  if(!istr00(x, "cldep:x = dep[i]"))                       // if(!istr0(x))   2023.01.24
  { 
   // prdep(); prlot("-cldep");
   ++m;
   ipp("\ncldep: not proved \ngoal= ", goal, "\ndep[i]= ", x, " i= ", i);    // was errmsg 1.14.20;
  } // if(!istr0(x))
 } // for(i)
 if(m)
 {
  // prdep(); prlot("-cldep"); see prf
  ipp("cldep: there are unproved formulas, goal= ", goal, " m= ", m);        // was errmsg 1.14.20;
 } // if(m)
 else if(mm) ipp("cldep: Success! All formulas have been prooved! goal= ", goal);
 if(mm) ipp("-cldep m= ", m, " n= ", n, " idep= ", idep); mm = savemm;
 return m;
} // end int cldep

 /* void prdep()
{
 cout << "\n i   dep  dep1 dep2 idep= "<< idep;
 *pfhis << "\n i   dep  dep1 dep2 idep= "<< idep;
 for(int i=0; i<=idep; i++)
 {
  cout << "\n"<<i; prp("  ", dep[i]); prp("  ", dep1[i]); prp("  ", dep2[i]);
  *pfhis << "\n"<<i; prp("  ",dep[i],pfhis); prp("  ",dep1[i],pfhis); prp("  ",dep2[i],pfhis);
 } // for(i)
} // end prdep
*/

  elem typlot(elem z, bool fnt)
{
 elem a,b, r=zel; int i;           // typlot cannot use s.instance: recursion !
 if(mm) ipp("+typlot z= ", z, " ilot= ", ilot); 
 for(i=0; i <= ilot; i++)
  if(fnt2(lot[i], zin, &a, &b) && b != zany && b != zset && req(a,z) )
  { 
   r = b;
   if(mm) ipp("typlot:for:zin: z= ", z, " a= ", a, " b= ", b, " fnt= ", fnt);
   if(!fnt) goto ret;
   if(fntype(b)) goto ret; 
  } // if(fnt2h(lot[i])
 r = zel;
 ret: if(mm) ipp("-typlot r= ", r);
 return r;
} // end typlot

 elem axin(elem a, elem d, int i) // a is i-th axiom of d
{
 elem r=zel; headp g; elemp w;
 if(mm) ipp("+axin: a = ", a, " d= ", d, " i= ", i);
 if(fnt2h(a, zin, &g, &w) && bvel(w[1], d, i)) r = w[2];
 if(mm) ipp("-axin: r = ", r);
 return r;
} // end axin

 elem simd(elem t)
{
 elem r=zel; headp h; elemp q;
 if(mm) ipp("+simd: t= ", t);
 if(mel(t, &h, &q) == abt && h->l == 3) r = axin(q[2],t,1);
 if(mm) ipp("-simd: t= ", t, " r= ", r);
 return r;
} // emd simd

 elem simr(elem z)                // simplification (via reductions)
{
 int lar1 = lar-1, it, saveitt = ptt->itt; elem y, r=zel;
 if(9){ ipp("\n+simr z= ", z, " maxit= ", maxit); prlot(""); }
 if(strcmp(hintstr, "nosimr") == 0){ ipp("simr: strcmp(hintstr, \"nosimr\") == 0, z= ", z);  goto ret; }
 if(hint != zel && istrlh(z, hint)){ r = ztrue; goto ret; }
 if(ptt->istrf(z,'i')){ ipp("simr: istrf discovered truth of z= ", z); r = ztrue; goto ret; }
 iar = 0; it = 0;
 ar[0] = cand(z, cmpl(z),false);      // candidate for simplification, returns( r.e = x; r.c = c; r.exp = exp)
 while(++it <= maxit)
 {
  if(mm){ ipp("simr:while z= ", z, "\nit= ", it); prar(); }
  if(fnexp(&y)) goto ret1;             // find first unexpanded cand
  r = expand(y);                       // ar[i].e is first unexpanded cand
  if(r != zel) goto ret;               // r != zel == r is simple;
 } // while(++it > maxit)
 if(mm) ipp("simr: end while: z= ", " it= ", it);
 ret1: r = ar[0].e;
 ret: if(9) ipp("-simr z= ", z, "\nr = ", r, " it= ", it, " difitt= ", ptt->itt - saveitt);
      return r;
} // end elem simr

 bool fnexp(elem* ay)
{
 bool r = false; int i;
 if(mm) ipp("+fnexp: iar= ", iar, " it= ", it);
 *ay = zel;
 for(i=0; i<=iar; i++) if(!ar[i].exp) goto M;   // find first unexpanded cand
  if(mm) ipp("fnexp: all was expanded");
 r = true;
 M: *ay = ar[i].e; ar[i].exp = true;
 if(mm) ipp("-fnexp: *ay= ", *ay, " r= ", r);
 // if((*ay).ad == 274)
 // i = i;
 return r;  
} // end bool fnexp(elem* ay)

 elem explot(elem z)                    // expand z, using lot;  see inlot(z);
{
 elem a=zel,b=zel,d,P,x,y,r=zel; int i; sbst s;
 bool p = typ(z)==zbool;
 if(mm){ prlot(" "); ipp("+explot z= ", z, " p= ", p); }
 if(!p) error("explot: z is not a formula, z= ", z);
 for(i=0; i<=ilot; i++)
 {
  y = lot[i];
  // if(p)
  {
   if(req(y,z)){ r = ztrue; goto ret; }            // found y=z;
   if(fnt2(y, zA, &d,&P))
   {
    if(mm) ipp("explot: A[d,P]: z= ", z, " P= ", P);
    if(s.instance(z,P,y)){ r = ztrue; goto ret; }  // ??? add more checks like ismd; was false
    if(mm) ipp("explot: A[d,P]: z is not instance of P: z= ", z, "\nP= ", P);
   } // if(fnt2(y, zA, &d,&P)
  } // if(p)
  if(iseq(y, &a, &b)) goto M;
  if(interm(y,z)){ a = y; b = ztrue; } else continue;  // ??? interm 
  M: if(mm) ipp("explot: found true equation or equiv: \ny=", y, " a= ", a, " b= ", b);
  x = rep2(z,a,b);
  if(mm) ipp("explot: after first rep2: x= ", x);
  if(x != z){ r = wrar(x); if(r != zel) goto ret; }  
  x = rep2(z,b,a);
  if(mm) ipp("explot: after second rep2: x= ", x);
  if(x != z){ r = wrar(x); if(r != zel) goto ret; }  
 } // for(i)
 ret: if(mm){ prar(); ipp("-explot z= ", z, " r= ", r); }
 return r;
} // end elem explot()

 elem expand(elem z)  
{
 elem r,x; // int i;
 if(mm) ipp("\n+expand: z= ", z, "ieul= ", ieul, " it= ", it);
 x = cred(z);
 if(x != z){ r = wrar(x); goto ret; }
 r = explot(z);
 if(r != zel) goto ret;
 r = expvith(z);
 if(r != zel) goto ret;
 // for(i=0; i<=ieul; i++)
 // {
 // r = ptt->expand(z);               //  r = clad[eul[i]]->expand(z);
 r = expdcl(z);
 if(r != zel) ipp("expand:expdcl: success z= ", z);
 // } // for(i)
 // r = ar[0].e;
 ret: if(mm) ipp("-expand: z= ", z, " r= ", r); 
      return r;
} // end elem expand();

 elem tt::expand(elem z)  // for each true eqv(imp) a=b in tabt: 1. if s.instance(z,b) && istr(s.rep(a)) return true;
{                                                         //     2. otherwise wrar(s.rep(b));
 elem a,b,d,Q,P,x,T, r=zel; int i, i0=0, k=itt; headp h; sbst s;
 if(mym ==curm) k = curtritt; 
 if(mym == 0) i0 = k - lview*2; // zvith.ad;          // to skip tautologies
 T = pntu->ndcol();      // 1. in elem tt::expand(elem z);
 if(mm) ipp("+tt::expand: z= ", z, " T= ", T, "\nmym= ", mym, " k= ", k, " i0= ", i0);
 for(i=k; i > i0; i--)
 {
  h = tabt[i]; 
  Q = elm(mym,0,i); s.size = 0;
  if(gtrm(i,T))
  {
   if(mm) ipp("tt::expand: found global theorem Q= ", Q, " i= ", i);
   if(fnt2(Q,zA,&d,&P) && s.instance(z,P)){ r = ztrue; goto ret; }  // instance(z,P,true): true: vars_are_cons; ???
   if(fnt2(Q,zimp,&a,&b) && s.instance(z,b) )   //  bvars in Q are vars;
   { 
    if(mm) ipp("tt::expand: found special implication Q, z= ", z, "\nQ= ", Q, " ilot= ", ilot, " i= ", i);
    if(istr0(s.rep(a,"expand:a"))){ r = ztrue; goto ret; }
   } // if(fnt2(Q,zimp,&a,&b)
   if((goodimp(Q,&b,&a)) && a != b && s.instance(z,a))            // ,false)
   {
    if(mm) ipp("tt::expand: found true eqv or imp(ab is ba) Q= ", Q, " \na= ", a, " b= ", b, " i= ", i); 
    x = s.rep(b,"expand:b");
    r = wrar(x); 
    if(r != zel) goto ret;
   } // goodimp(Q,&b,&a)) if(iseq(Q,&a,&b) ...
   if(iseq(Q,&a,&b))
   { 
    x = rep2i1(z,a,b);
    if(x != z){ r = wrar(x); if(r!=zel) goto ret; }
   }
  } // if(gtrm(i,T)
 } // for(i)
 ret: if(mm){ prar(); ipp("-tt::expand: r= ", r, " mym= ", mym); }
      return r;
} // end elem tt::expand(z)

 elem expvith(elem z)
{
int i, k; elem a,b,x; elemp q; elem r = zel; sbst s;
 if(mm) ipp("+expvith: z= ", z, " iar= ", iar);
 if(! seqv(zvith,&k,&q)) error("invith: wrong vith = ", zvith);
 for(i=1; i<=k; i++)
  if((iseq(q[i],&a,&b) || goodimp(q[i],&b,&a)) && s.instance(z,a))
  {
   if(mm) ipp("expvith: found true eqv or imp(ab is ba) q[i]= ", q[i], " \na= ", a, " b= ", b, " i= ", i); 
   x = s.rep(b,"expvith");
   r = wrar(x); 
   if(r != zel) break;
  } // if(iseq(Q,&a,&b) ..
 if(mm) ipp("-expvith: z= ", z, " r= ", r);
 return r;
} // elem expvith(elem z)

 elem wrar(elem x)
{
 elem r=zel, x0; int i,j,c0, c = cmpl(x); int lar1 = lar-1; // lar1: the last;
 if(mm) ipp("+wrar: x= ", x, " c= ", c, " iar= ", iar);
 if(!comp(x)){ r = x; goto ret; }
 if(istr0(x)){ r = ztrue; goto ret; }   // was inlot
 for(i=0; i<=iar; i++)
 {
  x0 = ar[i].e; c0 = ar[i].c; 
  if(c == c0 && req(x,x0)) goto ret; // x is already in ar;
  if(c < c0)
  {
   if(mm) ipp("wrar: found place i= ", i, " c= ", c, " c0= ", c0);  
   for(j=iar; j>=i; j--)         // inserting x into ar[i], so shifting ar;
    if(j < lar1) ar[j+1] = ar[j];
   ar[i] = cand(x,c,false);  
   if(iar < lar1) ++iar;
   goto ret;
  } // if(c <= c0 ...)
 } // for(i)
 if(mm) ipp("wrar: inserting at the end, i= ", i, " c= ", c, " iar= ", iar);  
 if(iar < lar1) ar[++iar] = cand(x,c,false);
 ret: if(mm) ipp("-wrar: x= ", x, " r= ", r, " i= ", i);
 return r;
} // end elem wrar(elem)

 Cand cand(elem x, int c, bool exp)            // candidate for simplification
{
 Cand r;
 r.e = x; r.c = c; r.exp = exp;
 return r; 
} // end Cand cand

 void prar()
{
 Cand c;
 cout << "\n\nPrinting ar: iar= " << iar;
 *pfhis << "\n\nPrinting ar: iar= " << iar;
 for(int i=0; i<=iar; i++)
 {
  c = ar[i];
  cout << "\n"<<i; prp(") ", c.e); cout << " "<< c.c << " "<<c.exp;
  *pfhis << "\n"<<i; prp(") ", c.e, pfhis); *pfhis << " "<< c.c << " "<<c.exp;
 } // for(i)
 cout << "\n";
 *pfhis << "\n";
} // end void prar()  

  bool istrM(elem z, elemp arm)    // ??? make inline ???
 {
  if(mm) ipp("+istrM: z= ", z);
  elem P = repqmd(z, arm);
  bool r = istr0(P);
  if(mm) ipp("-istrM: z= ", z, " r= ", r);
  return r;
 }
// int lind(elem z,elem Q=zel, int* adisp=0); // z is a Dterm;  r: size of model; also checks that Q is a very simple method and computes D, Dd, dispDd;
 int lind(elem z, elem Q, int* dispd  )   // z is a Dterm;  r: size of model; also computes D, Dd, dispDd;
{                                         // if Q is a very simple method, *adisp = disp else *adisp = -1;
 static int count=0,r,disp;  int m,m2,k;  headp h,g; elemp q; 
 if(++count == 1){ r = 0; iD = -1; iDd = -1; disp = 0; if(dispd) *dispd = -1; } 
 else ipp("lind: recursive call: z= ", z, " count= ", count, " disp= ", disp, " mm= ", mm); 
 if(mm) ipp("+lind: z= ", z, " Q= ", Q, " iD= ", iD, " iDd= ", iDd, " r= ", r);
 if(z.ad==stad1 && ptt->itt >= stad2)
 mm=mm;
 // wrDD(z);
 m = mel(z,&h,&q);
 if(m==abt)
 { 
  k = kmain(h); r += k;  wrD(z); wrDd(z); dispDd[iDd] = disp; 
  if(htbv(Q)==z && dispd)  *dispd = disp;    // ??? check *adisp != -1;
  disp += k;  goto ret;
 } // if(m==abt)
 if(m != pfs || h->l != 3 || q[0] != zdconj)
   error("lind: wrong z(not d, z1&&P, z1&&d1), z= ", z);
//  if(Dterm(q[2])) wrDD(q[2]); 
 lind(q[1]);              // ??? no lind(q[2]); ??? 2023.01.20
 m2 = mel(q[2],&g);
 if(m2 == abt)
 { 
  k = kmain(g); r += k; wrD(q[2]); wrDd(q[2]); dispDd[iDd] = disp;
  if(htbv(Q)==q[2] && dispd)  *dispd = disp;
  disp += k; goto ret;
 } // if(m2 == abt)
 if(m2 != pfs || typ(q[2]) != zbool) error("lind: wrong z = z1&&P: wrong(not bool) P, z= ", z, "\nP= ", q[2]);
 wrD(q[2]);  // D contains all d's and P's; // Dd contains all d's;
 ret: if(mm) ipp("-lind: z= ", z, " r= ", r, " D= ", D, iD); --count;
 return r;
} // end void lind(elem z)

  bool vsmethod(elem z, elem Q, int* dispd) // Q is a very simple method in z, 
{                                           // if true then *dispd = place of htbv(Q in model [m1,...,mk];
 if(9) ipp("+vsmethod z= ", z, " Q= ", Q); bool r;
 lind(z, Q, dispd);
 r = *dispd != -1;
 if(9) ipp("-vsmethod z= ", z, " Q= ", Q, " r= ", r);
 return r;
} // end bool vsmethod(elem z,...)

  bool ismd1(elem d, elemp q, int nq, sbst* s)        // model:  q points to M-1; used only in Ismd;
{                                            // nq: model is q[1],...,q[nq];
 bool r = false; elemp ax,w; int i,i1,k,kax; elem y,z,t, test=zel; // sbst s;
 if(mm){ ippq1("+ismd1: d= ", d, " q= ", q+1, nq); s->psbs("+ismd1"); }
 assert(nq>0);
 if(nq==1 && ((t=typ(q[1]))==d || t==Abt1(d) || istr2(zin, q[1], d)))
 {
  ipp("ismd1:typ or Abt1 or istr2 discovered truth q[1] in d,  q[1]= ", q[1], " d= ", d); 
  s->adds(nami(d,1), q[1]);
  r = true; goto ret;
 } // if(nq==1 ...)
 if(d.i)                                    // d is a variable;
 {                                          // ??? d is d1 && P ???
  if(nq != 1) error("ismd1:d is var: wrong A[d,P](z), nq != 1, \nd= ", d, "\nnq= ", nq);
  t = tp(d); 
  if(t != zabterm) 
   ipp("ismd1:  d is not abterm, d= ", d);
  if(!istr2(zin, q[1], d)) error("ismd: not true: q[1] in d: d= ", d, " q[1]= ", q[1]);
 } //  if(d.i)
 if(!abterm(d,&k,&w,&ax,&kax))     // k = kmain(d);
 {
  if(mm) ipp("ismd1: not abterm, d= ", d, " nq= ", nq);
  goto ret;
 } // if(!abterm(...))
 if(k != nq)
 {
  if(9) ippq1("ismd1: wrong nq != k(d), \nd= ", d,  " \nq= ", q+1, nq);
  goto ret; 
 } // if(k != nq)
 // if(placeM + k >= KM) error("ismd1: model is too small, d= ", d, " k= ", k, " placeM= ", placeM, " KM= ", KM);
 for(i=0; i<kax; i++)
 {
  y = ax[i];  i1 = i+1;                   // y is the current axiom
  if(mm) ipp("ismd1:for: d= ", d, " ax[i]= ", y, " kax= ", kax, " i= ", i, " k= ", k);
  // if(fnt2(y,zin,&x,&t) && abtbvar(x,&d1) && d==d1 && int(x.i)==i+1 && i==0) r = fit(q[i+1],t);
  if(i < k)
  { 
   s->adds(nami(d,i1), q[i1]);
   t = typeax(y,d,i1); // ------------???? 6.24.22
   if(t != zel)
   { 
    t = s->rep(t, "ismd1:for:t=rep(t)");
    r = fit(q[i1],t); goto M; 
   } // if(t != zel)
  } // if(i < k)  
  z = repq(y,d,q,k);
  r = istr0(z);    // } // use rep !!!
  if(r) goto ret;        // elem tt::findelem(char* s);  "LfQ_AFN" LfQ_AFN := f|Q in AFN;
  test = ptt->fden("LfQ_AFN");
  r = ptt->istrf(z,'i',test); if(r){ ipp("ismd1: istrf discovered truth of z= ", z);  goto ret; }   // count ???
  { Lot L(z); r = L.innerinf(z); } 
  if(r){ ipp("ismd1: innerinf discovered truth of z= ", z); goto ret; }
  M: if(r == false) break; 
 } // for(i) 
 // if(++iard >= maxvars) error("ismd1: overflow of ard, d= ", d, " iard= ", iard);
 // ard[iard] = d; // ??? repetition ???
 // arpM[iard] = placeM; placeM += k;
 // qM += k; 
 ret: if(mm){ ipp("-ismd1: d= ", d, "\nk= ", k, "\nr= ", r); s->psbs("-ismd1"); }
 return r;
} // end ismd1

 bool ismd(elem d, elemp q, int nq, sbst** as)           //  z: d,d&&P, d&&d1, z&&P,z&&d;  model:  q points to M-1;
{                                             // nq: model is q[1],...,q[nq];  // REWORK !!! 2022.12.06 ???
 bool r=true; int i,k,m; elem y,d1,d2, lastd=zel; headp g; elemp w,qM = q; static sbst s;
 if(mm) ippq1("\n+ismd: d= ", d, " q= ", q+1, nq); 
 s.size = 0; k = lind(d);
 if(k != nq){ ipp("ismd: k != nq, d= ", d, " k= ", k, " nq= ", nq); r = false; }
 if(fnt2(d,zdconj, &d1, &d2) && Dterm(d2) && as == 0)
 {
  if(mm) ipp("ismd case d = d1 && d2, d= ", d, "\nd1= ", d1, " d2= ", d2, " nq= ", nq);
  if(nq==2)
  {
   if(mm) ipp("ismd case d = d1 && d2, nq=2, d= ", d, "\nq1= ", q[1], " q2= ", q[2], " nq= ", nq);
   if(!fit(q[1],d1)) error("ismd case d = d1 && d2, !fit(q[1],d1), d= ", d, "\nd1= ", d1, " q1= ", q[1]);
   if(!fit(q[2],d2)) error("ismd case d = d1 && d2, !fit(q[2],d2), d= ", d, "\nd2= ", d2, " q2= ", q[2]);
   goto ret;
  } // if(nq==2)
 } // if(fnt2(d,zdconj,...)
 for(i=0; i<=iD; i++)
 {
  y = D[i]; m = mel(y,&g,&w);
  if(m==abt)
  { 
   lastd = y; k = kmain(g); 
   r = r && ismd1(y,qM,k,&s); qM += k;
   if(r) continue; else goto ret; 
  } // if(m==abt)
  if(m != pfs) error("ismd: wrong z(not pfs), d= ", d, " D[i]= ", y, " i= ", i, " iD= ", iD);
  k = kmain(g);
  r = r && istrM(y, q);
  if(r) continue; else goto ret; 
 } // for(i=0);
 ret: if(r && as) *as = &s;
      if(mm){ ipp("-ismd: d= ", d, "\nnq= ", nq, "\nr= ", r); s.psbs("-ismd"); }
 return r;
} // end bool ismd(elem d, elemp q, int nq)

 bool equal(elem z, elem z1)       // r = istr2(zeq,z,z1) || istr2(zeq,z1,z);
{
 if(mm) ipp("+equal: z= ", z, "\nz1= ", z1); bool r=false; int static count=0;
 if(++count > 1)
 { 
  ipp("equal: recursive call: z= ", z, " z1= ", z1, " count= ", count); count = 1; goto ret;
 }
 r = istr2(zeq,z,z1) || istr2(zeq,z1,z);
 ret: --count; if(mm) ipp("-equal: z= ", z, " z1= ", z1, "\nr= ", r, " count= ", count);
 return r;
} // end equal

 int typcmpr1(elem t, elemp atz, elem z, achs* f)  // 1: tz <: t or z in t, 0: disjoint, 2: unknown;
{
 int r = 999; elem tz=*atz, tzv=zel;
 if(mm) ipp("+typcmpr1: t= ", t, "\ntz= ", *atz, "\nz= ", z); 
 // try
 { 
  r = typcmpr(t,atz,z,f);
  if(r==2)                     // && (tzv = valrt(tz)) != zel)
  { 
   if(comp(tz)) tzv = valrt(tz);
   if(tzv != zel)
   {
    if(mm) ipp("typcmpr:(tzv = valrt(*atz)) !=  trying r = typcmpr(t,&tzv,z,f) t= ", t, "\ntzv= ", tzv); 
    r = typcmpr(t,&tzv,z,f);
   } // if(tzv != zel)
  } // if(r==2 && ...)
 } // try{ 
 // catch( char* p){ ipp("typcmpr1: exception = ", p); r= 2; }                    // move to fit ?
 // catch(...){ error("typcmpr1:catch(...) t= ", t, "\ntz= ", *atz, "\nz= ", z); }
 if(mm){ ipp("-typcmpr1: t= ", t, "\ntz= ", *atz, "\nz= ", z, "\nr= ", r); }
  return r;
} // end int typcmpr1

  int typcmpr(elem t, elemp atz, elem z, achs* f)  // 1: tz <: t or z in t, 0: disjoint, 2: unknown;  
 {
  elem A,B,goal,Q,M,x, tz = *atz, t1,ft,ftz,st,stz; elemp ar;  headp h; elemp q; // bool p;  // ats k;
  int i,iar, savemm=mm, saveilot = ilot, r=2; static int count=0;
  if(mm){ ipp("\n+typcmpr: t= ", t, "\ntz= ", *atz, "\nz= ", z); prlot("+typcmpr"); }
  if(t.ad==stad && tz.ad==stad1)
  mm=mm;
  if(++count > 10) 
  { 
   error("typcmpr: big count > 10, possible recursion, t= ", t, " tz= ", *atz, " z= ", z, " count= ", count);
   // throw "rec count > 10 ";
   goto ret2;   //  count = 0; causes
  } // if(++count > 10)
  t1 = Abt1(t); if(t1 != zel) t = t1;
  if(tz==zany || tz==zset){ t1 = typlot(z); if(t1!=zel) tz = t1; } 
  if(t==tz || t==zset || t==zany || req(t,tz) || istr2(zeq,t,tz)) goto ret1;
  if(t==zbool || tz==zbool) goto ret0;              // ret0: disjoint, r==0;
  // if(disjoint(t,tz)) goto ret0;   // added on 6.5.20
  if(t==zany || t==zset || req(t,tz)) goto ret1;                // ret1: fit, r==1;
  if(z==zemp && (t==zset || fnt1(t,zP))) goto ret1;
  if(t==zabterm && Dterm(z)) goto ret1;
  if(inim(z,t)){ ipp("typcmpr:inim: found truth: z:f(x) in t:im(f), z= ", z, " t= ", t); goto ret1;  } 
  if(vterm(z,&Q,&M) && typ(M)==t && typ(Q) != t) goto ret0;   // elg.G <: elg.G1;  idubs: t=group; // 12.03.21; 
  if(fnt1(t,zP,&A) && (A==z || istr2(zincl,z,A))) goto ret1;  // A in P[A], z<:A -> z in P[A];
  if(istr2(zin,z,t)) goto ret1;
  if(t==zREL || t==zFN)
  {
   if(fntype(tz) || fnt2(tz,zdot,&A)&&fntype(A)) goto ret1; 
   iar = inthms2(z, &ar);
   if(mm) ipp("typcmpr: after inthms2, z= ", z, " iar= ", iar);
   for(i=0; i<=iar; i++) if(fntype(ar[i])) goto ret1;
  } // if(t==zREL || t==zFN)
  if(istr2(zincl, tz, t)) goto ret1; 
  if(atomic1s(tz,&ftz,&stz) && atomic1s(t,&ft,&st) && ftz==ft && monotonic(ft) && inlot2(zincl,stz,st))
    { if(99) ipp("typcmpr:monotonic:t= ", t, " tz= ", tz, " st= ", st, " stz= ", stz); goto ret1; }
  if(t==znat)
  {
   if(fnt2(tz,zseg, &A, &B) && A==zel0) goto ret1;     // 0..x <: nat;
   if(inlot2(zin,z,znat1)) goto ret1;
  } // if(t==znat
  
  if(t==znat1)
  {
   if(fnt2(tz,zseg, &A, &B) && A==zel1) goto ret1;     // 1..x <: nat1;
   if(z.m==ints && intval(z) > 0) goto ret1;           // 1,2,... <: nat1;
  } // if(t==znat1)
  
  if(t==zAFN && fnt1(tz,zafn)) goto ret1;
  if(f)
  {
   t1 = f->tfromach(z);
   if(t1 != zel && req(t1,t))
     { if(9) ipp("typcmpr: got type t1 from ach, z= ", z, " t1= ", t1, " t= ", t);   goto ret1; }
  } // if(f) 
  if(istr2eq(tz,t)) goto ret1;          
  if(istr2(zincl,tz,t)) goto ret1;
  if(istr2(zin,z,t)) goto ret1;
  if(istr2thms(zin,z,t)) goto ret1;              // added 11.26.21
  if(tplclos(z, trm2(zin,z,t,zbool))) goto ret1;
  iar = eqthms(z,&ar);
  for(i=0; i<=iar; i++) 
  if(istr2(zin,ar[i],t))
  {
   if(9)ipp("typcmpr: istr2 used eqthms for Z in t, z= ", z, " z=ar[i]= ", ar[i], " t= ", t);
   goto ret1;
  } // if(istr2(zin,ar[i],t)), for(i);
  iar = eqthms(t,&ar);
  for(i=0; i<=iar; i++)
  if(istr2(zin,z,ar[i]))
  {
   if(9)ipp("typcmpr: istr2 used eqthms for z in T, z= ", z, " t= ar[i]= ", ar[i], " t= ", t);
   goto ret1;
  } // if(istr2(zin,z,ar[i]))
  if(t==zint && (tz==znat || tz==znat1 || tz==znatm || isrt(tz, zseg))) goto ret1;
  if(t==zint && (inseqv(zFNtypes, tz) || isfnt(tz) || tz==zset) ) goto ret0; 
  if(tz==zany || tz==zset){ t1 = typtlot(z); if(t1 != zel){ tz = t1; *atz = tz;}} // was typtlot
  if(req(t,tz)) goto ret1;  // typtabt: infinite recursion: instance, typcmpr, typtabt !!!
  if(t==zSEQ && (tz==zSEQ1 || mel(tz,&h,&q)==pfs && (q[0]==zseq || q[0]==zseq1))) goto ret1;
  if(t==zSEQ1 && mel(tz,&h,&q)==pfs &&  q[0]==zseq1) goto ret1;
  if((t==zFN || t==zREL) && fntype(tz) ) goto ret1;
  if(fnt1(t,zP,&A) && fnt1(tz,zP1,&B) && req(A,B)) goto ret1;
  if(istr2(zincl,tz,t) || istr2(zin,tz, trm1(zP,t,zset)) || istr2(zin,z,t)) goto ret1;
  if(mel(t,&h,&q)==pfs && h->l==2 && fnt1(tz,q[0],&A) && istr2eq(q[1],A)) goto ret1;
  goal= trm2(zin,z,t,zbool);
  x = defrp(goal);
  if(istr0(x)) goto ret1;
  // if(mm) ipp("typcmpr: last: before lookfnt, z= ", z, " t= ", t, "\ngoal= ", goal, " itt= ", ptt->itt);
  // if(lookfnt(z, goal)) goto ret1;     // commented on 2022.11.16
  // try{
  // if(mm) ipp("typcmpr: last: before lookthms, z= ", z, " t= ", t, "\ngoal= ", goal);
  // if(lookthms(t, (*cond1), goal, zel)) goto ret1;
  // }
  // catch(char* p){ ipp("typcmpr:lookthms: exception p= ", p); goto ret2; }
  // if(99) ipp("typcmpr: last: before innerinf, z= ", z, " t= ", t, "\ngoal= ", goal, " itt= ", ptt->itt, " mm= ", mm);
  // {
  // Lot L(z);
  // if(L.innerinf(z)) goto ret1; 
  // } // end local block, "{ Lot L(z); ...}" 
  // goal = trm2(zin,z,t);
  // if(intabt(goal,ztrue)){ if(9) ipp("typcmpr: intabt discovered truth of goal, z= ", z, " goal= ", goal); goto ret1; }
  // if(addlot(t, goal)){ if(9) ipp("typcmpr: addlot discovered z= ", z, " diffilot= ", ilot-saveilot); goto ret1; }
  // if(addlot(tz, goal)){ if(9) ipp("typcmpr:tz: addlot discovered z= ", z, " diffilot= ", ilot-saveilot); goto ret1; }
  ret2: r = 2;  goto ret;    // 2: unknown;
  ret0: r = 0;  goto ret;    // 0: disjoint;
  ret1: r = 1;               // 1: OK!
  ret:  if(mm) ipp("-typcmpr: t= ", t, "\ntz= ", *atz, "\nz= ", z, " diffilot= ", ilot-saveilot, " r= ", r); 
        mm = savemm;
  if(--count < 0){ error("typcmpr: count< 0, t= ", t, " tz= ", *atz, " z= ", z, " count= ", count); count = 0; }
  return r;
} // end int typcmpr

   ats tt::clon2(att ad, headp hp, elemp q, ats bsz, ats bsz2,elem T) // allocates a new h1 (size(H) + bsz2*
{                                                                     // returns address T relativly q[0];
 headp hp1; elemp q1,qt1; ats i,k,k0,k1,bsz0; att rcheck;
 if(mm) ipp("+clon2 z= ", elm(curm,0,ad), " T= ", T, " bsz= ", bsz, " bsz2= ", bsz2, " ad= ", ad, " hp= ", int(hp));
 if(ww) checktabt("+clon2 elmcurm= ", elm(curm,0,ad));
 k0 = numson1(hp);            // k0: number of sons; ats numson1(headp h){ return (h->l); }
 hp1 = (headp) fylloc("clon2", sizeof(head)+(k0+bsz2)*sizeof(elem)); // new space
 *hp1 = *hp;                  // copy head; 0..k-1: sons and old theorems; k..k+kttm-1: new theorems;
 qt1 = thmbase(hp1);          // in tt::clon2: qt1 points to first theorem;
 k = k0 + bsz;                // k = old total numner of sons and theorems;
 k1 = k0 + bsz2;              // k1 = new total number of sons and theorems;
 q1 = &(hp1->son[0]);         // typ: copied with head;
 if(mm) *pfhis << "\nhp1= "<<int(hp1)<<" q1= "<<int(q1)<<" k= "<<k<<" k0= "<<k0<<" k1= "<<k1;
 if(mm) ph(hp, pfhis);
 for(i=0; i < k; i++) q1[i] = q[i]; // copied k sons and theorems from hp;
 q1[k] = T;                   // k points to new free space, size of it = bsz;
 // if(ww) checktabt("clon2:q1[k] = T; elmcurm= ", elm(curm,0,ad));
 for(i=k+1; i < k1; i++){ q1[i] = zel;  } // k1-(k+1) =  (k+bsz)-k-1 = bsz-1; + q[1] : all new theorem sp.
 hp1->lth = (bsz2== maxszthmbtabt? bsz2-1: bsz2);            // new lth = bsz * 2;
 if(mm) ph(hp1, pfhis);
 tabt[ad] = hp1; 
 bsz0 = bsz; bsz = bsz2;
 free(hp);
 if(mm) ipp("-clon2 z= ", elm(curm,0,ad), " T= ", T, " bsz= ", bsz, " bsz2= ", bsz2, " k= ", k);
 if(ww) if(rcheck = checktabt("-clon2 elmcurm= ", elm(curm,0,ad))) 
    error("checktabt T= ", T, " bsz0= ", bsz0, " bsz2= ", bsz2, " rcheck= ", rcheck) ;
 if(mm){ *pfhis<<"\n-clon2: Theorems"; for(i=0; i<int(hp1->lth); i++){ *pfhis<<"\ni= "<<i; pelm(q1[i], pfhis); } } 
 return k;
} // end clon2(att ad,...)

   ats tt::wrthmtabt(elem T, elem z, bool notval)        // write theorem T into tabt[z.ad] after sons;
{                                            // #[a,b] = b-a+1;  #[a,b) = b-a; #[0,1) = 1; #[0,1]=2;
 headp hp; elemp q,qt;  ats r,i,bsz, bsz2=0; att ad = z.ad; int savemm=mm; // elem yad = elm(mym,0,ad);
 if(z.ad == 0) mm=1;
 if(mm) ipp("+wrthmtabt T= ", T, "\nz= ", z, " notval= ", notval);
 if(notval && simple(T)) error("wrthmtabt: simple(T), T= ", T, " z= ", z);
 if(notval && ! Truth(T)) error("wrthmtabt: notval && ! Truth(T), T= ", T, "\nz= ", z);
 hp = tabt[ad]; assert(hp);
 if(mm){ *pfhis << "\nhp= "; prh(hp, pfhis); }
 q = &(hp->son[0]); qt = thmbase(hp);   // in tt::wrthmtabt
 bsz = hp->lth;    // assert // bsz: block size;
 if(bsz==0)
 { 
  if(mm) ipp("+wrthmtabt bsz=0, T= ", T, " z= ", z);
  r = clon2(ad,hp,q,bsz,4,T);
  goto ret;
 } // if(bsz==0)
 if(mm) ipp("wrthmtabt:bsz!=0, T= ", T, "\nz= ", z, "\nqt[0]= ", qt[0], "\nqt[1]= ", qt[1], "\nbsz= ", bsz,
              " qt= ", int(qt), " hp= ", int(hp), " hp->adt= ", hp->adt);
 
 for(i=0; i < bsz && qt[i] != zel; i++)     // empty body,  i: free place for writing T;
 { 
  if(qt[i]==T){ if(9) ipp("wrthmtabt: twice T: T= ", T, " z= ", z); r = i; goto ret; }
 } // if(i < bsz && qt[i] != zel )
 if(i < bsz)  // not changing lth, factually lth is block size !!!
 {
  qt[i] = T;
  if(mm) ipp("wrthmtabt:writing: qt[i]=T, T= ", T, " hp= ", int(hp), " qt= ", int(qt), " i= ", i);
  r = i; goto ret; 
 } // if(i < bsz)
 if(mm) ipp("wrthmtabt, l-block filled completely, T= ", T, "\nad= ", ad, " bsz= ", bsz);
 bsz2 = bsz*2;
 if(bsz2 > maxszthmbtabt)        // size1 =  hp->l + (?1)
  error("wrthmtabt: hpl2 >= maxszthmbtabt, T= ", T, " bsz2= ", bsz2, " maxszthmbtabt= ", maxszthmbtabt);
 r = clon2(ad,hp,q,bsz,bsz2,T);

 ret: if(mm){ ipp("\n-wrthmtabt T= ", T, "\nad= ", ad, " bsz= ", bsz, " r= ", r); prthms(z); } mm=savemm;  
      if(ww) checktabt("-wrthmtabt T= ", T);
      return r;
} // end tt::wrthmdtabt

  void tt::wrthm(elem T)      // for each subterm z of T write t into tabt[z] or den[z];
{                             // used only in mktr;
 // headp h=0; elemp q; char* s; char* s1;
 ats m,a,i,k; int lastart, savemm=mm; elem x; elem art[lsteq];  // #define lsteq 256
 // if(check(T.ad, stad2)) mm=1;
 if(mm) ipp("+wrthm T= ", T);
 // if(mel(T) != pfs) error("wrthm: mel(T) != pfs, T= ", T);
 if(badthm(T)) errorelm("wrthmden: wrong T= ", T);
 freet(T,art,&lastart);
 if(mm) ippq1("wrthm: after freet, T= ", T, " art= ", art, lastart+1);  // lastart+1: the number of el-s;
 for(i=0; i<=lastart; i++)
 {
  x = art[i]; m = x.m;
  if(m != curm && m != gpc)              // opb = (gpc, 91, 0) gpc == 247;
  {
   if(mm) ipp("istr:freet: x.m != curm, not imp.yet, T= ", T, " x= ", x, " x.m= " , m, " curm= ", curm);
   continue;
  } // if(m != curm && m != gpc)
  if(comp(x)) wrthmtabt(T, x);        // write theorem z into tabt[x.ad];
  else 
  { 
   a = avel(x);                          // x is simple;
   k = ptt->fdenaz(a,x);                 // k: index of x in den;
   if(k != -1) ptt->wrthmden(T,k);       // write theorem z into den[k]; ??? ptt ???
   else ipp("wrthm: wrong index in den, T= ", T, " k= ", k);
  } // else{ a = avel(x) ... }
 } // for(i);
  mm=savemm;
} // end void tt::wrthm(elem T)

 elem typeax(elem a, elem d, att i)  // a is i-th type axiom of d, i=1, ..., kmain;
{
 elem r=zel, x,t; headp h; elemp q;
 if(mm) ipp("+typeax: a= ", a, "\nd= ", d, "\ni= ", i);
 // if(badm(a.m)) error("typeax: bad a.m, d= ", d,  "\ni= ", i);
 if(mel(d,&h,&q) != abt) error("typeax: wrong(not abt) d= ", d);
 if(i <= 0 || i > kmain(h)){ if(mm) ipp("typeax: wrong i, d= ", d, " i= ", i); goto ret; }
 if(!fnt2(a,zin, &x, &t)){ if(mm) ipp("typeax: wrong a: not in-term,  a= ", a); goto ret; }
 if(htbv(x) != d || x.i != i){ if(mm) ipp("typeax: wrong x: not d.i bvar, x= ", x, "\nd= ", d, " i= ", i); goto ret; }
 r = t;
 ret:  if(mm) ipp("-typeax: a= ", a, "\nd= ", d, "\nr= ", r, " i= ", i);
       return r; 
} // end elem typeax(elem a, elem d, int i)

Lot::Lot(elem z){ itot = -1; count = -1; goal = z; }               // main constructor;

 void Lot::addtpthms(elem x0)      // add type theorems : x in t=typ(x), t in t1=typ(t), t1 in t2:=typ(t1), ...
{                                  // until trivt(ti): ti = set,any,REL,SEQ or i >= 10   
 if(mm) ipp("+addtpthms: x0= ", x0, " itot= ", itot);
 int i; elem z, x= x0, t = typ(x); // bool r=false;
 for(i=0; i < 10; i++)
 {
  if(trivt(t)) goto ret;         // bool trivt(elem t){ return t==zset || t==zany || t==zREL || t==zSEQ; } // ret1  
  if(istr2(zin,x,t,zel,&z)) add(z); // add(z): like wtot(z);
  else{ ipp("addtpthms: no type theorem for x, x0= " , x0, " x= ", x, " t= ", t); goto ret; }
  x = t; t = typ(x);
 } // for(i)
 error("addtpthms: too many linked type theorems, x0= ", x0); // 
 // ret1: r = true;
 ret: if(mm) print("-addtpthms x0= ", x0);
 // return r;
} // end void Lot::addtpthms(elem x) 

  bool Lot::wtotpat1(elem g, elem x, elem t, elem f) // pattern1: g(x,t) & f(t, &t1) -> g(x,t1);
{                                  //  x in t & t <: t1 -> x in t1;  x <: t & t <: t1 -> x <: t1;                                                                                  
  bool r = false; headp h; elemp q; int i; 
  if(mm) ipp("+wtotpat1 g= ", g, " x= ", x, " t= ", t, " f= ", f);  // 99: make mm;
  for(i= 0;i<=itot; i++)                                            // 2: trm2(...) == goal;
   if(fnt2h(tot[i], f, &h, &q) && q[1]==t) if(wrtot(trm2(g, x, q[2], zbool))==2){ r = true; break; } 
  if(mm) ipp("-wtotpat1 g= ", g, " x= ", x, " t= ", t, " f= ", f);
  return r;
} // end void wtotpat1(zin,x,t,zincl);

  att Lot::wrtot(elem z)     // r==1: already in tot, r==2: z==goal, r==0: not in tot;
{
 att r=0; ats i;  // c;
 if(mm) ipp("+wrtot z= ", z, " goal= ", goal, " ilot= ", ilot);
 if(z == zel)  error("wtot: wrong z= ", z);
 if(z.ad==stad2)
  mm=mm;
 if(z==goal){ if(9) ipp("wrtot: found z==goal, z= ", z, " goal= ", goal); r = 2; goto ret; }
 // if(itot > 8) goto ret;
 // c = cmpl(z);
 // if(c > maxc){ ippelm("wtot:not writing: too big z= ", z, " compl= ", c); goto ret; }
 for(i= 0; i<=itot; i++) if(req(tot[i], z)){ r = 1; goto ret; }  // already in tot;
 if(itot == maxvars-1)           // tot is full;  // maxvars=100=llot= size of tot;
 {
  if(++count==0){ print();  ipp("Lot::wrtot: overflow of tot, z= ", z, " itot= ", itot);  }  // not found in ar;
  if(count >= maxvars) error("Lot::wrtot: possible looping, z= ", z, " count= ", count);
  itot = -1; goto ret;
 } // if(++itot >= maxvars) 
 tot[++itot] = z;
 ret: if(mm) ipp("-wrtot z= ", z, " itot= ", itot, " r= ", r);
      return r;
} // end wrtot(elem z) 

 bool Lot::add(elem x)                   // write x into ar, if repetition, ipp; also check x=P[] or x=P1[];
{                                        // r=false: normal, r=true: overflow of tot;
 bool r=false; int i, k=itot; elem a,b,z; // headp h; elemp q; int hl;
 if(mm) ipp("+Lot::add: x= ", x, " itot= ", itot);
 for(i=0; i<=k; i++)
 {
  if(tot[i]==x){ ipp("Lot::add: x is already in ar, x= ", x, " i= ", i, " k= ", k); goto ret; }
 } // for(i)
 if(itot == maxvars-1)           // tot is full;
 {
  if(++count==0){ print(); ipp("Lot::add: overflow of tot, x= ", x, " itot= ", itot); }  // not found in ar;
  if(count >= maxvars) error("Lot::add: possible looping, x= ", x, " itot= ", itot); 
  r = true; itot = -1; goto ret;    // tot now is empty;
 } // if(itot == maxvars)
 tot[++itot] = x;
 if(fnt2(x,zconj,&a,&b)){ add(a); add(b); }
 z = defrp(x);     // ??? more general: look for all formulas of the form z' = x1;
 if(z!=zel) add(z); 
 ret: if(mm) ipp("-Lot::add: x= ", x, " itot= ", itot, " r= ", r);
      return r; 
} // end void Lot::add(elem x) 

 bool Lot::wtot(elem z, char* place) // write(wrtot) z into tot; then wrtot defrp(z); // defrp(z: x in P[t]) = x <: t;  
{
 // int hl, i, k=itot; elem a,b; headp h; elemp q; static ats count=0;
 bool r=false; elem x,tz; headp g; elemp w;  att r1;  ats static count1 = 0;
 if(mm) ipp("+wtot: z= ", z, " place= ", place, " itot= ", itot);
 // if(mm) ipp("+wtot z= ", z, " place= ", place, "\nitot= ", itot);
 if(++count1 > 20) 
  error("Lot::wtot: possible recursion: z=  ", z, " place= ", place, "\nitot= ", itot, " count1= ", count1);
 if(z.ad==stad2)
 mm=mm; 
 if(itot >= maxvars) error("wtot: impossible: too big itot, z= ", z, " itot= ",  itot);   // was goto ret;
 itot0 = itot; 
 tz = typ(z);         //  g->tp;   // was typ(z);  4/25/01
 // if(mm) ipp("wtot: z= ", z, " t= ", t);
 if(tz != zbool) error("wtot: not formula z= ", z, " tz= ", tz);
 if(r1 = wrtot(z)){ if(r1==2) r = true;  goto ret; }         // z is already in tot or z==goal;
 if(z == zfalse) { ipp("wtot: writing false!"); goto ret; }
 if(smel(z,&g,&w)){ if(mm) ipp("wtot: simple z= ", z, " itot= ", itot, " count= ", ++count);   goto ret; }
 x = defrp(z);     // ??? more general: look for all formulas of the form z' = x1;
 if(x==zel) goto ret; 
 if(wrtot(x)==2) r = true;
 ret: -- count1; if(mm) ipp("-wtot z= ", z, "\nitot= ", itot, " r= ", r); 
     return r;
} // end bool Lot::wtot(elem x) 

	bool Lot::innerinf(elem z)  // for each x = son of z add(wtot)  all thmbase_thms(x); //  from den or tabt;
{  // return true iff z is in lot or goal is in tot; TEMP !!! a simple version(not considering sons(x) is implemented !!!
 bool r=false; headp h,g; elemp q,w; elem x,d,T; ats i,j,k,a,hl;
 if(99) ipp("+innerinf z= ", z);
 if(mel(z,&h,&q) != pfs){ ipp("innerinf: wrong z(not pfs), z= ", z); goto ret; }
 for(i=0; i<=ilot; i++)
 {
  if((x=lot[i]) == z){ ipp("innerinf: the goal z is in lot, z= ", z); r = true; goto ret; }
  if(mel(x,&g,&w) == pfs && g->l==3 && (w[1]==q[1] || w[1]==q[2] || w[2]==q[1] || w[2]==q[2])) wtot(x,"x");
 } // for(i=0)
 a = comp(q[0])? 0:1;     hl = h->l;
 for(i=a; i<hl; i++)
 {
  x = q[i]; 
  if(abtbvar(x,&d,&h,&w)) if(r=wtot(w[x.i], "abtbvar")) goto ret;        // w points to d-axioms = 1;
  k = thmbase(x, &w);    // in Lot::innerinf(elem z);
  if(k>64){ ipp("innerinf:after thmbase: k>64, making k=64, old k= ", k); k = 64; }
  if(99) ipp("innerinf x= ", x, " i= ", i, " k= ", k); 
  for(j=0; j<k && (T = w[j]) != zel; j++) if(r=wtot(T,"T")) goto ret;
 } // for(i=a)
 if(99) ipp("innerinf before lclos, z= ", z);
 lclos();
 if(intot(goal)) r = true;
 ret: if(!r) print("-innerinf ");
 if(99) ipp("-innerinf z= ", z, " r= ", r);
 return r;
} // end bool innerinf(elem z)
 
 void Lot::lclos()                        // light closure of ar, using linf;
{
 int i,j,itot0,count=0; elem x; // int savemm = mm;
 if(mm) print("+Lot::lclos "); 
 do{
 itot0 = itot; ++count;
 for(i=itot0; i>=0; i--)
 for(j=0; j<i; j++)
 {
  x = linf(tot[i],tot[j]);                  // light inference
  //if(chch(ptt->tabt[13849]->tp, "while: after linf")) 
  //   ipp("lclos:chch: changed: tot[i]= ", tot[i], " tot[j]= ", tot[j], " i= ", i, " j= ", j);
  if(x != zel)
  { 
   if(add(x)) goto ret;                     // was overflow of tot;
   if(mm)ipp("lclos!!!, x= ", x, " itot= ", itot, "itot0= ", itot0, " count= ", count);
   if(x==goal){ if(9) ipp("lclos: x==goal!, x= ", x, " count= ", count); goto ret; }
  } // if(x != zel)
 } //for(j,i)
 } while( itot != itot0 && count <= 2) ;
 ret: if(mm) print("-Lot::lclos ");
 if(mm) ipp("-lclos itot= ", itot, "itot0= ", itot0, " count= ", count); // mm = savemm;
} // end void Lot::lclos() 
 
 bool Lot::intot(elem x)                      // checking if x is in ar;
{
 bool r=false; int i;
 if(mm) ipp("+Lot::intot: x= ", x);
 for(i=0; i<=itot; i++) if(tot[i]==x){ r= true; break; }
 if(mm) ipp("-Lot::intot: x= ", x, " r= ", r);
 return r;
} //  bool Lot::intot(elem x) 
               
 bool Lot::in2(elem f, elem x, elem y)  // checking if f(x,y) is in ar; // not using trm2;
{
 bool r=false;
 return r;
}   
      
 void Lot::print(char* s, elem x)        // print tot;
{
 *pfhis << "\n+Lot::print: " << s;  prp(x,pfhis); prp(" goal= ", goal, pfhis); *pfhis << " itot= " << itot << " mm= " << mm;
 cout << "\n+Lot::print: "<<s; prp(x); prp(" goal= ", goal); cout<<" itot= "<<itot<<" mm= "<<mm;
 for(int i = 0; i <= itot; i++)
 {
  *pfhis << "\n\n"<<i;  prp(") ", tot[i], pfhis);
  cout << "\n\n"<<i;  prp(") ", tot[i]);
 } // for(int i) 
 *pfhis << "\n-Lot::print"; cout << "\n-Lot::print";
} // void Lot::print(char* s, elem x)

 bool tplclos(elem x, elem goal)   // typ(x)=L, goal: x in elg; 
{
 Lot L(goal);
 if(mm) ipp("+tplclos: x= ", x, " goal= ", goal);
 L.addtpthms(x);                     // the unique occurrence;
 L.lclos();
 bool r = L.intot(goal);            // WAS l.intor(goal)
 if(r) ipp("-tplclos x= ", x, "\ngoal= ", goal);
 return r;
} // bool tplclos(elem x, elem goal)

  elemp firsecargthms(elem f, elem z, int n) // n: place of z, n=1: looking for z f x - lth-theorems(z), zel: means end;
{                                            // n=2: looking for x f z - lth-theorems(z)
 elem r = zel, T; int i,k,iar= -1; headp h; elemp q, w; elem static ar[lsbin]; // #define lsbin   16
 if(z.ad==stad1)
 mm=mm;
 if(mm) ipp("+firsecargthms: f= ", f, " z= ", z, " n= ", n);
 // if(comp(z)){ ar[0] = zel; goto ret; } 
 k = thmbase(z, &w);   // in firsecargthms(f,z,n): n: place of z, n=1: looking for z f x - 
 if(mm) ipp("firsecargthms: z= ", z, " k= ", k);
 for(i=0; i<k && (T = w[i]) != zel && (T.m == curm || scopeden(T) == zel); i++) // more checks if T.m == curm; 2022.11.06
 {              // for(i=0; i<k && accessible(T); i++)  // write a new function bool accessible(elem T);
  if(badm(T.m)) error("firsecargthms: wrong T.m, z= ", z, " k= ", k, " T.m= ", T.m);
  if(mm) ipp("firsecargthms:for: z= ", z, " w[i]= ", T, " i= ", i);
  if(z.ad == stad && i==stad1)
  mm=mm;
  if(mel(T,&h,&q)==pfs && h->l == 3)
  {
   r = zel;
   if(q[0]==f && q[n]==z) r = q[3-n]; // 3-n:  n=1:2, n=2:1  
   // else if(iseqequ(f)){ if(q[1]==z) r = q[2]; else if(q[2]==z) r = q[1]; } 
   if(r==zel) continue;
   // if(++iar >= lsbin) ipp("firsecargthms: overflow of ar, f= ",f, " z= ",z, " n= ", n, " iar= ", iar);
   if(iar < lsbin-2) wrlist(r,ar,&iar,lsbin);           // -1 : place for zel;  // ar[iar] = r;
   else ipp("firsecargthms: overflow(soon) of ar, f= ",f, " z= ",z, " n= ", n, " iar= ", iar);
   // if(q[0]==zincl && q[1]==z){ r = trm1(zP,q[2],zset); goto ret; };
  } // if(mel(x, ...)
 } // for(i)
 // if(++iar >= lsbin) ipp("firsecargthms:zel:overflow of ar, f= ",f," z= ",z, " n= ", n, " iar= ", iar);
 // if(iar >= lsbin) iar = lsbin-1;
  wrlist(zel,ar,&iar,lsbin);  // ar[iar] = zel; 
 if(mm) ipp("-firsecargthms: z= ", z, " ar= ", ar, iar);
      return ar;
} // end firsecargthms(elem f, ...); 

  elemp impequthms(elem z)                   // Look for thms z->P,z==P,P==z and write P into ar;
{
 int i,k,iar= -1; elem x,P; headp h; elemp q, w; elem static ar[lsbin]; int static count=0; // #define lsbin   16
 if(mm) ipp("+impequthms: z= ", z);
 if(++count > 1)
    error("impequthms: recursive call z= ", z, " count= ", count);
 k = thmbase(z, &w);
 for(i=0; i<k; i++)  // i = k; i>=0; i-- ???
 {
  x = w[i];
  if(badm(x.m)) error("impequthms: wrong x.m, z= ", z, " k= ", k, " x.m= ", x.m);
  if(mm) ipp("impequthms:for: z= ", z, " w[i]= ", x, " i= ", i);
  if(z.ad == stad && i==stad1)
  mm=mm;
  if(x==zel) break;
  if(mel(x,&h,&q)==pfs && h->l == 3)
  {
   if(q[0]!=zimp && q[0]!=zequ) continue;  // below q[0]==zimp or q[0]==zequ;
   P = zel;
   if(z==q[1]) P = q[2];
   else if(q[0]==zequ && z==q[2]) P = q[1]; 
   if(P==zel) continue;
   wrlist(P,ar,&iar,lsbin);           // -1 : place for zel;  // ar[iar] = r;
  } // if(mel(x, ...)
 } // for(i)
 wrlist(zel,ar,&iar,lsbin); 
 if(mm) ipp("-impequthms z= ", z, " ar= ", ar, iar); --count;
 return ar;
} // end elemp impequthms(elem z);

 bool lookthms(elem z, bool (*cond)(elem T, elem, elem), elem par1, elem par2) 
{                                   // a general function: look in thms for T such that cond(T,par1,par2)
 bool r = false; int i= -1, k,savemm = mm; elem T; elemp  w; int static count = 0;
 if(mm) ipp("+lookthms z= ", z, "\npar1= ", par1, " par2= ", par2);
 if(++count > 1){ ipp("lookthms: rec count > 1, z= ", z, "\npar1= ", par1, " count= ", count); goto ret; }
 // if(simple(z)){ ipp("lookthms: simple z= ", z); goto ret; }
 k = thmbase(z, &w);
 // if(k > 10) k = 10;
 for(i=0; i<k; i++)  // i = k; i>=0; i-- ???
 {
  T = w[i];
  if(mm) ipp("lookthms:for: T= ", T, " i= ", i);
  if(T==zel) break;
  try{
  if((*cond)(T, par1,par2)){ r = true; break; }
  } // try{
  catch(...)
  { 
   ipp("lookthms:catch z= ", z, " T= ", T, " par1= ", par1, " i= ", i);
   try{
   // mm=1;
   if((*cond)(T, par1,par2)){ r = true; break; }
   } // try{
   catch(...){ ipp("lookthms:catch:second: z= ", z, " T= ", T, " par1= ", par1, " i= ", i); continue; } 
  } // first catch(...)
 } // for(i)
 ret: if(99) ipp("-lookthms z= ", z, " par1= ", par1, " i= ", i, " r= ", r, " mm= ", mm);
      if(--count < 0) error("lookthms: (--count < 0), z= ", z, " count= ", count);
      // if(par1.ad==25241)
      // mm=mm;
 return r;
} // end bool lookthms;

 bool cond1(elem T, elem goal, elem par2)   // goal is an instance of T; or if T is A[d, P], then goal is an instance of P;
{
 bool r; sbst s; elem d, P;
 if(mm) ipp("+cond1 T= ", T, " goal= ", goal);
 r = s.instance(goal,T);
 if(r) goto ret;
 s.size = 0;
 if(fnt2(T,zA, &d, &P) && s.instance(goal,P,d)) r = true;
 ret: if(mm) ipp("-cond1 T= ", T, " goal= ", goal, " r= ", r);
 return r;
} // end bool cond1(elem T, 

 elem expdcl(elem z)  // expand(wrar) z  using an equiv-theorem T in thms(f)(z = f(...) or z = x in f(...);
{                     
 elem r=zel, f, P,Q,T; elemp q,w; ats i,k; sbst s;
 if(mm) ipp("+expdcl z= ", z);
 f = dclrin(z, &q);               // root(z) if atomic(z), but if z: x in f(..._) return f; // z: l([]) = 0;
 if(f==zel){ ipp("expdcl: f==zel: z= ", z); goto ret; }
 if(f==zeq) f = root(q[1]);
 k = thmbase(f, &w);  // in expdcl; look for an equiv-theorem T in thms(f)(z = f(...) or z = x in f(...);
 if(k>64){ ipp("expdcl:after thmbase: k>64, making k=64, old k= ", k); k = 64; }
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mm) ipp("expdcl:for: f= ", f, " w[i]= ", T, " i= ", i);
  // if(T==zel){ if(mm) ipp("expdcl: T==zel, z= ", z); goto ret; }
  if(req(z, T)){ ipp("expdcl discovered truth of z via T, z= ", z, " T= ", T); r = ztrue; goto ret; } 
  if(!fnt2(T, zequ, &P, &Q))
   { if(mm) ipp("expdcl: not equivalence, z= ", z, " T= ", T); continue; }
  if(s.instance(z,P))
  { 
   r = wrar(s.rep(Q,"expdcl")); 
   if(r==ztrue){ ipp("expdcl: wrar found truth of Q1, z= ", z, " P= ", P, " Q= ", Q, " r= ", r); goto ret; }
  } // if(s.instance(z,P))
  else ipp("expdcl: z is not instance of P, z= ", z, " T= ", T, " P= ", P, " s= ", &s); 
 } // for(i)
 ret: if(mm) ipp("-expdcl z= ", z, " r= ", r);
 return r;          
} // end elem expdcl(elem z);

 bool istrin1(elem z, elem t)   // look for T: z in t in thms(z); // or P -> z' in t;
{
 bool r=false;  ats i = -1, k; elemp w; elem a,b,T=zel; sbst s;
 if(mm) ipp("+istrin1 z= ", z, "\nt= ", t);
 k = thmbase(z, &w);     // in istrin1: look for (T:= z in t) in thms(z);
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mm) ipp("istrin1:for1: z= ", z, " T= ", T, " i= ", i); 
  if(fnt2(T,zin, &a, &b))
  { 
   if(b==t && req(z,a))
   { 
    if(mm) ipp("istrin:imp1: SUCCESS, z= ", z, " t= ", t, " T= ", T);
    r = true; goto ret; 
   } // if(b==t && req(z,a))
  } // if(fnt2(T,zin, &a, &b))
 } // for(i)
 ret: if(mm) ipp("-istrin1 z= ", z, "\nt= ", t, " r= ", r);
      return r;
} // end bool istrin1

 bool istrin(elem z, elem t)   // look for T: z' in t in thms(t); or P -> z' in t;
{
 bool r=false;  ats i = -1, k; elemp w;elem a,a1,b,b1,T=zel; sbst s;
 if(mm) ipp("+istrin z= ", z, "\nt= ", t);
  k = thmbase(t, &w);   // in istrin: look for (T:= z' in t) in thms(t);
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mm) ipp("istrin:for1: z= ", z, " T= ", T, " i= ", i); 
  if(fnt2(T,zin, &a, &b))
  { 
   if(b==t && s.instance(z,a))
   { if(mm) ipp("istrin:imp1: SUCCESS, z= ", z, " t= ", t, " T= ", T); r = true; goto ret; }
  } // if(fnt2(T,zin, &a, &b))
  else if(fnt2(T,zimp, &a, &b) && fnt2(b,zin,&a1,&b1) && b1==t )
  {
   if(mm) ipp("istrin: T is a->b, b is a1 in t, T= ", T, " a1= ", a1);  
   if(s.instance(z,a1) && istr0(s.rep(a,"istrin")))
   {
    if(mm) ipp("istrin:imp2: SUCCESS, z= ", z, " t= ", t, " T= ", T);
     r = true; goto ret;
   } // if(s.instance(z,a1) ...
  } // else if(fnt2(T,zimp, ...)
 } // for(i)
 
  k = thmbase(z, &w);   // in istrin: look for (T:= z in t1 & t1 <: t) in thms(t);;
 for(i=0; i<k && (T=w[i]) != zel; i++)  // i = k; i>=0; i-- ???
 {
  if(mm) ipp("istrin:for2: z= ", z, " T= ", T, " i= ", i); 
  if(fnt2(T,zin, &a, &b) && a==z && istr2(zincl,b,t)){ r = true; break; }
 } // for(i)
  
 ret: if(mm) ipp("-istrin z= ", z, "\nt= ", t, " T= ", T, " r= ", r);
 return r;
} // end bool istrin(elem z, elem t)
 
  void chilot(char* s, int newilot)   // change ilot;
{
 if(mm){ *pfhis << "\nchilot:"<<s<<" old ilot= "<<ilot<< " new ilot= "<< newilot;
         cout << "\nchilot:"<<s<<" old ilot= "<<ilot<< " new ilot= "<< newilot; }
 ilot = newilot;
} // end void chilot(char* s, int newilot)

//  void chiMod(char* s, int newiMod)   // change iMod;
// {
//  if(mm){ *pfhis << "\nchiMod:"<<s<<" old iMod= "<<iMod<< " new iMod= "<< newiMod;
//          cout << "\nchiMod:"<<s<<" old iMod= "<<iMod<< " new iMod= "<< newiMod; }
// iMod = newiMod;
// } // end void chiMod(char* s, int newiMod)


/* bool thax(elem z, elem* T)
{ 
 headp h; elemp q; bool r = false;
 if(mel(z,&h,&q)!=pfs) goto ret;
// if(q[0]==zexc1 || q[0]==zdexc){ r = true; *T = q[1]; goto ret; }
// if(h->t == truth){ r = true; *T = z; } 
 return r;
} */ // end thax
// end of lot.cpp
