#include "lib.h"    // 11/23/97 11/08/99 11/29/99 3/13/00 3/30/00
#include "myio.h"
#include "achs.h"
#include "sbs.h"
// #include "elem.h"
#include "tt.h"
#include "adl.h"  //  5/7/97 6/20/97  7/14/97
#include "typ.h"
#include "elem.h"
#include "term.h"
#include "prf.h"
#include "err.h"
#include "cr.h"
#include "assert.h"

#define lart 7
extern int dd,pdd,yy,cc,kk,qq,vv,zz,ll,ha,hb,notterm;
extern int aa,bb,ee,ff,hhh,ii,mm,oo,rrr,uu,its; // sizett, sizets;
extern ats avar;
extern elem yasop,ydexc,yexc; //zany1, zsome1, zeq, zequ, zfn, zbool, zexist, zmdot;
extern elemp wst1;
extern int iwst1, iasst, lasst, prcause; // maxmod1;
extern ats aExist, aExist1, aExistx, aAll;
extern elemp asst;
extern char source[80];
extern char fname[];
extern achs* pntu;
int hgt1(elem z);
void prlot(char* s);          // printing lot
                              // r=true: z is simple(m>245: ident,ubs ...), false: composite or z.i;
   bool adel(elem z,headp* ah,elemp* aq) 
{                             // inline bool wrongm(att m){ return m >= maxmod || clad[m] == 0; }
 static bool r; static headp h; att k, za=z.ad, m=z.m; ; tt* pnt; static ats count = 0;
 r = false;
 if(++count > 1)
 { 
  cout<<"\nERROR:adel ++count > 1 z.m= "<<m<<" z.i= "<<z.i <<" z.ad= "<<za<<" count= "<<count ;
  *pfhis<<"\nERROR:adel ++count > 1 z.m= "<<m<<" z.i= "<<z.i <<" z.ad= "<<za<<" count= "<<count ;
  pfhis->close();
  beep(2); exit(1);
 } // if(++count > 1)
 if(badm(m)) // not in extended use list; wrongm(m) == m >= maxmod || clad[m] == 0;
 {  // inline bool badm(att m){ return m < 245 && wrongm(m); }   // 245 = clp, 240..245: free space;
  cout<<"\nERROR: ADEL wrong mod m, z= ";
  pelm(z); 
  *pfhis<<"\nERROR: ADEL wrong mod m, z= "; 
  pelm(z, pfhis); 
  // goto ret;
  // ptt->futt(source);
  //  ptt->uden();
  prlot("adel");
  pntu->prach("adel");
  finish("ERROR:Adel in ", fname);
  myexit(1);         // assert(false); 
 } // if(wrongm(m)) 
 
 if(m >= maxmod){ r = true;  goto ret; }    // z is simple(ident,ubs,...)
 pnt = clad[m];             // already checked;
 
 k = pnt->lltt;
 if(za > k)   // ??? itt ???
 {
  cout<<"\nERROR: ADEL z.a > lltt, z.a= "<<za << " lltt= "<< k<<" z= "; pelm(z); 
  *pfhis<<"\nERROR: ADEL z.a > lltt, za=" << za << " lltt= "<< k<<" z= "; pelm(z, pfhis); 
  goto ret;
  pst("adel");
  myexit(1);              // 1: no fprp
 }
 h = clad[m]->tabt[za];
 //if(ah) *ah = clad[z.m]->tabt[za];
 //if(ah && (*ah) == 0) 
 if(h==0)
 {
  cout<<   "ERROR:adel h=0 z.m= "<<m<<" z.i= "<<z.i <<" z.ad= "<<za;
  *pfhis<< "ERROR:adel h=0 z.m= "<<m<<" z.i= "<<z.i <<" z.ad= "<<za;
  myexit(1);
 } // if(ah && (*ah) == 0)  
 if(ah) *ah = h;
 if(aq) *aq = &(h->son[0]);      // ++(*ah); did not work; 1.9.22;
 if(h && notterm) nstr = h->ln;
 ret: --count;                   // if(ee) cout<<"\n-adel ptt= "<<ptt;
 return r;
} // end adel

   att mel(elem z, headp *ah, elemp *aq, int place)
{
 if(ee)
 { 
  cout<<"\n+mel place="<<place<<" z= "; pelm(z);  // prp was wrong! 11/29/99
  *pfhis<<"\n+mel place="<<place<<" z= "; pelm(z, pfhis);
 }
 int r = con; headp vah,h1; elemp vaq,q1; elem x,x1;
 // if(z.m == bvr) { r = bvar; goto ret; }
 if(ah == 0) ah = &h1;
 if(aq == 0) aq = &q1;
 if(adel(z,ah,aq)) goto ret;  // simple(ident,ubs,...) // z.m >= maxmod // mel(zel)==con;
 vaq = *aq; vah = *ah;
 x = (vaq)[0]; x1 = (vaq)[1];
 if(ee) ipp("mel: z= ", z, " x= ", x, " x1= ", x1);
 if(z.i == 0)                     // composite: z.i == 0
 {
  r = (vah)->tel; 
  goto ret;
 } // z.i != 0                  // var or con or abbr or bvar or {x | P}(con??)

 if((vah)->tel == abt){ r = bvar; goto ret; } 
 if((vah)->tel == pfs)
 {	 
  if(x == yvar){ r = var; goto ret; }
  if(allex1(x)) //inline  bool allex1(elem a){ return a==zall || a==zexist || a==zexist1 || a==zexistx) || z==zexist1x }
  { 
   // error("mel: all or exist: z= ", z);
   r = bvar; goto ret;
  } // if(allex1(x))
  if(x == yasop && place==0)
  { 
   /*if(z.i != 1)
   {
	cout<<"\nmel:error:  z.i != 1: place="<<place<<" z= "; pelm(z);  // prp was wrong! 11/29/99
    *pfhis<<"\n+mel:error: z.i != 1: place="<<place<<" z= "; pelm(z, pfhis);
    myexit(1);  // assert(false);
   } */
   x1 = (vaq)[2];
   if(adel(x1, ah, aq)) goto ret; // z is x := x1; x1 is simple, r=con
   if(x1.i == 0)                     // composite
   {
    r = (vah)->tel; 
    goto ret;
   }
   cout<<"\nmel:error: wrong abbr: place="<<place<<" z= "; pelm(z);  // prp was wrong! 11/29/99
  *pfhis<<"\n+mel:error: wrong abbr: place="<<place<<" z= "; pelm(z, pfhis);
   myexit(1); // assert(false);  
  } // if(x == yasop && place == 0)
 } // if((*ah)->tel == pfs)
 ret: if(ee) 
	  {	  
		cout<<"\n-mel z="; pelm(z); cout<<" r= "<<r;  // prp was wrong! 11/29/99
        *pfhis<<"\n-mel z="; pelm(z, pfhis); *pfhis<<" r= "<<r;
      }
 return r;
} // end mel

   bool smel(elem z, headp *h, elemp *q)  // simple: con or var or bvar
{
 if(ee) { cout<<"\n+smel z="; prp(z); }   // ??? con: no h,q defined ???
 att m = mel(z,h,q); 
 return m==con || m==var || m==bvar;
} // end smel

/*   bool isseq(elem z, elemp *q, int *l)
{
 headp h;
 if(mel(z, &h, q) != psq) return false;
 *l = int(h->l);
 return true;
} // end isseq 
*/
     int len(headp h)
{
 int k=h->l;
 // if(h->tel == pfs)
 // {
 // if(h->t == keq || h->t == kimp) k+=1;
 // if(h->t ==keqim) k+=2;
 //  }
 return k;
} // end len(h)

   bool badel(elem z)   // bad element
{
 att m = z.m,  n, a = z.ad; tt* p; int static m1; bool r=false;
 if(m == ints || z==zel || z==zel1) goto ret;
 if(m == ident || m == ubs)
 {
  if(a <= its && z.i < 20) goto ret;
  cout<<"\nbadel: ident || ubs"<<" its= "<< its << " z.ad= " <<z .ad << " z.i= " << z.i;
  *pfhis<<"\nbadel: ident || ubs"<<" its= " << its<< " z.ad= " << z.ad <<" z.i= "<< z.i;
  r = true; goto ret;
 }
  if(wrongm(m))
 {
  cout<<"\nbadel: wrong m= " << m;    // <<" ieul= "<<ieul;
  *pfhis<<"\nbadel: wrong m= "<< m;   // <<" ieul= "<<ieul;
  r = true; goto ret;
 }
 p = clad[m];  n = p->itt;
 a = Att(z);
 if(a<0 || a > n || a > p->lltt)
 {
  cout<<"\nbadel: a = "<<a<<" itt="<<n;
  *pfhis<<"\nbadel: a = "<<a<<" itt="<<n;
  ipp("adel: badel: a= ", a);               // added 4/23/16
  r = true; goto ret;
 }
 if(z.i)
 {
  headp h; elemp q;
  if( adel(z, &h, &q) ) error("badel:adel: z= ", z);
  n = kmain(h);
  if(z.i <= n || dclname(z) || isvar(z)) goto ret;
  ippelm("badel: z.i > kmain(h), z= ", z);
  cout<<"\nbadel: z.i= " << z.i << " kmain(h)= " << n;
  *pfhis<<"\nbadel: z.i= " << z.i << " kmain(h)= " << n;
  r = true; goto ret;
 }
 ret: if(r==true)
 mm=mm;
 return r;
} // end badel

   bool iseq(elem z, elemp* w)     // = or ==
{
 if(hhh) ipp("+iseq z=", z);
 headp h; elemp q;  bool r=false;
 // z = valdexc(zz);         // ??? valabbr(zz,&h,&q)
 int m = mel(z,&h,&q); 
 if(m != pfs || q[0] != zeq && q[0] != zequ) goto ret;
 if(h->l != 3) error("iseq: wrong h->l= ", h->l);
 if(w) *w = q; // if(g) *g = h;
 r = true;
 ret: if(hhh) ipp("-iseq z=", z, " r= ", r);
 return r;  
}  // end iseq

   bool iseq(elem z, elem* a, elem* b)     // = or ==
{
 if(hhh) ipp("+iseq_ab z=", z);
 headp h; elemp q;  bool r=false;
 // z = valdexc(zz);         // ??? valabbr(zz,&h,&q)
 int m = mel(z,&h,&q); 
 if(m != pfs || q[0] != zeq && q[0] != zequ) goto ret;
 if(h->l != 3) error("iseq: wrong h->l= ", h->l);
 *a = q[1]; *b = q[2];
 r = true;
 ret: if(hhh) ipp("-iseq_ab z=", z, " r= ", r);
 return r;  
}  // end iseq

  bool iseqmn(elem z, elem* a, elem* b)     // = or ==
{
 if(mm) ipp("+iseqmn z=", z);
 headp h; elemp q,w;  bool r=true;
 if(iseq(z, &q)) { *a = q[1]; *b = q[2]; goto ret; } 
 if(fnt1(z,zmnbool,&q) && (iseq(q[1], &w) || fnt2h(q[1],zall,&h,&q) && iseq(q[2],&w) || 
                           fnt2h(q[1],zA,&h,&q) && iseq(q[2], &w)) )
 { 
  if(Truth(q[1]) && mel(z,&h)==pfs) h->t = truth;   // mktr(z): was wrong (var was made con)
  *a = w[2]; *b = w[1]; goto ret;  
 } // if(fnt1(z,zmnbool,&q))
 r = false; if(mm) ipp("iseqmn: not equality,mn,All,A[, z= ", z);
 ret: if(mm) ipp("-iseqmn z=", z, " r= ", r);
 return r;  
}  // end iseqmn

 bool iseqmn(elem z, bool mn, elem* a, elem* b)
{
 if(mm) ipp("+iseqmn z=", z, " mn= ", mn);
 elemp q; bool r = iseq(z, &q);  
 if(r)  
 { 
  if(mn){ *a = q[2]; *b = q[1]; }
  else{ *a = q[1]; *b = q[2];  } 
 } // if(r)
 if(mm) ipp("-iseqmn z=", z, " *a= ", r?*a:zel999, " *b= ", r?*b:zel999, " r= ", r);
 return r;
} // bool iseqmn(elem z, bool mn, ...) 

/*   elem pnot(elem a) // make not(
{
 elemp q;
 if(ee){ cout<<"\npnot a="; prp(a); }
 if(isrt(a,znot,&q)) return q[1];
 return trm1(znot,a,zbool);
}  // end pnot

   elem mnot(elem z)
{
 if(ee){ cout<<"\nmnot z="; prp(z); }
 headp h; elemp q; elem f,z1,z2;  int m;
 m=mel(z,&h,&q);
 if(m == con)
 {
  if(z == ztrue) return zfalse;
  if(z == zfalse) return ztrue;
  error("mnot:con z=",z);
 }
 if(m == var) return trm1(znot,z,zbool);
 if(m!=pfs) error("mnot z=",z);
 f=q[0];
 if(f == zdis)
  {
   z1=mnot(q[1]);
   z2=mnot(q[2]);
   return trm2(zconj,z1,z2,zbool);
  }
 if(f == zconj)
  {
   z1=mnot(q[1]);
   z2=mnot(q[2]);
   return trm2(zdis,z1,z2,zbool);
  }
 if(f == znot) return q[1];
 if(f == zimp)
  {
   z2=mnot(q[2]);
   return trm2(zconj,q[1],z2,zbool);
  }
 if(f == zexist) return trm2(zall,q[1],mnot(q[2]),zbool);
 if(f == zall) return trm2(zexist,q[1],mnot(q[2]),zbool);
 return trm1(znot,z,zbool);
} */ // end mnot

     int isrl(elem z, elem* a, elem* b) // is relation
{
 if(ee) ipp("isrl z= ", z);
 elemp q;  headp g; elemp w; int k;
 if(isrt(z,zfn, &q) &&
  seqv(q[1], &k, &w, &g) && g->l == 2 && q[2] == zbool)
 {
  *a = w[0]; *b = w[1];
  return 1;
 }
 return 0;
} // end isrl
  
     void assl(elem z, elem op, elemp a, int *ia, int la)
{
 if(ee) ipp("+assl *ia,z= ", *ia, z);
 headp h; elemp q; int i;
 if(smel(z,&h,&q) || q[0] != op)
 {
  if(++(*ia) >= la || *ia <0) error("assl: overflow *ia=",*ia);
  a[*ia] = z;
  if(ee) ipp("-assl *ia,z= ", *ia, z); // was cpp
  return;
 }
 for(i=1; i<int(h->l); i++) assl(q[i], op, a, ia,la);
 if(ee) ipp("-assl *ia,z= ", *ia, z);
} // end assl   


/*     void check(char* s)
{
 ptt->check(s);
}

	 elem valt(elem z) { return zel; }

   elem valt(elem z)   // value of t-elements 

{
 if(ee) ipp("+valt z= ", z);
 headp h; elemp q; elem r = zel;
 if(smel(z, &h, &q))  ipp("valt: simple z= ", z);
 else
 {
  int l = h->l; 
  switch (h->t)
  {
   case truth: r = ztrue; break;   
   
   case False: r = zfalse; break;
   
   case keq  : r = q[l]; break; // right part g: f=g
   
   case kimp : r = trm2(zif2, q[l], ztrue); break;
	      // premise p: p->q == q=if2(p,true)
  
   case keqim: r = trm2(zif2, q[l], q[l+1]); break;
	      // -1,-2:p,g:  p->f=g == f=if2(p,g)
  
   //default: error("valt switch z= ", z, " t= ", h->t);
  } // switch(h->t)
 } // else
 if(ee) ipp("-valt r= ", r);
 return r;
}*/ // end valt

/*   int iscn(elem z, int* v)          same as Ints
{
 if(z.m != ints) return 0;
 *v = intval(z);    // z.i OK, 12/02/99
 return 1;
}
*/
   bool fnt1h(elem z, headp* ah, elemp* aq)
{
 headp h; elemp q;
 if(mel(z,&h,&q)!= pfs) return false;
 if(h -> l != 2) return false;
 if(ah) *ah = h; if(aq) *aq = q;
 return true;
} // end bool fnt1h(elem z, ...)

   bool fnt(elem z, elem f, headp* ah, elemp* aq)
{
 headp h; elemp q;
 if(adel(z, &h, &q)) return false;
 assert(h->l > 1);
 if(h->tel != pfs || q[0] != f) return false;
 if(ah) *ah = h;
 if(aq) *aq = q;
 return true;
} // end bool fnt

   bool fnt1(elem z, elem f, elemp p1)
{
 headp h; elemp q;
 if(mel(z,&h,&q)!= pfs) return false;
 if(h -> l != 2) return false;
 if(q[0] != f) return false;
 if(p1) *p1 = q[1];
 return true;
} // end bool fnt1

   bool PP1(elem z, elemp* aq)                            // z is P[y] or P1[y];
{
 bool r; headp h; static elemp q;
 r = mel(z,&h,&q)==pfs && (q[0]==zP || q[0]==zP1);
 if(r && aq) *aq = q;
 return r;
} // end bool PP1

   bool fnt1(elem z, elem f, elemp* aq, headp* ah)
{
 headp h; elemp q; int m=mel(z,&h,&q); bool r = false;
 if(pp) ipp("+fnt1: z= ", z, " f= ", f," q[0]= ", m==pfs?q[0]:zel);
 if(m != pfs || h -> l != 2) goto ret;
 if(pp) ippelm("fnt1: f= ", f, " q[0]= ", q[0]);
 if(q[0] != f) goto ret;
 *aq = q;
 if(ah) *ah = h;
 r = true;
 ret: if(pp) ipp("-fnt1: z= ", z, " r= ", r);
      return r;
} // end bool fnt1


  bool fnt2(elem z, headp* ah, elemp* aq)
{
 headp h; elemp q;
 if(mel(z,&h,&q)!= pfs) return false;
 if(h -> l != 3) return false;
 if(ah) *ah = h; 
 if(aq) *aq = q;
 return true;
} // end bool fnt2


   bool fnt2(elem z, elem f, elemp p1, elemp p2)
{
 headp h; elemp q;
 if(mel(z,&h,&q)!= pfs) return false;
 if(h -> l != 3) return false;
 if(q[0] != f) return false;
 if(p1) *p1 = q[1]; 
 if(p2) *p2 = q[2];
 return true;
} // end bool fnt2

   bool fnt2h(elem z, elem f1, headp *ah, elemp *aq)
{
 headp h; elemp q;
 if(mel(z,&h,&q)!= pfs) return false;
 if(h -> l != 3) return false;
 if(q[0] != f1) return false;
 if(ah) *ah = h; 
 if(aq) *aq = q;
 return true;
} // end fnt2

   bool fnt12(elem z, elem f1, elem f2, elemp a, elemp b)           // f1(f2(a,b));
{
 headp h,g; elemp q,w; bool r;
 r = (mel(z,&h,&q) == pfs && h -> l == 2 && q[0] == f1 && mel(q[1], &g, &w) == pfs && g->l == 3 && w[0]==f2);
 if(r){ *a = w[1]; *b = w[2]; }
 return r;
} // end  bool fnt12

   bool fnt22r(elem z, elem f1, elem f2, elemp P1, elemp P2, elemp P3) // lr, 0:left, 1:right
{                                                                      //  P1 f1 (P2 f2 P3);
 elem y;            // elem p1, p2;
 if(!fnt2(z,f1, P1, &y)) return false;         // P1 -> P2 in P3; q[1] = P1, w[1] = P2, w[2] = P3;
 if(!fnt2(y,f2,P2,P3)) return false;
 return true;
} // end bool fnt22r

   bool fnt22l(elem z,elem f1,elem f2, elem* P1, elem* P2, elem* P3) // z = f1(f2(P1,P2),P3)
{                                               // z = P1 & P2 -> P3 // (x in f2) f1 R;
 elem y;
 if(!fnt2(z,f1,&y, P3)) return false;
 if(!fnt2(y,f2,P1,P2)) return false;
 return true; 
} // end bool fnt22l

   bool parsimp(elem z, elemp* hyp, elem* concl, int* lasthyp)           // parse an implication; lhyp: last;
{
 bool r; elem P, Q;
 if(mm) ipp("+parsimp z= ", z);
 r = fnt2(z, zimp, &P, &Q);
 if(!r) goto ret; 
 *hyp = linb(P, zconj, lasthyp);                            // linearization of p0&p1& ... &p_last;;
 *concl = Q;
 ret: if(mm) ipp("-parsimp z= ", z, " concl= ", *concl, " hyp= ", *hyp, *lasthyp);
 return r;
} // end bool parsimp(elem z, ...)

   elemp linb(elem z, elem f, int* lastar)       // linearization p_0 f p_1 f ... &p_last; // b: binary f;
{
 elemp r; elem y=z,P,Q; int iar=maxvars; static elem ar[maxvars];
 if(mm) ipp("+linb z= ", z, " maxvars= ", maxvars);
 while(fnt2(y,f,&P,&Q))
 {
  if(--iar < 0) error("parsb: --iar < 0, z= ", z, " y= ", y, " iar= ", iar);
  ar[iar] = Q;
  y = P;
 } // while(fnt2(y,f,&P,&Q))
 if(--iar < 0) error("parsb_last: --iar < 0, z= ", z, " y= ", y, " iar= ", iar);
 ar[iar] = y;
 r = &(ar[iar]);
 *lastar = maxvars-iar-1;
 if(mm) ipp("-linb z= ", z, " r= ", r, *lastar);
 return r;
} // end elemp linb(elem P, ...);

   bool eqPP1(elem z1, elem z2, elemp r1)                // z1 and z2 are P[y]  or P1[y];    
{
 bool r; elemp q1, q2;
 if(mm) ipp("+eqPP1 z1= ", z1, " z2= ", z2);
 r = PP1(z1, &q1) && PP1(z2, &q2) && q1[1]==q2[1]; 
 if(r1) *r1 = zset;
 if(r && r1)
 {
  if(q1[0]==q2[0]){ *r1 = z1; goto ret; }
  if(q1[0]==zP1){ *r1 = z2; goto ret; }
  if(q2[0]==zP1) *r1 = z1; 
 } // if(r && r1)
 ret: if(mm) ipp("-eqPP1 z1= ", z1, " z2= ", z2, "\nr1= ", r1==0? zel999: *r1, "\nr= ", r);
 return r;
} //  bool eqPP1

   bool inabt(elem z, elem* u, elem* v)         // z:  u in (v:={x1,...,xk ; F)
{                                               //   or u in v.M;
 bool r; elem x,t,t1;
 if(mm) ipp("+inabt z= ", z);
 r = fnt2(z,zin,&x,&t);                         
 if(r)
 {
  if(isst(t,&t1)){ if(mm) ipp("inabt:isst: t= ", t, "\nt1= ", t1); t = t1; }   // isst:8  inabt  check isst(t,&t)
  if(Dterm(t)){ *u = x; *v = t; } else r = 0;   // Dterm(t): t is abt-term or t is d&&...;
 } // if(r)
 if(mm) ipp("-inabt z= ", z, " r= ", r);
 return r;
} // end  bool inabt

   elem fnabt(ats x, elem v, headp h) // Find name x in abterm (v,h)
{
 int i,m; int k = -1; elem y, r = zel;
 if(rrr) ipp("+fnabt v= ", v, " x= ", x);    // || sss removed;
 assert(h->tel == pfs || h->tel == abt);
 assert(h->l > 0);
 m = kmain(h);
 for(i=1; i <= m; i++)
 {
  y = h->son[i];
  if(Ats(y) == x){ r = v; r.i = i; break; }
 }
 if(rrr) ipp("-fnabt r= ", r, " x= ", x);   // || sss removed;
 return r;
} // end elem fnabt

   bool abt1(elem d, elem* ax1, elem* x, elem* t)  // if(d is {x1; x1 in t1} return(ax1,x1,t1);
{ 
 headp h; elemp q; elem a,b; bool r;
 r = (mel(d,&h,&q)==abt && h->l==3 && kmain(h)==1 && fnt2(q[2],zin, &a, &b) && a.i==1 && a.m==d.m && a.ad==d.ad);
 if(r){ *ax1 = q[2]; *x = a; *t = b; }
 return r;
} // elem Abt1(elem d)

   elem Abt1(elem d)     // if(d is {x; x in t} return t else zel;
{ 
 elem ax1,x, t,r=zel;
 if(abt1(d,&ax1,&x, &t)) r = t;
 return r;
} // elem Abt1(elem d)

   bool Abt2(elem d, elem* t1, elem* t2)     // if(d is {x1,x2; x1 in t1, x2 in t2} return true(t1,t2);
{                //  bool typax(elem d, elem a, int j, elem* at)      // a is j-th type axiom in d;
 bool r; headp h; elemp q;
 r = mel(d,&h,&q)==abt && h->l==5 && kmain(h)==2 && typax(d,q[3],1,t1) && typax(d,q[4],2,t2);
 return r;
} // elem Abt1(elem d)


   elem axabt1(elem d)     // if(d is {x; x in t} return x in t else zel;
{ 
 elem ax1,x,t,r=zel;
 if(abt1(d,&ax1,&x,&t)) r = ax1;
 return r;
} // elem Abt1(elem d)

/*   elem valabbr(elem z) // actually valdexcval(x := z) = z, val(x) = z
{
 headp h; elemp q; elem r = z;
 if(bb) ipp("+valabbr z= ", z);
 if(r.m == ident) r.i = 0;               // for abterm, z.i = kmain
 if(adel(z, &h, &q)) { goto ret; }       // *ah = 0;
 if(ah) *ah = h; if(aq) *aq = q;
 {
  if(h->l != 3) error("valabbr h->l != 3, z= ", z);
  r = q[2];
  if(fnt2h(r, yasop, &h)) error("valabbr: asop in asop, z= ", z);	   
 }
ret: if(bb) ipp("-valabbr r= ", r);
     if(bb) if(r == z) ipp("valabbr: SAME! SAME! SAME !!! z= ", z); 
	    return r;
} // end elem valabbr

//   elem valdexc(elem z) // val(x := z) = z, val(x) = z
{
 headp h; elemp q; elem r = z;
 if(bb) ipp("+valdexc z= ", z);
 // if(r.m == ident) r.i = 0;               // for abterm, z.i = kmain
 if(adel(z, &h, &q)) goto ret;
 // if(ah) *ah = h; if(aq) *aq = q;
// if(h->tel == pfs && (q[0] == zdexc || q[0]==zexc1))
 {
  if(h->l != 2) error("valdexc h->l != 2, z= ", z);
  r = q[1];
  if(fnt1(r, zdexc)) error("valdexc: dexc in dexc, z= ", z);  // dexc is !!	   
 }
  ret: if(bb) ipp("-valdexc r= ", r);
	 return r;
}  // end elem valdexc
*/
   bool varc(elem z)   // z is a var or a con of a definition
{
 int m = mel(z);
 bool r = (m == con || m == var); // && z.vc; 
 if(ee) ipp("-varc z= ", z, " r= ", r);
 return r;
} // end varc

   bool dclname(elem z, headp* ah, elemp* aq, ats* a)  //  z is d.i & d is dcl[a, ..., t]
{
 headp h; elemp q; bool r = false;
 // if(mm) ipp("+dclname: z= ", z);
 if(z.ad==stad2)
 mm=mm;
 if(adel(z,&h,&q)) goto ret;        // z.m >= maxmod
 if(ah) *ah = h; 
 if(aq) *aq = q;                    // dcl[-,SEQ1, SEQ]: h->l = 4;  functional  dcl name
 r = z.i && Dcl(q[0]) && h->l >= 3 ; // Dcl(z): z.m==ident && int(z.ad)==adclb; dcl[true,bool]: h->l = 3: constant dcl name;
 if(r && a) *a = q[1].ad;           // dcl[a, ...]; 
 ret: // if(mm) ipp("-dclname: z= ", z, " q[0]= ", q[0], " h->l= ", h->l);
 return r;
} // end dclname

 bool dclname1(elem z, elemp t)
{
 bool r; headp h; elemp q; int hl1= -1; 
 if(mm) ipp("+dclname1 z= ", z);
 r  = dclname(z, &h, &q); if(r) r = (hl1 = int(h->l) - 1) >= 2;
 if(mm) ipp("+dclname1: after dclname(z,....), z= ", z, " hl1= ", hl1, " r= ", r);
 if(r&&t) *t = q[int(h->l)-1];
 if(mm) ipp("-dclname1 z= ", z, " t= ", r&&t? *t : zel999, " r= ", r);
  return r;  
}  // not constant, at least 1 parameter

 bool atomic(elem z, elemp* aq, ats* a) // mel(z,&h,aq)==pfs && dclname(q[0],,,a); 
{
 bool r = false; headp h,g; elemp w; 
 if(mm) ipp("+atomic z= ", z);
 if(mel(z,&h,aq) != pfs) goto ret;
 if(!dclname((*aq)[0],&g,&w,a)) goto ret;  //  bool dclname(elem z, ..., ats* a) z is d.i & d is dcl[a, ..., t]
 r = true;
 ret: if(mm) ipp("-atomic z= ", z, " q[0]= ", r? (*aq)[0]: zel, " r= ", r);
      return r;
} // end bool atomic(elem z, ... );

 bool atomic1s(elem z, elem* f, elem* st) // mel(z,&h,aq)==pfs && dclname(q[0],,,a) &&  h->l==2 && g->l==4 && w[2]==zset && ... 
{                               // h->l==2 && g->l==4 && w[2]==zset && w[3]==zset; 
 bool r = false; headp h,g; elemp q=0,w; 
 if(mm) ipp("+atomic1s z= ", z);
 if(z==zel0)
 mm=mm;
 if(mel(z,&h,&q) != pfs) goto ret;
 if(!dclname(q[0],&g,&w)) goto ret;  //  bool dclname(elem z, ..., ats* a) z is d.i & d is dcl[a, ..., t]
 r = h->l==2 && g->l==4 && w[2]==zset && w[3]==zset;    // dcl[seq,set,set];
 if(r){ *f = q[0]; *st = q[1]; }
 ret: if(mm) ipp("-atomic1s z= ", z, " f= ", q==0?zel999: q[0], " st= ", q==0?zel999:q[1], " r= ", r);
      return r;
} // end bool atomic(elem z, ... );

   elem dclrin(elem z, elemp* aq)         // f=zel; if z is atomic f(...) (or z in atomic f(...)) return f; dclrin(x in SEQ1)=SEQ1;
{
 elem f=zel; elemp q; ats a;
 if(mm) ipp("+dclrin z= ", z);
 if(! atomic(z, &q, &a)) goto ret;
 f = q[0];
 if(f==zin)                                                     // z0: a dclname
 {
  if(Dterm(q[2])){ f = q[2]; goto ret; }
  if(!atomic(q[2], &q, &a)){ f = zel; goto ret; }               // 2022.07.10: f = zel;
  f = q[0];    
 } // if(q[0]==zin)
 ret: if(aq != 0) *aq = q;  if(mm) ipp("-dclrin z= ", z, " f= ", f);
 return f;
} // end elem dclrin(elem z)
                                                                    // defrp(z in SEQ1) = z in SEQ & l(z) != 0;
 elem defrp(elem z)  // right part of def: defrp(x nin A) = ~(x in A); defrp(X in P[Y]) = X <: Y; 
{                     //  the defining axiom for f is the first theorem in den(f);                                             defrp(not dclterm) = zel; 
 elem r=zel, f,Ax0, P,Q; elemp w; ats k; sbst s;
 if(mm) ipp("+defrp z= ", z);
 f = dclrin(z);               // f=zel; if z is atomic f(...) (or z in atomic f(...)) return f;
 if(f==zel){ if(mm) ipp("defrp: f==zel: z= ", z); goto ret; }
 // ad = Fdenaz(a, z0);       // Fdenaz checks z0.m !!!             // ptt->fdenaz(a,z0);
 // if(ad < 0){ ipp("defrp: ad<0: z= ", z, " ad= ", ad); goto ret; }
 // Ax0 = (clad[z0.m]->den)[ad]->son[0];
 // if(f.i==0) error("defrp: f.i==0, z= ", z, " f= ", f);
 k = thmbase(f, &w);          // in elem defrp(elem z): looking for a defining axiom of f;
 Ax0 = w[0];                  // the defining axiom
 if(Ax0==zel){ if(mm) ipp("defrp: Ax0==zel, z= ", z); goto ret; }
 if(!fnt2(Ax0, zequ, &P, &Q))
   { if(mm) ipp("defrp: not equivalence, z= ", z, " Ax0= ", Ax0); goto ret; }
 if(s.instance(z,P)) r = s.rep(Q, "defrp");
 else if(99) ipp("defrp: possible? error: z is not instance of P, z= ", z, " P= ", P, " s= ", &s); 
 ret: if(mm) ipp("-defrp z= ", z, " r= ", r);
 return r;          
} // end elem defrp(elem z);

 bool monotonic(elem f)   // dcl-name f is monotonic: a theorem T := A<:B -> f(A)<:f(B) is in thms(f);
{
 bool r=false; ats i,k; elem T,P,Q,A,B,fA,fB,A1,B1; elemp w;
 if(mm) ipp("+monotonic f= ", f);
 k = thmbase(f, &w);      // in bool monotonic(elem f): looking for a theorem T := A<:B -> f(A)<:f(B)
 for(i=0; i<k && (T=w[i]) != zel; i++)  
 {
  if(mm) ipp("monotonic:for: f= ", f, " w[i]= ", T, " i= ", i);
  if(fnt2(T,zimp, &P,&Q) && fnt2(P,zincl, &A,&B) && fnt2(Q,zincl,&fA,&fB) && fnt1(fA,f,&A1) && fnt1(fB,f,&B1) &&
     A1==A && B1==B){ r = true; break; }
 } // for(i)
 if(mm) ipp("-monotonic f= ", f, " r= ", r);
 return r;
} // end bool monotonic(elem f) 

	bool overname(elem z)
{
 if(mm) ippelm("+overname: z= ", z);  bool r; elem d;
 r = dclname(z) || abtbvar(z, &d);  // r2 = isrt(z,zF); r = r1 || r2;
 if(mm) ipp("-overname: z= ", z, " r= ", r);  //  " r2= ", r2);
 return r; 
} // end bool overname(elem z)   

   bool Adp(elem x,elemp d,elemp P, elemp u, elemp t)
{
 headp h; elemp q; bool r = fnt2(x, zA, d, P)  && (mel(*d,&h,&q)==abt);
 if(r){ *t = zel; *u = zel; if(kmain(h)==1){ *u = nami(*d,1); *t = tp(*u); } }
 return r;
} // end Adp;

   ats npar(elem z)          // number of parameters of z: npar(=) = 2; npar(z) = 0, if unknown;
{                            // rework !!! add types ???
 ats r = 0; headp h; elemp q; att m; elem d,t;
 if(mm) ipp("+npar: z= ", z);
 if(z.i==0) goto ret;
 d = z; d.i = 0;    // d = host_term(
 m = mel(d,&h,&q);
 if(m==pfs && q[0]==zdclb)   // was if(dclname(z,&
 {
  r = h->l - 3;
  if(z.m==0 && z.ad < 37 || r < 0){ ipp("npar: z.ad < 37 || r < 0, z= ", z, " r= ", r); r= 0; goto ret; }
  if(r==0) r = nparfn(q[2]);        // && mel(q[2])==abt) r = kmain(q[2]); 
  goto ret;
 } // if(m==pfs ...)
 if(m==abt)
 {
  t = tp(z);
  if(mm) ipp("npar: z= ", z, " m==abt, t= ", t);
  r = nparfn(t);
 } // if(m==abt)
 ret: if(mm) ipp("-npar: z= ", z, " r= ", r);
      return r;
} // end ats npar(elem z)

  ats nparfn(elem t)          // number of parameters of t = fn(t1,t2,...,tr); 
{
 att r = 0, k; elemp w; elem t1;
 if(mm) ipp("nparfn: t= ", t);
 k = isrt(t, zfn, &w);
 if(k)                                         // fn(t1,t2, ..., tk);
 {
  if(k < 3) error("npar: m==abt: wrong t= ", t);
  if(k==3)
  {
   t1 = w[1]; 
   if(fnt2(t1, zdp)){ r = 2; goto ret; }       // t1 = A#B
   if(mel(t1)==abt){ r = kmain(t1); goto ret; }
  } // if(k==3) 
  r = k - 2;                                   // fn(t1,t2,tr), k=4, r=2;
 } // if(k)
 ret: if(mm) ipp("-nparfn: t= ", t, " r= ", r);
 return r;
} // end ats nparfn(elem t) 

  bool Truth(elem z, bool p)   // p: check for h->t == 3;
 {
  bool r = false; headp h; elemp q;
  if(mm) ipp("+Truth z= ", z, " p= ", p);
  if(z==ztrue) goto ret1;
  if(mel(z,&h,&q)!=pfs) goto ret;
  if(h->t == truth || p && h->t == truth3) goto ret1;
  if(q[0]==zconj && Truth(q[1],p) && Truth(q[2],p)){ h->t = truth; goto ret1; } // ???h->t = truth; ???mktr??? 5.19.21
  goto ret;
  ret1: r = true;
  ret: if(mm) ipp("-Truth z= ", z, "\np= ", p, " r= ", r);
      return r;
 } // end bool Truth(elem z); 
         
  elem stripalls(elem y)
 { 
  headp g; elemp w; elem y1 = y;  
  while(fnt2h(y1,zall,&g,&w)) y1 = w[2];
  if(y1 != y) ipp("stripalls: stripped: y= ", y, " y1= ", y1); 
  return y1; 
 } // elem stripalls(elem y)

  bool normd(elem d)  // d is normal: only type axioms in d;
{
 bool r=false; headp h; elemp q; att m,i, k, hl; elem x; 
 if(mm) ipp("+normd d= ", d);
 m = mel(d,&h,&q); 
 if(m==abt)
 {
  k = kmain(h); hl = h->l;
  // if(99) ipp("normd d= ", d, " k= ", k, " hl= ", hl, " q[2]= ", q[2]);
  if(hl != k*2+1) goto ret;
  for(i=k+1; i < hl; i++)
  {
   if(!fnt2(q[i], zin, &x)) goto ret;
   if(htbv(x) != d || int(x.i) != i-k) goto ret;
  } // for(i=k+1)
  r = true; goto ret;
 } // if(m==abt)
 if(m==pfs && h->l==3 && q[0]==zdconj) r = normd(q[1]) & normd(q[2]);
 ret: if(mm) ipp("-normd d= ", d, " r= ", r);
 return r;
} // bool normd(elem d)

  bool Dconj0(elem z, elemp d)           // z is d && x;
{ 
 headp h; elemp q; bool r = mel(z,&h,&q)==pfs && q[0]==zdconj; 
 if(r) if(mel(q[1])==abt) *d= q[1]; else error("Dconj0: temporally wrong(not abt) q[1], z= ", z);
 return r;
} // bool Dconj0

 elem Athabv(elem d)     // if d is unnamed and mel(d)==abt and Q := A[d,P] is a theorem above d then return Q, else zel;
{ 
 elem r = zel, d1; headp h;
 if(mm) ipp("+Athabv d= ", d);
 if(mel(d, &h) != abt || h->name != noname) goto ret;
 r = elm(d.m, 0, d.ad-1);                 // in tabt, normally, after A[d,P], d is located.
 if(!fnt2(r,zA,&d1) || d1 != d) r = zel;
 ret: if(mm) ipp("-Athabv d= ", d, " r= ", r);
      return r;
} // elem Athabv(elem d);

// end adl