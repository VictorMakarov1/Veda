#define lpar 2
/*&struct elemdef      // 11/24/99 2/10/00 5/13/00 5/27/00 11/22/00
{                   // 2/24/00 3/24/00 3/10/01
 unsigned m   :8;   // mode = def
 unsigned km  :8;   // number of main names
 unsigned modn:8;   // module where ts is situated
 unsigned fdv :1;   // flag of dv
 unsigned fdcl:1;   // flag of declaration
 unsigned fset:1;   // flag of set definition
 unsigned froot:1;  // flag of root definition
 unsigned rez :4;   // rezerv
};

struct elemd:elemh
{
 elem  thisd;        // this definition (term z)
 char isdef;         // 1 if thisd is a def, 0 otherwise
 elem par[lpar];     // parents (maximum 2 : lpar = 2)
 elemp pn;           // names
 elemp pt;           // types
 elemp pa;           // axioms
 //elemp pm;           // methods
 //elemp ps;           // stock
 int kpar;           // number of parents
 //int kam;            // number of methods
 int kax;            // number of "true(first)" axioms 
 int kaxth;          // number of axioms and theorems (including zel)
 int km;             // number of main names
 int dcl;            // flag of dcl
 int dv;             // con or var (for def or dv)
 int modn;           // module where TS is situated
 tt* pmodn;          // pmodn = clad[modn]
// sbst ss;            // substitution (x1->z1,  ...) see elemd::sbs
 elemd(elem z);      // constructor
 elemd();
 ~elemd(); 
                              // z1 - composite definition
 elem dcatf(elem z, elem z1); // catenation of thisd and formula z
 elem dcatd(elem z, elem z1); // catenation of thisd and definition z
 elem clond(headp* h, sbst* s); // cloning of thisd ( * s), h = h(clon) 
 elem field(char* s); // element-field for s
 elem namd(char* s);  // element-field or method for s
 elem namd(ats a);    // element-field or method for ats a (prr!)
 void sbs(elem z);    // substitution (x1->z1, ,,, )
 elem frm(elem z);    // formula "z in t & ax1(z) & ... & axk(z) 
 int IstrueAx(elemp q); // M = q[1], q[2], ...
 char* strd();        // string for definition (numbers of bool types)
 int IsMethod(elem z);// z is a field or method of thisd
 void meit(elem z);   // MEthods (incl. fields) of thisd in z
 elem pref(elem z, elem m); // Prefixes methods of thisd in z by m
 void prpd(ofstream* f); // Printing of thisd
 int Edp(elem edp);    // checking edp is E[d, p] - validation of d1 
 void hax();           // assigning truth to axioms
}; // end elemd

 struct elems:elemd
{
 int nvc;            // number of variable or constant
 elem typ;           // type of the variable or the constant
 char* svel;
 elems(elem z);      // constructor
 elem tafn(int i);   // type of i-th argument of (fn(d, r))
};  // end elems
*/

 void prpd(ofstream* f);  // pretty printing thisd;

elem elmdef(int km, int fdv, int modn = 0, int fdcl = 0, int fset = 0);
//int kpar(elemp q);
int km(elemp q);
int fdv(elemp q);
int fdcl(elemp q);
int fset(elemp q);
int froot(elemp q);

int ldev(elem d, elemp* pn=0, elemp* pt=0, elemp* pa=0, int* kax= 0);
int ldeva(elem d, elemp* pa, int* kax, int* kaxth=0);
int isdf(elem z, elemp* q=0);
int D_dcl(elem z);
elem clond(elem d);
elem clond(elem d, headp* h, sbst* s);
void dexp(elem z);
elem devc(elem x); // definition for a variable(or const) x
int numvc(elem x); // number of a variable (or const) x in def
int Consistent(elem d); // d is a consistent definition
int Relevant(elem d); // d is a root definition or ...
int InActiveChainAE(elem d); // d is in ach or A[d, p] in ach or ...
int fimp(elem z, elem d);  // z is a generic method of d
int varc(elem z);          // z is a var or a con of a definition
int dpar(elem z, elem d);  // z has the form "d".g
int depend(elem z, elem d); // z depends on d
// end df.h