// tran.h     // 2/11/2016

int prognum=0;     // term:0,     
int numtrm  = 1;   // trm
// int nummacr = 1;   // macr
int numbdef = 2;   // bdef
int numsortden=3;  // sortden
int numrnam =  4;   // rnam
int numtopt =  5;
int nummzcn =  6;   // ??? 1 or 2 ???
int numcthms = 7;
int numtyp  =  8;
int lvarsp =  12;   // smp
elem opp;  // openning  parenthesis
elem opb;  // openning  bracket, ? also use "seq", zseq: [a,b] -> seq(a,b)?;
elem opc;  // openning  curly brace
// elem clpar; // closing parenthesis
elem comma; // comma ","
elem semicolon; // semicolon ";"
elem mid ;  // | 
elem yexc;  // ! exclamation mark
elem ydexc;  // !! double exclamation mark
elem yvar;   // var special multiple symbol
elem zpostfix;   // elm(ident,0,wrts("postfix"));
elem ysuppose;
elem yfn,yif,yby,ybyeq;
void trans(char* M);
void hbin(char* M);        // handling of beginning of in
void post(int m);          // m has been just changed
void wrr(int m, int n);    // add n to rr[m]
void wrul(int m);
void rfts();               // read ts from file
void wfts();               // write ts to file
modsize_t findallm(char* s);  // find s in allm, if not in allm, error
void rfallm();             // read allm from file
void wfallm();             // write allm to file
modsize_t wallm(char* s);  // write s into allm into file allm.txt
void makezelm();           // make z-constants of the form elm(ident,...) or elm(ubs, ...)
ats afn,aeq,aimp,aconj,acol,acrl,amaid;

int aa, bb, cc, dd, ee, gg,ff,hhh, ii, jj, kk, ll,mm,nn,oo, pp, qq;  // ??? no ii: it is used differently in prf!
int ppp, rrr, sss, ttt, uu, vv, ww, xx, yy, zz, fff;


