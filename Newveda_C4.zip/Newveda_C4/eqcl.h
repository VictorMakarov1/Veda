// eqcl.h   12/07/00 05/16/01

elem eqvl(elem x, int p=0, sbst* s=0);   // p=1: find an instance of x 
elem esolv(elem d, elem p);  // solve E[d, p]: find an instance of p
elem eqvlot(elem z);
// elem eqcl(elem x, bool smel_exit);   // equality closure of x: into lot!
elem eqclot(elem z, elem sbt[], int ksbt, bool smel_exit);
elem eqcs(elem z, elem a, elem b, elem sbt[], int ksbt, bool smel_exit);
void wrsteq(elem z, int save = -1);  
void prsteq(char* s, elem z, int x);

