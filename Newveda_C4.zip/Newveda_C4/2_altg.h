﻿module 2_altg;                  // Newveda_C: 2_altg.v
use 0_root, 1_group; 
[
i_nat := {i; i in nat};
// !! LdconjA :=  A[z:d, z in d&&P == Rep(d,P,z)];     // error ??? 2022.12.05
!! Tfinset1 := X in finset1 == X in finset & X ~= {};  // rename existing Tfinset1 to Lfinset1;
!! Tfinset2 := X in finset & a in X & b in X & a ~= b -> #X > 1;
!! Tnat7 := n <= 1 -> (n=1 == ~(n=0));           // var n, nat;  // see root.v
!! TAFNIFN := AFN <: IFN;
AFN :: [ 
!! LAFNds := A[x:dom(f), x in ds == f(x) ~= x];
!! LAFNdsdom := ds <: dom(f);
!! LAFNdsid := ds={} == f = id(dom(f)); 
!! TAFNre := B <: dom(f) & f|B in AFN -> A[i:nat, b:B, ((f|B)^i)(b) = (f^i)(b)];
];

perm := AFN && (Axp := dom(f) in finset1);         // {f; f in afn(A) };    
! Tperm := g in perm == g in AFN & dom(g) in finset1;  byeq Axdconj;                 // // Axdconj := z in d&&P == z in d & Rep(d,P,z);
! LpermAFN := perm <: AFN;                         is LdconjIn;                     // !! LdconjIn := d&&P <: d; // !! TAFNREL := AFN <: REL;
! L00 := perm <: REL;                              is TIntrans(LpermAFN & TAFNREL); // ! TIntrans := X0 <: Y0 & Y0 <: Z0 -> X0 <: Z0; 
! LpermFN := perm <: FN;                           is TIntrans(LpermAFN & TAFNFN);  // for type checking in typ;
perm :: [
A := dom(f);
// x_A := {x; x in A};
! L0_type := A in finset1;    is Axp;
! L00 := f in afn(A);                              is L4;                      // AFN :: !! L4 := f in afn(dom(f));
! L07 := afn(A) <: AFN;                            is LafnAFN;                 // !! LafnAFN := afn(A) <: AFN;
! L05 := f in AFN;                                 is TinIn(L00 & L07);    
! L2 := f in perm;                                 by Axdconj; L05 & Axp;      // Axdconj := z in d&&P == z in d & Rep(d,P,z);
! L6 := A[g:afn(A), dom(g) = A];                   is Tafndom;                 // !! Tafndom := A[f: afn(A), dom(f) = A]; 
// ! L01 := A[i_nat, L01_type := f^i in afn(A)];      is Lf;                      // AFN :: !! Lf :=A[i_nat, Lf_type := f^i in afn(dom(f))]; 
// ! L02 := A[i_nat, dom(f^i) = A];                   is L6@AFN(f^(i@i_nat));        // is Tafndom(f^(i@i_nat));        
! L06 := A in finset;                              is TinIn(Axp & Lfinset1In); // ! TinIn := x in X2 & X2 <: Y2 -> x in Y2;
! Lim := A = im(f);                                is AxAFN2;                  // AxAFN2 := dom(f) = im(f)
n := #A;
// ds := {x: A; f(x) ~= x};                        moved to root;
ab_A := {a,b; a in A, b in A};
trp := F[ab_A, Trp(A,a,b)];                         // tr(a,b) \/ id(A--{a,b}]; // F[x:A, if5(x=a,b,x=b,a,x)]];

! L03 := A[ab_A, Ltrp_type := trp(a,b) in perm];
 Proof L03;
F0 := a in A;                                      assume;
Ltrp_type;                                         by Red("F");
G0 := Trp(A,a,b) in perm;                          by Axdconj; G1 & G2;        // Axdconj := z in d&&P == z in d & Rep(d,P,z);
G1 := Trp(A,a,b) in AFN;                           is LTrpAFN;                 // !! LTrpAFN := A[Aab, Trp(A,a,b) in AFN];
G2 := dom(Trp(A,a,b)) in finset1;                  by LTrpdom; is Axp;         // !! LTrpdom := A[Aab, dom(Trp(A,a,b)) = A];
 end Proof L03;

! L04 := A[ab_A, L04_type := trp(a,b) o f in perm];                            // for checking trp(a,b) o f;   
 Proof L04;
F0 := a in A;                          assume;                                 // !! Tafnin1 := f in afn(A) == f in AFN & dom(f)=A; 
F01 := Trp(A,a,b) o f in afn(A);       is LTrpcomp; by Tafnin1; F02 & F03;     // !! LTrpcomp := A[Aab, dom(f)=A -> Trp(A,a,b) o f in afn(A)]; 
F02 := Trp(A,a,b) o f in AFN;
F03 := dom(Trp(A,a,b) o f) = A;
L04_type;                              by Red("F");
G0 := Trp(A,a,b) o f in perm;          by Axdconj; F02 & G2;                   // Axdconj := z in d&&P == z in d & Rep(d,P,z); 
G2 := dom(Trp(A,a,b) o f) in finset1;  by F03; is Axp;
 end Proof L04;

! Lds1 := ds <: A;                    is TabIn;                                // !! TabIn := {x:X; P(x)} <: X;  // ds := {x: A; f(x) ~= x};
! Lds2 := ds in finset;               // is TfinsetIn(L06 & Lds1);             // !! TfinsetIn := A in finset & B <: A -> B in finset;
Lds2 & Lds3;                          is TfinsetIn1(L06 & Lds1);               // !! TfinsetIn1 := A in finset & B <: A -> B in finset & #A <= #B;
! Lds3 := #ds <= #A;                  
]; // perm :: [

perma := perm && {a; Ax2 := a in A; };   // perma := {f,a; Ax1 := f in perm; Ax2 := a in A@perm; }; 
perma :: [                         // !! Axlboundedint := A[S:P[int], lboundedint(S) == S ~= {} & E[a:int, a <= S] ];

orbf := F[i_nat, (f^i)(a)];        // orbit function 
! LorbfFN := orbf in FN;            is TFFN;                      // !! TFFN    := F[d, g] in FN;
! Lorbfdom := dom(orbf)=nat;        is TFdom1;                    // !! TFdom1 := dom(F[x:A, G(x)]) = A; 
! L08 := A[i_nat, (f^i)(a) in A];   is L5;                        // !! L5 := A[i_nat, A[a: dom(f), (f^i)(a) in dom(f)]]; 
! Lorbfim := im(orbf) <: A;         by TimFA; L08;                // !! TimFA := im(F[d, f]) <: B == A[d, f in B];
! Lorbfim1 := im(orbf) in finset;   is TfinsetIn(L06 & Lorbfim);  // !! TfinsetIn := A in finset & B <: A -> B in finset;  
! Lorbfim2 := fin(im(orbf));        by -Axfinset; Lorbfim1;       // !! Axfinset := X in finset == fin(X);  // ! L06 := A in finset;
! LorbfEij := Ex[i,j: nat, (L09 := i ~= j) & (L010 := orbf(i)=orbf(j))]; is TFN5@FN(Lorbfdom & Lorbfim2); 
! Lorbf0 := orbf(0) = a;            by Red("F"); is TAFN0;

! Lorbf1 := A[i_nat, orbf(i) in A]; by Red("F"); is L08;
k := abs(i-j);                                                    // FN :: !! TFN5 := dom(f)=nat & fin(im(f)) -> E[a,b:nat, a ~= b & f(a)=f(b)];
! Lk1 := k in nat1;                 is Labs3;                     // !! Labs3 := A[i,j:int, i ~= j -> abs(i-j) in nat1];
// ! Lk2 := k ~= 0;                    is Labs2(L09);                // !! Labs2 := A[i,j:int, i ~= j -> abs(i-j) ~= 0];
L010; by Red("F"); 
! Lk3 := (f^i)(a) = (f^j)(a);
! Lk4 := (f^k)(a) = a;              is L13(Lk3);                  // !! L13 := A[i,j:int, (f^i)(vd) = (f^j)(vd) -> (f^abs(i-j))(vd) = vd];
// !! Lk := k in nat & (k ~= 0 & (f^k)(a) = a);
S := {k:nat1; (f^k)(a)=a };         // because im(orbf) <: A, A is finite, so E[i,j:nat, i~=j & orbf(i)=orbf(j);
! LSk := k in S;  by Axab; Lk1 & Lk4;
! LS0 := S ~= {};                   is Tinnemp(LSk);              // ! Tinnemp := x in X -> X ~= {};  
! LSnat1 := S <: nat1;              is TabIn;                     // !! TabIn := {x:X; Q(x)} <: X;
! LS1 := S in lbint;                is Tlbint2(LSnat1 & LS0);     // !! Tlbint2 := S <: nat1 & S ~= {} -> S in lbint;
M := min(S);                        // dcl[min,lbint,int];

! LM0 := M in S;                    is Tmin1; by Axab; LM7 & LM3; // !! Tmin1 :=  A[S:lbint, min(S) in S];
! LM1 := M in nat;
// ! LM2 := M ~= 0;
! LM7 := M in nat1;                  // by Tnat1in1; LM1 & LM2;   // !! Tnat1in1 := x in nat1 == x in nat & x ~= 0;
! LM3 := (f^M)(a) = a;
! LM4 := A[k:1..M-1, ~((f^k)(a) = a)]; is Lmin4(LS1);              // !! Lmin4 := (S1 := {k:nat1; ff(i) }) in lbint -> A[i:1..min(S1)-1, ~ff(i)];
! L01 :=  A[i_nat, dom(f^(i%M)) = A];  is L14; // AFN :: L14 := dom(f^i) = dom(f);     // i_nat :: [ !! L01_type := i%M in nat; ];

! LM5 := A[i_nat, orbf(i) = orbf(i%M)];
 EqProof LM5;
F0 := i in nat;                        assume;
F01 := Ex[n:nat, F01a := i=n*M + i%M]; is Tnatres;  // !! Tnatres := A[i:nat, m:nat1, E[n:nat, i = n*m + i%m]]; // actually, E1[
F02 := orbf(i%M) = (f^(i%M))(a);       byeq Red("F");
F03 :=  A[n,r:nat, (f^(n*M+r))(a) = (f^r)(a)]; is L15(LM3); // !! L15 := A[m:nat1, a:dom(f), (f^m)(a) = a -> A[n,r:nat, (f^(n*m+r))(a) = (f^r)(a)]];
F1 := orbf(i);                         by Red("F");
F2 := (f^i)(a);                        by F01a;
F3 := (f^(n*M + i%M))(a);              by F03;  
F4 := (f^(i%M))(a);                    by -F02;
F5 := orbf(i%M);     
 end EqProof LM5;

! LM6 := A[i,j: 0..M-1, i ~= j -> orbf(i) ~= orbf(j)];   // injectivity;
 Proof LM6;
F0 := i in 0..M-1;                     assume;
F01 := j in 0..M-1;                    assume;
F02 := i ~= j;                         assume;
F03 := orbf(i) = orbf(j);              assume; by Red("F");
F1 := (f^i)(a) = (f^j)(a);
k := abs(i-j);
F2 := k in nat1;                       is Labs3;            // !! Labs3 := A[i,j:int, i ~= j -> abs(i-j) in nat1];
F3 := (f^k)(a) = a;                    is L16(F1);          // !! L16 := A[i,j:int, a:dom(f), (f^i)(a) = (f^j)(a) -> (f^abs(i-j))(a) = a];
F4 := k in S;                          by Axab; F2 & F3;
F5 := k < M;                           is Labs4(M,i,j)(F02);       // !! Labs4 := A[m:nat1, i,j: 0..m-1, i~=j -> abs(i-j) < m];
F6 := k nin S;                         is Tmin3(F5);        // !! Tmin3 :=  A[S:lbint,x:int, x < min(S) -> x nin S];
F7 := false;                           is Stautin(F4 & F6); //  ! Stautin := (x in X) & (x nin X) -> false;
 end Proof LM6;

! LM8 := A[i: 0..M-1, orbf(i) in A];   by Red("F"); is L08; // ! L08 := A[i_nat, (f^i)(a) in A];
! LM9 := 0..M-1 <: nat;
! LM10 := 0 in 0..M-1;                 is Tseg9;            // !! Tseg9 := 0 in 0..n1-1;              // var n1, nat1;
// !! Lorbf1 := orbf in seqp(nat,M);            // seqp(nat,M): periodic sequences of nat with period M;

sorb := F[i:0..M-1, orbf(i)];          
! Lsorb1 := sorb in seqinj(A);         by LFseqinj; LM8 & LM6;   // !! LFseqinj := F[x: 0..k, G(x)] in seqinj(A) == 
                                                                 // A[x: 0..k, G(x) in A] & A[x,y: 0..k, x~=y -> G(x) ~= G(y)];
Mp := [orbf, M];
! LMp := Mp in FNpnat;                 by Axab; LorbfFN & Lorbfdom & LM7 & LM5;

! Lsorb2 := im(sorb) = im(orbf);       is LFNpnatim.Mp;  // FNpnat :: !! LFNpnatim := im(F[k:0..p-1, f(k)]) = im(f); // orbf := F[i_nat, (f^i)(a)]; 

! Lsorb0 := seqinj(A) <: SEQ;          is LseqinjSEQ;  // !! LseqinjSEQ := seqinj(A) <: SEQ;  // A's are different: first: A := dom(f), other: var; 

! LsorbSEQ := sorb in SEQ;             is TinIn(Lsorb1 & Lsorb0); 
! Lsorb3 := l(sorb) = M;               is TFl;                        // !! TFl := l(F[i:0..n1-1, G(i)]) = n1;
                                                     // !! Axl := l(f) = #dom(f);
! L1 := im(sorb) in finset;            is LFimseg;   // !! LFimseg := im(F[i:0..k, G(i)]) in finset;
! Lsorb4 := #(im(sorb)) = M;           by -Lsorb3,2; is Lseqinj2(Lsorb1);   // Lseqinj2 := z in seqinj(A) -> #(im(z)) = l(z); // 2: M in sorb;

orb := im(orbf);                       // orbf := F[i_nat, (f^i)(a)];
! Lorb0 := orb = im(orbf);             is Axrefl;    // !! Axrefl := x = x; 
! Lorb1 := orb = im(sorb);             is -Lsorb2;    
! LorbR := orb = R[i:0..M-1, orbf(i)]; by Lorb1;     is TimF;               // !! TimF   := im(F[d, g]) = R[d, g];  
! Lorbfinset := orb in finset;         by LorbR;     is TfinsetRseg;        // !! TfinsetRseg := R[k:i..j, g] in finset;
! Lorbf01 := a = orbf(0);              is -Lorbf0;                          // ! Lorbf0 := orbf(0) = a; 

! Lorb2 := a in orb;                   by Lorbf01,1; is Tvalim(orbf,0);     // ! Lorbf01 := a = orbf(0); // fx :: !! Tvalim := f(x) in im(f);
/* Proof Lorb2;
F1 := a in orb;                        by LorbR;
F2 := a in R[i:0..M-1, orbf(i)];       by TRin;         // !! TRin := z in R[d,f] == E[d, z = f]; 
F3 := E[i:0..M-1, a = orbf(i)];        is Witness(0);   // uses ! LM10 := 0 in 0..M-1; and ! Lorbf01 := a = orbf(0);  
 end Proof Lorb2;
*/  
! Lorb3 := orb ~= {};                  is Tinnemp(Lorb2);                    // ! Tinnemp := x in X -> X ~= {};
! Lorbfinset1 := orb in finset1;       by Tfinset1;   Lorbfinset & Lorb3;
// !! Torb1 := orb = R[i:nat, (f^i)(a)];s
                                                                             // AFN :: !! LAFNinj := injective(f);
! Lorb4 := orb <: A;                   is Lorbfim;                           // ! Lorbfim := im(orbf) <: A; // orb := im(orbf); // A := dom(f);

! Lorb5 := A[x:orb, f(x) in orb];                                            // fA := {f, A; f in FN, A in set, AxfA1 := A <: dom(f) };  
 Proof Lorb5;                          // orbf := F[i_nat, (f^i)(a)];        // ! Lorb0 := orb = im(orbf);
F0 := x in orb;                        assume;  by TimFin;                   // !! TimFin := z in im(F[d,f]) == E[d, z = f]; 
F01 := Ex[i_nat, F01a := x = (f^i)(a)];
F02 := f(x) = (f^(i+1))(a);            byeq F01a, LAFN4;                     // AFN :: !! LAFN4 := A[x:dom(f),k:int, f((f^k)(x)) = (f^(k+1))(x)];
F03 := i+1 in nat;                     is Tnatadd;                           // Tnatadd := A[k,m:nat, k+m in nat];
G0 := f(x) in orb;                     by TimFin;
G1 := E[j:nat, f(x) = (f^j)(a)];       is Witness(i+1);  
 end Proof Lorb5;

! Lorb6 := f|orb in fn(orb,orb);       by Trein@fA; Lorb5;                   // fA :: !! Trein := A[B:set, f|A in fn(A,B) == A[x:A, f(x) in B]];
! Lorb7 := injective(f|orb);           is Tinjre@FN(Lorb4 & LAFNinj);        // !! Tinjre := A <: dom(f) & injective(f) -> injective(f|A); 
! Lorb8 := f|orb in afn(orb);          is Lafn2(Lorbfinset & Lorb6 & Lorb7); // !! Lafn2 := A in finset & f in fn(A,A) & injective(f) -> f in afn(A);
// ! Lorb8a := f|orb in AFN;           is TinIn(Lorb8 & TafnAFN);            // !! TafnAFN := afn(A) <: AFN;
trivorb := #orb = 1;                   // trivial orbit
ntrivorb := ~(#orb = 1);               // nontrivial orbit
]; // perma :: [

dsjp := F[f,g: perm, ds(f) NI ds(g)];      // dom(f) = dom(g) && ...

perm :: [  // 2
x_A := {x; x in A};   // var v_A, A;
! Lorbsin := A[x_A, orb(f,x) in orbs]; is TAinR;           // !! TAinR   := A[d, f in R[d,f]];
! L17 := A[x_A, orb(f,x) <: A];        is Lorb4(f,x@x_A);  // !! Lorb4 := orb <: A; 
! L18 :=  A[x_A, x in orb(f,x)];       is Lorb2(f,x@x_A);  // ! Lorb2 := a in orb;
! L18a := A[x:dom(f), x in orb(f,x)];  is L18;             // A := dom(f), rep can replace A with A.g, not dom(g);

! L18b := A[x:dom(f), f(x) in orb(f,x)]; 
 Proof L18b;
F0 := x in dom(f);                      assume;
F01 := x in orb(f,x);                   is L18a;
!! F02 := orb(f,x) <: dom(f);
F03 := A[z:orb(f,x), f(z) in orb(f,x)]; is Lorb5(f,x);     // ! Lorb5 := A[x:orb, f(x) in orb];
G0 := f(x) in orb(f,x);                 is F03(x);    // @perma;  
 end Proof L18b;

! L19 := A[x_A, orb(f,x) ~= {}];       is Lorb3(f,x@x_A);    // ! Lorb3 := orb ~= {}; // ??? commented 2022.11.25 (did not work: new eqadt);

orbs := R[x_A, orb(f,x)];              // x_A := {x; x in A}; 
!! Torbs := orbs(f) = R[x_A, orb(f,x)];  

Q_orbs := {Q; AxQ := Q in orbs};
! LQ_orbs := Q_orbs = orbs;            is Tabin;           // ! Tabin := {x; x in X} = X;                                                        
! L7 := orbs in finset;                is TfinsetR(L06);   // !! TfinsetR := X in finset -> R[x:X, g] in finset; // ! L06 := A in finset;
! L7a := Q_orbs in finset;             by LQ_orbs; L7;

Q_orbs :: [  // 1
! L0 := Ex[x_A, L0a := Q = orb(f,x)];  by -TRin; AxQ;                 // !! TRin := z in R[d,f] == E[d, z = f]; 
! LQnemp := Q ~= {};                   by L0a;  is L19;
! L01 := A = dom(f);                   is Axrefl;                     // !! Axrefl := x = x;
! LQA := Q <: A;                       by L0a; is Lorb4(f,x@x_A);     // ! Lorb4 := orb <: A;
! Lcorb1 := Q <: dom(f);               by -L01; LQA;                  // because dom(f) = (2,0,1630), A = (2,0,13); not merging for printing; req ???
! L8 := Q in finset;                   is TfinsetIn(L06 & LQA);       // !! TfinsetIn := A in finset & B <: A -> B in finset; / ! L06 := A in finset;
! L8a := Q in finset1;                 by Tfinset1; L8 & LQnemp;      // !! Tfinset1 := X in finset1 == X in finset & X ~= {}; 
! LfQ_type := f|Q in afn(Q);           by L0a; is Lorb8(f,x@x_A);     //  ! Lorb8 := f|orb in afn(orb); 
LfQ_type;                              by Tafnin1; LfQ_AFN & LfQ_dom; // !! Tafnin1 := f in afn(A) == f in AFN & dom(f)=A;
! LfQ_AFN := f|Q in AFN;
! LfQ_dom := dom(f|Q) = Q; 
! LfQ_dom1 := dom(f|Q) <: A;           by LfQ_dom; LQA;  
! LfQ_dom2 := dom(f|Q) in finset1;     by LfQ_dom; L8a;
! LfQ_perm := f|Q in perm;             by Tperm;  LfQ_AFN & LfQ_dom2; // ! Tperm := g in perm == g in AFN & dom(g) in finset1; 

! LfQ_orbs := orbs(f|Q) = {Q};
 EqProof LfQ_orbs;
F1 := orbs(f|Q);                       by 

 end EqProof LfQ_orbs;
]; // Q_orbs:: [  // 1
                                                          
! L20 := A[x_A, orb(f,x) = im(orbf(f,x))]; is Lorb0(f, x@L20);  // ! Lorb0 := orb = im(orbf);

! Lorbf_fx := A[x_A, orbf(f,x) = F[i_nat, (f^i)(x)] ];         byeq Red;

! Lorb_fx := A[x_A, orb(f,x) = im(F[i_nat, (f^i)(x)])];        by -Lorbf_fx; L20;

! L21 := A[x:A, k:nat, orbf(f,(f^k)(x)) = F[i_nat, orbf(f,x)(i+k)] ];
 EqProof L21;
F0 := x in A;                          assume;         
F01 := orbf(f,x) = F[i_nat, (f^i)(x)];                         byeq Red;
F02 := F[i_nat, orbf(f,x)(i+k)] = F[i_nat, (f^(i+k))(x)];      byeq F01, Red("F");  // orbf := F[i_nat, (f^i)(a)];
F1 := orbf(f,(f^k)(x));                by Red;
F2 := F[i_nat, (f^i)((f^k)(x))];       by TAFN3;     // AFN :: !! TAFN3 := A[x:dom(f),i,k:int, (f^i)(f(k)(x)) = (f^(i+k))(x)];
F3 := F[i_nat, (f^(i+k))(x)];          by -F02;
F4 := F[i_nat, orbf(f,x)(i+k)];
 end EqProof L21;

// Mpfx := [orbf(f,x), M(f,x)];

// ! LMpfx := A[x_A, Mpfx in FNpnat];     is LMp(f,x@x_A);            // ! LMp := Mp in FNpnat;    // Mp := [orbf, M];  

! L22 := A[x,y:A, y in orb(f,x) == orb(f,y) = orb(f,x)];
 Proof L22;
F0 := x in A;                          assume;
F01 := y in A;                         assume;  
G0 := y in orb(f,x) == orb(f,y) = orb(f,x); by Deqv; L1 & L2;

L1 := y in orb(f,x) -> orb(f,y) = orb(f,x);
  EqProof L1;                                  
F02 := y in orb(f,x);                  assume; by Lorb_fx,TimFin; // !! TimFin := z in im(F[d,f]) == E[d, z = f];
F03 := Ex[k:nat, F03a := y = (f^k)(x)];                           // ! Lorb_fx := A[x_A, orb(f,x) = im(F[i_nat, (f^i)(x)])];
Mpfx := [orbf(f,x), (M@perma)(f,x)];
! LMpfx := Mpfx in FNpnat;             is LMp(f,x);               // ! LMp := Mp in FNpnat;    // Mp := [orbf, M];  
F1 := orb(f,y);                        by F03a;
F2 := orb(f, (f^k)(x) );               by L20;                    // ! L20 := A[x_A, orb(f,x) = im(orbf(f,x))];
F3 := im(orbf(f, (f^k)(x) ));          by L21;                    // ! L21 := A[x:A, k:nat, orbf(f,(f^k)(x)) = F[i_nat, orbf(f,x)(i+k)] ]; 
F4 := im( F[i_nat, orbf(f,x)(i+k)]);   by LFNpnatim1.Mpfx;        // FNpnat :: !! LFNpnatim1 := A[k:nat, im(F[i_nat, f(i+k)]) = im(f)];  
F5 := im(orbf(f,x));                   by -L20;
F6 := orb(f,x);
  end EqProof L1;

L2 := orb(f,y) = orb(f,x) -> y in orb(f,x);
  Proof L2;
F0 := orb(f,y) = orb(f,x);             assume;
F1 := y in orb(f,y);                   is L18; by F0;             // ! L18 := A[x_A, x in orb(f,x)]; 
F2 := y in orb(f,x);
  end Proof L2;
 end Proof L22;

! LorbsU := U[x_A, orb(f,x)] = A;      is TUIn1(L17 & L18);  // !! TUIn1 := A[x:A, G(x) <: A] & A[x:A, x in G(x)] -> U[x:A, G(x)] = A;
! Lorbsun := union(orbs) = A;          by -TUunion; LorbsU;  // !! TUunion := U[d,w] = union(R[d,w]);
! Lorbsnemp := A[z:orbs, z ~= {}];     by TAR; L19;          // !! TAR  := A[x: R[d, f], Q(x)] == A[d, Q(f) ];  

// !! L23 := A[Q_orbs, Q <: A];          // orbs := R[x_A, orb(f,x)]; 

! L24 := A[Q:orbs,x:Q, x in A & Q = orb(f,x)];
 Proof L24;
F0 := Q in orbs;                      assume;    by TRin;         // !! TRin := z in R[d,f] == E[d, z = f]; // orbs := R[x_A, orb(f,x)];
F00 := Ex[y:A, F0a := Q = orb(f,y)];
F01 := Q <: A;                        by F0a; is L17;             // ! L17 := A[x_A, orb(f,x) <: A];
F02 := x in Q;                        assume; by F0a;
F03 := x in orb(f,y);                 by L22;
F04 := orb(f,x) = orb(f,y);                                       // is L22(F03);
G1 := x in A;                         is TinIn(F02 & F01);
G2 := Q = orb(f,x);                   by F04;  F0a;
 end Proof L24;

! LorbsNI := A[Q,Q1:orbs, Q /\ Q1 ~= {} -> Q = Q1];
 Proof LorbsNI;
F0 := Q in orbs;                        assume;  // by TRin;         // !! TRin := z in R[d,f] == E[d, z = f]; // orbs := R[x_A, orb(f,x)];
// F00 := Ex[y:A, F0a := Q = orb(f,y)];
F01 := Q1 in orbs;                      assume;  // by TRin; 
// F02 := Ex[x1:A, F02a := Q = orb(f,x1)];
F03 := Q /\ Q1 ~= {};                   assume;  by TInempE;      // ! TInempE := A/\B ~= {} == Exist(x, x in A & x in B); byeq TinnempE, AxI;
F04 := Existx(x, (F04a := x in Q) & (F04b := x in Q1));
(F02 := x in A) & (F1 := Q = orb(f,x)); is L24(Q,x);
F02 & (F2 := Q1 = orb(f,x));            is L24(Q1,x);
F3 := Q = Q1;                           is Axeq2(F1 & F2);        // !! Axeq2 := x=a & y=a -> x=y;
 end Proof LorbsNI;

part := [A,orbs];                        // !! Tprtin := [A,B] in partition == union(B)=A & A[Q:B, Q ~= {}] & A[Q1,Q2:B,  Q1/\Q2 ~= {} -> Q1=Q2]; 
! Lpart := part in partition;           by Tprtin; Lorbsun & Lorbsnemp & LorbsNI;

! LorbsE := All(Q, Q in orbs == E[x:A, Q = orb(f,x)]);     is TRin;  // !! TRin := z in R[d,f] == E[d, z = f]; 
                                                                     // we are in perm;
ntorbs := Q_orbs && #Q > 1;             // nontrivial orbits; // Q_orbs := {Q; Q in orbs}; 

// ! Tntorbs := A[Q_orbs, Q in ntorbs == #Q > 1];             is LdconjA;  // !! LdconjA :=  A[z:d, z in d&&P == Rep(d,P,z)]; 

! Lntorbs := A[Q_orbs, A[a,b:Q, a ~= b -> Q in ntorbs]];
 Proof Lntorbs;
F0 := Q in orbs;                        assume;
F01:= a in Q;                           assume;
F02:= b in Q;                           assume;
F03 := a ~= b;                          assume;                                   // !! Tfinset2 := X in finset & a in X & b in X & a ~= b -> #X > 1;                       
F1 := #Q > 1;                           is Tfinset2(L8@Q_orbs & F01 & F02 & F03); // Q_orbs :: ! L8 := Q in finset;
F2 := Q in ntorbs;                      by Axdconj; F0 & F1;                      // !! Axdconj := z in (d&&P) == z in d & Rep(d,P,z);
 end Proof Lntorbs;

! L9 := ntorbs in finset;               is Ldconjfs(L7a);     // ! L7a := Q_orbs in finset; // !! Ldconjfs := d in finset -> d&&P in finset;

! Lntorbs1 := A[x:dom(f), f(x) ~= x -> orb(f,x) in ntorbs];   // A := dom(f);
 Proof Lntorbs1;
F0 := x in dom(f);                       assume;
F01 := f(x) ~= x;                        assume;                     
F1 := x in orb(f,x);                     is L18;                             // ! L18 := A[x_A, x in orb(f,x)]; 
F2 := f(x) in orb(f,x);                  is L18b;                            // !! L18b := A[x:dom(f), f(x) in orb(f,x)]; 
F3 := orb(f,x) in ntorbs;                is Lntorbs(orb(f,x))(f(x),x)(F01);  // ! Lntorbs := A[Q_orbs, A[a,b:Q, a ~= b -> Q in ntorbs]];
 end  Proof Lntorbs1;

dsc := #ds + #ntorbs;                          //even(dsc(f)) == even(f);
evenp := even(dsc);                            // evenp(f): f is an even permutation iff even(dsc(f)); // ab_A := {a,b; a in A, b in A};

! Lds4 := ds ~= {} -> ntorbs ~= {};            // == ??? 2022.12.03 ???
 Proof Lds4;
F0 := ds ~= {};       assume;                  // ds := {x: dom(f); f(x) ~= x};
x := arb(ds);                      
F01 := x in ds;       is Axarb(F0);             by Axab; F02 & F03;  // !! Axarb := X ~= {} == arb(X) in X;
F02 := x in A;                                  // A := dom(f);
F03 := f(x) ~= x;
F04 := R <: A;                                  is Lorb4(f,x);       // ! Lorb4 := orb <: A; 
F05 := A[z:R, f(z) in R];                       is Lorb5(f,x);       // perma :: ! Lorb5 := A[x:orb, f(x) in orb]; 
R := orb(f,x);
F1 := R in Q_orbs;    by LQ_orbs;               is Lorbsin;          // ! LQ_orbs := Q_orbs = orbs; // ! Lorbsin := A[x_A, orb(f,x) in orbs];
F2 := R in finset;    is Lorbfinset(f,x);                            // ! Lorbfinset := orb in finset;
F3 := x in R;         is Lorb2(f,x);                                 // perma :: ! Lorb2 := a in orb; 
F4 := f(x) in R;      is F05;                  // F05 := A[z:R, f(z) in R];      // is Lorb5(f,x)(x);                               
F5 := #R >1;          is Tfinset2(F2 & F4 & F3 & !F03);              // ! Tfinset2 := X in finset & a in X & b in X & a ~= b -> #X > 1;   
F6 := R in ntorbs;    by Axdconj; F1 & F5;                           // !! Axdconj := z in (d&&P) == z in d & Rep(d,P,z);
F7 := ntorbs ~= {};   is Tinnemp(F6);                                // ! Tinnemp := x in X -> X ~= {}; 
 end Proof Lds4;
                                                                     // ! CP := p->q == ~q -> ~p; // ContraPosition
! Lds4a :=  ntorbs = {} -> ds = {};   by CP, -Axneq; Lds4;           // !! Axneq := z ~= z1 == ~(z = z1);               

corb := F[Q_orbs, f|Q || A];                 // cycle for the orbit Q; // fA :: !! Tredom := dom(f|A) = A; // !! Treval := A[x:A, (f|A)(x) = f(x)];
! Lcorb := A[Q_orbs, corb(Q) = f|Q || A];    byeq Red("F");        // ! Tdvl := A[f_AFN_A_set, f||A = F[x:A, if(x in dom(f), f(x), x)]];
// !! Lcorb1 := A[Q_orbs, Q <: dom(f)];  // for Tredom(f,Q@Q_orbs) in LcorbF;      // f_FN_A_P_dom_f_x_A := {f,A,x; f in FN, A in P[dom(f)], x in A};

! LcorbF := A[Q_orbs, corb(Q) = F[x_A, if(x in Q, f(x), x)]]; // byeq Lcorb, Tdvl(f|Q@Q_orbs, A), Tredom(f,Q@Q_orbs), TrevalA; //(f,Q@Q_orbs,x@x_A); 
 EqProof LcorbF;                                              // byeq; did not work !!!
F0 := Q in orbs;                             assume;
F1 := corb(Q);                               by Lcorb;
F2 := f|Q || A;                              by Tdvl(f|Q@Q_orbs, A);       // ! Tdvl := A[f_AFN_A_set, f||A = F[x:A, if(x in dom(f), f(x), x)]];
F3 := F[x_A, if(x in dom(f|Q), (f|Q)(x), x)]; by Tredom(f,Q@Q_orbs);       // fA :: !! Tredom := dom(f|A) = A; 
F4 := F[x_A, if(x in Q, (f|Q)(x), x)];       by TrevalA; // (f,Q@Q_orbs,x@x_A); // !! TrevalA := A[f_FN_A_P_dom_f_x_A, (f|A)(x) = f(x)];
F5 := F[x_A, if(x in Q, f(x), x)]; 
 end EqProof LcorbF; 


/* Proof Lcorbafn;                                // !! LafnFif := B<:A & f in afn(B) -> F[x:A, if(x in B, f(x), x)] in afn(A);
F0 := Q in orbs;                              assume; by TRin;             // !! TRin := z in R[d,f] == E[d, z = f]; 
F01 := Ex[x_A, F01a := Q = orb(f,x)];
F02 := f|orb(f,x) in afn(orb(f,x));           is Lorb8(f,x);               // ! Lorb8 := f|orb in afn(orb);
F03 := orb(f,x) <: A;                         is Lorb4(f,x);               // ! Lorb4 := orb <: A; 
F04 := F[x_A, if(x in orb(f,x), (f|orb(f,x))(x), x)] in afn(A); is LafnFif(F03 & F02); by Treval@fA; // fA :: !! Treval := A[x:A, (f|A)(x) = f(x)]; 
                                              // !! LafnFif := B<:A & f in afn(B) -> F[x:A, if(x in B, f(x), x)] in afn(A);
F05 := F[x_A, if(x in orb(f,x), f(x), x)] in afn(A); by -Lcorb;
F1 := corb(Q) in afn(A);
 end Proof Lcorbafn; 
*/
                                         
 
Q_orbs :: [   // 2                     // Q_orbs := {Q; Q in orbs};         // orbs := R[x_A, orb(f,x)];
c := corb(Q);                          // corb := F[Q_orbs, f|Q || A];      // ! L07 := afn(A) <: AFN;
! Lcorbdom := dom(c) = A;              by LcorbF; is TFdom1;                // !! TFdom1 := dom(F[x:A,G(x)]) = A;  
! Lcorbafn := c in afn(A);             by Lcorb; is Ldvlafn(f|Q@Q_orbs, A); // !! Ldvlafn := A[f_AFN_A_set, Ldvlafn_type := f||A in afn(A)];
! LcorbAFN := c in AFN;                is TinIn(Lcorbafn & L07);            // !! TinIn := x in A & A<:B -> x in B;  
! LcorbIFN := c in IFN;                is TinIn(LcorbAFN & TAFNIFN);        // !! TAFNIFN := AFN <: IFN;

! Lcorb_type := c in perm;
 Proof Lcorb_type;
F0 := dom(c) in finset1;               by Lcorbdom; Axp;
G0 := c in perm;                       by Axdconj; LcorbAFN & F0;           // Axdconj := z in d&&P == z in d & Rep(d,P,z); 
 end Proof Lcorb_type;

!! LcorbQ := Q in orbs.c;            // c := corb(Q);  
!! LcorbQ1 := #Q > 1 -> Q in ntorbs.c; 

! LQds := #Q > 1 -> ds.c = Q;
 Proof LQds;
F0 := #Q > 1;                          assume;
G0 := ds.c = Q;                        by Axext; L1 & L2;                   // ! Axext := X = Y == X <: Y & Y <: X; 
L1 := ds.c <: Q;  
  Proof L1;                            by AxIn;                             // !! AxIn := X2 <: Y2 == All(x, x in X2 -> x in Y2);
G1 := All(x, x in ds.c -> x in Q);
   Proof G1;
assume(x);                                                                  // c := corb(Q);
H0 := A[x:dom(c), x in ds.c == c(x) ~= x]; is LAFNds.c;                     // !! LAFNds := A[x:dom(f), x in ds == f(x) ~= x]; 
H01 :=  x in ds.c;                         assume;   // by H0;                 
H02 := ds.c <: dom(c);                     is LAFNdsdom.c;                  // !! LAFNdsdom := ds <: dom(f);
H1 := x in dom(c);                         is TinIn(H01 & H02);     
H2 := c(x) ~= x;                           by -H0; H01;
Qx := orb(c,x);
H3 := x in Qx;                             is L18a.c;                       // ! L18a := A[x:dom(f), x in orb(f,x)];                    
H4 := Qx in ntorbs.c;                      is Lntorbs1.c(H2);               // !! Lntorbs1 := A[x:dom(f), f(x) ~= x -> orb(f,x) in ntorbs]; 
H5 := Q in ntorbs.c;                       is LcorbQ1(F0);
!! H6 := Qx = Q;
H7 := x in Q;                              by -H6; H3;    
   end Proof G1;
  end Proof L1;

!! L2 := Q <: ds.c;
 end Proof LQds; 
]; // Q_orbs :: [   // 2

! LcorbafnA := A[Q_orbs, c in afn(A)];    is Lcorbafn@Q_orbs;               // Q_orbs :: ! Lcorbafn := c in afn(A);
! Lcorb_typeA := A[Q_orbs, c in perm];    is Lcorb_type@Q_orbs;             // Q_orbs :: ! Lcorb_type := c in perm;  

     // ??? A[Q_orbs, corb in perm];      is Lcorb_type@Q_orbs;     ??? was not caught!!! ??? 2022.12.04;
                                              
!! T1 := A[ab_A, a ~= b -> (evenp.(trp(a,b) o f) == ~(evenp.(f:perm)))];    //  was evenp(trp(a,b) o f): ERROR (not function term) ??? ~evenp.f:LOST .f ???

cycle := #ntorbs <= 1;                         // f is a cycle;
ntrivcycle := #ntorbs = 1;                     // f is a nontrivial cycle;
trivcycle := #ntorbs = 0;                      // f is a trivial cycle;
! Lntrivcycle := ntrivcycle == ~trivcycle;     is Tnat7(cycle);             // Tnat7 := n<=1 -> (n=1 == ~(n=0));    // var n, nat;
 
! Ltrivcycle := trivcycle -> f = id(A);
 Proof Ltrivcycle;
F0 := trivcycle;                               assume; by Tcardz@finset;  // !! Tcardz := #A = 0 == A = {}; 
F01 := ntorbs = {};
F02 := ds = {};                                is Lds4a(F01);           by LAFNdsid;  // !! LAFNdsid := ds={} == f = id(dom(f));
F1 :=  f = id(A);                                                                     // is LAFNdsid(F02);       
 end Proof Ltrivcycle;

! Lft := f in fn(A,A);                         is Tafnfn1(L00); // !! Tafnfn1 := f in afn(A) -> f in fn(A,A); // ! L00 := f in afn(A);
                                       // (||) := F[{f:AFN, A:set; dom(f) <: A}, F[x:A, if(x in dom(f), f(x), x)]];     
cycles := R[Q_orbs, corb(Q)];                                     // fcs := {C; AxC1 := C in FS(elg); AxC2 := A[x,y: C, x*y = y*x] };
! L23 := cycles <: afn(A);             by TRA; LcorbafnA;         // !! TRA  := R[d, f] <: B == A[d, f in B]; // ! Lcorbafn := corb(Q) in afn(A); 
! K7 := cycles <: AFN;                 is TIntrans(L23 & L07);    // used in L3;  // ! L07 := afn(A) <: AFN; 
! L25 := cycles in finset;             is TfinsetR(L7);           // !! TfinsetR := X in finset -> R[x:X, g] in finset; 
! L26 := cycles <: perm;               by TRA; Lcorb_typeA;       // ! L7 := orbs in finset; // ! Lcorb_typeA := A[Q_orbs, corb in perm];
! LcyclesFS := cycles in FS(afn(A));   is AxFS(L23 & L25);        // !! AxFS := X in FS(A) == X <: A & X in finset;
// ! L27 := cycles <: IFN;             is TIntrans(K7 & TAFNIFN); // for type checking in L1; 
! L28 := cycles <: REL;                is TIntrans(K7 & TAFNREL); // for type checking in Lcyclescomm; (+6sec if commented ???);
                                                                  // !! TAFNREL := AFN <: REL; // ! TInIn := X0 <: Y0 & Y0 <: Z0 -> X0 <: Z0;                                        
! Lcyclescomm := A[f,g:cycles, f o g = g o f];
 Proof Lcyclescomm;
K0 := f in cycles;                     assume;
K1 := f in afn(A);                     is TinIn(K0 & L23);
K2 := g in cycles;                     assume;
K3 := g in afn(A);                     is TinIn(K2 & L23);
K4 := A[f: afn(A), f o id(A) = f];     is Tafn4;         // !! Tafn4 := A[f: afn(A), f o id(A) = f]; // different A's;
K4a := A[f: afn(A), id(A) o f = f];    is Tafn4a;        // !! Tafn4a := A[f: afn(A), id(A) o f = f];
K5 := dom(f) = A;                      is Tafndom1(K1);  // !! Tafndom1 := f in afn(A)-> dom(f) = A;!! Tafndom1 := f in afn(A)-> dom(f) = A;
K6 := dom(g) = A;                      is Tafndom1(K3);  // Axneq := z ~= z1 == ~(z = z1);  
K8 := ntrivcycle.f == ~(trivcycle.f);  is Lntrivcycle.f; // ! Lntrivcycle := ~(ntrivcycle) == trivcycle;
K9 := ntrivcycle.g == ~(trivcycle.g);  is Lntrivcycle.g;

Lcase := f=g or trivcycle.f or trivcycle.g or f ~= g & ntrivcycle.f & ntrivcycle.g; by Axneq,K8,K9; is Taut(p or q or r or (~p)&(~q)&(~r));       
G0 := f o g = g o f;                   by Case4(Lcase);   L0 & L1 & L2 & L3;
! L0 := f=g -> G0;
  Proof L0;
F0 := f=g;                             assume;
G0;                                    by F0;
F1 := g o g = g o g;                   is Axrefl;            // !! Axrefl := x = x;  
  end Proof L0;
L1 := trivcycle.f -> G0;
  Proof L1;
F0 := trivcycle.f;                     assume;
F00 := trivcycle.f -> f = id(dom(f));  is Ltrivcycle.f;      // !! Ltrivcycle := trivcycle -> f = id(A); // A := dom(f);
F01 := f = id(dom(f));                 is F00(F0);  by K5;  
F01a := f = id(A);
F02 := f o g = g;                      by F01a; is K4a;      // !! K4a := A[f: afn(A), id(A) o f = f];
F03 := g o f = g;                      by F01a; is K4;       // !! K4 := A[f: afn(A), f o id(A) = f]; 
F1 := f o g = g o f;                   is Axeq2(F02 & F03);  // !! Axeq2 := x=a & y=a -> x=y;             
  end Proof L1;
L2 := trivcycle.g -> G0;
  Proof L2;
F0 := trivcycle.g;                     assume;
F00 := trivcycle.g -> g = id(dom(g));  is Ltrivcycle.g;      // !! Ltrivcycle := trivcycle -> f = id(A); // A := dom(f);
F01 := g = id(dom(g));                 is F00(F0);  by K6;
F01a := g = id(A);
F02 := f o g = f;                      by F01a; is K4;       // !! Tafn4 := A[f: afn(A), f o id(A) = f]; 
F03 := g o f = f;                      by F01a; is K4a;      // !! Tafn4a := A[f: afn(A), id(A) o f = f];
F1 := f o g = g o f;                   is Axeq2(F02 & F03);  // !! Axeq2 := x=a & y=a -> x=y;             
  end Proof L2;
L3 := f ~= g & ntrivcycle.f & ntrivcycle.g -> G0;
  Proof L3;
F0 := f ~= g;                          assume;
F01 := ntrivcycle.f;                   assume;
F02 := ntrivcycle.g;                   assume;
!! F1 := ds.f NI ds.g;
F2 := f o g = g o f;                   is Tafncomm(K1 & K3 & F1); // !! Tafncomm := f in afn(A) & g in afn(A) & ds.f NI ds.g -> f o g = g o f;
  end Proof L3;
 end Proof Lcyclescomm;

! LSymA_type := Sym(A) in group;       is TSym(A);                // finset1 :: Sym := [afn(A), compA]; // finset1 :: ! TSym := Sym in group;
!! LfcsSymA := fcs.(Sym(A)) = {C; C in FS(afn(A)); A[f,g:C, f o g = g o f] }; // byeq Red("dot"); 
! Lcyclesfcs := cycles in fcs.(Sym(A));       by LfcsSymA, Axab; LcyclesFS & Lcyclescomm;

!! L10 := ntorbs <: orbs;
ntcycles := R[Q:ntorbs, corb(Q)];              // nontrivial cycles;
!! L11 := ntcycles <: perm;

NN1_ntc := {N,N1; N in ntcycles, N1 in ntcycles};
NN1_ntc :: [
!! L29 := N in REL;                             // remove asap !!!
!! L30 := N1 in REL;
]; // NN1_ntc :: [
!! L12 := A[NN1_ntc, L9_type := N o N1 in perm];
!! Lntc1 := A[NN1_ntc, ds(N o N1) = ds(N:perm) \/ ds(N1:perm)];   // ds := {x: A; f(x) ~= x};
!! Lntc2 := U[N:ntcycles, ds(N:perm)] = ds(f:perm);
!! Lntc3 := A[NN1_ntc, N~=N1 -> dsjp(N,N1)]; 

comp := Pset.(Sym(A));
!! Lcomp_type := comp in fn(fcs.(Sym(A)), A);        // Ax1 := Pset in fn(fcs,elg)

cc := comp(cycles);                            // composition
!! Lcc_type := cc in afn(A);
!! Lccdom := dom(cc) = A;

!! T2 := f = cc;                               // !! Tfneq := A[f,g: FN, f=g == dom(f)=dom(g) & A[x:dom(f), f(x)=g(x)]];
/* Proof T2;                                     by Tfneq; L1 & L2;  
L1 := dom(f) = dom(cc);                        byeq Lccdom;
L2 := A[x:A, f(x) = cc(x)];
  Proof L2;
F0 := x in A;                                  assume;
qx := orb(f,x);
F1 := x in qx;                                 is Lorb2(f,x);  perma :: !! Lorb2 := a in orb;
zx := corb(qx);
F2 := f(x) = zx(x);                            is ???
C1 := cycles - {zx};
Q1 := orbs(f) - {qx};
F3 := A[q1:Q1, x nin q1];                      is ???
F4 := cc = zx o comp(C1);                      is Tcompx ???
F5 := A[z:C1, z(x) = x];                       is Lx;
F6 := comp(C1)(x) = x;                         is Tcompx1; ???
F7 := cc(x) = (zx o comp(C1))(x);              by 
F8 := cc(x) = zx(comp(C1)(x));                 by F6, -F2, Axsym;   // Axsym := u=v == v=u; 
F9 := f(x) = cc(x);
  end Proof L2;
 end Proof T2;
*/

! Lcff := seqinj1(A) <: SEQinj1;               is Lseqinj1In;        // !! Lseqinj1In := seqinj1(A) <: SEQinj1;
cf := F[z:seqinj1(A), F[x:A, if(x in im(z), nextf.z(x):A, x)] ];
! Lcf_type := cf in fn(seqinj1(A), afn(A));  is Lnextf9;
               // !! Lnextf9 := F[z:seqinj1(A), F[x:A, if(x in im(z), nextf.z(x):A, x)] ] in fn(seqinj1(A), afn(A));  
! Lcf0 := A[x_A, [x] in seqinj1(A)];  is Lseqinj8;  //  !! Lseqinj8 := A[a:A, [a] in seqinj1(A)];
! Lcf1 := A[x_A, [x] in SEQinj1];     is LSEQinj1b; //  !! LSEQinj1b := [x] in SEQinj1;
// ! Lcf2 := A[x_A, im([x]) = {x}];      is LSEQ1im;   //  !! LSEQ1im := im([x]) = {x};
// ! Lcf3 := A[x_A, x in im([x]) ];      is LSEQim1;   //  !! LSEQim1 :=  x in im([x]);
// ! Lcf4:= A[x_A, nextf.[x](x) = x];    is Lnextf10;  //  !! Lnextf10 := nextf.[x](x) = x;

! Lcfid := A[x_A, cf([x]) = id(A)]; 
 EqProof Lcfid;
F0 := x in A;                                    assume;
F01 := a in im([x]) -> nextf.[x](a) = a;         is Lnextf11;     // !! Lnextf11 := a in im([x]) -> nextf.[x](a) = a;  
F1 := cf([x]);                                   by Red("F");
F2 := F[a:A, if(a in im([x]), nextf.[x](a), a)]; by Tif4(F01);    // !! Tif4 := (p -> a=c) -> if(p,a,b) = if(p,c,b); 
F3 := F[a:A, if(a in im([x]), a, a)];            by Tif3;         // !! Tif3 := if(p,a,a) = a;
F4 := F[a:A, a];                                 by -TidF;        // !! TidF := id(A) = F[x:A, x]; 
F5 := id(A);
 end EqProof Lcfid;

aCD := {a,C,D; Axa := a in A; AxC := C in seqinj(A); AxD := D in seqinj(A); AxaC := a nin im(C); AxaD := a nin im(D); AxCD := im(C) NI im(D)};
aCD :: [
! L1 := C in seq(A);                 is TInin(Lseqinj3 & AxC);    // !! Lseqinj3 := seqinj(A) <: seq(A); /
! L2 := D in seq(A);                 is TInin(Lseqinj3 & AxD);    // !! TInin := X <: Y & x in X -> x in Y;
! LCim := im(C) <: A;                is Tseqim(L1);               // !! Tseqim := z in seq(A) -> im(z) <: A;
! LDim := im(D) <: A;                is Tseqim(L2);   
! L1C := C ~= [] -> C in SEQinj1;    is Lseqinj4(AxC);            // !! Lseqinj4 := z in seqinj(A) -> (z ~= [] -> z in SEQinj1);
! L1D := D ~= [] -> D in SEQinj1;    is Lseqinj4(AxD);            // !! L1 := seqinj1(A) <: SEQinj1;
! L2C := C ~= [] -> C in SEQ1;       is Lseq4(L1);                // !! Lseq4 := z in seq(A) -> (z ~= [] -> z in SEQ1);               
! L2D := D ~= [] -> D in SEQ1;       is Lseq4(L2); 
! L3C := C ~= [] -> 0 in dom(C);     is Lseq5(L1);                 // !! Lseq5 := z in seq(A) -> (z ~= [] -> 0 in dom(z));
! L3D := D ~= [] -> 0 in dom(D);     is Lseq5(L2);                
! L4C := [a]^C in SEQinj1;           is Lseqinj6(AxC & AxaC);      // !! Lseqinj6 := z in seqinj(A) & a nin im(z) -> [a]^z in SEQinj1;
! L4D := [a]^D in SEQinj1;           is Lseqinj6(AxD & AxaD); 
// !! L5 := C ~= [] & x in im(C-) -> x in A;                      // !! TSEQinj1t := SEQinj1 <: SEQ1;
// !! L6 := C ~=[] -> im(C-) <: im(C);
! L7 := C ~=[] -> Last(C) in A;      is Lseq6(L1);                 // !! Lseq6 := z in seq(A) -> (z ~= [] -> Last(z) in A);
! L8 := D ~=[] -> Last(D) in A;      is Lseq6(L2);                
! LaC := [a]^C in seqinj1(A);        is Lseqinj5(AxC & AxaC);      // !! Lseqinj5 := z in seqinj(A) & a nin im(z) -> [a]^z in seqinj1(A);
! L10 := [a]^C in seq(A);            is TInin(Lseqinj3a & LaC);    // !! Lseqinj3a := seqinj1(A) <: seq(A);
! LaCim := im([a]^C) <: A;           is Tseqim(L10);
! LaD := [a]^D in seqinj1(A);        is Lseqinj5(AxD & AxaD); 
! L11 := [a]^D in seq(A);            is TInin(Lseqinj3a & LaD); 
! LaDim := im([a]^D) <: A;           is Tseqim(L11);               // !! Tseqim := z in seq(A) -> im(z) <: A;
! L12 := im(D) NI im(C);             by TNIsym; AxCD;              // ! TNIsym := X NI Y == Y NI X; 

saDC := [a]^D^C;                     // !! Lseqconc :=  y in seq(t) & z in seq(t) -> y^z in seq(t)]; 
! L3 := saDC in seq(A);              is Lseqconc(L11 & L1);        // ! L11 := [a]^D in seq(A); // ! L1 := C in seq(A); 
! LaDCim := im(saDC) <: A;           is Tseqim(L3);                // !! Tseqim := z in seq(A) -> im(z) <: A;
! LaDC := saDC in seqinj1(A);       is Lseqinj7(Axa & AxD & AxC & AxaD & AxaC & L12);   
              // Lseqinj7 := a in A & y in seqinj(A) & z in seqinj(A) & a nin im(y) & a nin im(z) & im(y) NI im (z) -> [a]^y^z in seqinj1(A);
! L5 := saDC in SEQinj1;             is TInin(Lseqinj1In & LaDC);  // !! Lseqinj1In := seqinj1(A) <: SEQinj1;
M := [[a],D,C];                      // uyz := {u,y,z; u in SEQ, y in SEQ, z in SEQ; Ax1 := u^y^z in SEQinj1; };
! L0a := [a] in SEQ;                 is LSEQ0;                     // !! LSEQ0 := All(x, [x] in SEQ);
! L0C := C in SEQ;                   is Lseq0a(L1);                // !! Lseq0a := x in seq(t) -> x in SEQ; // ! L1 := C in seq(A); 
! L0D := D in SEQ;                   is Lseq0a(L2);                // ! L2 := D in seq(A); 
! L5_type := M in uyz;               by Axab; L0a & L0D & L0C & L5;
! L9 := im(C) <: im(saDC);           is L1.M;                      // !! L1 := im(z) <: im(u^y^z); 
! L9a := im(D) <: im(saDC);          is L4.M;                      // !! L4 := im(y) <: im(u^y^z);   
! LinimC := x in im(C) -> ~(x in im([a]^D));         is L9.M;      // !! L9 := x in im(z) -> ~(x in im(u^y));
! LinimD := x in im(D) -> ~(x in im([a]^C));         is L10.M;     // !! L10 := x in im(y) -> ~(x in im(u^z));
! LD0imaC :=  D ~= [] -> ~(D(0) in im([a]^C));       is L11.M;     // !! L11 :=  y ~= [] -> ~(y(0) in im(u^z)); 
! L5C := x ~= a & x nin im(C) -> ~(x in im([a]^C));  by Axneq,Axnin,Lconcim4; is Taut; // !! Axneq := z ~= z1 == ~(z = z1); !! Axnin := x nin X == ~(x in X); 
! L5D := x ~= a & x nin im(D) -> ~(x in im([a]^D));  by Axneq,Axnin,Lconcim4; is Taut; // !! Lconcim4 := A[z:SEQ, x in im([a]^z) == x=a or x in im(z)];
! L6 := x ~= a & x nin im(D) & x nin im(C) -> ~(x in im([a]^D^C)); by Axneq, Axnin,Axnin,Lconcim5; is Taut;
                                                     // !! Lconcim5 := A[y,z:SEQ, x in im([a]^y^z) == x=a or x in im(y) or x in im(z)];
aC := cf([a]^C);
! LaC0 := aC = F[x:A, if(x in im([a]^C), nextf.([a]^C)(x):A, x)];  byeq Red("F");
! LaC_type := aC in afn(A);        is typeaxiom;
! LdomaC := dom(aC) = A;           is Tafndom1(LaC_type);

! LaC1 := C = [] -> aC = id(A);
 EqProof LaC1;
F0 := C = [];                      assume;
F01 := [a]^C = [a];                by F0; is Lconcempl;            // is !! Lconcempl := A[z:SEQ, z^[] = z];
aC;                                by F01;                         // aC := cf([a]^C);
F2 := cf([a]);                     by Lcfid;                       // !! Lcfid := A[x_A, cf([x]) = id(A)]; 
F3 := id(A);
 end EqProof LaC1;

! L4 := im(C) <: im([a]^C);       is LconcimIn@dyz;                // dyz :: !! LconcimIn := im(z) <: im(y^z);

! LaC2 := x in im([a]^C) -> aC(x) = nextf.([a]^C)(x);
 EqProof LaC2;
F0 := x in im([a]^C);             assume; 
F01 := x in A;                    is TinIn(F0 & LaCim);            // ! LaCim := im([a]^C) <: A; 
F1 := aC(x);                      by LaC0, Red("F");
F2 := if(x in im([a]^C), nextf.([a]^C)(x):A, x);   by Tif1(F0);    // !! Tif1 := p -> if(p,a,b) = a;
F3 := nextf.([a]^C)(x);
 end EqProof LaC2;

! LaC3 := x in A & ~(x in im([a]^C)) -> aC(x) = x;
 EqProof LaC3;
F0 := x in A;                     assume;
F01 := ~(x in im([a]^C));         assume; 
F1 := aC(x);                      by LaC0, Red("F"); // ! LaC0 := aC = F[x:A, if(x in im([a]^C), nextf.([a]^C)(x):A, x)];
F2 := if(x in im([a]^C), nextf.([a]^C)(x), x);   by Tif2(F01);   // !! Tif2 := ~p -> if(p,a,b) = b;   // :A : error, 2022.10.03;
F3 := x;
 end EqProof LaC3;

! LaCa := C ~= [] -> aC(a) = C(0);
 EqProof LaCa;
F0 := C ~= [];                    assume;
F01 := a in im([a]^C);            is Lconcim3;              // !! Lconcim3 := A[z:SEQ, x in im([x]^z)];
F02 := C in SEQ1;                 is L2C(F0);               // ! L2C := C ~= [] -> C in SEQ1;
F1 := aC(a);                      by  LaC2(F01);            // ! LaC0 := aC = F[x:A, if(x in im([a]^C), nextf.([a]^C)(x):A, x)];  byeq Red("F");  
F2 := nextf.([a]^C)(a);           by Lnextf5(L4C);          // !! Lnextf5 := A[x:any, z:SEQ1, [x]^z in SEQinj1 -> nextf.([x]^z)(x)) = z(0)];
F3 := C(0);                                                 // ! L4C := [a]^C in SEQinj1;
 end EqProof LaCa;

! LaCim1 := C ~= [] & x in im(C) & x ~= Last(C) -> aC(x) = nextf.C(x);      // x in im(C) -> C ~= [];
 Proof LaCim1;                    // SUCCESS! main: grand total time= 91.837
F0 := C ~= [];                    assume;
F01 := x in im(C);                assume;                   // dyz := {y,z; y in SEQ; z in SEQ; };       
F02 := im(C) <: im([a]^C);        is LconcimIn@dyz;         // dyz :: !! LconcimIn := im(z) <: im(y^z);
F03 := x in im([a]^C);            is TinIn(F01 & F02);      // ! TinIn := x2 in X2 & X2 <: Y2 -> x2 in Y2;
F04 := x ~= Last(C);              assume;                   // dyz2 := dyz && (Ax1 := z in SEQ1) & (Ax2 := y^z in SEQinj1);  
F05 := [a] in SEQ1;               is LSEQ1c1;               // !! LSEQ1c1 := [x] in SEQ1;
F06 :=  nextf.([a]^C)(x) = nextf.C(x);                      is Lnextf6([a], C)(x)(F04);   
F1 := aC(x) = nextf.([a]^C)(x);   is LaC2(F03);             by F06;  // !! LaC2 := x in im([a]^C) -> aC(x) = nextf.([a]^C)(x);
F2 := aC(x) = nextf.C(x);         // dyz2 :: !! Lnextf6 := A[x:im(z), x ~= Last(z) -> nextf.(y^z)(x) = nextf.z(x)];
 end Proof LaCim1;

! LaCLastC := C ~= [] -> aC(Last(C)) = a;  
 EqProof LaCLastC;
F0 := C ~= [];                    assume;                   // var u0,v0, SEQ; // v_SEQ, v1_SEQ, // u0 := var(SEQ,0) ??? 
F01 := C in SEQ1;                 is L2C(F0);               // ! L2C := C ~= [] -> C in SEQ1;
F02 := Last(C) in im([a]^C);      is TLastimconc@SEQ1;      // SEQ1 :: !! TLastimconc := Last(f) in im(u0^f); 
F03 := Last(C) in A;              is TinIn(F02 & LaCim);    // ! LaCim := im([a]^C) <: A; system can infer it: ! LaCim := im([a]^C) <: A; 
F1 := aC(Last(C));                by LaC0, Red("F");        // ! LaC0 := aC = F[x:A, if(x in im([a]^C), nextf.([a]^C)(x):A, x)];
F2 := if(Last(C) in im([a]^C), nextf.([a]^C)(Last(C)), Last(C));    by Tif1(F02);   // !! Tif1 := p -> if(p,a,b) = a; 
F3 := nextf.([a]^C)(Last(C));     by Lnextf8a@SEQ1(L4C);    // SEQ1 :: !! Lnextf8a := [a]^f in SEQinj1 -> nextf.([a]^f)(Last(f)) = a;
F4 := a;                                                    // ! L4C := [a]^C in SEQinj1; 
 end EqProof LaCLastC;
                                  // !! LinimD := x in im(D) -> ~(x in im([a]^C);   // !! LaC3 := ~(x in im([a]^C)) -> aC(x) = x;
! LaCimD :=  x in im(D) -> aC(x) = x;  // is HS(LinimD & LaC3); // ! HS := (p->q) & (q->r) -> (p->r); // // Hypothetical Syllogism
 Proof LaCimD;
F0 := x in im(D);                 assume;
F01 := ~(x in im([a]^C));         is LinimD(F0);            // !! LinimD := x in im(D) -> ~(x in im([a]^C)); 
F02 := x in A;                    is TinIn(F0 & LDim);      // ! LDim := im(D) <: A;
F1 := aC(x) = x;                  is LaC3(F02 & F01);        // ! LaC3 := x in A & ~(x in im([a]^C)) -> aC(x) = x;
 end Proof LaCimD;

! LaCD0 := D ~= [] -> aC(D(0)) = D(0); 
 Proof LaCD0; 
F0 := D ~= [];                    assume;
F01 := D(0) in im(D);             is TSEQ1_im0.D;           // SEQ1 :: !! TSEQ1_im0 := f(0) in im(f);
F02 := D(0) in A;                 is TinIn(F01 & LDim);     // ! LDim := im(D) <: A; 
F1 := ~(D(0) in im([a]^C));       is LD0imaC(F0);           // !! LD0imaC :=  D ~= [] -> ~(D(0) in im([a]^C));
F2 := aC(D(0)) = D(0);            is LaC3(F02 & F1);        // ! LaC3 := x in A & ~(x in im([a]^C)) -> aC(x) = x;
 end Proof LaCD0;
 
! LaCelse := x in A & x ~= a & x nin im(C) -> aC(x) = x;    // is HS(L3 & LaC3);    
 Proof LaCelse;
F0 := x in A;                     assume;
F01 := x ~= a;                    assume;
F02 := x nin im(C);               assume;
F03 := ~(x in im([a]^C));         is L5C(F01 & F02);        // !! L5C :=  x ~= a & x nin im(C) -> ~(x in im([a]^C));
F1 := aC(x) = x;                  is LaC3(F0 & F03);        // ! LaC3 := x in A & ~(x in im([a]^C)) -> aC(x) = x;
 end Proof LaCelse;

aD := cf([a]^D);

! LaD0 := aD = F[x:A, if(x in im([a]^D), (nextf.([a]^D))(x):A, x)];  byeq Red("F");
! LaD_type := aD in afn(A);      is typeaxiom;
! LdomaD := dom(aD) = A;         is Tafndom1(LaD_type);            // !! Tafndom1 := f in afn(A)-> dom(f) = A;
! LimaD := im(aD) = A;           is Tafnim1(LaD_type);             // !! Tafnim1 := f in afn(A)-> im(f) = A;

! LaD1 := D = [] -> aD = id(A);
 EqProof LaD1;
F0 := D = [];                      assume;
F01 := [a]^D = [a];                by F0; is Lconcempl;            // is !! Lconcempl := A[z:SEQ, z^[] = z];
aD;                                by F01;                         // aD := cf([a]^D); 
F2 := cf([a]);                     by Lcfid;                       // !! Lcfid := A[x_A, cf([x]) = id(A)]; 
F3 := id(A);
 end EqProof LaD1;

! LaD2 := x in im([a]^D) -> aD(x) = nextf.([a]^D)(x);
 EqProof LaD2;
F0 := x in im([a]^D);             assume; 
F01 := x in A;                    is TinIn(F0 & LaDim);            // ! LaDim := im([a]^D) <: A; 
F1 := aD(x);                      by LaD0, Red("F");
F2 := if(x in im([a]^D), nextf.([a]^D)(x):A, x);   by Tif1(F0);    // !! Tif1 := p -> if(p,a,b) = a;
F3 := nextf.([a]^D)(x);
 end EqProof LaD2;

! LaD3 := x in A & ~(x in im([a]^D)) -> aD(x) = x;
 EqProof LaD3;
F0 := x in A;                     assume;
F01 := ~(x in im([a]^D));         assume; 
F1 := aD(x);                      by LaD0, Red("F"); // ! LaD0 := aD = F[x:A, if(x in im([a]^D), nextf.([a]^D)(x):A, x)];
F2 := if(x in im([a]^D), nextf.([a]^D)(x), x);   by Tif2(F01);   // !! Tif2 := ~p -> if(p,a,b) = b;   // :A : error, 2022.10.03;
F3 := x;
 end EqProof LaD3;

! LaDa := D ~= [] -> aD(a) = D(0);
 EqProof LaDa;
F0 := D ~= [];                    assume;
F01 := a in im([a]^D);            is Lconcim3;              // !! Lconcim3 := A[z:SEQ, x in im([x]^z)];
F02 := D in SEQ1;                 is L2D(F0);               // ! L2D := D ~= [] -> D in SEQ1;
F1 := aD(a);                      by LaD2(F01);             // ! LaD0 := aD = F[x:A, if(x in im([a]^D), nextf.([a]^D)(x):A, x)];  byeq Red("F");  
F2 := nextf.([a]^D)(a);           by Lnextf5(L4D);          // !! Lnextf5 := A[x:any, z:SEQ1, [x]^z in SEQinj1 -> nextf.([x]^z)(x)) = z(0)];
F3 := D(0);                                                 // ! L4D := [a]^D in SEQinj1;
 end EqProof LaDa;

! LaDim1 := D ~= [] & x in im(D) & x ~= Last(D) -> aD(x) = nextf.D(x);
 Proof LaDim1;
F0 := D ~= [];                    assume;
F01 := x in im(D);                assume;                   // dyz := {y,z; y in SEQ; z in SEQ; };       
F02 := im(D) <: im([a]^D);        is LconcimIn@dyz;         // dyz :: !! LconcimIn := im(z) <: im(y^z);
F03 := x in im([a]^D);            is TinIn(F01 & F02);      // ! TinIn := x2 in X2 & X2 <: Y2 -> x2 in Y2;
F04 := x ~= Last(D);              assume;                   // dyz2 := dyz && (Ax1 := z in SEQ1) & (Ax2 := y^z in SEQinj1);  
F05 := [a] in SEQ1;               is LSEQ1c1;               // !! LSEQ1c1 := [x] in SEQ1;
F06 :=  nextf.([a]^D)(x) = nextf.D(x);                      is Lnextf6([a], D)(x)(F04);   
F1 := aD(x) = nextf.([a]^D)(x);   is LaD2(F03);             by F06;  // !! LaD2 := x in im([a]^D) -> aD(x) = nextf.([a]^D)(x);
F2 := aD(x) = nextf.D(x);         // dyz2 :: !! Lnextf6 := A[x:im(z), x ~= Last(z) -> nextf.(y^z)(x) = nextf.z(x)];
 end Proof LaDim1;

! LaDimC :=  x in im(C) -> aD(x) = x;
 Proof LaDimC;
F0 := x in im(C);                 assume;
F01 := ~(x in im([a]^D));         is LinimC(F0);            // !! LinimC := x in im(C) -> ~(x in im([a]^D)); 
F02 := x in A;                    is TinIn(F0 & LCim);      // ! LCim := im(C) <: A;
F1 := aD(x) = x;                  is LaD3(F02 & F01);       // ! LaD3 := x in A & ~(x in im([a]^D)) -> aD(x) = x;
 end Proof LaDimC;
 
! LaDLastC := C ~= [] & D ~= [] -> aD(Last(C)) = Last(C); 
 Proof LaDLastC;
F0 := C ~= [];                    assume;
F01 := D ~= [];                   assume;
F02 := Last(C) in im(C);          is TLastim@SEQ1;          // SEQ1 :: !! TLastim := Last(f) in im(f); 
F1 := aD(Last(C)) = Last(C);      is LaDimC(F02);           // ! LaDimC :=  x in im(C) -> aD(x) = x;
 end Proof LaDLastC;

! LaDLastD := D ~= [] -> aD(Last(D)) = a; 
 EqProof LaDLastD;
F0 := D ~= [];                    assume;                   // var u0,v0, SEQ; // v_SEQ, v1_SEQ, // u0 := var(SEQ,0) ??? 
F01 := D in SEQ1;                 is L2D(F0);               // ! L2D := D ~= [] -> D in SEQ1;
F02 := Last(D) in im([a]^D);      is TLastimconc@SEQ1;      // SEQ1 :: !! TLastimconc := Last(f) in im(u0^f); 
F03 := Last(D) in A;              is TinIn(F02 & LaDim);    // ! LaDim := im([a]^C) <: A; system can infer it: ! LaDim := im([a]^D) <: A; 
F1 := aD(Last(D));                by LaD0, Red("F");        // ! LaD0 := aD = F[x:A, if(x in im([a]^D), nextf.([a]^D)(x):A, x)];
F2 := if(Last(D) in im([a]^D), nextf.([a]^D)(Last(D)), Last(D));    by Tif1(F02);   // !! Tif1 := p -> if(p,a,b) = a; 
F3 := nextf.([a]^D)(Last(D));     by Lnextf8a@SEQ1(L4D);    // SEQ1 :: !! Lnextf8a := [a]^f in SEQinj1 -> nextf.([a]^f)(Last(f)) = a;
F4 := a;                                                    // ! L4D := [a]^D in SEQinj1; 
 end EqProof LaDLastD;

! LaDelse := x in A & x ~= a & x nin im(D) -> aD(x) = x;            // no x in A ???: because aD(x) was merged with correct aD(x) in LaD2, LaD3, ... 
 Proof LaDelse;
F0 := x in A;                     assume;
F01 := x ~= a;                    assume;
F02 := x nin im(D);               assume;
F03 := ~(x in im([a]^D));         is L5D(F01 & F02);        // !! L5D :=  x ~= a & x nin im(D) -> ~(x in im([a]^D));
F1 := aD(x) = x;                  is LaD3(F0 & F03);        // ! LaD3 := x in A & ~(x in im([a]^D)) -> aD(x) = x;
 end Proof LaDelse;

aDC := cf(saDC);                  // saDC := [a]^D^C;
! LaDC0 := aDC = F[x:A, if(x in im(saDC),  nextf.saDC(x):A, x)];   byeq Red("F");
! LaDC_type := aDC in afn(A);     is typeaxiom;
! LaDCdom := dom(aDC) = A;        is Tafndom1(LaDC_type);   // !! Tafndom1 := f in afn(A)-> dom(f) = A;
! LaDC01 := C=[] -> saDC = [a]^D;  is Lconcemp1@SEQ;        // SEQ :: !! Lconcemp1 := A[z:SEQ, z=[] -> f^z = f];
! LaDC02 := D=[] -> saDC = [a]^C;  is Lconcemp2;            // !! Lconcemp2 := A[u,y,z:SEQ, y=[] ->u^y^z = u^z];

! LaDC1 := C=[] -> aDC = aD;  
 Proof LaDC1;
F0 := C=[];                       assume; 
F01 := saDC = [a]^D;              is LaDC01(F0);            //  ! LaDC01 = C=[] -> saDC = [a]^D;
F1 := aDC = aD;                   byeq F01;
 end Proof LaDC1;

! LaDC2 := D=[] -> aDC = aC; 
 Proof LaDC2;
F0 := D=[];                       assume; 
F01 := saDC = [a]^C;              is LaDC02(F0);            //  ! LaDC02 = D=[] -> saDC = [a]^C;
F1 := aDC = aC;                   byeq F01;
 end Proof LaDC2;

! LaDCa := D ~= [] -> aDC(a) = D(0);                       // ! LaDC0 := aDC = F[x:A, if(x in im(saDC),  nextf.saDC(x):A, x)];
 EqProof LaDCa;
F0 := D ~= [];                   assume;
F01 := D in SEQ1;                is L2D(F0);               // ! L2D := D ~= [] -> D in SEQ1;  
F02 := a in im(saDC);            is Lconcim3a;             // ! Lconcim3a := A[z:SEQ, x in im([x]^z^u0)]; 
F1 := aDC(a);                    by LaDC0, Red("F");
F2 := if(a in im(saDC),  nextf.saDC(a), a);                 by Tif1(F02);
F3 := nextf.saDC(a);             by Lnextf5a@dyz2(L5);      // dyz2 :: !! Lnextf5a := [x]^z^y in SEQinj1 -> nextf.([x]^z^y)(x) = z(0);
F4 := D(0);                                                 // !! L5 := saDC in SEQinj1;
 end EqProof LaDCa;

! LaDCim1C := x in im(C) & x ~= Last(C) -> aDC(x) = nextf.C(x);
 EqProof LaDCim1C;
F0 := x in im(C);                assume;  // uyz := {u,y,z; u in SEQ, y in SEQ, z in SEQ1; Ax1 := u^y^z in SEQinj1; }; 
F00 := C in SEQ1;                is LSEQim@SEQ(F0);         // SEQ :: LSEQim := x in im(f) -> f in SEQ1;
F01 := x ~= Last(C);             assume;  // uyz :: !! Lnextf6a :=  A[x: im(y),  z in SEQ1 & x ~= Last(z) -> nextf.(u^y^z)(x) = nextf.z(x)];
F02 := x in im(saDC);            is TinIn(F0 & L9);         // !! L9 := im(C) <: im(saDC);
F03 := nextf.saDC(x) = nextf.C(x);                          is Lnextf6a([a],D,C)(x)(F00 & F01);
F1 := aDC(x);                    by LaDC0, Red("F");
F2 := if(x in im(saDC),  nextf.saDC(x), x);                 by Tif1(F02);
F3 := nextf.saDC(x);             by F03;
F4 := nextf.C(x);
 end EqProof LaDCim1C;
                       
! LaDCim1D := x in im(D) & x ~= Last(D) -> aDC(x) = nextf.D(x);
 EqProof LaDCim1D;
F0 := x in im(D);                assume;  // uyz := {u,y,z; u in SEQ, y in SEQ, z in SEQ1; Ax1 := u^y^z in SEQinj1; }; 
F00 := D in SEQ1;                is LSEQim@SEQ(F0);         // SEQ :: LSEQim := x in im(f) -> f in SEQ1;
F01 := x ~= Last(D);             assume;  // uyz :: !! Lnextf6b :=  A[x: im(y),  y in SEQ1 & x ~= Last(y) -> nextf.(u^y^z)(x) = nextf.y(x)];
F02 := x in im(saDC);            is TinIn(F0 & L9a);        // !! L9a := im(D) <: im(saDC);
F03 := nextf.saDC(x) = nextf.D(x);                          is Lnextf6b([a],D,C)(x)(F00 & F01);
F1 := aDC(x);                    by LaDC0, Red("F");
F2 := if(x in im(saDC),  nextf.saDC(x), x);                 by Tif1(F02);
F3 := nextf.saDC(x);             by F03;
F4 := nextf.D(x);
 end EqProof LaDCim1D;

! LaDC_LastC := C ~= [] -> aDC(Last(C)) = a;
 EqProof LaDC_LastC;
F0 := C ~= [];                  assume;
F01 := C in SEQ1;               is L2C(F0);                 // ! L2C := C ~= [] -> C in SEQ1;
F02 := Last(C) in im(saDC);     is TLastimconc1@SEQ1;       // SEQ1 :: !! TLastimconc1 := Last(f) in im(u0^v0^f);
F03 := [a] in SEQ1;             is LSEQ1c1;                 // !! LSEQ1c1 := [x] in SEQ1;
F1 := aDC(Last(C));             by LaDC0, Red("F");
F2 := if(Last(C) in im(saDC),  nextf.saDC(Last(C)), Last(C));                 by Tif1(F02);  // !! L5 := saDC in SEQinj1;
F3 := nextf.saDC(Last(C));      by Lnextf4a([a],D,C)(F03 & F01 & L5);    // uyz :: !! Lnextf4a := u in SEQ1 & z in seq1 & u^y^z in SEQinj1 -> nextf.(u^y^z)(Last(z)) = u(0);  
F4 := [a](0);                   by LSEQ1S0;                              // !! LSEQ1S0 := [x](0) = x;   // F04; 
F5 := a;
 end EqProof LaDC_LastC;

! LaDC_LastD := D ~= [] & C ~= [] -> aDC(Last(D)) = C(0);
 EqProof LaDC_LastD;
F0 := D ~= [];                  assume;
F00 := C ~= [];                 assume;
F01 := C in SEQ1;               is L2C(F00);                // ! L2C := C ~= [] -> C in SEQ1;
F02 := Last(D) in im(saDC);     is TLastimconc2@SEQ1;       // SEQ1 :: !! TLastimconc2 := Last(f) in im(u0^f^v0); 
F03 := D in SEQ1;               is L2D(F0);                 // ! L2D := D ~= [] -> D in SEQ1; 
F1 := aDC(Last(D));             by LaDC0, Red("F");
F2 := if(Last(D) in im(saDC),  nextf.saDC(Last(D)), Last(D));            by Tif1(F02);   // !! L5 := saDC in SEQinj1;
F3 := nextf.saDC(Last(D));      by Lnextf4b([a],D,C)(F03 & F01 & L5);    // uyz :: !! Lnextf4b := y in SEQ1 & z in SEQ1 & u^y^z in SEQinj1 -> nextf.(u^y^z)(Last(y)) = z(0);  
F4 := C(0); 
 end EqProof LaDC_LastD;

! LaDCelse := x in A & x~=a & x nin im(D) &  x nin im(C) -> aDC(x) = x;
 EqProof LaDCelse;
F0 := x in A;                     assume;
F01 := x ~= a;                    assume;
F02 := x nin im(D);               assume;
F03 := x nin im(C);               assume;
F04 := ~(x in im(saDC));          is L6(F01 & F02 & F03);            // !! L6 := x ~= a & x nin im(D) & x nin im(C) -> ~(x in im([a]^D^C));
F1 := aDC(x);                     by LaDC0, Red("F");
F2 := if(x in im(saDC), nextf.saDC(x), x);  by Tif2(F04);            // !! Tif2 := ~p -> if(p,a,b) = b;  
F3 := x;
 end EqProof LaDCelse;
                                                                     // ! LaC_type := aC in afn(A);// ! LaD_type := aD in afn(A);
! LaCaD := aC o aD in afn(A);     is Tafncomp1(LaC_type & LaD_type); // !! Tafncomp1 := f in afn(A) & g in afn(A) -> f o g in afn(A)];  
! LaCaDdom := dom(aC o aD) = A;   is Tafndom1(LaCaD);                // !! Tafndom1 := f in afn(A)-> dom(f) = A;
! L0 := im(aD) <: dom(aC);        by LimaD, LdomaC; is TInrefl;       // ! TInrefl := X <: X; 
! L01 := dom(aD) = dom(aC o aD);  by LdomaD, LaCaDdom; is Axrefl;    // ? byeq ?

! LT3case := C=[] or D=[] or C ~= [] & D ~= [];  by Axneq, Axneq;     is Taut;

! T3 := aC o aD = aDC;         // ! Case3 := (p1 or p2 or p3) -> (q == (p1 -> q) & (p2 -> q) & (p3 -> q));
 Proof T3;    by Case3(LT3case);   L1 & L2 & L3;
L1 := C=[] -> aC o aD = aDC;
  EqProof L1;
F0 := C=[];                    assume;
F1 := aC o aD;                 by LaC1(F0);      // !! LaC1 := C=[] -> aC = id(A);
F2 := id(A) o aD;              by Tafn4a;        // !! Tafn4a := A[f: afn(A), id(A) o f = f]; 
F3 := aD;                      by -LaDC1(F0);
F4 := aDC;
  end EqProof L1;

L2 := D=[] -> aC o aD = aDC;
  EqProof L2;
F0 := D =[];                   assume;
F01 := A[f: afn(A), f o id(A) = f];              is Tafn4;  // !! Tafn4 := A[f: afn(A), f o id(A) = f]; // DIFFERENT A's !!! 
F1 := aC o aD;                 by LaD1(F0);      // !! LaD1 := D=[] -> aD = id(A);
F2 := aC o id(A);              by F01;         
F3 := aC;                      by -LaDC2(F0);    // !! LaDC2 := D=[] -> aDC = aC; 
F4 := aDC;
  end EqProof L2;

! L3 := C ~= [] & D ~= [] -> aC o aD = aDC;
 Proof L3;
F0C := C ~= [];                 assume;
F01 := C in SEQ1;              is L2C(F0C);       // !! L2C := C ~= [] -> C in SEQ1;   // wlot can prove F01 ;
F0D := D ~= [];                assume; 
F03 := D in SEQ1;              is L2D(F0D);       // !! L2D := D ~= [] -> D in SEQ1;   // wlot can prove F03;
F07 := C in SEQinj1;           is L1C(F0C);       // !! L1C := C ~= [] -> C in SEQinj1; // F0C := C ~= []; 
F08 := D in SEQinj1;           is L1D(F0D);       // L1D := D ~= [] -> D in SEQinj1;    // F0D := D ~= [];

G0 := aC o aD = aDC;           by Tfneq; Ldom & LA; // !! Tfneq := A[f,g: FN, f=g == dom(f)=dom(g) & A[x:dom(f), f(x)=g(x)]]; 
Ldom := dom(aC o aD) = dom(aDC); byeq LaCaDdom, -LaDCdom;

! LAcase := x in A == x=a or x in im(D) & x~=Last(D) or x=Last(D) or x in im(C) & x~=Last(C) or x=Last(C) or
                 x in A & x~=a & x nin im(D) & x nin im(C); is Lconcim6(A,a,D,C)(LDim & LCim);    // ! LDim := im(D) <: A; ! LCim := im(C) <: A;
 
// !! Lconcim6 := A[A:set, a:A, y,z:SEQ1, im(y)<:A & im(z)<:A -> (x in A ==  x=a or x in im(y)&x~=Last(y) or x=Last(y) or 
//                              x in im(z)&x~=Last(z) or x=Last(z) or x in A & x~=a & x nin im(y) & x nin im(z)];

! LA := A[x:dom(aC o aD),(aC o aD)(x) = aDC(x)]; 
   Proof LA;
F0 := x in dom(aC o aD);       assume; by LaCaDdom;
F0A := x in A;                 by LAcase;         // fgcomp := {f,g ; f in FN, g in FN, Axfg := im(g) <: dom(f)};
F1 := x=a or x in im(D) & x ~= Last(D) or x=Last(D)  or x in im(C) & x~=Last(C) or x=Last(C) or x in A & x~=a & x nin im(D) & x nin im(C);
G0 := (aC o aD)(x) = aDC(x);   by Tcompval(aC, aD);       // !! Tcompval := A[x:dom(g), (f o g)(x) = f(g(x))];
G1 := aC(aD(x)) = aDC(x);      by Case6(F1); L1 & L2 & L3 & L4 & L5 & L6;

! L1 := x=a -> G1;                                // Case 3.1. x=a:(aC∘aD)(a)=first(D);aDC(a)=first(D); // first(D) = D(0);
    Proof L1;
F0 := x=a;                     assume;                          // F0D := D ~= []; 
F1 := aC(aD(x)) = D(0);        byeq F0,LaDa(F0D),LaCD0(F0D);    // !! LaDa := D ~= [] -> aD(a) = D(0); // !! LaCD0 := D ~= [] -> aC(D(0)) = D(0); 
F2 := aDC(x) = D(0);           byeq F0,LaDCa(F0D);       // !! LaDCa := D ~= [] -> aDC(a) = D(0);
G1;                            byeq F1, -F2;             // 9.11.22:DNW: is Axeq2(F1 & F2);  // !! Axeq2 := x=a & y=a -> x=y; DNW: did not work; 
    end Proof L1;              // G1 := aC(aD(x)) = aDC(x); 

! L2 := x in im(D) & x ~= Last(D) -> G1;          // Case 3.2. x∈im(D) and x≠last(D):(aC∘aD)(x)=next(D,x);aDC(x)=next(D,x);        
    Proof L2;
F0 := x in im(D);              assume;
F01 := x ~= Last(D);           assume;                   // F0D := D ~= [];  // !! LaCimD  := x in im(D) -> aC(x) = x;
F02 := nextf.D(x) in im(D);    is Lnextf3.D(x);          // !! Lnextf3 := A[x_imf, nextf(x) in im(f)]; 
F03 := aC(nextf.D(x)) = nextf.D(x);  is LaCimD(F02);     // !! LaCimD :=  x in im(D) -> aC(x) = x;           
F1 := aC(aD(x)) = nextf.D(x);  byeq LaDim1(F0D & F0 & F01), F03;    // !! LaDim1 := D ~= [] & x in im(D) & x ~= Last(D) -> aD(x) = nextf.D(x);    
F2 := aDC(x) = nextf.D(x);     byeq LaDCim1D(F0 & F01);  // !! LaDCim1D := x in im(D) & x ~= Last(D) -> aDC(x) = nextf.D(x);
G1;                            byeq F1, -F2;
    end Proof L2;                // G1 := aC(aD(x)) = aDC(x); 

! L3 := x=Last(D) -> G1;                         // Case 3.3. x=last(D);(aC∘aD)(last(D))=first(C);aDC(x)=first(C);
    Proof L3;                    // was Proof L1;  ??? not catched ???  // !! LaCa := C ~= [] -> aC(a) = C(0);
F0 := x=Last(D);               assume;                        // F0D := D ~= []; // !! LaCD0 := D ~= [] -> aC(D(0)) = D(0); 
F1 := aC(aD(x)) = C(0);        byeq F0,LaDLastD(F0D), LaCa(F0C);    // !! LaDLastD := D ~= [] -> aD(Last(D)) = a;  
F2 := aDC(x) = C(0);           byeq F0,LaDC_LastD(F0D & F0C); // !! LaDC_LastD := D ~= [] & C ~= [] -> aDC(Last(D)) = C(0); 
G1;                            byeq F1, -F2;                  // G1 := aC(aD(x)) = aDC(x);
    end Proof L3;                // byeq F0,LaDLastD(F0D )& LaCa; ??? did not catched ???

! L4 := x in im(C) & x~=Last(C) -> G1;           // Case 3.4. x∈im(C) and x≠last(C):(aC∘aD)(x)=next(C,x);aDC(x)=next(C,x);
    Proof L4;
F0 := x in im(C);              assume;                    // G1 := aC(aD(x)) = aDC(x); 
F01 := x ~= Last(C);           assume;                    // F0D := D ~= [];  // !! LaCimD  := x in im(D) -> aC(x) = x;
F02 := nextf.C(x) in im(C);    is Lnextf3.C(x);           // !! Lnextf3 := A[x_imf, nextf(x) in im(f)]; 
F03 := aC(x) = nextf.C(x);     is LaCim1(F0C & F0 & F01); // !! LaCim1 := C ~= [] & x in im(C) & x ~= Last(C) -> aC(x) = nextf.C(x); 
F1 := aC(aD(x)) = nextf.C(x);  byeq LaDimC(F0), F03;      // !! LaDimC :=  x in im(C) -> aD(x) = x; 
F2 := aDC(x) = nextf.C(x);     byeq LaDCim1C(F0 & F01);   // !! LaDCim1C := x in im(C) & x ~= Last(C) -> aDC(x) = nextf.C(x);  
G1;                            byeq F1, -F2;              // G1 := aC(aD(x)) = aDC(x); 
    end Proof L4;

! L5:= x=Last(C) -> G1;                          // Case 3.5. x=last(C);(aC∘aD)(last(C))=a;aDC(last(C))=a
    Proof L5;
F0 := x=Last(C);              assume;                      // F0C := C ~= []; // !! LaCLastC := C ~= [] -> aC(Last(C)) = a;
F1 := aC(aD(x)) = a;          byeq F0,LaDLastC(F0C & F0D),LaCLastC(F0C);  // !! LaDLastC := C ~= [] & D ~= [] -> aD(Last(C)) = Last(C);   
F2 := aDC(x) = a;             byeq F0,LaDC_LastC(F0C);     // !! LaDC_LastC := C ~= [] -> aDC(Last(C)) = a; 
G1;                           byeq F1, -F2;                // G1 := aC(aD(x)) = aDC(x);
    end Proof L5;                

! L6 := x in A & x~=a & x nin im(D) &  x nin im(C) -> G1; // Case 3.6. x≠a,x∉im(C),x∉im(D):(aC∘aD)(x)=x;aDC(x)=x; 
    Proof L6;
F00 := x in A;               assume;
F0 := x~=a;                  assume;
F01 := x nin im(D);          assume;                                     // F0A := x in A;
F02 := x nin im(C);          assume;                                     // !! LaCelse := x in A & x ~= a & x nin im(C) -> aC(x) = x;
F1 := aC(aD(x)) = x;         byeq LaDelse(F00 & F0 & F01), LaCelse(F0A & F0 & F02);  // !! LaDelse := x ~= a & x nin im(D) -> aD(x) = x;
F2 := aDC(x) = x;            byeq LaDCelse(F00 & F0 & F01 & F02);        // !! LaDCelse := x in A & x~=a & x nin im(D) &  x nin im(C) -> aDC(x) = x;
G1;                          byeq F1, -F2;                               // G1 := aC(aD(x)) = aDC(x);
    end Proof L6;
   end Proof LA;
  end Proof L3;
 end Proof T3;

 ]; // aCD :: [
]; //  perm :: [  // 2

// !! LdconjIn := (d&&P) <: d;                   // && precedence ???
// !! Ldconjfs := d in finset -> (d&&P) in finset;
// !! Tafnfn1 := f in afn(A) -> f in fn(A,A); 
     // !! TafnAFN := afn(A) <: AFN; // rename to LafnAFN???
// !! LafnFif := B<:A & f in afn(B) -> F[x:A, if(x in B, f(x), x)] in afn(A);
// !! Lafn2 := A in finset & f in fn(A,A) & injective(f) -> f in afn(A);
// !! TFdom1   := dom(F[x:A, G(x)]) = A;                 // root :: !! TFdom1 := dom(FAGx) = A; 
// !! TAinIna := A[d, g in A] & A<:B -> A[d, g in B];  
     // !! TfinsetRa := X in finset -> R[x:X, G(x)] in finset;
// AFN :: !! LAFNinj := injective(f);
// AFN :: !! LAFN4 := A[x:dom(f),k:int, f((f^k)(x)) = (f^(k+1))(x)];
    // AFN :: !! L4 := f in afn(dom(f));!! L4 := f in afn(dom(f));
// !! Lafn9 := g in AFN & dom(g)=A -> g in afn(A);
// dcl[||, fn({f:AFN, A:set; dom(f) <: A}, afn(A)];   // extension of f on A;
// f_AFN_A_set := {f:AFN, A:set; dom(f) <: A};
// (||) := F[{f:AFN, A:set; dom(f) <: A}, F[x:A, if(x in dom(f), f(x), x)]];
// ! Tdvl := A[f_AFN_A_set, f||A = F[x:A, if(x in dom(f), f(x), x)]];                 byeq Red("F");  // dvl: double vertical line;
// ! Ldvldom := A[f_AFN_A_set, dom(f||A) = A];                                        by Tdvl; is TFdom1;
// !! Ldvlafn := A[f_AFN_A_set, Ldvlafn_type := f||A in afn(A)];


] // end module 2_altg.v