#include "lib.h"  // 7/12/00 8/3/00 8/31/00 9/20/00 9/25/00 11/03/00
#include "achs.h"
#include "sbs.h"  // 11/27/00 12/07/00 01/08/01 01/31/01 02/22/01
#include "tt.h"   // 03/14/01 06/01/01
#include "adl.h"  
#include "rep.h"     
#include "typ.h"    
#include "lot.h"
#include "cr.h"     
#include "elem.h"
#include "prf.h"
// #include "ismd.h"
#include "term.h"
#include "err.h"
// #include "achs.h"
#include "etc.h"
#include "assert.h"
elem arqt[maxlevqt];  // all qabterms in achs, beginning from top, r: last occupied
elem arqt1[maxlevqt]; // maxlevqt = 20, see lib.h
extern elem zexist1,opb,savetyp,convar[maxvars]; extern int isteq; //ist2; elem st2[lst]
extern elemp wst;
extern  int istparinst,lstr,iconvar,iMod, Maxipp;
// extern  elem stparinst[lst]; // stack of parameters: to avoid recursive looping 
// extern  elem stparinst1[lst];
extern int zz, aa, bb, gg, hhh,kk,ii,oo,qq,yy,mm,ll, uu, prcause; extern ats acrlf;
extern achs* pntu;
elemp qM1;
int KM1;
int placeM1;
int sbstcount=0;
int instcount=0;
int repcount=0;
int typcount=0;
int sumcount=9;
char* CAUSE;     // for cause in insteqt;
elem cause_V;
elem cause_V1;
void warm(elemp arm, int i, elem z, int maxarm);
int checkts(char*, elem);
// inline bool Exbvar(elem z){ headp h; elemp q; return (mel(z,&h,&q)==bvar) && (q[0]==zexistx); }
bool conv(elem z); // { return inlist(z,convar,iconvar); } 
#define maxwhile 150   // move to dd;

    sbst::sbst()
{
 size = 0;  
 iMod = -1;
 rpsimple = true;                            // right body has no composite terms
 stqab.init();  ++sbstcount; 
 for(int i=0; i<size; i++) body[i] = zel;
} // end sbst::sbst()

/* sbst::sbst(elem z, elemp q, int n)     // z: d,d&&P, d&&d1, z&&P,z&&d;  used in ismd;
{                                       // q points to M-1; n: the number of el-s;
 // int savemm = mm;
 // mm=1;
 if(mm) ippq1("+sbst::sbst z= ", z, " q= ", q+1, n);
 size = 0; qM1 = q; KM1 = n; placeM1 = 0;
 Sbst(z);
 if(mm) ipp("-sbst::sbst z= ", z, " s= ", this);
 // mm = savemm;
} // void sbst::sbst(elem z, elemp qM, int n)

 void sbst::Sbst(elem z)                     // z: d,d&&P, d&&d1, z&&P,z&&d;  used in ismd;
{                                            // qM points to M-1;
 ats m,m1,m2; headp h,h1,h2; elemp q,q1,q2;
 if(mm) ipp("+Sbst z= ", z); // , " placeM1= ", placeM1, " KM1= ", KM1);
 m = mel(z,&h,&q);
 if(m==abt){ sbst1(z); goto ret; }           // sbst1: adds to s (z++i, qM[KqM+i]);
 if(m!=pfs || q[0] != zdconj) error("Sbst: wrong z= ", z, " zdconj= ", zdconj);
 m1 = mel(q[1],&h1,&q1); m2 = mel(q[2],&h2,&q2);
 if(m1==abt)
 {
  sbst1(q[1]); 
  if(m2==pfs) goto ret; 
  if(m2==abt){ sbst1(q[2]); goto ret; }
  error("Sbst: wrong q[2], z= ", z, " q[2]= ", q[2]);
 } //  if(m1==abt)
 if(m1!=pfs || q1[0] != zdconj) error("Sbst: wrong q[1], z= ", z, " zdconj= ", zdconj);
 Sbst(q[1]);
 ret: if(mm) ipp("-Sbst z= ", z);
} // end sbst::Sbst(elem z)

 void sbst::sbst1(elem d)       // adds to s (d++i, qM[KqM+i]);
{
 int i,k; headp h;
 if(mm) ipp("+sbst::sbst1: d= ", d, " placeM1= ", placeM1, " KM1= ", KM1  );    // ???
 if(mel(d,&h) != abt) error("sbst::sbst1(d,qM,n): not abterm d= ", d);
 k = kmain(h);
 if(placeM1+k > KM1) error("sbst::sbst1(d): placeM1+kd > KM1, d= ", d, " placeM1= ", placeM1, " KM1= ", KM1);
 for(i=1; i <= k; i++) adds(nami(d, i), qM1[placeM1+i]);  // init(placeM) = -1;
 placeM1 += k;
 if(mm) psbs("-sbst::sbst= ");
} // end sbst::sbst(elem d, elemp q)

   sbst::sbst(elem d, elem d1) // d -> d1
{
 if(mm&&sss) ipp("+sbst d= ", d, " d1= ", d1);
 int i, k = ldev(d);
 size = 0;
 if(k != ldev(d1))
 {
  ipp("sbst: different sizes d= ", d, " d1= ", d1);
  goto ret;
 }
 if(k == 0) error("sbst::sbst(d, d1): not definition d= ", d);
 for(i=1; i <= k; i++) adds(vard(d, i), vard(d1, i) );
 ret: if(mm&&sss) psbs("-sbst::sbst(d, d1)= ");
} // end sbst::sbst(d, d1)
  
   sbst::sbst(elem sq)
{
 if(mm&&sss) ipp("+sbst: sq= ", sq);
 int i; headp h; elemp q; int k;
 if(!seqv(sq, &k, &q, &h)) error("sbst: not sequence, sq= ", sq);
 size = h->l;
 if(!even(size)) error("sbst(sq): not even size= ", size);
 for(i=0; i<size; i++) body[i] = q[i];
 if(mm&&sss) psbs("-sbst(sq) s= ");
} // end  sbst::sbst(elem sq)

   sbst::sbst(int k, elem arq[], elem stqab[])
{
 error("sbst::sbst(int k, elem arq[], elem stqab[]), k= ", k);
 size = (k+1)*2;
 for(int i=0; i<=k; i++){ body[i*2] = arq[i]; body[i*2+1] = stqab[i]; }
 if(mm&&sss) psbs("-sbst::sbst(k, arq, stqab)= ");
} // end sbst::sbst(int k, elem arq[], elem stqab)

*/
    void sbst::adds(elem x, elem y) // , elem y1) // y1==zel1: dont check x in y !
{
 headp h; elemp q; int i,m = mel(x,&h,&q), save = size, savemm=mm, savesss = sss;
 elem b,b1; bool psmel = (m==var || m==bvar);
 if(mm) ipp("+adds x= ", x, "\ny= ", y, " sbstcount= ", sbstcount);  // , " y1= ", y1); }
 if(size < 0 || size >= lsbst) error("sbst::adds: wrong size= ", size);
 if(mm && interm(x,y)) errmsg("adds: wrong(interm(x,y), x= ", x, "\ny= ", y); //  goto ret; }
 if(x == zel) error("adds: wrong(x==zel) x= ", x);
 if(x == y){ ipp("adds: x=y, x= ", x, "\ny= ", y); return; } // typ does not work
 if(comp(x)) rpsimple = false;
 if(mm && !psmel) ipp("adds: not smel x= ", x, " y= ", y);
 for(i=0; i < size; i=i+2)   // if size==2 then sbst = {[body[0],body[1]]}, i.e. size points to first free.
 {
  b = body[i], b1 = body[i+1];
  // if(interm(b,b1)) ipp("adds: recursive! x= ", x, "\ny= ", y, "\nb= ", b, "\nb1= ", b1, " s= ", this);
  if(b == x)
  { 
   if(b1==y){ ipp("adds: double x= ", x, "\ny= ", y); goto ret; }
   pst("adds");
   stqab.pr();
   psbs("adds"); 
   ipp("adds: multiple sbst, cancelling the present one (x,b1), \nx= ", x, "\ny= ", y, "\nb1= ", b1); //  " y1= ", y1);
   body[i+1] = y; 
   goto ret;
  } // if(b == x
 } // for(i)
 size += 2;
 if(size >= lsbst)
 {
  size -= 2; pntu->prach("adds:size");
  psbs("adds"); //cout<<"\nelm x,z="; pelm(x); pelm(z);  M:
  error("adds: size >= lsbst, x= ", x, " y= ", y, " size= ", size, " lsbst= ", lsbst);
 }
 if(mm&&sss) ipp("adds x= ", x, " y= ", y); // , " y1= ", y1; 
 body[size-2] = x; body[size-1] = y;
 /* if(psmel)
 {
  if(mm&&sss) ipp("adds: checking for possible changes in right parts, x= ", x, " y= ", y);
  M: for(i=0; i < save; i=i+2) 
  {
   b = body[i];  b1 = body[i+1];
   if(interm(x,b1))
   {
    body[i+1] = rep2(b1,x,y); b1 = body[i+1];
    if(interm(b, b1))
    { 
     if(b == b1){ remove(i); goto M; }
     error("adds: interm(body[i], body[i+1]),  x= ", x, " y= ", y, " body[i]= ", b, " s= ", this);
    } // if(interm(b, b1)
   } // if(interm(x,z))
  } // for(i; i < save; )
 */ //} // if(psmel)
 ret: if(mm) ipp("-adds x= ", x, " y= ", y, " s= ", this);  sss=savesss; mm=savemm;
}  // end adds

  bool sbst::addsch(elem x, elem y) // add with checking vals(x) != zel;
{
 bool r=true; elem z = vals(x);
 if(z==zel) adds(x,y);
 else if(!req(y,z)){ ipp("addsch: z:vals(x) != y, x= ", x, " y= ", y, " z= ", z); r = false; } 
 return r;
} // end bool addsch
                                                    
  void sbst::addsp(elem Q, elem Y[], int k, elem V) // add to body (Q,Y[0]), ..., (Q,Y[k-1]), (Q,V);
{                                                   // addsp: lambda-notation: Q = lambda(Y[0],...Y[k-1];V)
 if(mm) ipp("+addsp: Q= ", Q, "\nV= ", V, " Y[0]= ", k==0? zel: Y[0], " k= ", k);
 int i,j, sizepar = size + (k)*2, sizenew = sizepar + 2;
 if(sizenew >= lsbst) error("addsp: size + (k+1)*2 >= lsbst, Q= ", Q, " size= ", size, " k= ", k);
 for(i=size, j=0; i<sizepar; i+=2,j++){ body[i] = Q; body[i+1] = Y[j]; }
 body[sizepar] = Q; body[sizepar+1] = V; size = sizenew;
 if(mm) ipp("-addsp: Q= ", Q, "\nV= ", V, " s= ", this);
} // end void addsp

  void sbst::remove(int k)          // remove body[k], body[k+1];
{
 int i; 
 if(k&1 != 0 || k < 0 || k > size-2) error("sbst::remove: wrong k= ", k, " size= ", size);
 if(mm){ ipp("+remove: removing(x,y), k= ", k, " x= ",body[k]," y= ", body[k+1]); psbs(); }
 if(k < size-2 && mm){ ipp("remove: inside body: k < size-2,  k= ", k); psbs(); }
 for(i= k; i < size-2; i++) body[i] = body[i+2];
 size -= 2; assert(size >= 0);
 if(mm){ ipp("-remove: k= ", k); psbs(); }
} // end void remove(int k) 

  void sbst::removebvars(elem z)    // remove bvars of qabterm z from body;
{
 for(int i=size-2; i >= 0; i-=2)
 {
  elem x = body[i];
  if(htbv(x)==z) remove(i);
 } // for(i)
} // end removebvars  
                                // k=0 : look only in body, k=1: look in stqab and in body; k=2: ??? vals2 ??? not imp. yet
  elem sbst::vals(elem x, att k)    // look in body for x; if yes return body[i+1], if k==1 look in stqab;
{ // if pvar(x) then use valsp;     // if not in body,  look in stqab; if not return zel; 
 elem r = zel, Q; elemp qx; int i, kx;  // savesss = sss, savettt = ttt, savemm = mm; elemp qx;
 // elem Q=pvar(x,&qx,&kx), r = zel; // Q(a1,...,ak), ai : actual parameters; kx = k+1;
 if(mm){ ipp("\n+vals x= ", x, " k= ", k, " rpsimple= ", rpsimple);  psbs("vals");  }
 Q = pvar(x,&qx,&kx);
 if(Q==zel)    // x is not a pvar;
 {
  if(comp(x) && rpsimple){ if(mm) ipp(" x is composite but sbst is simple, r= zel, x= ", x); goto ret; } // 
 } // if(Q==zel)
 else { if(mm) ipp("vals: x is a pvar, x= ", x, " Q= ", Q, " kx= ", kx); }
 // sss = 0; ttt = 0; 
 if(size >= lsbst) error("vals: size >= lsbst ", size, lsbst);
 if(x.i && k==1 && (r = stqab.valbvar(x)) != zel)
 { 
  if(mm) ipp("vals: stqab.valbvar(x) found r= ", r, " x= ", x); 
  goto ret; 
 } // if(x.i && ...)
 for(i=0; i<size; i=i+2)  // s.size=the number*2
 { 
  elem b = body[i], b1 = body[i+1];
  if(b==zel) continue;
  if(mm && interm(b,b1)) ipp("vals:body: interm(b,b1),  x = ", x, "\nb= ", b, "\nb1= ", b1, " s= ", this);
  if(Q != zel)       // x is Q(a1,...,ak)
  {
   if(b != Q) continue;     // qb: formal parameters;
   if(mm) ipp("vals: found Q= ", Q, " x= ", x, " kx= ", kx, " i= ", i);
   if(kx==0){ if(mm) ipp("vals:kx==0: r= ", b1); r = b1; goto M; }
   r = valsp(x,qx,kx,b,i);  goto M; // x = Qx(...qx...), b = Qb(...qb...), (b,b1) is lambda-notation;
  } // if(Qx != zel)
  // mm=0;
  if(req(b, x))
  { 
   r = b1; 
   M: /*if(ax) *ax = i;*/  break;
  } // if(req(b, x))
 } // end for(i)
 ret: if(mm) ipp("-vals x= ", x, "\nr= ", r);   //  sss = savesss; ttt = savettt; mm = savemm;
 return r;
}  // end vals

   elem sbst::vals1(elem z)    // must occure only once: and only in rep;
{ 
 elem r; 
 // if(mm) ipp("+vals1 z= ", z);
 r = vals(z); 
 if(r==zel) r = z; // else if
 // ret: if(mm) ipp("-vals1 z= ", z, " r= ", r);
 return r;
} // end elem sbst::vals1(elem z)

   elem sbst::vals2(elem z)               // for speeding modify vals by adding second parameter to vals; 2023.04.04;
{
 if(mm) ipp("+vals2: z= ", z, " sbstcount= ", sbstcount);
 elem r1, r = vals(z);                    // k=1
 if(r!=zel)
 { 
  r1 = vals(r,0);
  if(r1 != zel){ if(mm) ipp("vals2:r1 != zel z= ", z, " r(temp)= ", r, " r1= ", r1);  r = r1; }
 } // if(r!=zel)
 if(mm) ipp("-vals2: z= ", z, " r= ", r);
 return r;  
} // end elem sbst::vals2(elem z)

   elem sbst::valsp(elem x, elemp qx, int kx, elem Q, int place)
{    // qx -actuals, qb: formals;  // x = Q(...qx...), b = Q, (b,b1) is lambda-notation;
 int i,j, savemm = mm; elem a,a1, z, V, r; sbst s; // s = [...(qb_i, qx_i)...]
 // mm=1;
 if(mm) ipp("\n+valsp x= ", x, "\nQ= ", Q, "\nkx= ", kx);
 if(kx==0) error("valsp:kx==0: x= ", x, "\nQ= ", Q);
 if(mm) psbs("valsp");   // was if(mm) prstqab("valsp"); 
 for(i=1, j=place; i<=kx; i++, j+=2)
 {
  if(j >= lsbst) error("valsp: j >= lsbst, x= ", x, " Q= ", Q, " place= ", place, " j= ", j);
  if(body[j] != Q) error("valsp: body[j] != Q, x= ", x, " Q= ", Q, " body[j]= ", body[j], " j= ", j);
  z = body[j+1]; a = qx[i];  // z: formal, a: actual;
  if(mm) ipp("valsp:for, formal z= ", z, " actual a = ", a);
  a1 = stqab.repb(a); // else a1 = vals(a);          // use just a1 = rep(a); ???
  if(a1==a){if(mm) ipp("valsp:a1==a(repb(a) failed): before 'a1 = rep(a)', a= ", a);  a1 = rep(a,"valsp1"); }
  if(a1 != a) ipp("valsp: repb or rep changed a to a1, a= ", a, " a1= ", a1);  
  s.adds(z, a1);   // s.
 } // for(i=1)
 if(mm){ ipp("valsp: after for, i= ", i, " j= ", j); s.psbs("s.psbs: valsp:after for"); }
 if(body[j] != Q) 
                   error("valsp:error:body[j] != Q: kb < kx, x= ", x, " j= ", j, " s= ", this);
 V = body[j+1];
 if((j+=2) < size && body[j]==Q){  
        ipp("valsp: too small kx, x= ", x, " kx= ", kx, " j= ", j, " s= ", this);  r = zel; goto ret; }
 r = s.rep(V, "valsp2");  // value of Q(...qx...);  // REWORK !!! replace rep ???
 if(mm) ipp("valsp3: after 'r = s.rep(V)', before 'r = rep(r)', \nV= ", V, "\nr= ", r);
 // r = rep(r, "valsp4");  // ???       // REWORK !!! replace rep ???                   // commented on 2023.04.03 
 ret: if(mm) ipp("-valsp x= ", x, "\nQ= ", Q, "\nV= ", V, "\nr= ", r);  mm = savemm;
 return r;
} // end valsp

/*   elem sbst::vals(int k)   // k = 0,1,2, ...  // not used'
{
 elem r; 
 if(mm&&sss){ ipp("+vals k= ", k); psbs("vals");  }
 if(size >= lsbst) error("vals: size >= lsbst ", size, lsbst);
 int i = k*2 + 1;
 if(i < 0 || i >= size) error("vals: wrong k= ", k);
 r = body[i];
 if(mm&&sss) ipp("-vals k= ", k, " r= ", r);
 return r;
}  // end vals

   int sbst::valsarqt(elem x, elemp ay, elem arq[]) // not used 
{        // *ay = vals(x);  arq[] - lambda-arguments; r=last(arq)
 int i,ax,j = -1; elem y;
 if(mm&&sss) error("+valsarqt: x= ", x);
 y = vals(x, &ax);
 if(y == zel) error("valsqart: no x is in sbst s, x= ", x, " s= ", this);
 for(i=ax+2; i < size; i+=2)  // ax+2: skipping x, y;
 {
  if(body[i] != x) goto ret;
  if(++j >= maxlevqt) error("valsarqt: too big embeddingness of qterms j= ", j);
  arq[j] = body[i+1]; 
 } // for(i)
 ret: *ay = y;  if(mm&&sss) ippq1("-valsarqt x= ", x, " r= ", arq, j+1);
      stqab.pr(); return j;
} // end valsarqt
*/

 elem sbst::valHM(elem z)                   // , att pHM)   // , int pHM)         // value z in Models(Host, Mod),
{  
  elem r=z,Q,M,M1,t; att a; int saveff=ff;              // was r=z;  // cannot use top, #define top st[ist];
 if(mm) ipp("+valHM z= ", z);               //  " pHM= ", pHM);  // pHM not used ???
 if(iMod<0) goto ret;// error("valHM: iMod < 0, z= ", z, " iMod= ", iMod);
  a = method(z, &M);
 if(a==0) goto ret;                         // a==0: z is not a method;
 if(a==1){ r = M; goto ret; }               // a==1: z is a VS method;
 if(a==2)                                   // a==2: z is a NVSmethod, M is the model for R.M from HostMod;
 {
  t = pntu->topach().e;
  if(fnt2(t, zdot, &Q, &M1) && Q==z && M1==M)
  {
   if(mm) ipp("valHM: top = z.M, no trm2(zdot,z,M), z= ", z, "\ntop= ", t);
   r = z; goto ret;
  } // if(fnt2(top, zdot,...)
  // ff=1;
  r = trm2(zdot,z,M,zel);           // zany): ERROR, no typ(r) and therefore, no val !!!;
  typ(r); if(mm) ipp("valHM: created type of r, z= ", z, " r= ", r); 
  goto ret;
 } // if(a==2)  
 error("valHM: wrong a, z= ", z, " a= ", a);                              // wrong a
 ret: if(mm) ipp("-valHM z= ", z, "\nr= ", r); ff=saveff;
 return r;
} // elem valHM
                                 // named_abt_in_dterm: named abt-term z(h belongs to z) is in a dterm; cannot made z.M;
 elem sbst::valsHM(elem z, att pvals, bool abt_in_dt) // value z in the sbst, including Host, Mod;
{                          // r==zel neans that z is composite and is not in body,stqab,HostMod;
 elem r=zel; att n; headp h=0;
 if(mm){ ipp("\n+valsHM z= ", z); psbs(); prHostMod("+valsHM"); }
 if(rootname(z)){ r = z; goto ret; }
 r = pvals==2? vals2(z): vals(z);              // was r = vals2(z);
 if(r!=zel) goto ret;
 if(abt_in_dt){ if(mm) ipp("valsHM:abt_in_dt: goto M, z= ", z, " r(temp)= ", r); goto M; }// skipping r = valHM(z);
 r = valHM(z);         // returns r=z, if z is not in Host,Mod; r==z means that 
 if(r != z || simple(z)) goto ret;  // depend works here: not exactly, z can contain some body-left-parts !!!
 if(dterm(z) &&  !depend(z)){ if(mm) ipp("valsHM:dterm(z) && !depend(z)) z= ", z); goto ret;  }// +++ 2023.04.09, should affect ||;
 if(cltyp(z)) goto ret;  // ??? cltyp ???
 if(kmain(z, &h))            // r=z and comp(z) here; // +++ ",&h"
 {
  M: if(mm) ipp("valsHM:M:kmain(z) z= ", z);
  if(!depend(z)) goto ret;  // +++ "h->tel==pfs && " //--- h && h->tel==pfs && 
  n = ptt->newtt("valsHM"); filltabt(n); stqab.wr(z,n);          // when to remove z from stqab ???
  if(mm) ipp("valsHM:kmain(z):depend(z): created a new place n for z', z= ", z, " n= ", n);
 } // if(kmain(z))
 r = zel;                  // see elem r=zel above; to go into depth of V in rep; (via goto Nxt;)
 ret: if(mm) ipp("-valsHM z= ", z, "\nr= ", r);
 return r;
} // end valsHM

   elem sbst::rep(elem z, char* place, att pvals)     // replace z using body,stqab,HM; result: r; 
{
 elem r=z; elem V,V1,tz,t,tr; each E,E1; int i,hl,save, saveist=ist, savemm=mm; // bool depV;
  att m,n; short k, iarr= -1,im=0,iF=0;  achs f(z); bool abt_in_dt=false;// elemp q; int savemm=mm;
 int static depth=0; bool finr=false; headp h,g; elemp q; elem arr[maxvars]; elem artp[maxvars];
 // if(z.ad==10321)
 //  mm=mm;
 if(mm)
 {
  ipp("\n+rep z= ", z, "\nist= ", ist, " depth= ", depth, " repcount+1= ", repcount+1);  //  " place= ", place); 
  if(place){ *pfhis << " place= " << place; cout << " place= " << place; }
  // prext("+rep");
  psbs(" s= "); 
  prHostMod();
  f.prach("+rep");
  if(mm && depth==1)
  mm=mm;
 } // if(mm)
 
 ++repcount;
 if(++depth > 20) error("rep:depth > 20: possible looping, z= ",z," depth= ",depth, " repcount= ",repcount," ist= ", ist);
 if(rootname(z)) goto ret;      // ??? Final ???
 // if(kmain(z) && !depend(z)) goto ret;      // kmain(z) ==  mel(z)==abt or qterm(z) == qabterm(z);
 if(ist != -1)
 { 
  pst("rep: ist != -1"); 
  ipp("rep: ist != -1, z= ", z, " ist= ", ist, " depth= ", depth, " repcount= ", repcount); *pfhis << " place= " << place;
  if(depth>=1) ipp("rep:depth>=1: ist != -1, z= ", z, " place= ", "rep");
 } // if(ist != -1)
 
 if(size==0 && stqab.iar == -1 && iMod == -1)
 { 
  if(mm) ipp("rep:no action:size==0 && stqab.iar == -1 && iMod == -1, z= ", z);             
  goto ret1; 
 } // if(size==0 && ...)
 
 if(repcount == stad2)
 mm=mm;   

 while(f.iach >= 0)
 {
  V = f.curvert(&finr);
  E = f.topach(); ++im;
  if(mm){ ipp("\nrep:while: V= ", V, "\nf.iach= ", f.iach, " finr= ", finr, " im= ", im); 
          pst("rep:while"); f.prach("rep:while"); }
  if(im > 200) error("rep:while looping V= ", V, " f.iach= ", f.iach, " k= ", k, " im= ", im);
  if(V.ad==stad1 && im==stad2)
  mm=mm;
/*
  if(E.p == -1 && kmain(V,&h))  -----------wrong ??? see valsHM 2023.04.08;
  { 
   if(mm) ipp("rep: E.p == -1 && kmain(V,&h), z= ", z, "\nV= ", V);
   // if(!depend(V)){ V1 = V; goto Main; }   // change depend !!! use vals(V) = zel
   if(vals(V)==zel && iMod<0){ if(99) ipp("rep: not depend: V= ", V); V1 = V; goto Main; }  
   // if(h->tel==abt && f.iach>=1 && dterm(f.ach[f.iach - 1]))f.topach1().e)) goto Nxt;
   if(mm) ipp("rep: E.p == -1 && kmain(V,&h): depend(V): going to Nxt, z= ", z, "\nV= ", V);
   goto Nxt;
  } // if(kmain(V,&h))
*/
/*-----------------from C1
 if(z==zbool || z.m==ints || dclname(z)&&scopeden(z)==zel ) goto ret2;       
 if(comp(z) && ++dpth > 100)
   error("rep: dpth > 100, z= ", z, " dpth= ", dpth); 
 if(dpth < 0) error("rep: dpth < 0, z= ", z, " dpth= ", dpth);
                       // 2. size==0 && istqab<0 && pHM == 0
 if(size==0 && stqab.iar<0 && iMod<0) // pHM == 0)                            
    { if(mm) ipp("rep:size==0 && stqab.iar<0 && iMod<0 no action: size==0 && istqab<0 && iMod<0, z= ", z); goto ret1; } 
 // if(mel(z)==abt && scope(z)==zel){if(9) ipp("rep: abt: scope(z)==zel, z= ",z); goto ret1; } 
                       // 3. cltyp(z): no action;
 if(cltyp(z)){ if(mm) ipp("rep:cltyp(z) no action: closed type, z= ", z); goto ret1; } 
                       // 4. iMod < 0  && !depend(z);   
 if(iMod<0 && !depend(z)) // ??? 7.10.20        pHM == 0                         
 {
  if(mm) ipp("rep:iMod<0 && !depend(z)  no action: iMod<0 && !depend(z), z= ", z); 
  goto ret1;
 }  // if(iMod<0 && !depend(z)) // vals1 can be used only in rep !!!
 */ // -----------end from C1

  m = mel(V, &h, &q);
  if(m != pfs) goto Normal;
  
  if(q[0]==zdot)
  {
   if(mm) ipp("rep: dot term V= ", V, " q[1]= ", q[1], " q[2]= ", q[2]);
   // if(h->name != noname) goto M1;
   if(f.ach[f.iach].p != -1) error("rep:zdot: f.ach[f.iach].p != -1, z= ", z, "\nV= ", V, " p= ", f.ach[f.iach].p);
   V1 = valsHM(V);
   if(V1 != zel) goto Main;              // replace V with V1;
   wrst(zdot);
   V1 = vals(q[1]);
   if(V1 != zel)     // a separate by (by1) for such cases ??? 2023.04.07 ???
   {                // F1 := *(mSS).Gr;             by AxmSS,Red("dot"); // !! AxmSS := * @ mSS = F[A:P[elg], ...];
    f.ach[f.iach].p = 0;     // skipping dot ;
    V = f.curvert(&finr); E = f.topach();        // V == q[2] here;
    goto Normal;
   } // if(V1 != zel)
   wrst(q[1]);              // vals(q[1]) == zel here;      
   f.ach[f.iach].p = 1;     // skipping dot and q[1];
   goto Nxt;                // skipping method;
  } // if(q[0]==zdot)
  
  if(h->adt)
  {
   if(mm) ipp("rep: adt term V= ", V, " q[1]= ", q[1], " q[2]= ", q[2]);
   V1 = valsHM(V);          // ??? took from zdot above
   if(V1 != zel) goto Main; // ??? see zdot case above; 2023.04.07;
   wrst(q[0]);              
   f.ach[f.iach].p = 0;     // skipping  q[0];
   goto Nxt; 
  } // if(h->adt)

  Normal: abt_in_dt = (m==abt && f.iach > 0);
  if(abt_in_dt){ E1 = f.ach[f.iach-1]; abt_in_dt = E1.p == 1 && dterm(E1.e) && root(E1.e) != zfn; }
  if(mm) ipp("rep:Normal z= ", z, "\nV= ", V, " abt_in_dt= ", abt_in_dt, " f.iach= ", f.iach); // f.prach("Normal"); }
  V1 = valsHM(V, pvals, abt_in_dt);         
  if(V1==zel) goto Nxt;          // V is composite, it is not clear yet; 
 
  Main: if(mm) ipp("rep:Main:V1!=zel:wrst(V1), V= ", V, "\nV1= ", V1, " ist=", ist);  //  Main: 
  if(f.iach==0 && E.p == -1) //  && simple(z))
  { 
   r = V1;
   if(mm) ipp("rep:f.iach==0 && (E.p == -1) && simple(z),r=V1, z= ", z, "\nV= ", V, " V1= ", V1);
   goto ret;
  } // if(f.iach==0 && ...)
 
  wrst(V1);
  if(V==V1)
  {
   if(mm) ipp("V==V1 z= ", z, "\nV=V1= ", V);
   if(abtallex1(V))
   {
    k = kmain(E.h); 
    if(k<=0) error("rep: abtallex1(V): k<=0 z= ", z, "\nV=V1= ", V);
    q = &(E.h->son[0]);
    if(mm) ipp("rep: k = kmain(E.h), V= ", V, " V1= ", V1, "\nq[0]= ", q[0], " k= ", k, " ist=", ist, " itt= ", ptt->itt);
    for(i=1; i<=k; i++) wrst(q[i]);   // bounded names;
   } // if(abtallex1(V))
   if(finr) goto Final; goto Nxt1;
  } // if(V==V1); below V != V1;
 
  if(mm) ipp("rep:Main: V != V1 z= ", z, "\nV= ", V, "\nV1= ", V1);
  f.acteach(&k);                // k: active index(iach or iach-1);
  f.ach[k].ch = 1;              // ch: changed;
  if(mm) ipp("rep:Main: V1 != V, V= ", V, "\nV1= ", V1, "\nf.ach[k].ch =1, k= ", k, " iach= ", f.iach);
  if(!finr) goto Nxt1; 
 
  Final: if(mm){ ipp("rep:Final:before while V= ", V, " depth= ", depth, " ist= ", ist); f.prach("Final"); }
  if(ist==0){ if(mm) ipp("rep:Final:before while:ist==0, V= ", V, " ist= ", ist); goto ret0; }
  while(f.iach >= 0)
  {
   E = f.acteach(&k); ++iF;
   if(mm){ ipp("rep:Final:while k= ", k, " iF= ", iF); pst("rep:Final:while "); }
   if(ist==stad1 && ptt->itt == stad2)
   mm=mm;
   if(E.h==0)
   { 
    if(mm) ipp("rep E.h==0, z= ", z, " V= ", V, " f.iach= ", f.iach, " iF= ", iF); 
    goto ret; 
   } // if(E.h==0)
   hl = E.h->l;
   n = emptt;
   if(iF > 100) error("rep:Final looping V= ", V, " f.iach= ", f.iach, " k= ", k, " iF= ", iF);
   if(mm) ipp("\nrep:Final: while: V= ",V, "\nE.e= ",E.e, " hl= ",hl, " k= ",k, " E.ch= ",E.ch, " ist= ",ist, " iF= ",iF);
   short pqab = qabterm(E.e);
   if(pqab) n = stqab.val1(E.e);
   if(E.ch)
   { 
    if(mm) ipp("rep:Final: E.ch, ist= ", ist);
    // save=mm; mm=0;
    r = fsegh1(E.e,E.h,n); 
    // mm=save;
    if(k>0) f.ach[k-1].ch = 1; 
   } // f(E.ch
   else
   { 
    if(mm) ipp("rep:Final: NOT E.ch, ist= ", ist);
    if(popst(E.h->l, false)) error("rep: popst failed, z= ", z, "\nV= ", V, "\nE.e= ", E.e, " repcount= ", repcount);
    wrst(E.e);
    r = E.e; 
   } // else{ // add: if(pkab) write n into the list of free places in tabt; ??????
   if(mm) ipp("rep:Final:if(E.ch): E.e= ", E.e, "\nr= ", r); // , " tr= ", tr);
   // if(mel(r,&g,&w)==pfs && w[0]==zRep) r = redRep(r); 
   if(E.h->tp==zel) ipp("rep:Final: E.h->tp==zel z= ", z, "E.e= ", E.e, " r= ", r); // was error, 2023.03.21
   if(comp(mel(r,&g)) && g->tp==zel)
   {
    for(i=0; i<=iarr; i++) if(arr[iarr]==r) goto M;
    if(++iarr >= maxvars) error("rep:Final:iarr >= maxvars,z= ", z, "\nE.e= ", E.e, "\nr= ", r); 
    arr[iarr] = r; artp[iarr] = E.h->tp;
    if(mm) ipp("rep:Final:tp(r)==zel E.e= ", E.e, "\nE.h->tp= ", E.h->tp, " r= ", r, " iarr= ", iarr);
   } // if(comp(mel(r,&g))...

   M: if(mm&&sss) f.prach("after fsegh1");
   f.iach = k-1;                // ????????????
   if(f.iach < 0) goto ret;
   if(!f.mostr(&k)) break;
  } // Final: while(f.mostr())                         
  Nxt1: f.next1(); if(mm&&sss) f.prach("Next1");  continue;           // Nxt1:  // skipping V;
  Nxt: f.next(); 
 } // end while
 if(ist != 0){ pst("-rep");  error("-rep: ist != 0, z= ", z, " ist= ", ist); }
 ret0: r = st[0];
 ret: if(mm) ipp("-rep0 z= ", z, "\nr= ", r, " depth= ", depth, " ist= ", ist, " iarr= ", iarr);  
      tz = typ(z);    
      // if(mel(r,&g,&w)==pfs && w[0]==zRep) r = redRep(r);  moved up;
      for(i=0; i <= iarr; i++) 
       if(comp(mel(arr[i], &g)))
       { 
        t = artp[i];
        if(mm) ipp("rep:ret:+for: arr[i]= ", arr[i], " artp[i]= ", t);
        if(t==zel){ if(mm) ipp("rep:ret: artp[i]==zel, z= ", z, "\narr[i]= ", arr[i], "\nartp[i]= ", t); continue; }
        save=mm; mm=0;
        if(fnt1(t,zP)) tr = typ(t); else tr = rep(t, "-rep");  // was recursive looping in rep; 2023.03.23
        mm=save;
        g->tp = tr;
        // if(t==zel) error("rep:ret:for:t==zel z= ", z, " r= ", r, " artp[i]= ", artp[i], " i= ", i); 
        if(mm) ipp("rep:ret:-for: arr[i]= ", arr[i], " artp[i]= ", t, " tr= ", tr);
       } // if(comp(mel ...)), for(i=0;...)
ret1:  --depth; ist=saveist;  
      if(depth==0 && ist != -1) ipp("rep: depth==0 && ist != -1, z= ", z, " r= ", r); 
      if(mm)
      {
       ipp("-rep z= ", z, "\nr= ", r, "\ntz= ", tz, " depth= ", depth, " ist= ", ist);  
       // prext("-rep"); 
      };  mm=savemm;                         
      return r;
} // end rep

   elem sbst::redinab1(elem z, elem x, elem d)    // reduction of z = x in d, d = {x1,...,xk; F};
{
 elem y0,y1,y1a,y2,y3,r = z; elem F; // F: axiom of z;
 achs f(z); int i,j,k,k1,n,save=ist; headp g; elemp w,v; att N[maxvars];
 chtead(z, "redinab");
 if(mm) ipp("+redinab1 z= ", z, " x= ", x, " d= ", d, " s= ", this);
 if(z.ad == stad2)
 mm=mm;
 if(mel(d,&g,&w) != abt) error("redinab1: not inabt term, z= ", z, "\nd= ", d); 
 k = kmain(g); 
 F = Axabt(d,g,w);          //w[k+1];  // F: axiom of y, replace to axabt(g);
 if(!tupl(x,&k1,&v)) { k1 = 1; v = &x; }   // q[1] == x;
 if(k != k1)
 {
  if(mm) ipp("redinab1: +case(k!=k1) in-term z= ", z, " k(abt)= ", k," k1(tuple)= ", k1);
  if(k1 != 1) error("redinab: wrong k1(tuple) (!= 1) in-term z= ", z, " k(abt)= ", k," k1(tuple)= ", k1);
  for(i=0; i<k; i++)
  {
   n = ptt->newtt("redinab1");   // places for Exist(x1, ..., Exist(xk, // x = [x1, ... ,xk] & F(x1, ... ,xk) )...)
   N[i] = n;
  filltabt(n);  // ptt->tabt[n] = ptt->tabt[0];
  } // for(i=0), places
  wrst(opb);                                               // [ in st;
  for(i=0; i<k; i++) wrst(elm(curm,1,N[i]));               // [x1, ...,xk in st           
  fseg(k+1); y0 = st[ist]; popst(y0); assert(ist == save); // y0 =  [x1, ... ,xk];
  y1 = trm2(zeq,x,y0,zbool);                               // y1 = "x = [x1, ... ,xk]";
  y1a = rep(y1,"redinab1_1");                                           // ???
  if(mm) ipp("redinab1: y1= ", y1, "\ny1a= ", y1a);
  for(i=1; i<=k; i++) adds(nami(d,i), elm(curm,1,N[i-1])); // s = x1(abt):x1(Exist), ... , xk(abt):xk(Exist);
  y2 = rep(F,"redinab1_2");                                           // y2 = F(x1(Exist),...,xk(Exist))
  y3 = trm2(zconj,y1a,y2,zbool);                            // y3 = y1 & y3;
  for(i=k-1,j=k; i>=0; i--,j--) y3 = trm2(zexist,w[j],y3,zbool,N[i]); // Exist(x1, ..., Exist(xk, y3)...)
  if(mm) ipp("redinab1: -case(k!=k1) in-term z= ", z, "\ny3= ", y3);
  r = y3;  goto ret;
 } // if(k != k1) // below k == k1;
 if(mm) ipp("redinab1: k==k1 case, z= ", z, "\nx= ", x, "\nd= ", d);
 for(i=1; i <= k; i++)
 { 
  d.i = i; 
  adds(d,*v); 
  ++v; 
 } // for(i=1) // was s.adds
 if(mm) psbs("redinab1 before rep(F)");   // ipp("redinab1 before rep(F): F= ", F);
 r = rep(F,"redinab1_3");                                          // was s.rep
 ret: if(mm){ ipp("-redinab1 r= ", r, " s= ", this); stqab.pr(); }
 // if(tead != 0 && z.m==curm && z.i==0 && int(z.ad)==abs(tead)){ mm=savemm;ttt=savettt;sss=savesss; }
 return r;
} // end elem redinab1(elem z)

   elem sbst::redinab(elem z, elem x, elem D)         // reduction of z := x in D, D=d1,D1&&P, D1&&d2);
{
 elem r = z, P1, P2; headp h; elemp q,w; int k,m,m2;
 if(mm) ipp("+redinab z= ", z, "\nx= ", x, "\nD= ", D);
 // if(istr2c(zin,x,D)){ r = ztrue; goto ret; }
 m = mel(D,&h,&q);
 if(m==var) goto ret;
 if(m==abt){ r = redinab1(z,x,D); goto ret; }
 if(h->l!=3 || q[0]!=zdconj) error("redinab: wrong Dh->l!=3 || q[0]!=zdconj, z= ", z, " x= ", x, " D= ", D);
 m2 = mel(q[2]);
 if(m2==pfs)                // D = D1 && P1;
 {
  P1 = redinab(q[1],x,D);       // q[1] = D1;
  P2 = rep(q[2],"redinab");           assert(typ(P2)==zbool);
  // if(P1==ztrue){ r = P2; goto ret; }
  r = trm2(zconj,P1,P2,zbool);
 } // if(m2==pfs)  
 if(m2 != abt) error("redinab: d2 is not abt, z= ", z, " d2= ", q[2], " m2= ", m2);
 if(!seqv(x,&k,&w)) goto ret;    // [w[1],w[2]] in D1 && d2, // D1 = q[1], d2 = q[2];
 if(k != 2) error("redinab: wrong model x: k != 2, z= ", z, " x= ", x);
 P1 = trm2(zin, w[1],q[1],zbool);  P2 = trm2(zin, w[2],q[2],zbool);
 // if(P1==ztrue){ r = P2; goto ret; }
 // if(P2==ztrue){ r = P1; goto ret; }
 r = trm2(zconj, P1, P2, zbool);
 ret: if(mm){ ipp("-redinab z= ", z, "\nr= ", r, " s= ", this); stqab.pr(); }
 return r;
} // end elem sbst::redinab

   bool sbst::isba(elem F, elem G)    // F: [z1, ... ,zk1] in {x1,..., xk; Q}; by Axab; G;
{                               // Simple case: _(z1,...,zk) in {x1,...,xk; Q(X)} == Q(Z);
 bool r = false; elem x,z,y=G,y1,Q,Q1,Q2,R; int i,k,k1,k2; headp h,g,g1; elemp q,w,w1,v;
 // if(check(F.ad, stad)) mm=1;
 if(mm) ipp("+isba F= ",F,"\nG= ",G); int static rec=0;
 if(++rec > 1) error("isba:rec: F= ",F," G= ",G); 
 if(!fnt2h(F,zin,&h,&q))
 {
  if(mm) ipp("isba: F is not in-term, F= ", F);
  goto ret; // error("isba: not an in-term F= ", F);
 }
 z = q[1];            // z: z or _(z1,...,zk) in x;
 x = q[2];            // x: abterm {x1, ... ,xk; F}
 if(mel(x,&g,&w) != abt)
 {
  if(mm) ipp("isba: x is not abterm, F= ", F, " x= ", x);
  goto ret; // error("isba: not an in-term F= ", F);
 }  // error("isba: not abterm y in F= ",F," y= ",y);
 k = kmain(g); // Q = w[k+1];  // Q: axiom of y, replace to axabt(g); ?????? Urgent: use Axabt !!! 7.10.19
 Q = Axabt(x,g,w);
 if(mm) ipp("isba: after kmain, z(in abt)= ", z, " Q(abt)= ", Q, " k= ", k);
 if(!tupl(z, &k1, &v)) { k1 = 1; v = &z; }    // z in x
 if(k==k1) // simple case
 {
  if(mm) ipp("isba: simple case, k=k1, z= ", z, " *v= ", *v, " k= ", k);
  for(i=1; i <= k; i++) { x.i = i; adds(x,*v); ++v; }  // v for tuple z in F
  if(mm) psbs("isba: simple case");
  Q1 = rep(Q,"isba");
  if(mm) ipp("isba: chabged Q(abt) to Q1, Q= ", Q, "\nQ1= ", Q1);
  r = eqt(Q1,G);    // ,true); 4.19.20
  if(!r) ipp("isba: not equal(simple case), G= ", G, "\nQ1= ", Q1);
  goto ret;
 } // if(k==k1) // simple case
 if(k1 != 1) error("isba: wrong(k1(tuple) != 1) in-term F= ", F, " tuple z= ", z);
 if(mm) ipp("isba: Exist case: F= ", F, "k1(tuple)= ", k1, " k(abt)= ", k);
 for(i=1; i<=k; i++)   // Exist-prefix (k Exists)
 {    // Exist case: z in {x1,...,xk; Q(X)} == Exist(y1,Exist(y2, ... Exist(yk, z = _(y1,...,yk) & Q(Y) ))...)
  if(!fnt2(y,&g1,&w1)) error("isba: not binary y= ", y, " in G= ", G);
  if(w1[0] != zexist && w1[0] != zexistx) error("isba: not Exist and not Existx in G= ", G, " y= ", y);
  x.i = i; y1= y; y1.i = 1; adds(x, y1);   // here y === Exist(yi, ...)
  y = w1[2];
 } // for(i)  // z = (z1,...,zk) & Q
 if(mm) ipp("isba: formula after Exists y= ", y);
 if(!fnt2h(y,zconj,&g,&w)) error("isba: not conjunction y= ", y, " in G= ", G);
 if(!iseq(w[1], &q)) error("isba: not equality w[1]= ", w[1], " in G= ", G);
 Q1 = q[1]; Q2 = q[2]; R = w[2];  // Q1 = z;  Q2 = _(z1,...,zk) & Q(Z) // Existx(yk,z = _(y1,...,yk) & R);
 // if(!req(Q1,z)) error("isba: Q1(tuple in G) != z(tuple in F), Q1= ", Q1, " z(F)= ", z, " G= ", G); 
 if(!tupl(Q2, &k2, &w)) error("isba: not tuple Q2= ", Q2, " in G= ", G);
 if(k2 != k) error("isba: wrong tuple Q2 in z = Q2,, k2 != k(abt), Q2= ", Q2, " G= ", G, " k2= ", k2, " k= ", k);
 if(!eqt(R,Q))      // ,true)) 4.19.20
 {
  psbs("isba: R != Q");
  error("isba: different formulas in F= ", F, " and in G= ", G, " Q= ", Q, " R= ", R); 
 }
 r = true; // goto ret;
 ret: if(mm) ipp("-isba r= ", r); --rec;
 return r;
} // end bool isba(elem F...)

   elem sbst::sbbvt(elem z)  // is sbbv term, r: reduced term
{
 elem x,y,P, r=z; headp h,g; elemp q,w; 
 if(mm&&sss) ipp("+sbbvt: z= ", z);
 if(mel(z,&h,&q)==pfs && mel(q[0],&g,&w)==pfs && h->l==2 && g->l==3 &&
    (w[0]==zall || w[0]==zexist || w[0]==zexist1))
 {
  x = q[0]; x.i = 1; y = q[1]; P = w[2];
  // r = rep2(P,x,y);
  r = rep(P,"sbbvt"); 
  ipp("sbbvt: reduced z= ",z, " to r= ",r);
 }
 if(mm&&sss) ipp("-sbbvt: z= ", z, " r= ", r);
 return r;
} // end elem sbst::sbbvt(elem z)

   elem sbbv(elem z)           // reduction z = All(x,P)(y) = Sb(P,x,y);
{
 elem x,y,P, r=z; headp h,g; elemp q,w;  
 if(mm&&sss) ipp("+sbbv: z= ", z);
 if(mel(z,&h,&q)==pfs && mel(q[0],&g,&w)==pfs && h->l==2 && g->l==3 &&
    (w[0]==zall || w[0]==zexist || w[0]==zexist1))
 {                 // P = w[2], y = q[1];
  x = q[0]; x.i = 1; y = q[1]; P = w[2];
  r = rep2(P,x,y); 
  ipp("sbbv: reduced z= ",z, " to r= ",r);
 } 
 if(mm&&sss) ipp("-sbbv: z= ", z, " r= ", r);
 return r;
} // end sbbv                                              
               // inline bool eqex(elem x, elem y){ return x==y || x==zexist && y==zexistx || x==zexistx && y==zexist ||
               //  x==zexist1 && y==zexist1x || x==zexist1x && y==zexist1 || x==zE && y==zEx || x==zEx && y==zE; }
   bool sbst::Addsqt(elem V, achs* f, elem V1, achs* f1)      // Add trivial subs for qt and abt terms; 
 {   // if V==zall,zexist ... adds (V1-V)-substitutions;      // also check if bounded vars are s-equal;
 bool r = false; int i,k; elem y,y1; bool p1,p2;              // the result is true iff one of the two cases had place;
 if(mm&&kk) ipp("+Addsqt: V= ", V, "\nV1= ", V1);             // eqex(x,y) is x==y || x==zexist && y==zexistx ...
 if(mel(V)==abt && Dconj0(V1, &y1)) { y = V; goto M; }        // V = {x1, ...,xk; Ax}, V1 = {z1, ...,zk; Ax'} && P;
 p1 = (allex1(V) || Abt(V)) && V==V1;                         // p1: V = All,Exist,Exist1,Existx,Exist1x, abt_k; & V=V1;
 p2 = V != V1 && eqex(V,V1);
 if(p1 || p2)  //  ||   (allex1(V) || Abt(V)) && V==V1)       // case 1;
 {
  y = f->topach().e;      //  y: {x; ...} or y: All(x,P(x)), ...
  y1 = f1->topach().e; // y1.i = 1;  // y1 = vname(f1.topach().e, f1.topach().h); 
  r = true;                       // trying to move "r = true; " one line down DID NOT WORK ! 
  M: y.i = 1; y1.i = 1;   // r = true; // error was in EqProof LRker: isbe(F6,F7 ,...);  04.13.23;
  adds(y1,y); 
  if(Abt(V)){ k = V.i; for(i=2; i<=k; i++){ y.i = i; y1.i = i; adds(y1,y); } }
  goto ret;
 } // if(V==zexistx)-----------------------------end 1 V = V1; below V != V1;  opb == elm(247,'[',0);
 if(boundvar(V1) && vals(V1)==V)  r = true;                   // case 2;  // move out ???
 // if(vals(V1)==V) r = true;  // || equal(V,V1) 
 ret: if(mm&&kk) ipp("-Addsqt: V= ", V, "\nV1= ", V1, " r= ", r);
 return r;
} // end sbst::Addsqt

   bool sbst::Addsqt1(elem V, achs* f, elem V1, achs* f1)  // Add trivial subs for qt and abt terms; 
 {   // if V==zall,zexist ... adds (V1-V)-substitutions;   // also check if bounded vars are s-equal;
 bool r = false; int i,k; elem y,y1; // bool p1,p2;        // the result is true iff one of the two cases had place;
 if(mm) ipp("+Addsqt1: V= ", V, "\nV1= ", V1);             // eqex(x,y) is x==y || x==zexist && y==zexistx ...
 // if(mel(V)==abt && Dconj0(V1, &y1)) { y = V; goto M; }  // V = {x1, ...,xk; Ax}, V1 = {z1, ...,zk; Ax'} && P;
 // p1 = (allex1(V) || Abt(V)) && V==V1;                   // p1: V = All,Exist,Exist1,Existx,Exist1x, abt_k; & V=V1;
 // p2 = V != V1 && eqex(V,V1);
 // if(p1 || p2)  //  ||   (allex1(V) || Abt(V)) && V==V1)       // case 1;
 {
  y = f->topach().e;      //  y: {x; ...} or y: All(x,P(x)), ...
  y1 = f1->topach().e; // y1.i = 1;  // y1 = vname(f1.topach().e, f1.topach().h); 
  r = true;                       // trying to move "r = true; " one line down DID NOT WORK ! 
  y.i = 1; y1.i = 1;   // r = true; // error was in EqProof LRker: isbe(F6,F7 ,...);  04.13.23;
  adds(y1,y); 
  if(Abt(V)){ k = V.i; for(i=2; i<=k; i++){ y.i = i; y1.i = i; adds(y1,y); } }
  goto ret;
 } // if(V==zexistx)-----------------------------end 1 V = V1; below V != V1;  opb == elm(247,'[',0);
 // if(boundvar(V1) && vals(V1)==V)  r = true;                   // case 2;  // move out ???
 // if(vals(V1)==V) r = true;  // || equal(V,V1) 
 ret: if(mm) ipp("-Addsqt1: V= ", V, "\nV1= ", V1, " r= ", r);
 return r;
} // end sbst::Addsqt1


                  // repvals: r=0: V cannot be equal to y1(V!=Y1 && (simple(y1) or simple(V): was goto to ret 
 att repvals(elem V, elem V1, elem y1,achs* f,achs* f1, att peqt) // r=1: V=y1: was goto Nxt1; in insteqt;
{    // y1 = vals2(V1);                             // r=2: V != y1 && comp(V) && comp(y1); was goto Repeat;                                                   
 if(99)
 { 
  f1->prach("+repvals: f1= "); 
  ipp("+repvals: V= ",V,"\nV1= ",V1,"\ny1= ",y1," peqt= ",peqt);
  // prext("+repvals");
 } // if(mm)
 att r = 0; //
 if(V==y1){ r = 1; goto ret; }  // below V != y1;----------------------------0 V==y1;
 if(comp(V))                         
 {
  if(simple(y1))
  { 
   if(9) ipp("repvals(eqt): cause: composite V but simple y1=vals(V1), \nV= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt);
   goto ret; // r==0;
  } // if(!comp(y1)), below y1 is composite;
  if(simple(V1))   // simple V1 can be only in ach[0], because wach writes to ach only composite terms; 
  {                // void achs::wrel(elem z){ assert(iach>=0); --iach; wach(z); }
   if(f1->iach != 0) f1->prach("f1->iach != 0");   // ??? check !!!  // mm &&
   if(simple(f1->topach().e)) f1->wrel(y1); else f1->wach(y1); // if(simple(f1.topach().e))  // if(f1.iach==0) f1.wrel(y1); else
   if(mm)
   {
    f1->prach("repvals:f"); f1->prach("repvals:after simple y1: f1->wach(y1)");
    ipp("repvals: executed f1->wach(y1), \nV= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt);
   } // if(mm)
   if(f->topach().p != -1)    // because V is composite
   {
    f->prach("f"); f1->prach("f1");
    error("repvals:insteqt: f->topach().p != -1, \nV= ", V, "\nV1= ", V1, " peqt= ", peqt);
   } // if(f.topach().p != -1)
   f->prach("f"); f1->prach("f1");
   r = 2; 
   error("repvals_1:insteqt:r = 2  \nV= ", V, "\nV1= ", V1, " peqt= ", peqt);  goto ret;                                  // goto Repeat; because f1 was changed;
  } //  if(simple(V1)) below V1 is composite;          // void achs::wrel(elem z){ assert(iach>=0); --iach; wach(z); }
  assert(comp(V1)); assert(comp(y1));  f1->wrel(y1);   // wrel: writes y1 instead of V1;
  if(mm){ ipp("repvals: y1=vals(V1) was written into f1, instead of V1, goto Repeat, \nV= ",V,
                 "\nV1= ", V1, " y1= ", y1, " peqt= ", peqt);
  f->prach("f"); f1->prach("f1"); }
  r = 2; 
  error("repvals_2:insteqt:r = 2  \nV= ", V, "\nV1= ", V1, " peqt= ", peqt); goto ret; // was error; was in insteqt: goto Repeat;
 } // if(comp(V)), below V is simple && V != y1 (case V==y1: see above);
 if(mm) ipp("repvals: insteqt: cause: simple V && V != y1), V= ", V, " y1= ", y1, " peqt= ", peqt); // goto ret; 
 ret: if(mm)
 { 
  f1->prach("-repvals: f1= "); 
  ipp("-repvals: V= ",V," V1= ",V1," y1= ",y1," r= ",r); 
  // prext("-repvals");
 } // if(mm)
      return r;
} // end att repvals

   att sbst::hnpvar(elem V, achs* f, elem V1, achs* f1, elemp Qx, int k)  // V1 is Q(x1,...,xk)
{                                                                         // used only in instance;
 att r=0; elem a,x,y,y1,Q; att peqt=0; int i,iY,lastF,savemm=mm; elem F[maxvars]; elem Y[maxvars]; // peqt ???
 // mm=1;
 if(mm) ipp("\n+hnpvar V= ", V, "\nV1= ", V1, " k= ", k); // k==0?zel: "\nQx[0]= ", Qx[0],
 if(k==0) Q = V1; else Q = Qx[0];
 y1 = vals(Q);  // y1 = vals(V1); 2023/03/19;
 if(y1 == zel)  // first occurrence of Q(x1,...,xk)) // if first occurrence, wright into body 
 {
  iY = -1;
	 for(i=1; i <= k; i++)  // check all Qx[i] are bvars and
  {                      // change Q(...xi...) to Q(...yi'...), where yi correspondons to xi;
   x = Qx[i];            // to get Lambda notation in sbst (Q(y1,...,yk), V) denotes lambda(y1,...,yk;V);
   y = corr(x,f,f1,this);     // bvar y in f corresponds to bvar x in f1;
   if(y==zel)            // if not: x is not bvar or no correspondence'
   {
    f->prach("f"); f1->prach("f1"); psbs("hnpvar");
    ipp("hnpvar:error?: no correspondence for x in V1, \nV= ",V, "\nV1= ", V1, "\nx= ",x);
    goto ret;
   } // if(x==zel) // below: was Qx[i] = x; WRONG !!! All(x, Q(x)): changing x violated the bvar rule#1;
   wrlist(y, Y, &iY, maxvars); 
  } // for(i=1)

  lastF = freenames(V,F,maxvars);  // lastF: last occupied in F // F - all "free" vars and bvars in V;
  for(i=0; i <= lastF; i++)        // each local bvar from F must be 
     if(f->bvarin(a=F[i]) && !inlist(a,Y,iY))
        { ipp("hnpvar:cause pvar:not free \nV= ", V, "\nfrom a= ", a, "\nV1= ", V1); goto ret; }
  addsp(Q,Y,k,V); r = true; goto ret;   // now (V1(...xi'...), V) is considered as Lambda(...xi'...), V)
 } // if(y1 == zel)  // end of first occurrence of Q(x), below it is not first occurrence;
 if(9){ ipp("hnpvar: not first occurrence:  V= ", V, " y1= ", y1); f->prach("M1"); } // , " dt1= ", dt1
            // if(eqt(V, y1)) r = true; // { f.next1("M1f"); f1.next1("M1f1"); goto Nxt2; }
 // if(9) ipp("hnpvar: y1=vals(V1) writing into f1, instead of V1, V= ", V, "\nV1= ", V1, " y1= ", y1);
 // r = repvals(V, V1, y1, f, f1, peqt);   
 // if(r==0) ipp("hnpvar: M1: cause: !eqt(V,y1), V= ", V, " y1= ", y1);
 y1 = vals(V1);
 if(instance(V,y1)) r=1; // else r=0;
 ret: if(mm) ipp("-hnpvar V= ", V, "\nV1= ", V1, "\nQx[0]= ", Qx[0], " k= ", k, " r= ", r); mm=savemm;
 return r;
} // end bool sbst::hnpvar         // zel0: vars are vars, hanging bvars are cons;
               // if(fit_inst(z, z1, V, V1, &f1, (achs*) f0, peqt, &cause))  goto Nxt1; goto ret1;
  bool sbst::fit_inst(elem z, elem z1,elem V, elem V1, achs* f1,achs* f0,att peqt, char** acause)     // V1 is var or bvar;
{
 bool r=false; elem t,t1,t1r,t1f,x,y1; int p,m2; char* cause;
 if(mm) ipp("+fit_inst V= ", V, "\nV1= ", V1, " peqt= ", peqt) ;
 t = typ(V);     // was Mvar:                 // t = K, active chain f contain conj(x
 t1 = tp(V1);    // must: t <: t1, V in t1;   // t1==elg
 //  if(mm) ipp("fit_inst: before t1r = rep(t1)  V= ", V, "\nV1= ", V1, "\nt= ", t, "\nt1= ", t1, " ist= ", ist,
 //   " instcount= ", instcount);
 t1r = rep(t1,"fit_inst:");  // t1r: replaced t1;
 if(mm) ipp("fit_inst:t1r,  V= ", V, "\nV1= ", V1, "\nt= ", t, "\nt1= ", t1, "\nt1r= ", t1r);
 x = root(f1->topach().e); p = f1->topach().p;
 if(p==0) f1->prach("fit_inst p==0 before typarg");
 t1f = typarg(x,p);
 if(mm) ipp("fit_inst x= ", x, " t1f= ", t1f, " p= ", p);
 if(t1f==t1r) m2 = 1; else
 m2 = typcmpr1(t1r,&t,V,f0);   // 1: tz <: t or z in t, 0: disjoint, 2: unknown;
 if(m2 != 1)
 {
  cause = "fit_inst: cause: var&bvar: wrong types, \nV= ";
  if(mm) ipp(cause,V, "\nV1= ", V1," t= ", t, " t1= ", t1," t1r= ", t1r);
  goto ret;    // t1 and t are disjoint or cannot establish t <: t1 or V in t1;
 } // if(m2 != 1)
 y1 = vals2(V1);   // M:
 if(y1==zel)
 {
  cause = "fit_inst: varbvar V1 not assigned, V= ";
  if(mm) ipp(cause, V, " V1= ", V1, " peqt= ", peqt);  // Madds:
  if(peqt) ipp("fit_inst:eqt: unif: ?cause: varbvar: not equal, V= ", V, " V1= ", V1, " s= ", this ); //  goto ret; }  
  adds(V1, V); r = true; goto ret; //  goto Nxt1;
 } // if(y1==zel)                   // below y1 != zel;
 if(V==y1) r = true; goto ret; // goto Nxt1; // if(eqt(V, y1)) goto Nxt1;
 if(99) ipp("fit_inst:cause: V != y1, z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " y1= ", y1, " peqt= ", peqt);
 // goto ret;
 // if(mm) ipp("insteq: y1=vals2(V1) writing into f1, instead of V1, V= ", V, "\nV1= ", V1, " y1= ", y1, " peqt= ", peqt);
 //  m2 = repvals(V, V1, y1, &f, &f1, peqt); // repvals: if(V==y1) m2=1; already done; see above;
 // if(comp(V) && simple(y1))  goto ret;   // from repvals, but r=false already;                        
 // if(m2==0) goto ret;
 // if(m2==1) goto Nxt1;

 // if(m2==2) goto Repeat;  // was already commented;
 // error("insteqt: wrong m2, V= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " m2= ", m2);
 // ret1: Cause = cause;
 ret: *acause = cause; if(mm) ipp("-fit_inst V= ", V, "\nV1= ", V1, " peqt= ", peqt, " r= ", r) ;
      return r;
} // end  bool fit_inst; 
 
        // d0: was vars_are_cons (for V1) also used in eqt and rep2i;
   bool sbst::instance(elem z,elem z1, elem d0, elem dpat, void* f0, att peqt)   // z is an instance of z1;
{      // z cannot be "less" than z1;  not_stripped==false: it is allowed to bvar to be unassigned
 bool r = false; elem V=zel,V1=zel0,y,y1,y2,R,R1,A,dV1,d1; each E1;  // tV,tV1,
  // f0 used in typcmpr // peqt==2: sign of eqt(V1, B).
 int iw=0,k=0,k1,m,m1,m2,save = size,savemm=mm, savekk=kk;  char* cause="???"; att my1, my2; 
 headp h=0,h1=0; elemp q,q1,Qx,Qx1;  int static depth=0, vcnt=0; // int static instcount=0;
 
 ++instcount;
 // if(instcount==7243)
 // mm=mm; 
 if(check(z.ad, stad1) && check(z1.ad, stad2))
 ++mm;    // == is stronger than &&; 10: ==, 14: &&, 5: *, 6: +;
 if(++depth > 1 && mm)  //  && kk)
 { 
  ipp("insteqt: depth > 1,", z, "\nz1= ", z1, "\npeqt= ", peqt," depth= ", depth);
  psbs();
 }  // if(++depth > 1 && mm)
 if(mm)
 { 
  // rrn2(z,z1,0);  // remove names z,z1;
  ipp("\n+insteqt z= ", z, "\nz1= ", z1, "\nd0= ", d0, "\ndpat= ", dpat, " peqt= ", peqt, " depth= ", depth);
  // prext("+insteqt");
  psbs();
 } // if(mm)
 // if(depth==1) saveipp = ippcount;
 achs f(z); 
 achs f1(z1);  // bool not_stripped = varbvar;
 
 // if(depth > 5 || (k = ippcount-saveipp) > 0) // Maxipp/100)  // 10: to prevent error in newlskip;
 if(depth > 5)     //  || (k=ippcount-saveipp) > Maxipp/2) // CANNOT depend on ippcount !!! 2023.04.05 !!!
 {   // was error  2022.11.16
  ipp("insteqt: depth > 5, \nz= ",z, "\nz1= ",z1, "\npeqt= ",peqt, " k= ", k, " depth= ", depth); // was ipp;
  psbs();  cause = "big depth";
  // depth = 0; // saveipp = ippcount;
  // throw("big depth or ippcount");     error("insteqt:throw") 
  goto ret1;
 } // if(depth > 5 || ...)

 if(!eqex(R=root(z), R1=root(z1)) && (m=mel(R1)) != var && m != bvar)              // check R1 is not varbvar
    { if(mm) ipp("instance: R != R1, R= ", R, " R1= ", R1); } // goto ret; } 
 // if(mm) kk=1;
 m = hgt(z); m1 = hgt(z1);          // 2020.01.27 ??? z = *.Gk hgt(*.Gk) = hgt(*) ???
 // kk=savekk;
 if(m < m1 && peqt != 2) //   && !peqt)           // --------------0. if z is instance of z1, then hgt(z) >= hgt(z1);
 {
  // y1 = Abt1(z1);                              // moved to eqt;
  // if(z==y1){ ipp("insteqt:m<m1: z = Abt(z1), z= ", z, " z1= ", z1); r = true; goto ret; }
  if(mm) ipp("insteqt: cause: z is less than z1, z= ",z, "\nz1= ",z1, "\nhgt(z)= ",m, " hgt(z1)= ",m1, " peqt= ", peqt);
  cause = "insteqt: cause: z is less than z1, z= ";
  if(mm)
  mm=mm;
  goto ret1;
 } // if(m < m1)

 if(z==zin && z1==zeq)
    mm=mm;

 while(f.iach >= 0 && f1.iach >= 0)
 { 
  V = f.curvert(); // if(V.m != 253) tV = typ(V); else tV = zel;
  if(f.iach > 0)
  {
   each E1 = f.topach1();
   if(E1.h->son[0]==zif && E1.p==2)
   { 
    if(mm) ipp("instance:if z= ", z, " V= ", V);
    wlot(E1.h->son[1], "instance:if");
   } // if(E1.h->son[0]==zif) && E1.p==2)
  } // if(f.iach > 0)
   
  // Repeat: ??? Nxt0:
  V1 = f1.curvert();  // if(V1.m != 253) tV1 = typ(V1); else tV1 = zel;     //Repeat: y1 was written to f1; looping is possible
  if(++iw > maxwhile)
  {
   f.prach("f"); f1.prach("f1");   // below was ipp, not error: never encountered; 8.31.20
   error("insteqt: looping in Repeat: while, \nz= ",z,"\nz1= ",z1,"\nV= ",V,"\nV1= ",V1,"\npeqt= ",peqt ," iw= ", iw);
   goto ret;
  } // if(++iw > maxmod)
  if(mm)
  { 
  ipp("\ninsteqt:+while V= ", V, "\nV1= ", V1,   "\npeqt= ", peqt,   // " tV1= ", tV1,
           " f.iach= ", f.iach, " f1.iach= ", f1.iach, " iw= ", iw); // if V1 is a local bvar then
   // prext("insteqt:while");
   if(mm&&kk){ f.prach("f"); f1.prach("f1"); }
  } // if(mm) 
  m = mel(V, &h, &q); 
  m1 = mel(V1, &h1, &q1);
  if(mm) ipp("insteqt:m = mel(V),m1 = mel(V1),V1= ", V1, " m1= ", m1, " m= ", m);
  switch(m1)
  {
   case con: if(mm) ipp("insteqt:switch:con(V1), V= ", V, " V1= ", V1);
   if(!eqex(V,V1)){ cause = "insteqt:con: !eqex(V,V1), z= ";  goto ret1; }
   if(allex1(V) || Abt(V)) Addsqt1(V,&f,V1,&f1);
   goto Nxt;

   case var: if(mm) ipp("insteqt:switch:var(V1), V= ", V, " V1= ", V1);
   M_var: // if(mm) ipp("insteqt:M_var:var(V1), V= ", V, "\nV1= ", V1);
   if(conv(V1))      // was M_var: , but for bvars there is a different tool (Varbvar);
   { 
    if(mm) ipp("insteqt:var(V1):conv(V1), V= ", V, " V1= ", V1);
    if(V != V1){ cause = "insteqt:var:conv(V1): V != V1, z= "; goto ret1; }
    goto Nxt;
   } // if(conv(V1))
   if(V==V1) goto Nxt;              // 04.21.23
   y1 = vals(V1); 
   if(y1 != zel)
   {
    if(V==y1) goto Nxt1;
    y2 = vals(y1); my1= mel(y1);
    if(mm) ipp("insteqt:var(V1):y1 != zel V1= ", V1, " y1= ", y1, " y2 = ", y2, " m1= ", m1, " my1= ", my1);
    if(y2==zel) goto M_end;
    my2= mel(y2);
    ++vcnt;
    if(mm) ipp("insteqt:var(V1):y2 != zel  V1= ", V1, " y1= ", y1, " y2= ", y2, " m1= ", m1, 
                             " my1= ",  my1, " my2= ",  my2, " vcnt= ", vcnt);
    
    if(mm) psbs("y2 != zel");  // pntu->prach("y2 != zel"); f.prach("f"); f1.prach("f1"); 
    if(my1==bvar){ if(mm) ipp("my1==bvar):changing y1 to y2, y1= ", y1, " y2= ", y2);  y1 = y2; }   // y2 == vals1(y1);
   M_end: ;} // if(y1 != zel) // (m1 != var && my1==bvar

   if(y1==zel)
   {
    if(!fit_inst(z, z1, V, V1, &f1, (achs*) f0, peqt, &cause)) goto ret1;
    adds(V1,V); 
   } // if(y1==zel)
   else{ 
   if(mm) ipp("insteqt:var(V1):y1 != zel, V= ", V, "\nV1= ", V1, "\ny1= ", y1);
   if(simple(y1)){ if(y1==V) goto Nxt1; cause = "insteqt:var(V1):simple(y1):y1 != V, z= "; goto ret1; }
   if(!eqt(V,y1)){ cause = "insteqt:var(V1):!req(V,y1), z= "; goto ret1; } // eqt(V,y1) ???!instance(V,y1)
   } // else{
   f.next1(this); f1.next(this); goto Nxt2;
   
   case bvar: if(mm) ipp("insteqt:switch:bvar(V1), V= ", V, " V1= ", V1);
   if(V==V1) goto Nxt;
   if(f1.seek(htbv(V1)) != -1)   // if(localbvar(V1)): make inline function !!!
   { 
    if(mm) ipp("insteqt:localbvar(V1), V= ", V, " V1= ", V1);
    if(vals(V1) != V){ cause = "insteqt:bvar(V1):localbvar(V1): vals(V1) != V, z= "; goto ret1; }
    goto Nxt;
   } // if(localbvar(V1))
   y1 = vals(V1);
   if(y1==V) goto Nxt1;
   dV1 = htbv(V1); // bool p = Dterm(dpat);        // m = abt || m==pfs && q[0]==zdconj;
   if(d0==zel0 && (A = Athabv(dV1)) != zel) d0 = A;     // 2022.09.26
   // if(dV1==d0 || DinA(dV1,d0) || DinD(dV1,dpat))// if((dV1==d0 || dV1==dpat))  // main case;
   //     { if(mm) ipp("insteqt:d0 or dpat, V= ", V, "\nV1= ", V1,"\nd0= ", d0, "\ndpat= ", dpat); goto M; }
   if(Varbvar(V1,d0,dpat))
   { 
    if(99) ipp("insteqt:bvar(V1):Varbvar(V1): goto M_var, V= ", V, "\nV1= ", V1, " m= ", m, " m1= ", m1);
    goto M_var;
   } // if(Varbvar(V1,d0,dpat))
   if(V != V1){ cause = "insteqt:bvar(V1): !Varbvar(V1): V != V1, z= "; goto ret1; };
   goto Nxt;                 //f.next1(this); f.next(this); goto Nxt2;

  case pfs: if(mm) ipp("insteqt:switch:pfs, V= ", V, "\nV1= ", V1);
  if(V==V1) goto Nxt1;          // 04.19.23 // vals(V1)==zel &&
  if(h && h->v && valrt(V,h,q)==V1) goto Nxt1;          // case: comp(V) && simple(V1) ???
  if(h1->v && valrt(V1,h1,q1)==V) goto Nxt1;
  
  if(q1[0]==znot && m==pfs)
  {
   y = vals(q1[1]);
   if(isneg(V, y)) goto Nxt1; 
  } // if(q1[0]==znot && m==pfs)
 
  if(q1[0]==zcol)                                                             //-----2.V1 is a conversion term;
  { 
   ipp("instance: V1 is a conv term, changing V1 to q1[1], V= ", V, "\nV1= ", V1, " q1[1]= ", q1[1]);
   if(V==q1[1] || V==vals(q1[1]))
      { if(mm) ipp("inseqt:pfs:equal conversion term, goto Nxt1, V= ",V, "\nV1= ", V1); goto Nxt1; }
   V1 = q1[1]; m1 = mel(V1,&h1,&q1);
  } //  if(m1==pfs && q1[0]==zcol)
  // if(neqNeq(V,V1) || neqNeq(V1,V)) goto Nxt1;           // x ~=y == ~(x = y)
  // if(ninNin(V,V1) || ninNin(V1,V)) goto Nxt1;           // x nin y == ~(x in y);

  if(peqt && q1[0]==zRep)  
  {
   if(mm) ipp("instance: V1= Rep(d,P,z), V= ", V, "\nV1= ", V1);
   if(h1->l != 4) error("instance: V1=Rep(...): h1->l != 4, V= ", V, "\nV1= ", V1);
   y1 = rep(V1,"insteqt_V1", 2);   // 2: use vals2;
   if(mm) ipp("instance: V1= Rep(d,P,z): after y1 = rep(V1) \nV= ", V, "\nV1= ", V1, "\ny1= ", y1);
   if(req(V,y1)) goto Nxt1;
   ipp("instance: V1=Rep(...): !req(V,y1), V= ", V, "\nV1= ", V1 , "\ny1= ", y1);
   cause = "-insteqt: cause: V1=Rep(...): !req(V,y1), V= ";
   goto ret1;
  } //  if(peqt && && q1[0]==zRep .
  
  if(pvar(V1, &Qx1, &k1 ) != zel && k1 != 0)            // ----3: V1 = Q(x1, ...k = h->l, for Q (without params) k = 0; 
  {
   if(mm) ipp(" insteqt: pvar(V1): V= ", V, "\nV1= ", V1, " peqt= ", peqt);       // 1.pvar
   if(pvar(V, &Qx, &k ) != zel && k != 0)
   {
    if(mm) ipp("insteqt:pvar(V1)::pvar(V): V= ", V, "\nV1= ", V1, " peqt= ", peqt);
    if(Qx[0] != Qx1[0]){ cause = "insteqt:pvar(V1):pvar(V):for:Qx[0] != Qx1[0], z= "; goto ret1; }
    if(k != k1) { cause = "insteqt:pvar(V1):pvar(V): k != k1, z= "; goto ret1; } 
    for(int i=1; i<=k; i++) 
    {
     y1 = vals(Qx1[i]);
     if(mm) ipp("insteqt:pvar(V1):pvar(V):for: V= ", V, "\nV1= ", V1, "\ny1= ", y1, " i= ", i);
     if(y1==zel){ if(Qx[i]==Qx1[i]) continue; cause = "insteqt:pvar(V1):pvar(V):for: Qx[i]!=Qx1[i], z= "; goto ret1; }
     if(y1==Qx[i]) continue; 
     cause = "insteqt:pvar(V1):pvar(V):for: y1 != Qx[i], z= ";  goto ret1;
    } // for(int i=1)
    goto Nxt1;
   } // if(pvar(V,...)
   if(peqt)
   { 
    y1 = vals(V1);              // vals2 ??? changed to vals2 on 6.6.20
    if(mm) ipp("insteqt:after y1 = vals(V1), y1= ", y1,"\nV= ", V, "\nV1= ",V1," peqt= ",peqt," iw= ", iw);
    if(eqt(V,y1)) goto Nxt1;       // y1 == V: error; because no merging with F3: old problem !!!
    cause = "insteqt:pvar(V1):vals(V1) !=V, z= "; goto ret1;
   } // if(peqt)
   
   m2 = hnpvar(V,&f,V1,&f1,Qx1,k1);          // ??? document !!!
   // if(mm || repcount > 4280) prext("insteqt:after m2 = hnpvar");
   if(m2==1) goto Nxt1;   // here: peqt == false
   if(m2==2) error("insteqt:goto Repeat,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m2= ", m2); 
   if(m2!=0) error("insteqt:pvar: wrong m2, \nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m2= ", m2);
   if(9) if(peqt) ipp("eqt:pvar: cause: wrong pvar V1,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
         else ipp("instance:pvar: cause: wrong pvar V1,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
   goto ret1;
  } // if(pvar(V1,...) 
  
  if(mm) ipp("inseqt:pfs: not pvar, V= ", V, "\nV1= ", V1, " m= ", m);
                                             // && f1.iach > 0: added on 2022.10.26
  if(fnt1(V1,zanyd,&d1) && f1.iach > 0 && (E1 = f1.topach1()).h->l == 2)     // -----2: V1 = ^d1,  // E1 = [u1(^d1),h,p]
  {                                                           // E = pw(x,n);
   if(mm) ipp("insteqt: V1=f(^d1), V= ", V, "\nV1= ", V1, "\nE1:f1.topach1().e= ", E1.e);
   if(mm){ f.prach("f"); f1.prach("f1"); }
   if(simple(d1)) d1 = vals(d1);
   if(mel(d1) != abt) error("insteqt:anyd: mel(d1) != abt, \nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
   --f1.iach;
   f.iach = f1.iach;
   each E = f.ach[f.iach]; 
   elemp q = &(E.h->son[0]);
   att k = E.h -> l;
   for(att i=1; i < k; i++)                    // q[1] is z1 in f(z1,...,zk);
    if(q[i] != nami(d1,i))
    {
     cause = "insteqt:V1=f(^d1)): cause: q[i] != nami(d1,i), V= ";
     ipp(cause,V, "\nV1= ",V1,"\nz= ",z, "\nz1= ",z1, " i= ", i);
     goto ret1;
    } // if(q[i] ...)
   f.jumpend(); f1.jumpend();         // jumpend(): p := h->l;
   if(9) ipp("insteqt:V1=f(^d1)): Success! V= ", V, " V1= ", V1);
   goto Nxt;
  } // if(fnt1(V1,zanyd,&d) int(h->l)-1 == kmain(d)
 
  if(m==pfs) goto M_comp;        // V and V1 are composite terms;
  y1 = rep(V1,"insteqt_V1");     // below m != pfs,abt,  m1==pfs; --// ---------------------6.1 Checking V=y1;
  if(mm) ipp("insteqt: trying istr2eq(V,y1) and istr2(zincl,y1,V))(if y1 is a function),\nV= ",
                                    V, "\nV1= ", V1, "\ny1= ", y1, " m= ", m);
  if(istr2eq(V,y1) || peqt && eqre(y1,V, &f, &f1))  
  {
   ipp("insteqt: istr2eq(V,y1) or eqre found V=y1, y1= s.rep(V1), V= ", V, "\nV1= ", V1, "\ny1= ", y1, " iw= ", iw);
   goto Nxt1;
  } // if(istr2eq(V,y1) || ..) 
   
   cause = "insteqt: cause: m1==pfs && m != pfs, V= ";
   if(mm || peqt) ipp(cause, V, "\nV1= ", V1, " peqt= ", peqt, " m= ", m);
   goto ret1;
 
  case abt: if(mm) ipp("insteqt:switch:abt_pfs, V= ", V, " V1= ", V1);
  if(V==V1) goto Nxt1;
  M_comp: y1 = vals(V1);
  if(y1==zel) goto Nxt;   // continue comparing;  // if(simple(V)) ???
  if(y1 != V){ cause = "insteq:y1=vals(V) != V, z= "; goto ret1; }
  goto Nxt1;
   default : error("insteqt:switch(m1): wrong m1, z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m1= ", m1);
  } // end switch(m1);

  ret1: CAUSE = cause; cause_V = V; cause_V1 = V1;
  if(mm) ipp(cause, z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
  if(peqt){ f.prach("f"); f1.prach("f1"); } goto ret;
  Nxt1: f.next1(this); 
        f1.next1(this); 
        goto Nxt2; 
  Nxt:  f.next(this);
        f1.next(this);   // default: true: skipbv
  Nxt2: if(mm) ipp("instance:-while f.iach= ", f.iach, " f1.iach= ", f1.iach);
 } // end while
 if(mm) ipp("insteqt: after while: f.iach= ", f.iach, " f1.iach= ", f1.iach, " peqt= ", peqt);
 r = (f.iach == f1.iach);
 ret: if(!r) size = save; else if(r && sss ) psbs("-instance"); 
 if(--depth < 0) error("insteqt: depth < 0,   z= ", z, 
       "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " depth= ", depth);
 if(mm)
 { 
  ipp("-insteqt z= ", z, "\nz1= ", z1, " peqt= ", peqt, "\nr= ", r, " iw= ", iw); psbs(); 
  // prext("-insteqt");
 } // if(mm)
 mm= savemm;
 return r;
} // end sbst::insteqt



  
  
 /* line 1037, end this comment: line 1345   +/
 b = eqbvs(V,&f,V1,&f1, this, peqt); // 0: V != V1, 1: V==V1 or ..., 2: unknown;    // V is a local congruent bvar.
  if(mm)
  {
   ipp("insteqt:after b = eqbvs(V,...) \nV= ", V, "\nV1= ", V1, " peqt= ", peqt, " b= ", b);
   // prext("instext:eqbvs");
  } // if(mm)
  if(b==1) goto Nxt1;
  y1 = vals(V1);
  if(mm) ipp("insteqt:after y1 = vals(V1) \nV= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " b= ", b);
  if(y1 != zel)
  {
   if(y1==V){ if(mm) ipp("insteqt:y1==V\nV= ",V,"\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " b= ",b); goto Nxt1; }
   if(instance(V,y1))
   {  
    if(mm) ipp("insteqt:instance(V,y1) \nV= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " b= ", b);
    goto Nxt1;
   } // if(instance(V,y1)
   // if(req(y1,V,this)) goto Nxt1;  // 1: V==V1 or bvars V,V1 are congr, was Nxt, check Nxt1( because comp(V,V1);  
   // if(vals(y1)==V) goto Nxt1;          // was vals,  changed to vals2 on 6.6.20 
  } // if(y1 != zel)
  if(b==0)                             
  {
   if(mm) ipp("insteqt:while:b==0: V= ", V, "\nV1= ", V1);
   if(V1==zdot && simple(V))                   // added 2022.11.17;
   {
    elem v1 = valrt(f1.topach().e);   
    if(mm)
    { 
     ipp("insteqt:while: V1==zdot && simple(V), V= ", V); 
     f.prach("f:e= ", f.topach().e); f1.prach("f1: v1= ", v1); 
    }
   } // if(V1==zdot && simple(V)
   
   if(V==zdot && simple(V1))          // added on 2021.9.9;
   {
    each E = f.topach();   each E1 = f1.topach(); 
    if(E.h==0) goto Cause;
    elemp w = &(E.h->son[0]);
    if(mm){ f.prach("f:b==0"); f1.prach("f1:b==0"); }
    // x = vdt(E.e, w[1], w[2]); x1 = E1.e;               comm. 1.2.22;
    if(!E.h->v)
    {
     ipp("instance: V==zdot && simple(V1) !E.h->v:\nz= ", z,"\nz1= ",z1,"\nV= ",V,"\nV1= ",V1,"\npeqt= ",peqt ," iw= ", iw);
     cause = "instance: V==zdot && simple(V1) !E.h->v"; goto Cause;
    } // if(!E.h->v)
    x = valrt(E.e, E.h, w); x1 = E1.e;
    if(req(x,x1))
    { 
     ipp(" insteq b==0 && V==zdot && simple(V1): req(x,x1)\n V= ", V1, " x= ", x, " x1= ", x1);
     f.ach[f.iach].p = E.h->l; 
     f1.ach[f1.iach].p = E1.h->l;
     goto Nxt;
    } // if(req(x,x1))
   } // if(V==zdot && ...)
   
   Cause: cause = "-insteqt: cause: eqbvs(V,V1)= 0, V= ";
   if(mm || peqt) ipp(cause,V,"\nV1= ", V1, " peqt= ", peqt, " iw= ", iw);
   if(mm) 
   if(peqt) ipp("neweqt: it is the real cause !!!");
   goto ret1; 
  } // if(b==0)
  
  if(b != 2) error("instance: b != 2,  V= ", V, "\nV1= ", V1, " b= ", b); 
  if(mm) ipp("instance b = 2 ,  V= ", V, "\nV1= ", V1); 
  if(peqt && mel(V1, &g, &w)==pfs && w[0]==zRep)
  {
   if(mm) ipp("instance: V1= Rep(d,P,z), V= ", V, "\nV1= ", V1);
   if(g->l != 4) error("instance: V1=Rep(...): g->l != 4, V= ", V, "\nV1= ", V1);
   y1 = rep(V1,"insteqt_V1", 2);   // 2: use vals2;
   if(mm) ipp("instance: V1= Rep(d,P,z): after y1 = rep(V1) \nV= ", V, "\nV1= ", V1, "\ny1= ", y1);
   // if(simple(w[1]))            // commented on 2023.04.02 (5 lines)
   // { 
   //  ipp("instance:Rep:simple(w[1]), trying another rep,  V= ", V, "\nV1= ", V1, "\ny= ", y, " w[1]= ", w[1]);  // ??????
   //  y = rep(y,"insteqt_y:simple(w[1]");
   // } // if(simple(w[1]))
   // y1 = redRep(y);            // commented on 2023.04.02: redRep is used now in fsegh1
   if(req(V,y1)) goto Nxt1;
   ipp("instance: V1=Rep(...): !req(V,y1), V= ", V, "\nV1= ", V1 , "\ny1= ", y1);
   cause = "-insteqt: cause: V1=Rep(...): !req(V,y1), V= ";
   goto ret1;
  } //  if(peqt && mel(V1, &g, &w) ...

  if(Dclname(V)==acrlf || Dclname(V1)==acrlf || V==opb || V1==opb)   //--------2;
  { 
   cause = "insteqt: cause: different dclnames, V= ";
   if(mm || peqt) ipp(cause,V,"\nV1= ", V1, " peqt= ", peqt);  
   goto ret1;
  } // if(Dclname(V)==acrlf ...)
                                          //  && k!=0 : added on 2022.03.17
  if(pvar(V1, &Qx, &k ) != zel && k!=0)   // ----3: V1 = Q(x1, ...k = h->l, for Q (without params) k = 0; 
  {
   if(mm) ipp(" insteqt: pvar(V1): V= ", V, " V1= ", V1, " peqt= ", peqt);
   if(peqt)
   { 
    y1 = vals(V1);              // vals2 ??? changed to vals2 on 6.6.20
    // if(y1==zel) ipp("insteqt: y1==zel,\nz= ",z,"\nz1= ",z1,"\nV= ",V,"\nV1= ",V1," peqt= ",peqt," iw= ", iw);
    if(y1 != zel)                 // && eqt(V,y1)) goto Nxt1;
    {
     if(9) ipp("insteq:pvar: y1=vals(V1) writing into f1, instead of V1, V= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " iw= ", iw);
     m2 = repvals(V, V1, y1, &f, &f1, peqt);
     if(m2==0) goto Mr;
     if(m2==1) goto Nxt1;
     if(m2==2)
     { 
      error("insteqt:pvar: wrong m2 after repvals, \nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m2= ", m2);
      // goto Repeat;
     } // if(m2==2)
     error("insteqt:pvar: wrong m2, V= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " m2= ", m2);
    } // if(y1!=zel)
    Mr: cause = "insteqt: pvar(V1): cause: !eqt(V,y1), V= ";
    if(mm || peqt) ipp(cause, V, " V1= ", V1, " y1= ", y1, " peqt= ", peqt);
    goto ret1;
   } // if(peqt)
   m2 = hnpvar(V,&f,V1,&f1,Qx,k);          // ??? document !!!
   // if(mm || repcount > 4280) prext("insteqt:after m2 = hnpvar");
   if(m2==1) goto Nxt1;   // here: peqt == false
   if(m2==2) error("insteqt:goto Repeat,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m2= ", m2); 
   if(m2!=0) error("insteqt:pvar: wrong m2, \nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " m2= ", m2);
   if(9) if(peqt) ipp("eqt:pvar: cause: wrong pvar V1,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
         else ipp("instance:pvar: cause: wrong pvar V1,\nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
   goto ret1;
  } // if(pvar(V1,...) 
   
  m = mel(V,&h,&q); m1 = mel(V1,&h1,&q1); // mel,comp, ==, ... use valn, adl: not ? or a default param in mel, ...
  if(mm) ipp("insteqt: computed mels, V= ", V, "\nV1= ", V1, "\nm= ", m, " m1= ", m1);
  if(m1==pfs && q1[0]==zcol)
  { 
   ipp("instance: V1 is a conv term, changing V1 to q1[1], V1= ", V1, " q1[1]= ", q1[1]);
   V1 = q1[1]; m1 = mel(V1,&h1,&q1);
  } //  if(m1==pfs && q1[0]==zcol)                                           // && f1.iach > 0: added on 2022.10.26
  
  if(fnt1(V1,zanyd,&d1) && f1.iach > 0 && (E1 = f1.topach1()).h->l == 2)     // -----4: V1 = ^d1,  // E1 = [u1(^d1),h,p]
  {                                                           // E = pw(x,n);
   if(mm) ipp("insteqt begin V1=f(^d1), V= ", V, "\nV1= ", V1, "\nE1:f1.topach1().e= ", E1.e);
   if(mm){ f.prach("f"); f1.prach("f1"); }
   if(simple(d1)) d1 = vals(d1);
   if(mel(d1) != abt) error("insteqt:anyd: mel(d1) != abt, \nz= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
   --f1.iach;
   f.iach = f1.iach;
   each E = f.ach[f.iach]; 
   elemp q = &(E.h->son[0]);
   att k = E.h -> l;
   for(att i=1; i < k; i++)                    // q[1] is z1 in f(z1,...,zk);
    if(q[i] != nami(d1,i))
    {
     cause = "insteqt:V1=f(^d1)): cause: q[i] != nami(d1,i), V= ";
     ipp(cause,V, "\nV1= ",V1,"\nz= ",z, "\nz1= ",z1, " i= ", i);
     goto ret1;
    } // if(q[i] ...)
   f.jumpend(); f1.jumpend();         // jumpend(): p := h->l;
   if(9) ipp("insteqt:V1=f(^d1)): Success! V= ", V, " V1= ", V1);
   goto Nxt;
  } // if(fnt1(V1,zanyd,&d) int(h->l)-1 == kmain(d)
 
  if(m1==abt)     //-----------------------5: m1 = abt
  {
   if(mm) ipp("insteqt: m1==abt,  V= ", V, "\nV1= ", V1, " peqt= ", peqt);
   if(m==abt) goto Nxt;
   cause = "insteqt: cause: m1==abt, m!=abt, V= ";
   if(mm || peqt) if(peqt) ipp("eqt: cause: m1==abt, m!=abt, V= ", V, " V1= ", V1);
          else ipp(cause, V, " V1= ", V1);
   goto ret1;
  } // if(m1==abt)
  
  if(m1==pfs)     //-----------------------6: m1 = pfs;
  {
   // y1 = vals(V1);
   if(mm) ipp("insteqt: m1==pfs,  V= ", V, "\nV1= ", V1, " peqt= ", peqt);
   if(q1[0]==znot && m==pfs)
   {
    y = vals(q1[1]);
    if(isneg(V, y)) goto Nxt1; 
   } // if(q1[0]==znot && m==pfs)
   if(m==pfs)
   {                                // using istr2eq in insteqt is dubious, V1 can depend on s !!!
    // if(false) // istr2eq(V,V1) || equal(V,V1))
    //  { ipp("insteqt: istr2eq or equal found V=V1, V= ",V, " V1= ",V1, " s= ", this); goto Nxt1; } // if(false)
    goto Nxt;        // continue comparing;
   } // if(m==pfs)   
   y1 = rep(V1,"insteqt_V1");     // below m != pfs,abt,  m1==pfs; --// ---------------------6.1 Checking V=y1;
   if(mm) ipp("insteqt: trying istr2eq(V,y1) and istr2(zincl,y1,V))(if y1 is a function),\nV= ",
                                    V, "\nV1= ", V1, "\ny1= ", y1, " m= ", m);
   if(istr2eq(V,y1) || peqt && eqre(y1,V, &f, &f1))  
   {
    ipp("insteqt: istr2eq(V,y1) or  found V=y1, y1= s.rep(V1), V= ", V, "\nV1= ", V1, "\ny1= ", y1, " iw= ", iw);
    goto Nxt1;
   } // if(istr2eq(V,y1) || ..) 
   
   cause = "insteqt: cause: m1==pfs && m != pfs, V= ";
   if(mm || peqt) ipp(cause, V, "\nV1= ", V1, " peqt= ", peqt, " m= ", m);
   goto ret1;
  } // if(m1==pfs)          // conv(V1) = inlist(V1,convar,iconvar); // zel9: inlot(see byel);
 
  y1 = vals(V1);            // m1==var || m1==bvar
  if(y1 != zel)
  {
   ipp("insteqt: y1: vals(V1) != zel, V= ", V, "\nV1= ", V1, "\ny1= ", y1, " m1= ", m1);
   if(V==y1) goto Nxt1;
   elem x1 = Abt1(y1); 
   if(x1 != zel && x1==V) goto Nxt1;  // {x; x in t} = t;
   // cause = "insteqt: cause: V != y1, y1=vals(V1), \nV= ";
   // ipp(cause, V,  "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt);
   // goto ret1;
  } // if(y1 != zel)
  if(mm) ipp("insteqt: below m1=var or m1==bvar, vals(V1)=zel, \nV= ", V, "\nV1= ", V1, " m1= ", m1);
  m2 = 0;            // calculating m2, if m2 >0: error; 1: conv(V1), 2: Existbvar, 3:zel9, 4: d0==zel0 && dpat==zel0,
  if(d0==zel1)       // if(d0 != zel0){ if(!DinA(dV1,d0) && !DinD(dV1,dpat)) m2 = 5;
  {                  // if(Dterm(dpat)){ if(!DinD(dV1,dpat)) m2 = 6; // if(!DinD(dV1,d) && !DinD(dV1,scopeden(d))) m2 = 8;
   error("instance d0==zel1: not used, m2=0, z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1);
   goto M; 
  } // if(d0==zel1)
  if(m1==var || Allbvar(V1) )
  {
   if(conv(V1) || d0==zel9) m2 = 1; // d0==zel9: d0 in lot, all vars of d are constants;
   goto M;
  }  // if(m1==var)  below m1==bvar;
  
  if(abtbvar(V1, &dV1) && conv(V1) && (d0==zel0 || !DinA(dV1,d0))){ m2 = 1; goto M; }             
  if(mm) ipp("insteqt: calculating m2 V1= ", V1, "\nd0= ", d0, "\ndpat= ", dpat);
  if(Existxbvar(V1)){ m2 = 2; goto M; }   // below V1 is abtbvar; see Allbvar(V1) 7 lines above;
  // if(!abtbvar(V1)) error("insteqt: (!abtbvar(V1), \nV= ", V, "\nV1= ", V1, " m1= ", m1);      // con !!! 
  // if(d0==zel1){ error("instance d0==zel1: not used, m2=0, z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1); goto M; } 
  if(d0==zel9){ m2 = 3; goto M; } 
  if(peqt==2 && vals(V)==V1){ ipp("insteqt:STRANGE! \nV= ", V, "\nV1= ", V1, " m1= ", m1);   goto Nxt1; }            
  dV1 = htbv(V1); // bool p = Dterm(dpat);        // m = abt || m==pfs && q[0]==zdconj;
  if(d0==zel0 && (A = Athabv(dV1)) != zel) d0 = A;     // 2022.09.26
  if(dV1==d0 || DinA(dV1,d0) || DinD(dV1,dpat))// if((dV1==d0 || dV1==dpat))  // main case;
        { if(mm) ipp("insteqt:d0 or dpat, V= ", V, "\nV1= ", V1,"\nd0= ", d0, "\ndpat= ", dpat); goto M; }
  // ??? below: check, is it necessary ???   2022.08.18
  if(mm) ipp("insteqt: dV1 is not d0 or dpat, V= ", V, "\nV1= ", V1, " dV1= ", dV1);
  E = f1.topach();   // E.e = ism(G,G1), ! Tismin := All(f, f in ism(G,G1) == f in bfn(elg.G, elg.G1) & ...)
  h2 = E.h;         
  if(h2 && h2->adt)
  { 
   elemp q = &(h2->son[0]); elem d = scopeden(q[0]);   // dV1 = group, d = scopeden(ism) = GG1;
   if(mm) ipp("insteqt:adt V= ",V, "\nV1= ", V1, "\nE.e= ", E.e, "\ndV1= ", dV1, "\nd= ", d);
   if(!DinD(dV1,d) && !DinD(dV1,scopeden(d))) m2 = 8; goto M;  
  } // if(h && h->adt)
  if(d0==zel0 && dpat==zel0){ m2 = 4; goto M; }                
  if(d0 != zel0){ if(!DinA(dV1,d0) && !DinD(dV1,dpat)) m2 = 5; goto M; }
  if(Dterm(dpat)){ if(!DinD(dV1,dpat)) m2 = 6; goto M; }
  // if(!dinterm(dV1, d0)) m2 = 7;    // d in term z:  A[d,P], All(x, A[d,P], A[d1, A[d,P]], ... d cannot be A[d,P],...
  
  M: if(mm) ipp("insteqt:m2: V1= ", V1, " d0= ", d0, "\ndpat= ", dpat, " m1= ", m1, " m2= ", m2);
  if(Varbvar(V1,d0,dpat) && m2>1) error("insteqt:Varbvar(V1,d0,dpat) && m2, V= ", V, "\nV1= ", V1, "\nd0= ", d0, 
                                      "\ndpat= ", dpat, " m2= ", m2);
  if(m2)
  { 
   m1 = con;  
   if(mm) ipp("insteqt: V1 is var or Allbvar, converting to con, V1= ", V1,  // d0: was vars_are_cons;
              "\nd0= ", d0, "\ndpat= ", dpat, "\nhtbv(V1)= ", htbv(V1), " peqt= ", peqt, " m2= ", m2);
  } // if(m2)
  
  if(m1==con)              //------------------------7: m1 = con;
  {                        /// make more general(table driven?) !!! because P1[X] <: P[X];
   // if(V==zP1 && V1==zP){ if(9) ipp("insteqt:con: V==zP1 && V1==zP, z= ", z, " z1= ", z1); goto Nxt; }
   if(V1==zdot)
   {
    int i = f1.iach;
    if(eqfmdot(f.ach[i].e, f1.ach[i].e))
      { f.iach = i-1; f1.iach = i-1; f.prach("eqfmdot:f"); f1.prach("eqfmdot:f1");  goto Nxt1; } 
   } // if(V1==zdot)
   cause = "instance: cause: m1==con, \nV1= ";
   if(mm || peqt) ipp(cause, V1, " V= ", V, " peqt= ", peqt);
   goto ret1;      // because here V != V1;
  } // if(m1==con) 
  
  if(m1==var || m1==bvar)   //------------------------8: m1 = var; // checking if V fits to V1:
  {
   if((m1 == bvar) && mm) ipp("insteqt: m1==bvar: z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " peqt= ", peqt) ;
   t = typ(V);     // was Mvar:                 // t = K, active chain f contain conj(x
   t1 = tp(V1);    // must: t <: t1, V in t1;   // t1==elg
   if(mm) ipp("insteqt: before t1r = rep(t1)  V= ", V, "\nV1= ", V1, "\nt= ", t, "\nt1= ", t1, " ist= ", ist,
    " instcount= ", instcount);
   t1r = rep(t1,"insteqt_t1");  // t1r: replaced t1;
   if(mm) ipp("insteqt: m1==var,  V= ", V, "\nV1= ", V1, "\nt= ", t, "\nt1= ", t1, "\nt1r= ", t1r);
   x = root(f1.topach().e); p = f1.topach().p;
   if(p==0) f1.prach("instance p==0 before typarg");
   t1f = typarg(x,p);
   if(mm) ipp("insteqt: m1==var or bvar, x= ", x, " t1f= ", t1f, " p= ", p, " peqt= ", peqt);
   if(t1f==t1r) m2 = 1; else
   m2 = typcmpr1(t1r,&t,V,(achs*) f0);   // 1: tz <: t or z in t, 0: disjoint, 2: unknown;
   if(m2 != 1)
   {
    cause = "insteqt: cause: var&bvar: wrong types, \nV= ";
    if(mm || peqt) ipp(cause,V, "\nV1= ", V1,
              " t= ", t, " t1= ", t1," t1r= ", t1r, "peqt= ", peqt);
    goto ret1;    // t1 and t are disjoint or cannot establish t <: t1 or V in t1;
   } // if(m2 != 1)
   y1 = vals2(V1);   // M:
   if(y1==zel)
   {
    cause = "insteqt: varbvar V1 not assigned, V= ";
    if(mm) ipp(cause, V, " V1= ", V1, " peqt= ", peqt);  // Madds:
    if(peqt){ ipp("eqt: cause: varbvar: not equal, V= ", V, " V1= ", V1, " s= ", this ); goto ret1; }  
    adds(V1, V); goto Nxt1;
   } // if(y1==zel)                   // below y1 != zel;
   if(V==y1) goto Nxt1; // if(eqt(V, y1)) goto Nxt1;
   if(99) ipp("insteqt:cause: V != y1, z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, " y1= ", y1, " peqt= ", peqt);
   goto ret;
   if(mm) ipp("insteq: y1=vals2(V1) writing into f1, instead of V1, V= ", V, "\nV1= ", V1, " y1= ", y1, " peqt= ", peqt);
   m2 = repvals(V, V1, y1, &f, &f1, peqt);
   if(m2==0) goto ret;
   if(m2==1) goto Nxt1;
   // if(m2==2) goto Repeat;
   error("insteqt: wrong m2, V= ", V, "\nV1= ", V1, "\ny1= ", y1, " peqt= ", peqt, " m2= ", m2);
  }  // 8:if(m1 == var), below V1 is bvar, it was assigned in if(V==zall || V==zexist || V==zexist1 || V==zexistx)
  
  error("insteqt: wrong m1,  z= ", z, "\nz1= ", z1, "\nV= ", V, "\nV1= ", V1, "\nm1= ", m1, " peqt= ", peqt);
  line 1345   */

 
   elem sbst::finst(elem z, elem a)     // find an instance r of a in z. return r; 
{
 elem r = zel;
 if(mm&&sss) ipp("+finst z= ", z, "\na= ", a);
 achs f(z) ;  
 while(f.iach >= 0)
 {
  elem V = f.curvert(); size = 0;
  if(mm&&sss) ipp("\nfinst: while: V= ", V); 
  if((! dclname1(V)) && (!Abt(V)) && instance(V, a)) { r = V; goto ret; }  // false: ???
  f.next(); 
 } // end while
 if(mm&&sss) ipp("finst: no instance of a in z= ", z, " a= ", a);
 ret: if((mm || sss) && (r != zel)) ipp("finst: found a in z= ", z, "\na= ", a, " r= ", r);
 if(mm&&sss) ipp("-finst z= ", z, "\na= ", a, " r= ", r);
      return r;
} // end finst

  bool sbst::eqt(elem z, elem z1, elem  d0, elem dpat, att peqt)           // d0: was vars_are_cons
{
 bool r=false; elem y1;
 if(mm) ipp("\n+eqt z= ", z, "\nz1= ", z1, "\nd0= ", d0, "\ndpat= ", dpat, " peqt= ", peqt);
 if(z==z1){ if(99) ipp("eqt:z==z1, z= ", z); r = true; goto ret; } 
 y1 = Abt1(z1);
  if(z==y1){ ipp("insteqt:m<m1: z = Abt(z1), z= ", z, " z1= ", z1); r = true; goto ret; } 
 r = instance(z, z1,  d0, dpat, 0, peqt);  // zel0: for vars_are_cons(see byel),  0:f0,  true: peqt;
 ret: if(mm) ipp("-eqt z= ", z, "\nz1= ", z1, "\nr= ", r);
 return r; 
} // bool sbst::eqt

   bool eqt2(elem z, elem z1, elem a, elem b)
{
 if(mm) ipp("+eqt2: z= ",z," z1= ",z1," a= ",a," b= ",b);
 sbst s; bool r;
 s.adds(a,b);
 r = s.eqt(z,z1);
 if(r) goto ret;
 r = s.eqt(z1,z);
 if(r) goto ret;
 s.size = 0;
 s.adds(b,a);
 r = s.eqt(z,z1);
 if(r) goto ret;
 r = s.eqt(z1,z);
 if(r) goto ret;
 r = false;
 ret: if(mm) ipp("-eqt2: r= ", r);
 return r;
} // end eqt2
               // congr(A*(B+C), A*B + A*C, x*(y+z) = x*y = x*z): similar(not same) to isbe: subterms;
  bool sbst::congr(elem V, elem V1, elemp qq, int k)   // congr(V,V1,a0=b0, a1=b1, ... ak-1=bk-1, k);
{                                                      // look for such ai=bi, that V is s-instance of ai 
 bool r = false; elem z,a,b; elemp w; // sbst s;       // and V1 = s.bi;
 if(mm) ipp("+congr V= ", V, "\nV1= ", V1, "\nqq[0]= ", qq[0], " k= ", k);
 for(int i=0; i<k; i++)
 {
  z = qq[i];             // 
  if(iseq(z, &w))
  {
   a = w[1]; b = w[2];
   if(!instance(V,a)) continue;
   if(mm) ipp("congr: V is instance of a, V= ", V, " a= ", a);
   r = eqt(V1,b);
  } // if(iseq)
  else if(z == zAxab) r = isba(V,V1); 
       else error("congr: not equality or Axab z= ", z);
  if(r) break; 
 } // for(i)
 if(mm) ipp("-congr: V= ", V, "\nV1= ", V1, " r= ", r);
 return r;
} // end bool congr(...)

/*  int sbst::gens(elem z)     // if qterm(z), r =  a new place in ptt->tabt, and sbsts, else r = -1
{                            // gens: generate substitutions;
 int i,m,k,n = -1; elem y; headp h; elemp q;
 m = mel(z, &h, &q);
 if(m==abt || m==pfs && qterm(h))
 { 
  k = kboun(h);   // term(s) after bounded var
  // wrst(z);  // used in chabt
  n = ptt->newtt("gens"); filltabt(n);  // ptt->tabt[n] = ptt->tabt[0];                // n: future copy of the Qterm
  if(mm&&sss) ipp("+gens: z= ", z, " after newtt: n= ", n, " k= ", k);
  for(i=1; i<=k; i++) {y = z; y.i = i; 
             adds(y, elm(curm,i,n)); }
  if(mm&&sss) ipp("-gens z= ", z, "  n= ", n);
 } // if(m ...)
 return n;
} // end  int gens(elem z)
*/
   bool sbst::depend(elem z) // one of vars (or separate bvars) of s is in z or a bvar from z is in stqab;
{                            // or z has a method from iMod;
 int i,k,k1,k2,k3,k4; bool r = false; elem x,d; 
 elem L[maxvars];  // L: free vars in z; // int savemm=mm;
 elem L1[maxvars]; // L1: other terms(except local bvars) in z; // k, k1: last occupied;
 elem L2[maxvars]; // L2: local bvars;
 elem L3[maxvars]; // L3: nonlocal bvars;
 elem L4[maxvars]; // L4: this-methods;
 // elem L1[maxvars], L2[maxvars], L3[maxvars]; // L(k):vars, L1: composite terms, L2: bvars, L3: dclnames;
 if(mm) ipp("+depend z= ", z, " s= ", this); // mm=0;
 if(vals(z) != zel){ if(mm && kk) ipp("depend: cause1= ", z); r = true; k = 1; goto ret; } 
 
 k = freenames(z,L,maxvars, L1, &k1, L2, &k2, L3, &k3, L4, &k4, this);   // k - last occ. in L, k1 - in L1;
 if(mm&&sss) prlist("free vars in z, L= ", L, k);
 if(mm&&sss) prlist("other terms(except local bvars) in z, L1= ", L1, k1);
 if(mm&&sss) prlist("local bvars in z, L2= ", L2, k2);
 if(mm&&sss) prlist("nonlocal bvars in z, L3= ", L3, k3);
 if(mm&&sss) prlist("this-methods in z, L4= ", L4, k4);
 if(k4 != -1){ if(mm) ipp("depend: methods, z= ", z, " L4[0]= ", L4[0], " k4= ", k4); r = true; goto ret; }
 for(i=0; i<size; i+=2)
 {
  x = body[i];
  if(mm&&sss) ipp("depend:for body[i]= ", x, " i= ", i);   // next line: was inlist(x,L,k); 2022.09.27;
  if(inList(x,L,k) || inlist(pvar(x),L,k) || inlist(x,L1,k1) || inlist(x,L3,k3))  // interm(x,z))    // L1: others;
  {
   if(mm&&sss) ipp("depend: from sbst x= ", x, " s= ", this);
   r = true; goto ret; 
  } // if(inlist(x,L,k) || ... //  && ElemInTerm(x,z)
 } // for(i=0) // body;
 if(stqab.iar < 0) goto ret;
 if(mm&&sss){ ipp("depend: now checking stqab, z= ", z, " stqab.iar= ", stqab.iar); stqab.pr("depend"); }
 for(i=stqab.iar; i>=0; i--)
 {
  x = stqab.ar[i];                
  if(dterm(x,&d)) x = d;
  if(mm&&sss) ipp("depend:for(i=stqab.iar) x= ", x, " i= ", i);
  if(inlist(x,L,k,'d', "L") || inlist(x,L1,k1,'d',"L1") || inlist(x,L2,k2,'d',"L2") || inlist(x,L3,k3,'d', "L3"))
  // if(inlist(x,L2,k2,'d'))  // ??? L2 is empty' // commented on 02.09.22;
  { 
   if(mm&&sss) ipp("depend: from stqab x= ", x); 
   r = true; break;
  } // if(inlist(y,L2,...)
 } // for(i=stqab.iar)
 ret: // mm=savemm;   
      if(mm) ipp("-depend z= ", z, "\nk= ", k, " r= ", r);
      return r;
} // end bool depend(elem z)

/*  void sbst::changesize(int save, char* s)
{ 
 if(mm&&sss) *pfhis << "\nchangesize: zise= " << size << " save= " << save << " place= " << s;
 size = save;
}

  void sbst::AddMethods(elem z, elem M, elem T) // for each T-method y in z adds (y, y@M);
{
 elem t,t1,y; headp h; elemp q; int i,k;
 if(9) ipp("+sbst::AddMethods z= ", z, " M= ", M, " T= ", T);
 if(scope(z) == T)              // theory for method z 
 {
  t = typ(z);
  t1 = mdln(t,M,T);   // modelization;
  y = trm2(zat,z,M,t1);
  adds(z,y);
 } // if(mthd(z) == M)
 else if(comp(mel(z,&h,&q)))
 {
  int hl = h->l;
  if(mel(q[0]) == pfs) k = 0; else k = kmain(h)+1;
  for(i=k; i < hl; i++) AddMethods(q[i], M, T);
 } // else if
 if(9) ipp("-sbst::AddMethods z= ", z, " M= ", M, " T= ", T, " s= ", 
 
 );
} // void AddMethods(elem z, elem M, elem T)
*/    
   void sbst::psbs(char* t)
{
 int i;
	*pfhis<<"\n"<<t<<" sbst[size= "<<size<< " sbstcount= "<<sbstcount;
 // prp("\noneocc= ", oneocc, pfhis);
 // prp("\noneocc1= ", oneocc1, pfhis);
 for( i=0; i<size; i+=2)
 {
  elem x = body[i]; elem y = body[i+1];
  prp("\n", x, pfhis);  *pfhis << " : ";  cout << " : "; 
  prp(y, pfhis);  // if(y.i) pelm(y,pfhis); else prp(y, pfhis);//  pelm(y,pfhis);
 } // for i 
 *pfhis<<"\n]";
 cout<<"\n"<<t<<" sbst[i="<<size;
 for( i=0; i<size; i++)
 {
  //if((i & 1) == 0) pelm(body[i]);
  prp("\n", body[i]); // pelm(s.b[i]); 
 }
 cout<<']'; *pfhis<<']';
 stqab.pr();
} // end psbs
/*
 bool sbst::bvarinstqab(elem z)
{
 bool r=false; elem x,y,d; assert(z.i);
 x = z; x.i = 0;  // x = htbv(z)
 for(int i=istqab; i>=0; i--)
 {
  y = stqab[i];
  if(x==y || dterm(y,&d) && x==d) { r = true; break; }
 } // for
 return r;
} // end bool bvarinstqab(elem z)

 void sbst::wrstqab(elem z, att n, att m)
{
 if(mm) ipp("+wrstqab z= ", z, "\nn = ", n, " m= ", m);
 if(++istqab >= maxlevqt) error("rep: overflow of stqab z= ", z, " istqab= ", istqab);
 stqab[istqab] = z;  // top = smallest qabterm
 stqab1[istqab] = n;
 stqab2[istqab] = m;
 if(mm) ipp("-wrstqab z= ", z, "\nn = ", n, " m= ", m, " istqab= ", istqab);
} // end wrstqab

 att sbst::fstqab(elem z)               // find z in stqab;
{
 att r = emptt; int i;
 if(mm) ipp("+fstqab: z= ", z);
 for(i=0; i <= istqab; i++) 
   if(stqab[i]==z){ r = stqab1[i]; break; }
 if(mm) ipp("-fstqab: z= ", z, " r= ", r);
 return r;
} //  att fstqab(elem z)

 elem sbst::valstqab(elem z)
{
 elem r=zel; att a;
 if(mm) ipp("+valstqab z= ", z);
 a = fstqab(htbv(z));
 if(a==emptt) goto ret;
 r = z; r.ad = a; 
 if(r.m != curm){ ipp("valstqab: r.m != curm, z= ", z, " a= ", a, " r.m= ", r.m, " curm= ", curm); r.m = curm; }
 ret: if(mm) ipp("-valstqab z= ", z, " r= ", r);
      return r;
} // end sbst::valstqab(elem z)

 void sbst::prstqab(char* s)
{
 cout<<"\nprstqab: place: "<<s << " istqab= " << istqab;
 *pfhis<<"\nprstqab: place: "<<s << " istqab= " << istqab;
 for(int i=0; i<=istqab; i++)
 {
  cout<<"\n"<<i; prp(": ", stqab[i]); cout << "," << stqab1[i] << "," << stqab2[i];
  *pfhis<<"\n"<<i; prp(": ", stqab[i], pfhis); *pfhis << "," << stqab1[i] << "," << stqab2[i];
 } // for(i)
} // end void pstqab()
*/
                                          // ??? wrong for bounded terms !!! findtabt called from fseg1h    
 elem repb2(elem d, elem z, att n)        // replace in z every d-bvar x  on x(x.ad := n);
{                                         // used only in repr1;
 elem r=z, x,y; int i,k,hl,m; bool changed; headp h; elemp q;
 if(mm) ipp("+repb2: d= ", d, "\nz= ", z, " n= ", n); 
 m = mel(z,&h,&q);
 if(comp(m))
 {
  hl = h->l;
  if(mel(q[0]) == pfs) k = -1; else k = kmain(h);
  for(i=0; i<=k; i++) wrst(q[i]);                  // copying All,x;   {x1;P}, All(x,P)
  changed = false;
  for(i=k+1; i < hl; i++)
  {
   x = q[i]; 
   y = repb2(d,x,n);
   if(y != x) changed = true;
   wrst(y);
  } // for(i)
  if(changed){ r = fsegh1(z,h); popst(r); }   //
  else popst(hl);
  goto ret; 
 } // comp(m)
 if(mm) ipp("repb2: simple z= ", z, " htbv(z)= ", htbv(z));
 if(htbv(z) == d){ r = z; r.ad = n; }
 ret: if(mm) ipp("-repb2:  d= ", d, "\nz= ", z, "\nr= ", r, "\nn= ", n);
      return r;
} // end repb2;


   void sbst::repr()                    // replace right parts in s, using stqab // and repb;
{                                       // used only in rep2i;
 if(mm) ipp("+repr: stqab.iar= ", stqab.iar); elem y,y1;
 for(int i=1; i<size; i+=2)
 {
  y = body[i]; 
  y1  = rep(y, "repr"); 
  body[i] = y1;
  if(mm && y != y1) ipp("repr: changed: y= ", y, " y1= ", y1, " i= ", i);
 } // for(i)
 if(mm){ stqab.pr(); psbs("-repr"); }   // ipp("-repr: istqab= ", istqab); }
} //  void sbst::repr()

// moved to trash.txt; sbst::repr1(elem z, att n)     // replace right parts in s, using repb2;

  bool conv(elem z)
{
 if(mm) ipp("+conv: z= ", z);
 bool r = inlist(z,convar,iconvar); 
 if(mm) ipp("-conv: z= ", z, " r= ", r);
 if(r && mm) prlist("conv", convar,iconvar); 
 return r;
} // end  bool conv(elem z)
 
 bool fmt(elem z, elemp Q, elemp M)      // CS(group::nsubgr,GrH,N) 
{
 bool r; headp h; elemp q;
 r = mel(z,&h,&q)==pfs && h->l==4 && fnt2(q[1], zdcol);
 if(r){ *Q = q[0]; *M = q[3]; }
 return r;   
} // end bool fmt(elem z, elemp Q, elemp M)

  bool eqfmdot(elem z, elem z1)    // full meth term z is equal to its abridged dot term z1;
{
 bool r = false; elem Q,Q1,M,M1;
 if(9) ipp("+eqfmdot z= ", z, " z1= ", z1);
 if(!fmt(z,&Q,&M)){ ipp("eqfmdot: z is not a full method term, z= ", z); goto ret; }
 if(!vterm(z1,&Q1,&M1)){ ipp("eqfmdot: z1 is not a dot(meth) term, z1= ", z1); goto ret; }
 if(Q != Q1 || M != M1){ ipp("eqfmdot: Q != Q1 || M != M1, Q= ", Q, " Q1= ",Q1, "\nM= ", M, " M1= ", M1); goto ret; }
 r = true;
 ret: if(9) ipp("-eqfmdot z= ", z, " z1= ", z1, " r= ", r);
 return r;
} // end bool eqfmdot(elem z, elem z1)

   void sbst::crstqab(achs *f)             // create stqab from achs until V(not including);
{                                          // not used; ???
 int i,n, lastiach= f->iach; elem x; bool p=false; 
 //if(mm) f->prach("+crstqab ");
 if(mm) ipp("+crstqab");
 stqab.init();                              // istqab = -1; 
 for(i=0; i<=lastiach; i++)
 {
  x = f->ach[i].e;
  if(qabterm(x))
  { 
   if(stqab.val1(x)==emptt)
   {
    n = ptt->newtt("crstqab");
    stqab.wr(x, n);  
    filltabt(n);  // ptt->tabt[n] = ptt->tabt[0];
   } // if(stqab.val1(x) != emptt))
  } // if(qabterm(x))
 } // for(i)
 if(mm) psbs("-crstqab");
 // if(mm || p) f->prach("-crstqab");  // mm = save;
} // end void crstqab(elem V) 

  bool eqre(elem V, elem y1, achs* f,  achs* f1)
{
 bool r;  elem root, root1; bool p = f->actplace(&root)==0 && isfn(root);  // ??? p = f->actfn(
 bool p1 = f1->actplace(&root1)==0 && isfn(root1);
 if(mm) ipp("+eqre: V= ", V, "\ny1= ", y1, " root= ",root, "\nroot1= ", root1, " p= ", p, " p1=  ", p1); 
 r = p && p1 && istr2(zincl,V,y1);
 if(mm) ipp("-eqre: root= ",root, "\nroot1= ", root1, " p= ", p, " p1=  ", p1, " r= ", r); 
 return r;
} // end bool eqre  

// end sbs