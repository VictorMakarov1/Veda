// #include "ts.h"   // 11/21/97  04/07/00 04/14/00 04/27/00 10/31/00
#define emptyaden -1   // 11/21/97 12/19/00 01/30/01 02/23/01
extern att laden;  //was: #define laden 512  03/30/01 04/25/01 05/17/01                
//extern int lclad;  //was: #define lclad 10
extern att lden;   // lach should be the same as lst?
//extern int lach;   //was: #define lach  100
//extern int lsbst; 
extern int lvin;
extern elemp vin;
extern int kht; // sizett, sizets;
// den.h
class tt{
public:
att* uselist;       // uselist[0] = modname;
headp* tabt;
int* freqts;        // 
att lltt;           // last occupied (= lasttt from D.d);
att itt;            // fixed terms: last occupied;
att itt1;           // not fixed terms: "first: occupied;
att root;           // 0..itt: free space :itt1..lltt;  root in 0..itt;
// int iextf;
// charp* extf;     // external files ??? not needed ???
// ats* lonef;      // local names of external files 4/15
att mym;            // my number of file (module)
ats kuselist;
ats lastaden;
// int lht;            // length of ht ( = lltt*10 3/14/00) 
// att* ht;
// att ittd;        // definitions: 0,1, ... 

headp null1;
ats iden;       //iach;
edenp* den;     // 4/15/96
ats* aden;      // 4/15/96
att* nad;       // new addresses for prime terms;
att* har;       // hash array; size of har = 256K = 262144; alloc size = 524288
att* thms;      // theorems from tabt, before typ;   // was int lnad;
att* thmsic;    // theorems from tabt of the form P&P1 -> Q;  ic: impconj
att* indthms;   // index thms,if i is a den-name, indthms(i) is the beginning in thms theorems T:root(t)=i;
ats ithms;      // index of thms;  // was int;
ats ithmsic;    // index of thms from tabt of the form P&P1 -> Q;  ic: impconj;  // was int;
// int itruf;      // index of truf (LastO)
// int ltrim;      // address of last true implication
// int atrim;      // addres of true iplications in truf (now thms);
ats beg_impconj; // beginning of (->,&) segment in thms;  int => ats ???
ats end_impconj; // end of (->,&) segment in thms;
ats beg_rimpin;  // beginning of (<-,in) segment in thms;
ats end_rimpin;  // end of (<-,in) segment in thms;
ats beg_equin;   // beginning of (==,in) segment in thms;
ats end_equin;   // end of (==,in) segment in thms;
ats beg_exist;   // beginning a of (Exist)- segment in thms;
ats end_exist;   // end of (Exist)- segment in thms;
// elemp truf;   // all true formulas (size:not LastO!   ltruf) 12/13/00
//int gler,ib,line; char endsym;
//int pl; // see bint
tt(att ktabt, ats kul, ats kden, ats kaden);
elem elmstr(char* s);  // 11/06/00
// void ctt(att k=sizett, short il = maxmod, int d=lden, int lad=laden); // short c=0);
att newtt(char* s, bool pritt=true);      // s: place, pritt=true: r = ++itt; else r = --itt1;
headp fsq1(int q, int l, elem* a, att lev = sizestscp, att isz = iszthmb);    // sizestscp = 31; 
headp fsq(head h, elem*a);
// att wrtt(int,int,elem*);
att wrtt(int m, int l, elem* a, att n = emptt, att levsct = sizestscp, bool fixed=false,att isz=iszthmb); // sizestscp = 31;
elem wrtt(head, elem*, att n = emptt);
// void wrtt(int, int, elem*, att);
// elem findtt(int k, elem* a);              // w: write, f: find, h: find and write only atabt
att findtabt(int k, elem* a, char mode='w', att atabt=emptt, elemp az=0, elem test=zel); // find a0(a1,...ak) in tabt;
elem eqvl(elem z, int p=0, sbst* as=0);   // p=1: find an instance of x 
//void addtruf(elem z);  // add a true formula to truf
int adrtruf(elem f);   // address of beginnings of true formulas with root f in truf 
// void comptruf();       // computation of truf, itruf, atrim, ltrim in rdem
elem triminf(elem p);  // trim inference
elem eqcl1(elem z, bool smel_exit, int save = -1); // all terms equal to z, are in steq(not using subterm equality)
// elem eqcl(elem z, elem sbt[], int ksbt, bool smel_exit);  // all terms equal to z, are in steq  
att trm1(elem f, elem x1, int line = 0);
elem trm1e(elem f, elem x1, elem t = zel);
att trm2a(elem f, elem x1, elem x2, int line = 0);
elem trm2e(elem f, elem x1, elem x2, elem t = zel);
att wtrm(head h, elem* a, att az= emptt, elem t= zel);    // writing term into tabt (table of terms)
// void wrht(elem z, headp h, elemp q);
// void incr(int* ahh);  // increase hh
// void cht(int k=kht);
// int eqtr(head, elem*, att);
// void fht(elem z);          // fill ht
void ptbt(int);
void ptbtp(int i);
void prht(ofstream* p);
void prtruf(ofstream* p);
void prfreqts();                // sorting freqts, creating file source.freq and writing freqts to the file;
void futt(char* y);
void futt(ofstream* f);
void fprp(char* y);
void uden();
void sortden();            // sort den on den.a
void wrden(ats a, elem z, elem s); // write a,z,d,b
void pden(ofstream* f=0);  // ourput tt and den       // into den
// elem host(elem z);      // search in den for z, return z.d ( or zel)
// fden1s(elem z, elem s);        // search in sorted den for z & scope rns index of z in in den;
elem Dcol(headp h);        // if h points to d::f, returns d else zel
 //char* vden1(elem x);    // seach in the x.m den (or curr.den) 
//elem fden(char* s);      //(if den is unsorted, otherwise it uses aden)
int mltn(ats a);           // multiple name
void wtt(char* s);         // write tt
// template<typename T>
void wtabt(ofstream* f);   // write tabt to f;
void wden(ofstream* f);    // write den to f;
void chtt();               // change tt (first: theorems, ... )
//void rtt(ifstream* f);
void sdens(elem d, ats x, int n = -1);      // n: # of actuals (for wvin);
bool writt(att i);             // write tabt1[i]-term into first part(itt) of tabt, used in topt;
void topt();                   // term optimization (merging);      // j: #son; 
// int tt::comparthms(const void* p1, const void* p2);  // for sortthms
void sortthms();               // sort theorems using qsort;
void cthms();                  // calculating thms;  
void checkseg(att i, elem f1, elem f2, ats* beg, ats* end); // looking for (f1,f2)=segment in thms; 
bool chinthms(elem x, elem t); // check (x1 in t == P1) is in thms, s.instance(x,x1), inlot(s.rep(P1));              
elem macr(elem z, elem d = zel); // macroextension
// void mzcn();                // make z-constants using den  // see Mzcn();
void bdef(elem z, elem f);  // blocks and definitions
// void tt::facts(elemp q); // all facts about q[0], q[1], ... (zel is in end!)
bool stimp(elem Q, elem Q1, elem Q2, int m);
bool stimp1(elem Q, elem Q1, int m);
int firstad(ats a);              // first a in den (aden[a]), else -1;
elem uniqden(ats a, elem s, ats named= -2); // // named used in mzcn for to resolve overloading;
void fdentuns(ats a);  // find a in unsorted den, write .inn, .scope to arel, arscope
void fdent(ats a);     // total search: at first at current(possibly unsorted den), then in eul[1], eul[2], ...
elem tt::fden(char* s);                     // search s in den, return .inn; use only for unique s;
ats fdenaz(ats a, elem z);                  //  search for a, z(inn) in sorted den,  retu
ats fdenz(elem z);                          // address in den avel(z);
elem fdenabtdc(ats a);                      // find abt or && term named a, in den, return den[i].inn, else zel;
elem fdent1(ats a, elem s, ats named = -2, elemp s1=0); // find a in den[i] scope=s, return  den[i].inn; 
                                               // s==zel1: a is unique in den;  (all scopes);
void visndot(ats a, elem s);                   // search for all names with scope s in tt::den;
elem fden1s(char* b, elem s, ats named = -2);  // find findts(b) in den[i] scope=s, return  den[i].inn;
elem fdenuns(ats a, elem s);                   // find a in unsorted den, return den[i].inn; 
elem fden1d(ats a, elemp az);                  // find in den METHOD a (mel(den[i].s) = abt);
bool istr2(elem f,elem a, elem b, elem d=zel,elemp z=0); // is true f(a,b): search in tabt
bool tt::istrf(elem z, char mode, elem test=zel); // look in tabt for a theorem z, using findtabt; mode = f,i;
bool istr2inst(elem f, elem a, elem b);        // looking for the theorem "f(a,b)",using instance;
elem istr2a(elem f, elem a);                   // is true f(a,r);
void infer1(elem T);                    // for each theorem Q in tabt do infer2(Q,T);
void infer2(elem y1, elem y2);          // wlot(resultant of y1 and y2);
elem expand(elem );                     // expand z, using tabt; (body is in lot);
elem scope(ats a, elem z);              // find den[i].a = a && den[i].inn, return den[i].scope;
bool gtrm(att i, elem T, bool p=true);  // global theorem (scope = zel)&&p or T-local(scope = T);
elem typtabt(elem z, bool fnt = false); // look int tabt for z in r, if(fnt): only function types;
bool intabt(elem z, elem T);            // z is an instance of a global or T-local theorem in tabt 
void wrthmden(elem T, ats id);          // write theorem T into den[id].son; 
ats tt::clon2(att ad, headp hp, elemp q, ats bsz, ats bsz2,elem T); // allocates a new h1 (size(H) + bsz2*
                                                                   // returns address T relatively q[0];
ats wrthmtabt(elem T, elem z, bool notval= true); // write theorem T into tabt[id] after sons; // returns address T relatively q[0];
void wrthm(elem T);                     // for each subterm z of T write t into tabt[z] or den[z];
inline att  tt::sz1(){ return itt + 1; }  // sz1: 0..itt, fs: itt+1..itt1-1, sz2: itt1..lltt;
inline att  tt::sz2(){ return lltt+1 - itt1; }
inline att  tt::szfs(){ return itt1-itt-1; }  // itt1-1 - (itt+1) +1 = itt1-itt -1 ;
inline char* svad(att ad){ return vts(den[ad]->a); } // symbolic value  of a in den;
ats find2(elem f, elem g);         // f,g: addresses to den, find beginning in thms f(g...) theorems;
void wrthms(att i);
void wrthmsic(att i);       // write i into thmsic;
 
~tt();
}; // end class tt

extern tt* ptt;
extern tt* clad[maxmod];
bool nonempty(elem z);                     // typ(z)=P1[t] or istr2(zneq,z,zemp);
bool istr2(elem f,elem a, elem b, elem d=zel, elemp z=0);   // is true f(a,b): search in tabt; d: in A,...,S[d,f];
bool istr2c(elem f,elem a, elem b);  // same as istr2, but search only in current tabt;
elem istr2a(elem f, elem a);               // is true f(a,r);
void rtabt(tt* p, int last, ifstream* f);   // read tabt from f;
void rden(tt* p, int last, ifstream* f);    // read den  from f;
tt* rtt(char* s);
elem newp(headp h, elemp* q);
char* vden1(elem x);          //  search in the pertinent den
long stbt(tt* p);             // size of tabt
// elem fdent(char* s);       //total search of s in all dens
elem fdenabtdc(ats a);        // total search of abt or && term named a, in all dens, eul[0],...
elem fdent(ats a);   // total search: at first at current(possibly unsorted den), then in eul[1], eul[2], ...
elem fdent1t(ats a, elem s);  // total search: at first at current(unsorted den), then in eul[1], eul[2], ...
void visndot(ats a, elem s);  // total search for all names with scope s in eul[0], eul[1], ...
elem Fden1s(char* b, elem s, ats named = -2); // total search b in den_0, den_eul[0], .....
ats Fdenaz(ats a, elem z);                              //  search for a, z(inn) in sorted den_z.m;
// int fdent(elem z, elem d); //total search of z in all dens with .d == d
// elem fdent(ats a, elem s); //total search of a in all dens with .scope == s
elem tffom(char* s, elem* d); // total search of field or method
elem fden1d(ats a,elemp az);  // find in all (eul) dens METHOD a (mel(den[i].s) = abt);
// elem host(elem z);            // bvar(z) : htbv(z), comp(z): no name: zel, named(a): fden1d(a)
elem defval(elem z);          // defval("d") = d ( d must be a def!)
elem scope(elem z);           // body in den returns zel1 if noname(z);
elem scopeden(elem z);        // body in den
int hash(int k, elemp a, int* decr); // hash function
// bool wrongm(att m, tt** p = 0);   // wrongm(m) == clad[m] == 0);
inline bool wrongm(att m){ return m >= maxmod || clad[m] == 0; }
inline bool badm(att m){ return m < 245 && wrongm(m); }   // 245 = clp, 240..244: free space;
void Mzcn();                  // make z-constants using Den

