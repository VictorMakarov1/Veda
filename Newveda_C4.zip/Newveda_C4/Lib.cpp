#include "lib.h"   // 11/17/97 4/25/00 5/23/00 10/22/00
#include "achs.h"
#include "sbs.h"  
#include "tt.h" 
#include "adl.h"
#include "term.h"
#include "elem.h"
#include "glex.h" 
#include "etc.h"
#include "err.h"
#include <sys/stat.h>
// #include <time.h>

// struct tm* clock1;              // create a time structure
struct stat attr;               // create a file attribute structure

char* svel(elem z); // symbolic value of element;
att checktabt(char* s, elem z);

int pdd, ha, hb; extern ats aabterm;
extern int dd,yy,cc,kk,qq,vv,zz,ll,mm, aa,bb,ee,ff,hhh,ii,oo,rrr,uu;
extern int  notterm, count, mergecount;
extern ats adcl, asop, adclb, avar, aAll,aExist,aExist1,aExistx,aeps,aabt,aAb;
extern elem steq[lsteq],s,s0,s01;
//extern ofstream* pfout;
void checkr(int);   // 1. next time: != for !eqel
bool badel(elem z);
int ist;
// int ist1;
///int ist2;
// elem st[lst];  
// elem st1[lst]; 
// elem st2[lst]; 
extern elem zdclb, yasop, zall,aexist,zexist1,zeps, ztrue, zfalse, zfn; // -zvar
extern char* dcltypes[];
//int isrt(elem z, elem r, elemp* w=0, headp* g=0);
//int smel(elem z, headp *h=0, elemp *q=0, char* s=0);
elem elm(int m, int i, int a);

   void pelmcom(elem x, ofstream* f)
{
 int m=x.m, i=x.i, a=x.ad;
 if(f) *f<<'('<<m<<' ' <<i<<' '<<a<<')' ;
 else cout<<'('<<m<<' '<<i<<' '<<a<<')' ;  
} // end pelmcom

   void pelm(elem x, ofstream* f)
{
 int m = x.m, i = x.i; ats a; tt* pnt;
 pelmcom(x, f); 
 if(i || m==ident || m==ubs || m==ints || m==strng || m==gcom || m==gpc || m==clp)
 { 
  if(f) *f << svel(x);
  else cout << svel(x); 
 } //if(i || ...);  
 else if(m < maxmod && i==0)
 { 
  pnt = clad[m];
  if(pnt==0 || pnt->tabt[x.ad] == 0)
   if(f) *f << "pnt==0 || tabt["<<x.ad<<"] = 0"; else cout << "pnt==0 || tabt["<<x.ad<<"] = 0";
  else{ a = (clad[m]->tabt[x.ad])->name; if(f && a != noname) *f << vts(a); }
 } // else if
} // end pelm

  void pelmar(char* s, elemp q, int k, ofstream* f)
{
 *f << "\n"<<s;
 for(int i=0; i<k; i++) pelm(q[i], f);
} // void pelmar

  void prh(headp h, ofstream* f)   // printing h;
{
 if(h==0) *f << "prh:h=0"; else
 *f<<"\ntel= "<<h->tel<<" t= "<<h->t<<" postfix= "<<h->postfix<<" adt= "<<h->adt<<" at= "<<h->at<<" v= "<<h->v<<
 " l= "<<h->l<<" ln= "<<h->ln<< " name= "<< (h->name != -1? vts(h->name): " *** ") << " int(h)= "<<int(h);
 // pelm( "h->son[0]= ",  h->son[0], f);
 } // void prh

  void prh(att m, att ad, ofstream* f)
{ 
 *f<< "\nprh m= "<<m << " ad= "<< ad; 
 prh(clad[m]->tabt[ad], f); 
} // void prh(att m, ...)

  void filltabt(att n) { ptt->tabt[n] = clad[0]->tabt[0]; }

 void ph(headp h, ofstream* f)
{
 ats i, k; elemp q = &(h->son[0]);
 if(h==0){ cout << "ph: *****h==0\n";  *f << "ph: *****h==0\n"; goto ret;}
 k =  numsonthm1(h);
 cout<<"\nph:tel= "<<h->tel<<" t= "<<h->t <<" postfix= "<< h->postfix <<" adt= "<< h->adt<<
 " l= "<< h->l<< " h->lth= "<< h->lth<< " levsct= "<< h->levsct<< ")";
 *f<<"\ntel= "<<h->tel<<" t= "<<h->t <<" postfix= "<< h->postfix <<" adt= "<< h->adt<<
 " l= "<< h->l<< " h->lth= "<< h->lth<< " levsct= "<< h->levsct<< ")";
for(i=0; i < k; i++)
{ 
 pelm(q[i]); 
 pelm(q[i], pfhis); 
} // for(i=0);
ret:;
} // end void ph(headp h, ofstream* f)

 int prext(char* place)        // print external: ist, repcount, instcount, sbstcount,typcount, sum;
{
 int sum = ist+repcount+instcount+sbstcount+typcount; int static cnt=0;
 ++cnt;
 cout << "\nprext:"<<place<<" cnt= "<<cnt<< " ist= "<< ist <<" repcount="<<repcount<<" instcount= "<<instcount<< 
 " sbstcount= "<< sbstcount<<" typcount= "<< typcount<<" sum= "<< sum; // " sum= "<<ist+
 *pfhis << "\nprext:"<<place<<" cnt= "<<cnt<< " ist= "<<ist << " repcount="<<repcount<<" instcount= "<<instcount<< 
 " sbstcount= "<< sbstcount << " typcount= "<< typcount<<" sum= "<< sum ; // " sum= "<<ist+
 return sum;
}

   int len(head h)
{
 int r = h.l;
 // if(h.t == keq || h.t == kimp) r += 1;
 // if(h.t == keqim) r += 2;
 return r;
} // end len

/*   bool comp(elem z)   // z is a composite term
{       
 if(cc) ippelm("+comp z= ", z, " ieul= ", ieul);	   
 bool r = int(z.m) <= ieul && (!z.i);
 if(cc) ipp("-comp r= ", r);
 return r;
} // end comp 
*/
   void wrst(elem s)
{
 int m=s.m, i=s.i, ad=s.ad;
 if(aa)cout<<"\n+wrst s= "<<m<<' '<<i<<' '<<ad<<" ist= "<<ist;
 if(aa)*pfhis<<"\n+wrst s= "<<m<<' '<<i<<' '<<ad<<" ist= "<<ist;
 if(++ist >= lst){ --ist; pst("overflow ", 100);
  error("wrst: overflow ist= ", ist); }
 if(m >iallm && s.m < clp)      // clp = 245,meof = 246, ..., emps = 255; maxmod = 240; nothing in 241..244;
  error("wrst: wrong m= ", s.m, " iallm= ", iallm);
if(m==ident && i != 0 && ad == aAb) error("wrst: aAb, i= ", i);
 st[ist] = s;
 if(s==zin && ist<=1)
 ipp("wrst:s==zin && ist==0, ist= ", ist);
 if(mm) ipp("-wrst s= ", s, " ist= ", ist);
} // end wrst

/*   void wrst1(elem z)
{
 if(++ist1<0 || ist1>lst) error("wrst1: overflow ist1= ",ist1);
 if(int(z.m) > iallm && z.m < clp) error("wrst: wrong m= ", int(z.m));
 st1[ist1] = z;
} // end wrst1

   void wrst2(elem z)
{
 if(ee) ipp("+wrst2 z= ", z, " ist2= ", ist2);
 if(++ist2 < 0 || ist2 >= lst) error("wrst2: overflow ist2= ", ist2);
 st2[ist2] = z;
} */ // end wrst2

   bool popst(int k, bool err)      // err==true: error in popst; else error in the  popst caller;
{                                   // returns true if error;
 bool r= false;
 if(aa)ipp("+popst k= ", k, "ist=", ist);
 if(aa) pst("+popst ", k);
 ist=ist-k;
 if(ist<-1)
 { 
  ist+=k; pst("popst:ist<-1");
  ippelm("popst: error: s= ", s, " s0= ", s0, " s01= ", s01);
  r = true;
  if(err) error("popst: ist<-1, ist= ",ist-k, " k= ", k);
 } // if(ist<-1)
 // r = st[ist+1];
 if(mm){ pst("-popst ", k); ipp("-popst r=st[ist+1]= ", r, " k= ", k, " ist= ", ist); }
 return r;
} // end elem popst(int k)

   void popst(elem x)
{
 if(aa) ipp("+void popst elem x= ", x, " ist= ", ist);
 if(!eqel(top,x)) {pst("void popst"); error("popst:top!=x",x);}
 ist=ist-1;
 if(ist<-1)error("popst:ist<-1",ist);
 if(aa) ipp("-void popst ist= ", ist);
} // end popst

   bool eqel(elem f, elem g) // ???namt 11/11/99
{
 if(ee){cout<<"eqel:"; pelm(f); pelm(g);};
 return f.m == g.m && f.i == g.i && f.ad == g.ad;
} // eqel

   bool feql(elem f, elem g)
{
 if(ee)
  { cout<<"\nfeql f,g="; pelm(f); prp(f); pelm(g); prp(g); }
 return f.m==g.m && f.i==g.i && f.ad==g.ad;
}  // feql

    bool operator==(elem f, elem g)
{
 return f.m == g.m &&  f.i == g.i && f.ad == g.ad; // f.vc == g.vc &&
}

    bool operator!=(elem f, elem g)
{
 //if(pp){cout<<"neqel:"; pelm(f); pelm(g);};
 return !eqel(f, g);
}

   bool operator!=(head h, head g)
{
 return h.tel != g.tel || h.t != g.t // || h.lev != g.lev 
        || h.l != g.l || h.ln != g.ln || h.t != g.t;
} 

/*    int srts(elemp a, int* alast)    // 1:false!
{
 int l=*alast; elem x,z;   int j,r=1;  //ulong a1; ulong a2;
 //*alast = -1;
 if(pp) { prpa(a,l); cpp("+srts l=",l); }
 if(l < 0) error("srts 0>l = ", l);
 bsort(a,l); j = -1; z = a[0]; // ascending order!
 for(int i=1; i<=l; i++)
 {
  x=a[i];
  if(x == z)  //x.n is not used!
  {
   if(x.n != z.n) goto ret;   // true!
   continue;
  }
  a[++j] = z;  // x != z
  z=x;    
 } // end i
 if(z != zel) a[++j] = z; *alast = j; r = 0;
 ret: for(i=0; i<j; i++)
       if(lval(a[i]) > lval(a[i+1]))
       {
        cout<<"\nsrts: a[i], a[i+1]= "; pelm(a[i]); pelm(a[i+1]);
	error("srts: a[i]>a[i+1] ", lval(a[i]), lval(a[i+1]));
       }
 if(*alast < 0) error("srts: *alast < 0 ", *alast);
 if(pp) { prpa(a,*alast); cpp("-srts r=", r); }
 return r;        // r is not needed!
} // end srts
 
    void bsort(elemp q, int last) // ascending order!
{
 if(pp){cout<<"\n+bsort last="<<last; prpa(q,last); }
 int i,j; ulong v; elem key;
 for(j=1; j<=last; j++)
 {
  key = q[j]; v = lval(key);
  for(i=j-1; i>=0 && (ulong)lval(q[i]) > v; i--) q[i+1] = q[i];
  q[i+1] = key;
 } // end j
 if(pp){cout<<"\n-bsort last="<<last; prpa(q,last); }
} */ // end bsort

     int lval(elem z)
{
 int s1 = sizeof(elem); int s2=sizeof(int);
 if(s1 != s2)
   error("lval: different sizes of elem, int= ", s1, s2 );
 if(pp) ipp("+lval z= ", z);
 void* q= &z;
 int r = *((int*) q);
 //elem x = z; ulong v;
 // if(x.m>=namt) x.m=x.m-namt;
 //v=x.ad + x.i*65536L + x.n*128L*65536L + x.m*256L*65536L;
 if(pp) ipp("-lval z= ", z, " r= ", r);
 return r;
} // end lval

     void debs(char c)
{
  // char c1;
  //if(1){ cout<<"+debc c= "<<c; cin>>c1; }
  if(c=='p')
  {
   pp=1;sss=1;ttt=1; gg=1;xx=1;vv=1;ww=1;yy=1;nn=1;
	  kk=1;zz=1; qq=1; mm=1;ll=1;oo=1;aa=1;bb=1; cc=1;
	  ee=1;ff=1; hhh=1; ii=1; jj=1; uu=1; zz=1;
	  return;
  }

  if(c=='-')pp=0;
  if(c=='_'){pp=0; sss=0; ttt=0; gg=0; xx=0; vv=0; ww=0;
	     yy=0; nn=0; kk=0; zz=0; qq=0;aa=0;bb=0;ee=0;
          oo=0;   ff=0; hhh=0; uu=0; ii=0; jj = 0; return; }
  if(c=='a'){ aa^=1; return; }   //
  if(c=='b'){ bb^=1; return; }   // 
  if(c=='c'){ cc^=1; return; }   // for tt::check only
  if(c=='d'){cout<<"\ninput pdd"; cin>>pdd; }
  if(c=='e'){ ee^=1; return; }   // exception in exit1
  if(c=='g'){ gg^=1; return; }   // for sbs only
  if(c=='f'){ ff^=1; return; }  // for inference rules only
  if(c=='h'){ hhh^=1; return; }   // for hnax
  if(c=='i'){ ii^=1; return; }   //
  if(c=='j'){ jj^=1; return; }   // for cred only
  if(c=='k'){ kk^=1; return; }   // for smp only
  if(c=='l'){ ll^=1; return; }   // for nothing now
  if(c=='m'){ mm^=1; return; }   // for nacc in smp
  if(c=='o'){ oo^=1; return; }   // for end of prfr
  if(c=='n'){ nn^=1; return; }   // for glex only
  if(c=='q'){ qq^=1; return; }   // for smp only
  if(c=='s'){ sss^=1; return; }  // for sbs only
  if(c=='t'){ ttt^=1; return; }  // for typ only
  if(c=='u'){ uu^=1; return; }   // 
  if(c=='v'){ vv^=1; return; }   // for ff only
  if(c=='w'){ ww^=1; return; }   // for ff only
  if(c=='x'){ xx^=1; return; }   //
  if(c=='y'){ yy^=1; return; }   // additional
  if(c=='z'){ zz^=1; return; }   // used in smp
  if(c=='r'){ rrr^=1; return; }   // used in rnam only
      //cout<<"\ninput ai"; cin>>ha;
	     //cout<<"\ninput bi"; cin>>hb; }
  if(c=='*') error("debs: input = *");

 } // end debs

 int rtfm(char* S)              // raw time file modification (time in sec from 00.00 Jan 1, 1970)
{
 if(stat(S, & attr)) return -1; // error, something is wrong with file S: maybe S is absent;
 return attr.st_mtime;
}

 int filesize(char* S)          // file size in bytes;
{
 if(stat(S, & attr)) return -1; // error, something is wrong with file S: maybe S is absent;
 return attr.st_size;
}

 char* curtime()
{
 time_t now = time(0);
 char* dt = ctime(&now);
 return dt;
} // end curtime()

   char* mytime()
{
 time_t systime = time(NULL);
 return ctime(&systime);
} // end mytime

   double myclock(char* s)
{
 static clock_t t; //  = 0; 
 clock_t current = clock();
 double r = (double) (current - t) / (double) CLOCKS_PER_SEC ;
 t = current;
 *pfhis << "\n"<<s<<" its= "<<its<<" itt= "<<ptt->itt<<" itt1= "<< ptt->itt1<<
 " sz1= "<<ptt->sz1()<<" szfs= "<<ptt->szfs()<<" sz2= "<<ptt->sz2()<<
 "\nroot= "<<ptt->root<<" alm= "<<alm << " mergecount= "<<mergecount<< // <<" findcount= "<<findcount<<
 " nstr= " << nstr << " time(sec)= "<<r;
 cout << "\n"<<s<<" its= "<<its<<" itt= "<<ptt->itt<<" itt1= "<< ptt->itt1<<
 " sz1= "<<ptt->sz1()<<" szfs= "<<ptt->szfs()<<" sz2= "<<ptt->sz2()<<
 "\nroot= "<<ptt->root<<" alm= "<<alm << " mergecount= "<<mergecount<< // " findcount= "<<findcount<<
 " nstr= " << nstr << " time(sec)= "<<r;
 return r;
} // end myclock

     char* clon(char* s)
{
 if(pp)ipp("+clon s=", s);
 char* s1; int k = strlen(s);
 //k++;                              // for the last 0
 s1 = (char*) fylloc("clon", k+1);
 for(int i=0; i<=k; i++) s1[i] = s[i];
 if(pp)ipp("-clon s1=", s1);
 return s1;
} // end clon(s)

   bool sis(char* s1, char* s2)  // s1 in s2;
{
 bool r = false;
 // if(pp) ipp("+sis s1,s2= ", s1, s2);
 if(strstr(s2,s1)) r = true;
 // if(pp) ipp("-sis r= ", r);
 return r;
}

  bool findst(char* s, char* ar[])   // find string s in ar[lar]
{
 bool r = true; int lar = 20;   // 20: maximum length of ar
 if(pp) ipp("+findst s,ar[0]= ", s, ar[0]);
 if(pp) { cout << " lar= " << lar; *pfhis << " lar= " << lar; }
 for(int i = 0; i < lar; i++) 
	{
  if(strcmp(s, ar[i]) == 0) goto ret ;
  if(strcmp("*end*", ar[i]) == 0) break ;
 }
 // error("findst: no "*end*: lar= ", lar);
 r = false;
 ret: if(pp) ipp("-findst r= ", r);
 return r;
}

/*   bool Dcltype(ats a)    // not used 11.28.19
{
 bool r = false;
 char* s = vts(a);
 for(int i=0; i < 100; i++)
 {
  if(strcmp(dcltypes[i],"*end*")==0) goto ret;
  if(strcmp(dcltypes[i],s))  goto ret1;
 } // end for(i)
 error("Dcltype: no *end* in char* array s= ", s);
 ret1: r = true;
 ret: return r;
} // end Dcltype
*/

  bool elsf(elem z)        // elementary set formula (X <: Y or X = Y or X NI Y)
{
 headp h; elemp q; bool r2,r = false;
 if(mm) ipp("+elsf z= ", z);
 if(mel(z, &h, &q) != pfs || h->l != 3) goto ret;
 if(q[0] == zincl || q[0] == zNI){ r = true; goto ret; }
 if(q[0] != zeq) goto ret; 
 r = iset(q[1]);
 r2 = iset(q[2]);     // ??? replace iset to checking that term constructed only with \/,/\,-- ???
 if(r != r2) error("elsf: r != r2, z= ",z, " r= ", r, " r2= ", r2);
 ret: if(mm) ipp("-elsf r= ", r);
 return r;
} // end elsf

  bool elsforc(elem z)     // elsf or conjunction of elsfs
{
 headp h; elemp q; bool r = true;
 if(hhh) ipp("+elsforc z= ", z);
 if(elsf(z)) goto ret;
 if(!fnt2h(z, zconj, &h, &q)) { r = false; goto ret; }
 r = elsforc(q[1]) && elsforc(q[2]);
 ret: if(hhh) ipp("-elsforc r= ", r);
 return r;
} // end elsforc

  bool horn(elem z1)        //  z is Horn formula (Q; or Q1->Q2, or Q1 == Q2 where Q,Q1,Q2 are elsforcs)
{
 headp h; elemp q; bool r = false; elem z = stripalls(z1);
 if(hhh) ipp("+horn \nz1= ", z1, "\nz= ", z);
 if(elsforc(z)) { r = true; goto ret; }
 //if(!fnt2h(z, zimp, &h, &q)) { r = false; goto ret; }
 if(mel(z, &h, &q) != pfs || h->l != 3) goto ret;
 if(q[0] != zimp && q[0] != zequ ) goto ret; 
 r = elsforc(q[1]) && elsforc(q[2]);
 ret: if(hhh) ipp("-horn z= ", z, " r= ", r);
 return r;
} // end horn

  bool inseqv(elem s, elem x)         // s = [x1,...,xk], return x in s;
{
 int i,k; elemp q; bool r = true;
 if(!seqv(s,&k,&q)) error("inseqv: not sequence: s= ", s);
 for(i=1; i<=k; i++) if(q[i]==x) goto ret;
 r = false;
 ret:  return r;
} // end inseqv

 void inith(headp h, int pfsabt, int l, elem t, int line, att lev, att isz)
{
 if(mm&&sss) *pfhis<<"\n+inith h= "<<int(h)<<" pfs= "<<pfs <<" l= "<<l<<" lev= "<<lev;
 h->tel = pfsabt; 
 h->t   = undef; 
 h->at = 0;        // z@S;
 h->postfix = 0;  
 h->adt = 0; 
 h->v = 0;
 h->l   = l; 
 h->tp  = t;
 h->ln  = line; 
 h->name = noname;   // noname == -1; 
 h->lth = isz;   // initial size of theorem block, currently 4;
 h->levsct = lev;
 // sons may not exist yet;
} // end  void inith(head h,...)

 ats thmbase(elem z, elemp* base)   // returns the size of the theorem block and theorem base;;
{                                   // both for tabt and den, zel is in the end;
 ats r=0, a,k,m; headp h=0; elemp q,w; edenp h1; att zm = z.m; tt* pnt;
 if(mm) ipp("+thmbase z= ", z);
 if(ww) checktabt("+thmbase z= ", z);
 if(constm(zm) || z==zopsqbr || zm==ident && z.ad==att(aabt)) goto ret;  //12: aabterm,  // ??? // zabterm: replace with zabt!!!
 if(zm >= maxmod) errorelm("thmbase: wrong z.m, z= ", z, " aabterm= ", aabterm); 
 m = mel(z,&h,&q);
 if(m==var && mm) ipp("thmbase: no theorems for vars, z= ", z); // goto ret;  // no theorems are kept for vars;
 if(comp(m))
 { 
  r = h->lth - h->v; 
  if(r < 0) error("thmbase:tabt r < 0, z= ", z, " h->lth= ", h->lth);
  w = thmbase(h);             // in thmbase;
  if(mm) ipp("thmbase:tabt: Theorem block ", w, r);
  *base = w; goto ret;
 } // if(comp(m))
 if(m==con || m==bvar || m==var)   // ??? var ???
 { 
  pnt = clad[zm];
  if(pnt==0) errorelm("thmbase:den clad[z.m]=0, z= ", z);
  a = avel(z); 
  k = pnt->fdenaz(a,z);                 // k: index of x in den;
  if(ww) checktabt("thmbase:denfdenaz z= ", z);
  if(k<0 || k > pnt->iden)
   { ipp("thmbase:den wrong k, z= ", z, " k= ", k, " a= ", a, " pnt->iden= ", pnt->iden); goto ret; }
  h1 = pnt->den[k];
  w = thmbase(h1);             // in thmbase;
  *base = w;
  r = h1->lth;
  if(mm) ipp("thmbase:den Theorem block ", w, r);
 } // if(m==con || m==bvar)
 ret: if(mm) ipp("-thmbase z= ", z, " r= ", r); 
      if(r>50 && mm) ipp("thmbase: big r, z= ", z, " r= ", r, " mm= ", mm);
      if(h && h->v && mm) ipp("-thmbase z= ", z, "\nbase[0]= ", (*base)[0], " q[h->l]= ", q[h->l]); 
      if(ww) checktabt("-thmbase z= ", z);
       return r;
} // end ats thmbase(elem z, elemp* base)

 qab::qab() { iar = -1; } // see inline in lib.h

  void qab::init()
 { 
  iar = -1; 
  // if(mm) ipp("+-init: assigned -1 to iar= ", iar); // ERROR if placed inline in lib.h !!!
 } // void qab::init()

 bool qab::wr(elem z, att n, att m)  // void sbst::wrstqab(elem z, att n, att m), r=false
{                                    // ??? no checking that z is already in ar1;
 bool r = false;
 if(mm) ipp("+qab::wr z= ", z, "\nn = ", n, " m= ", m, " iar = ", iar);
 for(int i=0; i<=iar; i++)
  if(ar[i]==z)
  { 
   pr("wr: repetition"); 
   ipp("qab::wr: repetition z= ", z, " n= ", n, " m= ", m);
   if(R1[iar] != n) ipp("qab::wr: R1[iar] != n, z= ", z, " n= ", n, " R1[iar]= ", R1[iar]);
   if(R2[iar] != m) ipp("qab::wr: R2[iar] != m, z= ", z, " m= ", m, " R2[iar]= ", R2[iar]);
   goto ret;
  } // if(ar[iar]==z), for(int i);
 if(++iar >= maxlevqt) error("rep: overflow of qab z= ", z, " iar= ", iar);
 ar[iar] = z;   // stqab[istqab] = z;  // top = smallest qabterm
 R1[iar] = n;    // stqab1[istqab] = n;
 R2[iar] = m;  // stqab2[istqab] = m;
 r = true;
 ret: if(mm) ipp("-qab::wr z= ", z, "\nn = ", n, " m= ", m, " iar= ", iar);
      return r;
} // end wrstqab

 att qab::val1(elem z)                      // att sbst::fstqab(elem z) // find z in stqab;
{
 att r = emptt; int i;
 if(mm&&sss){ ipp("+qab::val1 z= ", z);  pr("+ val1"); }         // if(mm) ipp("+fstqab: z= ", z);
 for(i=0; i <= iar; i++)                    // for(i=0; i <= istqab; i++) 
   if(ar[i]==z){ r = R1[i]; break; }        // if(stqab[i]==z){ r = stqab1[i]; break; }
 if(mm&&sss) ipp("-qab::val1 z= ", z, "\nr= ", r);  // if(mm) ipp("-fstqab: z= ", z, " r= ", r);
 return r;
} //  att qab::val1: (elem z)

 elem qab::valbvar(elem z)          // elem sbst::valstqab(elem z)
{
 elem r=zel; att a;
 if(mm&&sss) ipp("+qab::valbvar z= ", z);    // if(mm) ipp("+valstqab z= ", z);
 // assert(that z is a bvar)
 a = val1(htbv(z));               // a = fstqab(htbv(z));
 if(a==emptt) goto ret;
 r = z; r.ad = a; 
 if(r.m != curm){ ipp("qab:valbvar: r.m != curm, z= ", z, " a= ", a, " r.m= ", r.m, " curm= ", curm); r.m = curm; }
 ret: if(mm&&sss) ipp("-qab::valbvar z= ", z, " r= ", r);
      return r;
} // end elem qab::valbvar(elem z)

 void qab::pop(elem z, char* place)  // decrease iar by 1;
{
 if(mm){ pr("qab::pop"); ipp("+-qab::pop z= ", z, " place= ", place); }
 if(iar<0){ *pfhis << "\nerror:qab::pop iar<0, iar= " << iar; error("qab::pop: iar<0, z= ", z, " place= ", place); }
 if(ar[iar] != z){ pr("qab::pop"); error("qab::pop: ar[iar] != z, z= ", z, " place= ", place); }
 --iar;
} // void qab::pop(char* place)

 void qab::pr(char* s)
{
 cout<<"\nSTqab::pr: place: "<<s << " iar= " << iar;
 *pfhis<<"\nSTqab::pr: place: "<<s << " iar= " << iar;
 for(int i=0; i<=iar; i++)
 {
  cout<<"\n"<<i; prp(": ", ar[i]); cout << "," << R1[i] << "," << R2[i];
  *pfhis<<"\n"<<i; prp(": ", ar[i], pfhis); *pfhis << "," << R1[i] << "," << R2[i];
 } // for(i)
 cout << "\n"; *pfhis << "\n";
} // end void pstqab()

 bool qab::bvarinqab(elem z)          // bool sbst::bvarinstqab(elem z)
{
 bool r=false; elem x,y,d; 
 if(mm&&sss) ipp("+qab::bvarinqab z= ", z); assert(z.i);
 x = z; x.i = 0;  // x = htbv(z)
 for(int i=iar; i>=0; i--)
 {
  y = ar[i];
  if(x==y || dterm(y,&d) && x==d) { r = true; break; }
 } // for
 if(mm&&sss) ipp("-qab::bvarinqab z= ", z, " r= ", r);
 return r;
} // bool qab::bvarinqab(elem z)


// end lib.cpp
