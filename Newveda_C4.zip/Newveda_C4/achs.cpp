// achs.cpp   4/30/15
#include "lib.h"   // 11/21/97 11/28/99 3/4/00 3/16/00 7/22/00 12/13/00
#include "myio.h"  // 03/13/01 
#include "achs.h"
#include "sbs.h"
// #include "elem.h"
#include "tt.h"
#include "adl.h"  
#include "typ.h"
#include "elem.h" 
#include "rep.h" 
#include "err.h"
#include "assert.h"
#include "term.h"
// #include "achs.h"
#include "lot.h"
int wrts(char* s);
modsize_t findallm(char* s); // find external module s in extm (see tran)
extern ats aAll, aExist, aExist1, aExistx,aExist1x, aProof,adclb,aterm,aabtermp,aset,
           aclass, aany, abool,aby,avariable,avar,asop,aeps,aEqProof,aabt,acol,adcol,adconj;
extern elem zexist1,zcol,abtermp,scpe,yfn; 
extern elem stgoals[]; 
extern int  counterrmsg,  hhh, mm, rrr,zz,icont,lexcount;
extern ats aAb;
extern att maxits;
extern char* countts;
extern tt* ptt;
extern achs* pntu;
extern char cont[];

// elem fseg(int k, int tel = pfs);

   achs:: achs(elem z)                          // constructor
{
 headp h;
 if(bb) ippelm("+achs::achs z= ", z);
 iach = 0;
 ach[0].ch = false;              // changed (for rep)
 ach[0].e = z;
 ach[0].p = -1;
 if(smel(z, &h))
 { 
  if(mm) ipp("achs::achs: not composite ", z);
  ach[0].h = 0;
 }
 else ach[0].h = h;
 if(bb) ipp("-achs::achs");
}

   void achs:: init(elem z)                         // z must be composite
{
headp h;
iach = 0;
ach[0].e = z;
ach[0].p = -1;
if(adel(z, & h) && z.i) error("achs::init: not composite ", z);
ach[0].h = h;
ach[0].ch = false;              // changed (for rep)
}  // end init 

   void achs::wach(elem z, int p)      // write z onto stack ach
{
 headp h; // int k; headp g; elemp w; // headp g1; elemp w1; elem x, x1;
 if(hhh)  ipp("+wach: z= ", z, " iach= ", iach);
 if(z==zel){ prach("wach"); 
      error("wach: z==zel"); } // if(z==zel){  
 if(iach>2 && z==ach[iach-2].e && z==ach[iach-1].e && z==topach().e)
      error("wach: possible recursion in ach, z= ", z, " iach= ", iach);
 if(++iach>=lach)
 {
  --iach; prach("wach:overflow ach");
  error("wach:overflow ach", iach);
 } // if(++iach>=lach)
 if(!comp(z))
 {
  // *pfhis<<"\nwach itt= "<<itt<<" z="; pelm(z, pfhis);
  prach("achs::wach z.m>0 or not composite  z=");
  error("achs::wach z.m>0 or not composite  z=",z);
 } // if(!comp(z))
 h = clad[z.m]->tabt[Att(z)];          // z is composite
 if(h==0) error("wach: h=0,  z= ", z, " z.m= ", z.m);
 ach[iach].e = z;
 ach[iach].p = p;
 ach[iach].h = h;
 ach[iach].ch = false;                     // changed in rep
 if(hhh) ippelm("-wach z= ", z," iach= ", iach);
 // if(prognum==numtyp && int(z.ad)==tead)
 // mm=mm;
} // end wach

   void achs::prach(char* s, elem z1)                      // print ach
{
 elem x,z; each y;  int i;  // headp h;
 cout<<"\n\n+prach place= "<< s; prp(z1); cout << " iach= " << iach;
 *pfhis<<"\n\n+prach place= "<< s;  prp(" ", z1, pfhis); *pfhis << " iach= " << iach<<" lexcount= " << lexcount;
 for(i=0; i<=iach; i++)
 {
  y = ach[i];
  z = y.e;
  cout<<"\ni= " << i << " y.p= "<<y.p <<" y.ch= "<<y.ch  <<" y.e= ";  prp(z); // pelm(z);
  *pfhis<<"\ni= " << i << " y.p="<<y.p<<" y.ch= "<<y.ch <<" y.e= "; prp(z, pfhis); // pelm(z, pfhis);
  if(prognum == numrnam) prp("\n     goal= ", stgoals[i], pfhis);
  if(y.p >= 0){x = y.h->son[y.p]; prp("\n     son= ", x); prp("\n     son= ", x, pfhis); }
  /* if(cmpl(z) < 100){ prp(" ", z); prp(" ", z, pfhis); }
  //else
  {
   int m = int(y.h ->tel);
   *pfhis << " tel= "<<m;
   if(y.p != -1) { *pfhis <<" son[y.p]= ";  prp(y.h->son[y.p], pfhis); } 
   // pelm(y.h->son[0], pfhis);
   // if(m == abt) prp( " son[1]= ", y.h->son[1], pfhis);
  }*/ // else
 } // for i
 cout<<"\n-prach "; prp("\n-prach z1= ", z1, pfhis);
} // void achs::prach(char* s, elem z)

  void achs::popach(void* s)
{       
 elem d,z,y=zel1; headp h; elemp q; int m; 
 if(iach < 0) error("pach: iach < 0,  iach= ", iach);
 if(s)
 {
  z = topach().e; sbst* s1 = (sbst*)s; assert(iach >= 0);
  if(qabterm(z,&h,&q,&m) && (!dterm2(y = justup(iach), &d) || comp(d) && d != z)) // was error: R[d,f]
  {
   // if(z.ad == 8572) 
   if(mm)
   { 
    ipp("achs::pach: removing qabterm z from ach, z= ", z, " d= ", d, " y= ", y); 
    --ach[iach].p;  
    prach("achs::pach: removing..."); 
   } // if(mm) 
   // if(iach > 0 || m != abt ) 
   // s1->removebvars(z);    // commented on 01.16.2022
   // else if(9) ipp("pach: no removebvars(z),z= ", z, " iach= ", iach, " m= ", m);
  } //  if(qabterm(z))
 } // if(s)
 if(--iach < -1) error("pach:iach",iach);   // pop ach
 if(pp) ipp("-pach:iach=", iach);
} // end popach 

  each achs::topach()
{
 if(iach < 0) 
  error("topach: wrong iach= ", iach); 
 return ach[iach];
} // end topach()
 
  each achs::topach1()
{
 if(iach < 1) 
  error("topach1: wrong iach= ", iach); 
 return ach[iach-1];
} // end topach1()
 
  bool achs::topachDabt(elem z)          // r  top.e == z && Dterm(top1.e) // && top1.p == 1; p== -1  in typ!!!
{
 bool r; each E = topach(), E1 = topach1();  
 r = (E.e==z) && dterm(E1.e);
 if(mm) ipp("+-topachDabt z= ", z, "\ndterm= ", E1.e, "\ntop.e= ", E.e, " r= ", r);
 return r;
}

  void achs::cach()                      // control ach
{
 elem z; headp h; int p;
 //cout<<"\nach iach="<<iach;
 for(int i=0; i<=iach; i++)
 {
  z = ach[i].e;  p = ach[i].p; h = ach[iach].h;
  if(z.m || !comp(z))
  {
   cout<<"\ncach  z="; pelm(z);
   error("tt::cach z.m>0 or not coposite  z=",z);
  }
  if(p >= int(h->l)  || p < -1)
  {
   cout<<"\ncach h->l="<<h->l<<" p="<<p;
   pelm(z); prp("=z=", z);
   prach("tt::cach wrong p = ");
   error("tt::cach wrong p = ", p);
  } // if(p)
 } // end for i
} // end cach

  elem achs::curvert(bool* finr)            // current vertex, finr : the vertex is the most right;
{
 if(iach < 0 || iach >= lach) error("curvert: wrong iach = ", iach);
 elem r;
 each a = ach[iach];
 int place = a.p;
 if(bb) ipp("+curvert iach= ", iach, " place= ", place);
 if (place == -1){ r = a.e; if(finr) *finr = iach==0? true: ach[iach-1].p == (short(ach[iach-1].h ->l) - 1); }
 else{ r = a.h->son[place]; if(finr) *finr = (place == short(a.h->l) - 1); }
 if(bb) ippelm("-curvert r= ", r, " *finr= ", finr? *finr: 999); //  " iach= ", iach);
 return r;
} // end curvert

// inline elem actarg(each Q){ elem r = Q.e; if(Q.h && Q.p != -1) r = (&(Q.h->son[0]))[Q.p]; return r; }

  each achs::acteach(short* ai)     // i - active index( iach or iach-1);
{
 if(mm) ipp("+acteach iach= ", iach); att static i;
 if(iach<0 || iach >= lach) error("acteach: wrong iach= ", iach, " lach= ", lach);
 each r = ach[iach]; i = iach;
 if(iach==0) goto ret;
 if(!comp(r.e)){ prach("!comp(r.e)"); error("acteach: not composite r.e= ", r.e); }
 if(r.p == -1) r = ach[--i]; 
 ret: *ai = i; if(mm) ipp("-acteach r.e= ", r.e, " r.p= ", r.p, " i= ", i);
      return r;
} // end acteach

  int achs::actplace(elemp az)
{
 int r = -1, i=iach; 
 if(i < 0 || i >= lach) error("actplace: wrong iach = ", i);
 each Q = ach[i];
 if(mm) ipp("+actplace Q.e= ", Q.e, " Q.p= ", Q.p, " iach= ", i);
 // if(Q.p == -1){ if(az) *az = Q.e; goto ret; }
 if(comp(Q.e) && i > 0 && Q.p == -1 )
 { 
  // if(--iach < 0) error("actplace:comp(Q.e): --iach < 0, iach= ", iach);
  Q = ach[--i];
 } // if(comp(Q.e))
 if(Q.h == 0){ ipp("actplace: Q.h == 0, Q.e= ", Q.e); *az = Q.e; goto ret; }
 r = Q.p;
 *az = (&(Q.h->son[0]))[r];     // r = Q.p; 
 ret: if(mm) ipp("-actplace Q.e= ", Q.e, " *az= ", *az, " Q.p= ", Q.p, " i= ", i, " r= ", r);
 return r;
} // end int actplace()

   elem achs::parent()                              // the parent of the current vertex   
{
 if(iach < 0 || iach >= lach) error("parentt: wrong iach = ", iach);
 elem r=zel;   // x;
 each a = ach[iach];
 // int p = a.p;
 if(bb) ipp("+curvert iach= ", iach, " p= ", a.p);
 if (a.p == -1) r = above();  // inline elem achs::above(){ return iach>0 ? ach[iach-1].e : zel; }  // ach grew down; 
 else r = a.e ; // if(comp(x=a.h->son[place])){ prach("parent: error");  error("parent: comp(x), x= ", x); } }
 if(bb) ipp("-parent r= ", r); //  " iach= ", iach);
 return r;
} // end curvert

   elem achs::lbr()                       // left brother
{
 elem r = zel; int p = -999, k=0; each a; // headp h;
 if(hhh) ipp("+lbr: curvert= ", iach<0? zel:curvert(), " iach= ", iach, " p= ", iach<0? -999:ach[iach].p); 
 if(iach < 0) goto ret;
 a = ach[iach];
 p = a.p;
 if(isrt(a.e, zProof)) k = 1; else k = kmain(a.e);    // p < k -> no left brother !
 p = a.p;
 if(p < 0) goto ret;
 if(--p > k){ r = a.h->son[p]; ach[iach].p = p; }   // else r=zel;  // see above r = zel;
 ret: if(hhh) ipp("-lbr r= ", r, " p= ", p);
      return r;
} // end lbr

 bool achs::mostr(short* p)                // the current vertex is the most right, p: the place;
{
 bool r; short p1;
 if(iach < 0 || iach >= lach) error("mostr: iach < 0 || iach >= lach, iach= ", iach, " lach= ", lach); 
 each a = acteach(&p1); int hl1=0; 
 if(mm) ipp("+mostr a.e= ", a.e, " iach= ", iach);
 if(a.h==0)
 { 
  ipp("mostr:h==0, return true, p=1"); 
  r = true; *p = 1; 
  goto ret; 
 } // if(a.h==0)
 hl1 = (a.h -> l) - 1;
 r = (a.p == hl1);
 *p = a.p;
 ret: if(mm) ipp("-mostr a.e= ", a.e, " iach= ", iach, " hl1= ", hl1, " *p= ", *p, " r= ", r);
 return r;
} // end mostr

   elem achs::pred()                     // preceding vertex (predecessor), otherwise zel
{
 if(hhh) ipp("+pred: curvert= ", iach<0? zel:curvert(), " iach= ", iach, " place= ", iach<0? -999:ach[iach].p);
 elem r = lbr();              
 while( r == zel && --iach >= 0) r = lbr();            // no left brother
 if(hhh) ipp("-pred: r= ", r, " iach= ", iach);
      return r;
} // end pred

   elem achs::prevt(achs* a, int i)                   // previous theorem, a == pntu, i in 0..lview;
{
 elem Q,V; headp h=0,g; elemp q,w; int k,m,hl1,gl1;
 V = iach<0? zel:curvert();
 if(mm)
 {
  ipp("+prevt: curvert= ", V, " iach= ", iach, " place= ", iach<0? -999:ach[iach].p);
  // a->prach(---); 
 } // if(mm)
 // if(V.ad == 735)
 // V=V;
 while((Q = pred()) != zel)     // Q != zel -> iach >= 0;
 {
  if(hhh) ipp("prevt:while Q= ", Q);
  m = mel(Q,&h,&q); 
  if(h==0){ ipp("prevt: wrong(ident) Q= ", Q); prach("prevt: h==0"); continue; }
  hl1 = int(h->l) - 1;
  if(m==abt && hl1 - kmain(h) > 0 && a->seekdcol(Q))   // hl1 - kmain(h) : the number of axioms;
  {
   if(hhh) ipp("prevt: abt: Q= ", Q);
   wach(Q,hl1);
   Q = q[hl1]; break;
  } //  if(m==abt ...)
  if(separ(Q)){ Q = zel; break; } 
  // if(q[0]==zexc1 || q[0]==zdexc){Q = q[1];  break; }
  if(Truth(h)) break;  // if(h->t == truth) break;
  if(q[0]==zA || q[0]==zE || q[0]==zF)        // Q is A[d,X], E[d,X], F[d,X]
  {
   if(mel(q[1],&g,&w) != abt) continue;
   gl1 = int(g->l)-1;
   wach(q[1],gl1);
   Q = w[gl1]; break;
  } // if(q[0]==zA ...)
  if(q[0] == zdcol && a->seekdt(q[1]))  // Q is d::X, if a dterm d*Y,..., is in ach; then
  {
   if(seqv(q[2],&k)){ wach(q[2], k+1); continue; }  // enter inside of [ ...] in d::
   Q = q[2]; 
   if(mel(Q,&h)==pfs && Truth(h)) break;            // h->t == truth) break;
  } // if(q[0] == zdcol ...)
 } // end while
 if(mm) ipp("-prevt: Q= ", Q, " i= ", i);
 return Q;
} // end prevt

 /*if(q[0]!=zA && q[0]!=zE && q[0]!=zF] continue;        // Q is A[d,X], E[d,X], F[d,X]
  if(mel(q[1],&g,&w) != abt) continue;
  gl1 = int(g->l)-1;
  wach(q[1],gl1); continue;
*/
   void achs::copy(achs* a)               // copy this to a;
{
 a->iach = iach;
 for(int i=0; i<=iach; i++) a->ach[i] = ach[i];
} // end copy

   bool achs::next(void* s) // , bool skipbv)                           // true: finish
{
 bool r = true; int p,k; elem z = zel;  headp h; bool skipbv = true; // elemp q;
 if(bb) *pfhis << "\n+achs::next: s= " << s << " iach= " << iach << " place= " << ach[iach].p;
 // if(bb) ippelm("achs z= ", z);
 if(ach[iach].h == 0) { assert(iach == 0); iach = -1; goto ret1; }
 while(++(ach[iach].p) >= int(ach[iach].h->l))
 { 
  popach(s);
  if(iach < 0) goto ret;
 } // end while
 p = ach[iach].p; h = ach[iach].h;
 // if(skipbv && ach[iach].h->tel == abt && p == 1)
 if(skipbv && p==1)
 {                // int kboun(headp h) // number of bounded names (All, Exist, Exist1: 1, abt : abt.i, else 0;
  k = kboun(ach[iach].h); 
  if(k)
  {
   if(bb) ipp("next: skipping bounded var= ", h->son[1], " p= ", p, " k= ", k);
   p += k; ach[iach].p = p;
  }
 } // if(skipbv && ...)
 z = ach[iach].h->son[p];
 if(bb) ippelm("1achs::next z= ", z);
 // if(fnt2h(z,yasop,&h,&q)) z = q[2];
 if (comp(z)) wach(z);
 ret1: r = iach < 0;
 ret:if(bb) ipp("-achs::next curvert= ", z, " iach= ", iach, " place= ", ach[iach].p);  // " iach= ", iach);
	 return r;
} // end next();

   bool achs::next1(void* s)     // goto the right brother, true: finish
{                      // ??? skip bounded names ???
 bool r = true; elem z=zel; int k,p; headp h; // elemp q;
 if(mm && kk) *pfhis << "+achs::next1: s= " << s << " iach= " << iach << " place= " << ach[iach].p;
 if(ach[iach].p < 0) popach();    // the only difference from next !
 if(iach < 0) goto ret; 
 if(ach[iach].h == 0) { assert(iach == 0); iach = -1; goto ret1; }
 while(++ach[iach].p >= int(ach[iach].h->l))
 { 
  popach(s);
  if(iach < 0) goto ret;
 } // end while
 if(iach < 0) goto ret;
 p = ach[iach].p; h = ach[iach].h;
 if(p==1)
 {
  k = kboun(h);
  if(k)
  {
   if(bb) ipp("next1: skipping bounded var= ", h->son[1], " p= ", p, " k= ", k);
   p += k; ach[iach].p = p;
  } // if(k)
 } // if(iach < 0)
 z = ach[iach].h->son[p];
 // if(fnt2h(z,yasop,&h,&q)) z = q[2];
 if(comp(z)) wach(z);
 ret1: r = iach < 0;
 ret:if(mm && kk) ipp("-achs::next1 curvert= ", z," iach= ", iach, " place= ", ach[iach].p);
	 return r;
} // end next1();

 /*  int achs::seek(elem d, int* k) // r==1: ach[k].e == 1, r==2: dterm(... ) && ..:
{                                 // not used
 int r=0,i; elem d1;
 for(i=iach; i>=0; i--)
 {
  if(ach[i].e == d) { r = 1; goto ret; }
  if(dterm(ach[i].h, &d1)) { r = 2; goto ret; }
 } // end for
 ret: *k = i; 
 return r;
} // end achs::seek


   int achs::seek1(elem z)                 // not used: 9.13.22 seek z==ach[i].e in ach, r: -1 : not in ach
{
 int i; // elem y; headp h;
 if(bb) ippelm("+seek1: z= ", z);
 for(i = iach; i >= 0; i--)
 {
  // h = ach[i].h; y = h->son[0];
  // if(bb) ippelm("seek: y= ", y, " i= ", i);
  if(z == ach[i].e) break;
 } // for(i)
 if(bb) ipp("-seek1: r= ", i);
 return i;
} // seek1(elem z)
*/

   int achs::seek(elem z)                 // seek z==ach[i].h->son[0] in ach, r: -1 : not in ach
{
 int i; elem y; // headp h;
 if(bb) ipp("+seek: z= ", z);
 for(i = iach; i >= 0; i--)
 {
  y = ach[i].e; 
  if(bb) ippelm("seek: y= ", y, " i= ", i);
  if(y == z) break;
 } // for(i)
 if(bb) ipp("-seek: z= ", z, " r= ", i);
 return i;
} // seek(elem z)

  elem achs::seekroot(elem f)            // r = ach[i].e; such that root(r) = f;
{
 elem r=zel,x; int i;
 if(mm) ipp("+seekroot f= ", f, " iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  r = ach[i].e;
  x = root(r);
  if(f==x) goto M;
 } // for(i)
 error("seekroot: no f in ach, f= ", f, " iach= ", iach);
 M: if(mm) ipp("-seekroot f= ", f, " r= ", r);
    return r;
} // end elem seekroot
                 
 int achs::findqabt(elem arqt[maxlevqt])  // all qterms in achs, beginning from top, r: last occupied
{                                         // arqt[0] = top;
 int i, j = -1;  elem y=zel; 
 if(mm) ipp("+findqabt: iach= ", iach);
 for(i = iach; i >= 0; i--)
 {
  y = ach[i].e;
  if(qabterm(y))
  {
   if(++j >= maxlevqt) error("findabqt: too big embeddingness of qterms j= ", j);
   arqt[j] = y;
  } // if(qabtermp)
 } // for(i = iach)
 if(mm) ippq1("-findqabt: y= ", y, " arqt= ", arqt, j);   // j: last occupied
 return j;
} // end findqabt(elem z)

 int achs::nqabt()                      // index of the nearest(from top) qabtermp in achs;
{
 int i;
 for(i = iach; i >= 0; i--)
  if(qabterm(ach[i].e)) goto ret;
 i = -1;
 ret: if(mm) ipp("-+nqabt: i= ", i);
 return i; 
} // end int achs::nqabt()

   bool achs::bvarin(elem z, int* place, elem* d) // z is boundvarQ(z, &Q) && Q is in achs;
{                                                 // p==true:  htbv(z) is qabterm; // All,..., {X;P(x)
 bool r = true; int i;  elem dz,Q,M,s; each el; headp h; // d: qabterm or d in dterm: A[d,P],...; //, savekk=kk
 // kk=1;
 if(mm && kk) ipp("+bvarin z= ", z);                                //  Rep(d,Q,M) = Q.M or Q(m1,...k); 
 if(d) *d = zel;
 if(z.i == 0){ if(mm) ipp("bvarin: not bvar, z= ", z); goto ret1; }                                // ret1: r = false;
 dz = htbv(z);                                       // x = z; x.i = 0;
 if(dz==zel || !qabterm(dz)){ if(mm) ipp("bvarin: not qabterm, dz= ", dz, " z= ", z); goto ret1; } // ret1: r = false;
 for(i = iach; i >= 0; i--)
 {  
  el = ach[i]; h = el.h; 
  // if(DinD(dz, s=scopeden(el.e)))
  // { 
  // if(mm) ipp("bvarin: DinD(dz, scopeden(el.e)) found dz in s, z= ", z, " s= ", s); 
  // if(place) *place = i; if(d) *d = dz; goto ret;
  // } // if(DinD(dz, ...)
  if(dz == el.e){ if(place) *place = i; if(d) *d = dz; goto ret; }
  if(h == 0){ if(mm) ipp("bvarin: ach[i].h==0, z= ", z, " i= ", i); continue; }
  if(dterm1(h) && (h->son[1])==dz) // || h->son[0]==zdconj && DinD(dz, h->son[1]))  // add || Dind(dz, h->son[2]) 2022.10.31 !!!
      { if(place) *place = i; if(d) *d = dz; goto ret; }
  if(vterm(el.e, &Q, &M))    // Rep(d,Q,M) = Q.M or Q(m1,...k);
  { 
   s = scopeden(Q);          // actually, another function Scope(el.e) is needed, which will use HostMod;
   if(mm) ipp("bvarin:vterm(el.e,Q,M), z= ", z, "\ndz= ", dz, " mm= ", mm, " wrlot_c= ", wrlot_c);
   if(DinD(dz, s))
   { 
    if(place) *place = i; if(d) *d = dz; 
    if(mm&&kk) ipp("bvarin:DinD(dz, s), r=1, z= ", z, " dz= ", dz, " wrlot_c= ", wrlot_c); // "\ns= ", s); 
    // if(wrlot_c==stad2)
    // mm=mm;
    goto ret; 
   } // if(DinD(dz, s))
  } // if(vterm(el.e,
 } // for(i)
 if(mm && kk){ ipp("bvarin: not in ach, dz= ", dz); prach("bvarin"); }
 ret1: r = false;
 ret: if(mm && kk) ipp("-bvarin z= ", z, "\nd= ",  d==0? zel999: *d, " r= ", r, " place= ", place==0? 999: *place);
      // kk=savekk;
 return r;
} // end bool bvarin(elem z)

   bool achs::bvarin1(elem z)   // z is boundvarQ(z, &Q) && Q is in achs;
{                                                   // p==true:  htbv(z) is qabterm; // All,..., {X;P(x)
 int i; bool r = true; elem d; each el; headp h;    // d: qabterm or d in dterm: A[d,P],..
 if(mm) ipp("+bvarin1 z= ", z);
 if(z.i == 0){ if(9) ipp("bvarin1: not bvar, z= ", z); goto ret1; }
 d = htbv(z);                                       // x = z; x.i = 0;
 // if(!qabterm(d)){ if(mm) ipp("bvarin: not qabterm, x= ", x, " z= ", z); goto ret1; }
 for(i = iach; i >= 0; i--)
 {  
  el = ach[i]; h = el.h;
  if(d == el.e) goto ret;
  if(h == 0){ if(mm) ipp("bvarin1: ach[i].h==0, z= ", z, " i= ", i); continue; }
  if(dterm1(h) && (h->son[1])==d) goto ret;   // A[d, P], ..., F[d,G], ...
 } // for(i)
 if(mm && kk){ ipp("bvarin1: not in ach, z= ", z, "\nd= ", d); prach("bvarin"); }
 ret1: r = false;
 ret: if(mm && kk) ipp("-bvarin1 z= ", z, " r= ", r);
 return r;
} // end bool bvarin(elem z)

   bool achs::varin(elem z)          // z is freevarQ(z, &Q) && Q is in achs;
{
 int i; bool r = false; 
 if(z.i == 0) error("varin: not var, z= ", z);
 for(i = iach; i >= 0; i--)
   if(qabterm(ach[i].e) && ach[i].h->son[1]==z){ r = true; break; }  // abt: only first bvar checked ???
 return r;
} // end bool varin(elem z)

   int achs::qablev()
{
 int i,r=0; headp h;
 for(i=iach; i > 0; i--)
  if(qterm(h=ach[i].h) || h->tel == abt || dterm(h)) ++r; else continue;
 return r;
} // int achs::qablev()
/*
   void achs::crstqab(elem V)             // create stqab from achs until V(not including);
{                                         // not used;
 int i,n; elem x; bool p=false; 
 if(mm) ipp("+crstqab V= ", V); 
 istqab = -1; 
 for(i=0; i<=iach; i++)
 {
  x = ach[i].e;
  if(x==V) goto ret;
  if(qabterm(x)){ wrstqab(x, n = ptt->newtt("crstqab")); filltabt(n);  /*ptt->tabt[n] = ptt->tabt[0]; +/ }
 } // for(i)
 prach("crstqab");
 ipp("??? crstaqb: no V in achs, V= ", V); p = true;
 ret: if(mm || p){ prach("-crstqab"); prstqab("crstqab"); ipp("-crstqab V= ", V ); } // mm = save;
} // end void crstqab(elem V) 
*/
   elem achs::clonch(elem y) // clon of active element with changing his active son to y
{
 elem r=y; int i = iach; headp h; elemp q; each a; head g; int saveist = ist; bool b;
 if(mm) ipp("+clonch: y= ", y, " ach[iach].e= ", ach[iach].e, "saveist= ", saveist);
 assert(iach >= 0); 
 if(ach[iach].p == -1) i = iach - 1;
 if(i < 0) { ipp("clonch: no cloning, i= ", i); goto ret; }
 a = ach[i];
 assert(0 <= a.p && a.p < int(a.h->l));
 q = &(a.h->son[0]);               
 g = *a.h; g.name = -1;;
 for(i=0; i < int(a.h->l); i++) wrst(q[i]);
 st[saveist + a.p + 1] = y;             // ist: last occupied (+1)
 r = ptt->wrtt(g, &(st[saveist+1]));    // r is a clon of ach[i].e;
 b = mel(a.e,&h)==abt || qterm(h);
 // if(b) chabt(r, a.e, r);
 ret: if(mm) ipp("-clonch: y= ", y, " r= ", r);
 ist = saveist;
 return r;
}  // end  elem achs::clonch;

  elem achs::repach(elem z, qab* W)        // clon all active terms, replacing at first active son on z
{                                  // and so on moving up active chain
 elem r=z,act, t; each Q; int i,k, savemm=mm; elemp q; att n;// mm=1;   , savemm=mm
 if(mm){ ipp("+repach z= ", z, " iach= ", iach); W->pr("W"); }
 // if(stopd!=0 && z.ad==stopd)
 // mm=mm;
 k = iach; Q = ach[iach]; t = Q.e;
 if(Q.p != -1 && comp(t) && comp(actarg(Q)))
 {
  if(iach <= 0){ prach("+ repach");  error("repach: iach <= 0, z= ", z); }
  Q = ach[iach-1]; 
  if((act = actarg(Q)) != t)
    error("repach: (act = actarg(ach[iach-1])) != t= ", t, "\nact= ", act); 
  // if(comp(z) && z != t) error(
  --k;
 } // if(comp(z))
 for(i=k; i>=0; i--) 
 {
  Q = ach[i]; q = &(Q.h->son[0]);
  n = W->val1(Q.e);
  if(mm) ipp("repach:+for Q.e= ", Q.e, "\nr= ", r, " Q.p= ", Q.p, " i= ", i, " n= ", n);
  r = reparg(Q.e, Q.h, q, Q.p, r, W);  // replace p-th arg in Q.e with r; // simple replacement
  if(mm) ipp("repach:-for Q.e= ", Q.e, "\nr= ", r, " Q.p= ", Q.p, " i= ", i);
 } // for(i=k)
 if(mm) ipp("-repach z= ", z, "\nr= ", r);  // mm=savemm;
 return r;
} // end elem achs::repach;
/*
   elem achs::repa(elem y)      // clon all active terms, replacing at first active son on y
{                               // and so on moving up active chain
 elem r = y; int i;
 assert(iach >= 0);
 if(mm) ipp("+repa y= ", y, "ach[iach].e= ", ach[iach].e);
 if(ach[iach].p = -1) iach--;
 for(i = iach; iach >= 0; iach--) r = clonch(r);
 r = sbbv(r); 
 if(mm) ipp("-repa r= ", r, " y= ", y); 
 return r;
} // elem achs::repa(elem y)
*/

 elem achs::ndcol()    // nearest(from top) dcol-term (T::z), returns T, else zel;
{
 int i; headp h; elem r = zel;
 if(pp) ipp("+ndcol iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h;
  if(h->tel == pfs && h->l == 3 && h->son[0] == zdcol){ r = h->son[1]; break; }
 } // for(i)
 if(pp) ipp("-ndcol r= ", r);
      return r;
}  // end ndcol

 bool achs::inproof()    // inside of Proof(...) or EqProof;
{
 bool r = false; int i; headp h; elem z;
 // if(pp) ipp("+ndcol iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h; z = h->son[0];
  if(h->tel == pfs && (z==zProof || z==zEqProof)){ r = true ; break; }
 } // for(i)
 // if(pp) ipp("-ndcol r= ", r);
 return r;
}  // end ndcol

 bool achs::inbyis()    // inside of by(...) or is(...);
{
 bool r = false; int i; headp h; elem z;
 // if(pp) ipp("+ndcol iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h; z = h->son[0];
  if(h->tel == pfs && (z==zby || z==zis)){ r = true ; break; }
 } // for(i)
 // if(pp) ipp("-ndcol r= ", r);
 return r;
}  // end inbyis




 bool achs::seekdcol(elem T)     // seek in achs dcol-term (T::z) or T && P
{
 int i; headp h; bool r = false;
 if(hhh) ipp("+seekdcol T= ", T, " iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h;
  if(h->tel == pfs && h->l == 3 && (h->son[0] == zdcol || h->son[0] == zdconj))
    if(T==zel1 || h->son[1] == T){ r = true; break; }
 } // for(i)
 if(hhh) ipp("-seekdcol r= ", r);
 return r;
} // end seekdcol

 bool achs::seekdt(elem T)              // seek in achs d-term { }, A[T,P],..., T::z), T&&P;
{                                       // more general than seekdcol;
 int i; bool r = true; elem d;
 if(hhh) ipp("+seekdt T= ", T, " iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  // if(ach[i].e == d) goto ret;
  if(dterm(ach[i].h, &d) && d==T) goto ret;
 } // for(i)
 r = false;
 ret: if(hhh) ipp("-seekdt r= ", r);
 return r;
} // end seekdt

 bool achs::seekd(elem d)              // seek in achs d-term { }, A[d,P],..., d::z), d&&P;
{                                       // more general than seekdcol;
 bool r = true; elem d1; // static int count = 0; 
 // ++count;
 if(mm && kk) ipp("+seekd d= ", d, " iach= ", iach);
 // if(count==stad2)
 // mm=mm;
 if(d==zel)
  error("achs::seekd: wrong d= ", d); 
 for(int i=iach; i>=0; i--)
 {
  each Q = ach[i];
  if(Q.h==0){ if(mm) ipp("seekd Q.h==0, Q.e= ", Q.e);  continue;  }             // error ??? 2022.11.21;
  if(Q.e == d) goto ret;
  if(dterm(Q.h, &d1) && d==d1) goto ret;
 } // for(i)
 r = false;
 ret: if(mm && kk) ipp("-seekd d= ", d, " r= ", r);
 return r;
} // end seekdt

  elem achs::seekdtd(elem f,elem d)   // seek in achs d-term f[d,..] or (if f==zel)){ }, A[d,P],..., S[d,f); d is variable;
{
 bool p; att hl; elem r; ats i; ats a; elem z; headp h; elemp q;
 if(mm) ipp("+seekdtd zR= ", zR, " iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h; q = &(h->son[0]);  hl = h->l; 
  z = q[0]; if(mm) ippelm("seekdtd z= ", z, " zR= ", zR, " hl= ", hl);
  if(z==f && q[1]==d){ r = d; goto ret; }
  p = bdname(z) && hl==3 && freevar(q[1], &a) && strcmp(vts(a),"d")==0;
  if(p){ r = q[1]; goto ret; }
 } // for(i)
 r = zel;
 ret: if(mm) ipp("-seekdtd r= ", r);
 return r;
} // end seekdtd

  elem achs::tpAdbv(elem z)    // seek in achs A[d,P], d==htbv(z), if found r = tp(z) else r = zel;
{                              
 int i; elem r = zel; elem d = htbv(z), d1;
 if(mm) ipp("+tpAdbv z= ", z, " iach= ", iach);
 for(i=iach; i>=0; i--)
 {
  if(fnt2(ach[i].e, zA, &d1) && d==d1)
  {
   r = tp(z); break;
  } // if(fnt2)
 } // for(i)
 if(mm) ipp("-tpAdbv z= ", z, " r= ", r);
 return r;
} // end tpAdbv

 elem achs::tfromach(elem z)            // type from ach : z in t -> R, z is inside of R, r = t; 
{
 elem x,t,P,r = zel; each a; bool p,p1;
 if(mm)
 { ipp("+tfromach z= ", z); prach("tfromach", z); }
 for(int i=iach; i>=0; i--)
 {
  a = ach[i];
  p = (a.p>1);
  p1 = fnt22l(a.e,zimp,zin,&x,&t,&P);
  if(mm) ipp("tfromach p= ", " p1= ", p1);
  if(p1 && mm) ipp("tfromach x= ", x, " t= ", t, " P= ", P);
  if(p && p1 && z==x){ r = t; break; }
 } // for(i)
 if(mm)  ipp("-tfromach z= ", z, " r= ", r);
 return r;
} // end elem achs::tfromach(elem z)

/*  int achs::nqt(headp* ah, elemp* aq)    // nearest(from top) Q-term (All, Exist, Exist1)
{
 int i; headp h;
 if(mm) ipp("+nqt iach= ", iach, " ach[iach].e= ", ach[iach].e);
 for(i=iach; i>=0; i--)
 {
  h = ach[i].h;
  if(h->tel == pfs && Qname(h->son[0]))
  {
   *ah = h; 
   *aq = &(h->son[0]); 
   if((mm) ipp("nqt: ach[i].e = ", ach[i].e);
   goto ret;
  } // if(h->tel == pfs)
 } // for(i)
 i = -1;
 ret: if(mm) ipp("-nqt i= ", i);
      return i;
} */ // end nqt

   elem achs::Scope(int ai, bool p)    // p=true: Scope was called from 5.1 (x := y)'
{              // nearest raw(before rnam) scope term(abterm,ALL,Exist,..., used only in bdef;
 int i; elem z,r,y; headp h; elemp q; ats a,a1;   // ,c,c1 // r1=zel,
 if(bb) ipp("+Scope: iach= ", iach);   // was if(bb)
 for(i=ai; i>=0; i--)
 {
  z = ach[i].e; r = z;
  h = ach[i].h; q = &(h->son[0]);
  if(h->tel == abt)
  {
   if(i > 1 && fnt2(ach[i-1].e, zEx)) continue;   // if met d in Ex[d,P], then d cannot be the scope!!!
   goto ret;
  } // if(h->tel == abt)
  if(h->tel != pfs) continue;
  if(!idubs(q[0], &a)) continue;
  // if(a==aAb && p){ if(Ident(q[1], &a1))  r = fdenabtdc(a1); goto ret; }   // the line was added on 6.25.22
  if(a==aAll || a==aExist || a==aExist1 || a==aeps || a==aProof || a==aEqProof || a==adconj) goto ret; // yes:no Existx!
  if(a==adcol)           // y :: 
  {
   if(h->l != 3) error("Scope:(::) h->l != 3, z= ", z);
   y = q[1];
   // if(fnt2(y,zdot,&c,&c1)) y = c;
   if(Ident(y, &a1))
   {
    r = fdenabtdc(a1);           // abt or dconj: && or zdot
    if(r == zel) error("Scope: (::) a1 is not abt or &&, z= ", z,  "\na1= ", vts(a1));
    goto ret;
   } // if(Ident(q[1])
   // if(!fnt2(y,zdot,&c,&c1))
   error("Scope: (::) q[1] is not ident, not zdot, z= ", z, "\nq[1]= ", q[1], " y= ", y);
   // r = y; goto ret;
  } // if(a==adcol)
 } // for(i=iach)   // no aExistx !!!
 r = zel;
 ret: if(bb) ipp("-Scope r= ", r, " i= ", i);   // was if(bb) // " r1= ", r1,
 return r;
} // end elem achs::Scope()

/*   void achs::normAEF(elem z, elemp q, int hl, int a) // normalization of A,E,E1,F[a0,a1:t1,a2,a3:t2,...,P]: q -> q;
{                                                    // a==1 for A[, 2 - for dcl;
 int i, j=-1, k=-1, hl1=hl-1, lev; headp g; elemp w; 
 elem x,y,d,P, A[maxlevqt], T[maxlevqt];   // maxlevqt = 20
 if(zz) ipp("+normAEF: z= ", z, " hl= ", hl); assert(hl >= 3);  
 ist = 0;                 // 0 rezerved for abtermp(k+1) 
 for(i=a; i<hl1; i++)     // a==1 for A[, 2 - for dcl
 {
  x = q[i]; 
  if(Ident(x))
  {
   if(++j >= maxlevqt) error("normalAEF: overflow of j, z= ", z, "j= ", j, "maxlevqt= ", maxlevqt);
   A[j] = x;  wrst(x); continue;  // A = a0,a1,a2,a3;  j = 3;
  } // if(Ident(x))
  if(!fnt2h(x,zcol,&g,&w) || !Ident(w[1]) )
     error("normAEF: wrong x: not a:t, z= ", z, "\nx= ", x, " zcol = ", zcol, " i= ", i);
  if(++j >= maxlevqt) error("normalAEF: overflow1 of j, z= ", z, "j= ", j, "maxlevqt= ", maxlevqt);  
  A[j] = w[1];  wrst(w[1]);  
  x = w[2];                 //  changing x = t from  x = a:t; was w[0] = zin;
  while(k < j) T[++k] = x;  // T = t1,t1,t2,t2;
 } // for(i=1, i<hl1)
 if(j != k) error("normAEF: the last x is not a:t, z= ", z, " j= ", j, " k= ", k);  // j = 3;
 x = abtermp; x.i = k+1; st[0] = x;       // abtermp = elm(ident, 0, wrts("abt"));
 for(i=0; i<=k; i++)for(j=i+1; j<k; j++)  // checking for repeating names in A;
  if(A[i] == A[j]) error("normaAEF: repeating name A[i]= ", A[i], " i= ", i, " j= ", j);
 for(i=0; i<=k; i++)                      // writing axioms;
 {
  x = A[i]; y = T[i];   // elem trm2(elem f, elem x, elem y, elem t=zel, att n = emptt);
  scpe = z;  
  y = trm2(zin,x,y,zbool);
  wrst(y);
 } // for(i=0; i<=k);
 if(ist != 2*k+2) error("normAEF: ist != 2*k+2, z= ", z, " ist= ", ist, " k= ", k);
 lev = qablev() + 1;               // ??? qablev() + 1: because d was not in ach;
 d = fseg(ist+1,emptt,abt,0,lev);  // 0: ah;
 // if(9) ipp("normAEF: z= ", z, " d= ", d);
 P = q[hl1];
 q[a] = d; q[a+1] = P;  // h->l will be changed in bdef;
 if(zz) ipp("-normAEF: z= ", z, "\nd= ", d, "\nP= ", P);
} // end void achs::normAEF
*/
   elem achs::spterm2(elem A, elem M)      // special term A@M; pars considers it as not prime;
{                                         // * @ mltSS, ...
 elem y,r; int m,k; ats aM, aA; headp h,g; elemp q,w; char sbig[80];
 if(9) ipp("+spterm2: A= ", A, " M= ", M);
 char* SM = vts(Ats(M)); // M must be ident or string;
 if(!Ident(M,&aM) && M.m != strng) error("rnam: spterm2 A@M: not ident M= ", M, " A= ", A); 
 if(!idubs(A, &aA)) error("rnam: spterm2 A@M: not idubs A, M= ", M, " A= ", A); // a1 = Ats(A);
 char* SA = vts(aA);
 if(strcmp(SA, "L8")==0)
 mm=mm;
 if(SM[0]=='"'){ strcpy(sbig, SM); k = strlen(SM); sbig[k-1] = 0; SM = sbig+1; }   // make a function !!!!
 m = findallm(SM);
 if(m != -1)     // SM is a module name;                             // 1. case group @ "0_bool";
 {
  if(9) *pfhis<<"\nrnam: spterm2: module  term, SM= " << SM << " SA= " << SA;
  if(9) cout<<"\nrnam: spterm2: module  term, SM= " << SM << " SA= " << SA;
  r = clad[m]->fdent1(aA, zel); // zel: main scope  // added 2 lines belowon 5.24.2022;
  if(r != zel) goto ret;
  r = clad[m]->fdent1(aA, zel1);  // zel1 means find unique aA in den; 
  if(r != zel) goto ret;
  error("rnam: spterm2: no unique name ", ts[aA], "in module ", SM); 
 } // if(m != -1)
 y = fnam(aM);    // SM is not a module name; y is a scope d or R[d,f] or name of a dcl;
 if(y==zel)       // aM is invisible at this point; looking in den for all scopes;
 {
  if(rrr) prach("spterm2: y==zel");
  ipp("achs::spterm2: fnam(M) = zel, maybe wrong M, A= ", SA, " M= ", SM);
  y = fdent1t(aM,zel1);   // look for unique aM for all scopes;
  if(y==zel) error("rnam: spterm2 A@M: not defined M= ", M, " A= ", A);
  prach("rnam:spterm2: fdent1t(aM,zel1), y= ", y);
 } // if(y==zel), below y!=zel;
 
 if((m=mel(y,&g,&w))==pfs && bdname(w[0]) && mel(w[1],&h,&q)==abt)  // 2. case A@R[d,Q];
 {   // bool bdname(elem z){ return z==zA || z==zE || z==zEx || z==zE1 || z==zF || z==zR || z==zU || z==zS; }
  r = fnabt(aA,w[1],h);         // Find name x in abterm (d,h), d = w[1];
  if(r != zel) goto ret;        // r is simple here;
  error("spterm2: no name aA in abterm w[1]= ", w[1], "\naA= ", vts(aA)); 
 } // if(mel(M,...)
 
 r = fdent1t(aA,y);               // * @ group: r=zel, because not unique! so need in spterm1!
 if(r != zel)                    // 3. case <| @ group;
 { 
  ipp("spterm2: fdent1 found r, scope= ", y, " A= ", SA);
  prach("rnam:spterm2 fdent1(aM,zel1), r= ", r);
  if(comp(mel(r, &g))) g->at = 1;     // at : indication  that r was derived from A@M; 
  goto ret;
 }  
 r = spterm1(aA,aM);                                        // 4,5. cases * @ group, // * @ mltSS 
 if(r==zel) error("spterm2 can't find A, scope= ", y, " A= ", A);
 if(9) ipp("--spterm2: r= ", r, " scope= ", y, " A= ", vts(A));
 ret: if(9) ipp("-spterm2: A= ", A, " M= ", M, " r= ", r);
      return r;
} // end elem achs::spterm2

   elem spterm1(ats aA, ats aM) // special term or A(M): * @ mltSS,*(mltSS),*(group),II(indset),...
{                                    // aM = mltSS; M is not a module name;
 int m; elem y,r=zel; headp g; elemp w; char* sA = vts(aA); char* sM = vts(aM); 
 // error("+spterm1: sA= ", sA, " sM= ", sM);
 if(rrr) ipp("+spterm1: sA= ", sA, " sM= ", sM);
 // if(p==0 && hl1==1 && Ident(h->son[1],&a2))    // CHECK for f(d) and f(M): f(d),f(M) => proper f; -----------
 y = pntu->fnam(aM);                               // aM = d or M; (M := dcl[f,...], M and d must be unique;
 if(y==zel)             // no name or multiple names;
 {
  y = fdent1t(aM, zel1);
  if(y==zel && aA != aby) error("spterm1: wrong aM = ", vts(aM), " aA= ", vts(aA));   // a2 = mltSS = aM;
 } // if(y==zel)
 m = mel(y,&g,&w);
 if(m==abt)                                   // 1. case f(d);
 {
  r = fnabt(aA,y,g);                       // Find name aA in abterm (y,g)= { ...a1...; ...}
  // r = fdent1(aA,y);                           // find name aA in scope y;
  if(r != zel) goto ret;                      // replaced f(d) on f; // M: { ... f ... } 
  if(rrr){ ipp("spterm1: no name aA in abterm y= ", y, " aA= ", vts(aA)); } 
  goto ret;
 } // if(m==abt)
 if(m==pfs && Dcl(w[0]) && aA==Ats(w[1]) )       // 2. case f(M); M := dcl[f; *(mltSS) => mltSS.1
 {
  r = nami(y,1);
  goto ret;
 } // if(m==pfs && Dcl(w[0]) && aA==Ats(w[1]) )
 // error("spterm1: no name aA in abterm y= ", y, " aA= ", vts(aA)); 
 r = zel;
 ret: if(r != zel) ipp("-spterm1:  r= ", r, " sA= ",sA," sM= ",sM);   //  aA= ", vts(aA), " aM= ", vts(aM),
      return r;
} // end elem achs::spterm1
      
   void achs::bdef()
{
 ats a,a1;  att t; elem y,top1e, scope=zel; int i,n,p,iii=0, save =  counterrmsg; headp g;  elemp w; 
 ipp("+bdef curm= ", curm, " iach= ", iach, " itt= ", ptt->itt); // elem x,t;
  // counterrmsg;
 for(i=0; i <= maxits; i++) countts[i] = 0;

 while(iach >= 0)                // the main loop;
 {
  elem z = curvert(); ++iii;
  // if(z.ad == 921)
  // mm=mm;
  headp h = ach[iach].h;
  elemp q = &(h->son[0]);
  elem z0 = ach[iach].e;
  p = ach[iach].p;
  nstr = h->ln;
  // if(z==zEx && simple(q[1])) error("bdef wrong d(simple, not abt) in Ex[d,P]= ", z0);
  if(bb)
  { 
   ippelm("bdef curvert= ", z, " p= ", p);
   cout <<"\n\n\n--------"; cout << "\n";
   // if(p==2 && (fnt2(q[0],zEx) || fnt2(ach[iach-1].q[0], zEx))) bb=0; // if(99
   // if(z==zEx){ ipp("bdef:+while:z==zEx, z0= ", z0, " z= ", z, " iii= ", iii); prach("bdef:+while"); }
  } // if(bb)
  int hl = h->l; int i;
  if(h->tel == pfs && p == -1)
  {
   if(Ident(q[0], &a))
   {
    if(a == adclb)                                         // 1 dcl[in, term, term, bool];
    { 
     if(hl < 2) error("bdef: hl<2, z= ", z);
     if(!idubs(q[1], &a)) error("bdef: wrong dcl q[1]= ", q[1]);
     // if(hl == 3 && mel(q[2])==abt) goto M1;
     // {
    //  if(hl != 3) error("bdef: wrong(hl!=3) dcl with abt, z= ", z, " hl= ", hl);
    //  goto M1;
    // } // if(mel(q[2])==abt)    
     // if(hl < 4) goto M1;         // dcl[id,X:set, fn(X,X)], dcl[^,abterm, any] - hl = 4;
	    // if(!fnt2(zcol,q[hl-2])) goto M1;
     // normAEF(z,q,hl,2); h->l = 4; // 2 : index of first type; (e.g. X:set)
	    scope = Scope(iach);     // scope = zel;
     if(hl==2) goto Wrden1;
     if(scope!=zel && mel(scope)!=abt) ipp("bdef: dcl are allowed only in main or abt scope, z= ",z, " scope= ",scope);
     { 
      if(!isrt(q[2], yfn)) ach[iach].p = hl;
      goto Wrden1; 
     } //  if(scope==zel || mel(scope)==abt)
     // error("bdef: dcl are allowed only in main or abt scope, z= ", z, " scope= ", scope);
    } // if(a = adclb)
	  
    if(a == avar)                                     // 2 var x,y,z,t; 
    {
	    if(hl < 3) error("bdef:var: wrong var hl < 3, z= ", z);
	    if(hl > maxabtv) error("bdef:var: wrong var hl > maxabtv, z= ", z);
	    // if(!Ident(q[hl-1])) error("bdef:var: wrong type  ", q[hl-1]);
	    // if(iach != 1) error("bdef: var allowed only in main scope, z=", z, " iach= ", iach); ???
	    for(i=1; i < hl-1; i++)
     {
      if(!Ident(q[i], &a)) error("bdef:var: not ident q[i]= ", q[i]);
	     for(int j=1; j<i; j++)
		    if(a == ats(q[j].ad)) error("bdef:var: repeating q[i]= ", q[i]);
      y = z0; y.i = i; scope = Scope(iach);
      ptt->wrden(a, y, scope);
     } // for(i) var
     ach[iach].p = hl; goto Nextvert;
    } // if(a == avar)
	 
    if(qterm(h))                  // 3 All(x,P), Exist(x.P), Exist1(x,P), Existx(x,P)
    {                          //  top: ach[iach]
     // if(hl != 3) error("bdef:Qname: wrong qname= ", q[0]);
	    if(!Ident(q[1],&a))
     {
      prach("bdef: Qname: bounded var is not ident ");
      error("bdef: Qname: bounded var is not ident ", q[1]);
     } // if(!Ident(q[1],&a))
     if(gvar(a))
     { 
      if(bb) ipp("bdef: skipped global variable q[1]= ", q[1]);
      ach[iach].p = 1; goto Nextvert; 
     }  // skipped global variable
	    scope = Scope(iach); 
     // if(z0 != scope)  ipp("bdef:z0= ", z0, " scope= ", scope, " z= ", z);  // ???
     if(int(q[0].ad) == aExistx || int(q[0].ad) == aExist1x)  // zexistx
     {
      if(bb){ ipp("bdef:Existx: scope= ", scope); prach(); }
      // y = elm(ident,0,aProof);
      // i = seek(y);    seek was changed !!!
      // if(i == -1) i = 0;
      assert(iach > 0);
      if(abbr(ach[iach-1].e)) p=1; else p=0;
      // if(iach - i - p != 1) error("bdef: Existx is not in main(proof) scope i= ", i, " p= ", p);
      y = z0; y.i = 1; ;  goto Wrden;   // elm(bvr,1, a)
     } // Existx
     scope = z0;  //  n = qlev();  ??? move up ???
     if(bb) ipp("bdef: qterm: z0= ", z0, " qlev= ", n) ;
     y = z0; y.i = 1; ;  goto Wrden;
    } // if(qterm(h))
                 // 4. non normal d-terms( A[x,y:t,a,b:t1, P]
    if(bdname(q[0]) || q[0]==yfn && mel(q[1])==abt)  // q[0]==zA||q[0]==zE||q[0]==zE1||q[0]==zF||q[0]==zR || q[0]==zU || q[0]==zS;  
    {                 // A[x,y:t, P]: hl=4, q[hl-1]=P;
     if(hl < 3) error("bdef: wrong similar to A[...,P], z= ", z);
     // if(q[0]==zEx){ bb=1;  if(99) prach("+zEx:z0==zEx, z0= ", z0); }
     if( (mel(q[1])==abt || Ident(q[1])) && h->l==3) goto Nextvert ;  // goto M;
     if(!fnt2(q[hl-2], zcol)) ipp("bdef: non normal dterm: no ':' before end, z= ", z, "\nq[0]= ", q[0], "\nq[1]= ", q[1]); 
     // error("bdef: zcol: z= ", z);   // above: was error, not ipp; this line: commented on 2022.03.26;
    // normAEF(z,q,hl,1);  h->l = 3;   // normalization: q -> q; 1 : index of first name (x above);
     goto Nextvert;    // not skip d !!!
    } // if(q[0]==zA || ...

   } // if(Ident(q[0], &a)
  
   if(q[0].m == ubs && ats(q[0].ad) == asop)    // 5.1 x := y;  // q[1] = x, q[2] = y; // ??? if(abbr(
   {                                                    
    if(hl != 3) error("bdef:wrong asop(:=), z= ", z); 
    h->tp = zel1;                                        // to avoid zel: see futt; // 2022.11.10 
    if(idubs(q[1], &a)) 
    {
    if(ts[a][0] == '_') scope = zel; else  scope = Scope(iach,true);  // was Scope(z):here scope cannot be z; ??? Ex 12.13.20
	   ach[iach].p = 1; // skipping left part // check later for recursion !!!
    y = q[2];
    if(!smel(y, &g))
    {
     g->name = q[1].ad;  t = h->t;
     if(t){ h->t = 0; g->t = t; }           // moved t from "x := y" to y; // was also g->t1 = 0;
    } // if(!smel(y, &g))
    if(curm == 0 && a == abool) zbool = y;  // because mzcn was not working yet; zbool used in bdef; 
    goto Wrden;
    } //  if(idubs(q[1], &a))
	   error("bdef: parameters in := are not allowed yet, z= ", z, "\nq[1]= ", q[1], "\nq[2]= ", q[2]);
    if(mel(q[1], &g, &w) != pfs) error("bdef: :=, wrong name ", vts(a));
	   assert(g->l >= 2);                                  // 5.2 x(p1, ..., pk) := y;
	   // if(!idubs(w[0], &a)) error("bdef: := wrong name in composite left part ", q[1]);
	   for(i=1; i < int(g->l); i++)  // parameters
    {             
	    if(!Ident(w[i], &a1)) error("bdef: :=, parameter is not ident w[i]= ", w[i], " i= ", i);	
		   y = z; y.i = i+1; ptt->wrden(a1,y,z); // scope = z !
    } // for(i=1)
	   goto Wrden; 
   }  // if(q[0].m == ubs && ats(q[0].ad) == asop)
  } // if(h->tel == pfs)

  if(h->tel == abt && p == -1)                            // 6 abt terms also zEx
  {
   if(hl < 3) error("bdef:abt: wrong abtermp= ", z);  int m;
   n = kmain(h); // q[0].i, change parse !!!!
   if(n >= maxabtv) error("bdef: too many names in abt,n= ", n);
   top1e = topach1().e;                                   // ach[iach-1].e = Ex[d,P]
   if(fnt2(top1e, zEx))                                   // ach[iach].e = d;   // in Ex[d,P]
   {                                                      // ach[iach-2].e: the enclosing term for Ex[d.P];
    // if(99) prach("bdef:abt:top1e=Ex[d,P]");                                  // was bb
    if(iach <= 2){ prach("zEx");  error("bdef:zEx: iach <= 2, iach= ", iach); }
    scope = Scope(iach-2);         // search in ach[iach-2], ach[iach-3], ... for a scope term  // comm. 2023.01.09
    if((m=mel(scope,&g,&w)) != abt && (m != pfs || w[0] != zdconj && w[0] != zProof && w[0] != zEqProof)) // 2023.01.09
     { prach("zEx:scope"); error("bdef:zEx: not Dterm or proof scope, scope= ",scope); }         // comm. 2023.01.09
    
    // scope = Exscope(iach-2);
    // scope = ach[iach-2].e;                                                                // new 2023.01.09
    // if(scope.m == ubs && ats(scope.ad) == asop) scope = ach[iach-3].e;
    // m = mel(scope,&g,&w);                                                                // new 2023.01.09
    // if((m != abt || w[0] != zdcol) && (m != pfs || w[0] != zProof && w[0] != zEqProof))   // new 2023.01.09
    //  { prach("zEx:scope"); error("bdef:zEx: not dcol or proof scope, scope= ",scope); }  // new 2023.01.09
    if(bb) ipp("bdef:Ex scope= ", scope);     // was else 2023.01.09;
   } // if(fnt2(topach1().e, zEx))
   else if(fnt2(top1e,zdconj) && h->name == noname) scope = top1e; // 7.13.20
        else{ scope = Scope(iach);  assert(mel(scope) == abt); }
   // if(99) ipp("bdef:after Ex, before for: scope= ", scope);
   for(i=1; i <= n; i++)
   {
    if(!idubs(q[i], &a))
    {
     prach("bdef:abt: not idubs q[i]= ");
     error("bdef:abt: not idubs q[i]= ", q[i]);
    } // if(!idubs(q[i], &a))
	   for(int j=1; j<i; j++)
	   if(a == ats(q[j].ad)) error("bdef:abt: repeating q[i]= ", q[i]);
    y = z0; y.i = i; // scope = Scope();
    if(!gvar(a)) ptt->wrden(a, y, scope);
   } // for(i) abt
   ach[iach].p = n;  // skipping names
   goto Nextvert;
  } // if(h->tel == abt)
  goto Nextvert;
  Wrden1: y = z; y.i = 1; 
  Wrden:  ptt->wrden(a, y, scope);
  Nextvert:  next();
 } // while(iach >= 0)
 n = counterrmsg - save;
 time_bdef = myclock(" -bdef finished"); *pfhis << "  iii= " << iii; cout << "  iii= " << iii;
 if(n) error("bdef: there were error messages, the number is ", n);
} // end bdef

   elem achs::lbr(int i)                       // left brother of ach[i].e;
{
 elem r = zel; int p, k = i - 1; each a;
 if(rrr) ipp("+lbr: i = ", i);
 if(k < 0) goto ret;
 a = ach[k]; p = a.p;
 if(p>0) r = (a.h->son)[p-1];
 ret: if(rrr) ipp("-lbr: r= ", r);
 return r;
} // end elem achs::lbr()

   elem achs::rbr(int i)                       // right brother of ach[i].e;
{
 elem r = zel; int p, k = i - 1; each a;
 if(rrr) ipp("+rbr: i = ", i);
 if(k < 0) goto ret;
 a = ach[k]; p = a.p;
 if(p < int(a.h->l) - 1) r = (a.h->son)[p+1];
 ret: if(rrr) ipp("-rbr: r= ", r);
 return r;
} // end elem achs::rbr()



// end achs.cpp
