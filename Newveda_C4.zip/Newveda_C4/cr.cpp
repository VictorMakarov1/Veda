#include "lib.h" // 11/14/97   6/15/00 7/25/00 8/9/00 9/25/00 11/22/00
#include "achs.h"
#include "sbs.h" // 12/08/00 02/02/01 05/20/01
// #include "elem.h"
#include "tt.h"
#include "adl.h"  
#include <limits.h>    
#include "rep.h"
#include "typ.h"   
// #include "smp.h"
#include "cr.h"    
#include "elem.h"
// #include "ismd.h"
// #include "simp.h"
#include "eqcl.h"
#include "lot.h"
#include "term.h"
#include "prf.h"
#include "assert.h"
#include "err.h"

int ipol;
extern int lvarsp, isynv, oo;
int alle15 = 32767;                        //  2^15 = 32768 
int alle15m1 = 32766;                      // sero in the most right bit, all else are "1" 
int ivarsp;
extern elemp varsp;
extern intp pol;
extern int lpol, ilot;
extern int aa, hhh, mm; // mm - only for cred!
elem simp(elem z) { return z; }            // ?????? change !!!!!!

    elem cred(elem z)                      // constant reduction;
{
 //if(z.m == 0 && Att(z) == 9927) error("cred z= ", z);
 elem r = z, r1, r2, x,y,v,Q,M,S; int k=0, m1; 
 headp h,g; elemp q = 0, w;  //static int depth;
 //++depth;
 if(mm || jj) ipp("+cred z= ", z);
 if(z.ad==stad2) mm=mm;
 if(ist < -1 || ist >= lst) error("cred overflow of ist, z= ", z, " ist= ", ist);
 if(prognum < numtyp)
 {
  ipp("cred: wrong prognum, z= ", z, " prognum= ", prognum);
  goto ret;
 }
 // if(q == 0)  // q == w -> w == 0!!! 
 if(mel(z, &h, &q) != pfs ) goto ret;                       // 1. z is simple or abt;
 k = h->l;
 if(jj) prlot("cred before eqvlot");
 r = eqvlot(z);                                             // 2. z=r in lot; simple or abt r; 
 if(jj) ipp("cred: after eqvlot, z= ", z, " r= ", r);
 if(jj && r != z) ipp("cred: Success: after eqvlot, z= ", z, " r= ", r);
 if(mel(r) != pfs){ if(jj) ipp("cred(eqvlot) discovered simple z = ", z, " r= ", r); goto ret; }
 
 if(vterm(h,&Q,&M))
 { 
  // if(!h->v) error("cred: vterm(h,&Q,&M)) but !h->v ???
  r = h->v? valrt(z,h,q): Vdt(z,h,q,Q,M); goto ret; }        // 3. dot or adt term Q.M (or Q(M)); 

 if(q[0] == zsb)                                            // 4. z = Sb(K, a, b);
 {
  assert(h->l==4);
  if(mm) ipp("cred:Sb z= ", z, " r= ", r);
  r = redsb1(q[1],q[2],q[3]); 
  if(r != z) r = cred(r);
  goto ret; 
 } // if(q[0] == zsb)

 if(q[0] == zexist)                                        // 5. Exist(x,P(x));
 { 
  x = zel;        // esolv(q[1], q[2]);
  if(x != zel)
  {
   ipp("cred: esolved! d= ", q[1], " p= ", q[2], " x= ", x);
   r = ztrue;
  } // if(x != zel)
  else ipp("cred: not esolved! d= ", q[1], " p= ", q[2]);
  goto ret;
 } // if(q[0] == zexist) 
 if(q[0]==zA){ assert(h->l==3); r1 = cred(q[2]); if(r1==ztrue) r = r1; goto ret; }
 m1 = mel(q[0],&g,&w);
 if((m1 != pfs)) goto cred_simple;        // below q[0] is composite;
 if(g->l != 3) goto ret;

 if((w[0]==zA || w[0]==zF))                               // 6. F[d,f](a) = rep(f,d,a) = A[d,f](a);
 {
  if(jj) ipp("cred:F[d,w[2]], z= ", z, " d= ", w[1], " w[2]= ", w[2]);
  r = redAF(z,h,q,w);
  goto ret;
 } // if(mel(q[0],&g,&w) ...

 if(w[0]==zimp){ r = redimp(z,w[1],w[2],q[1]); goto ret; }               // 7. (P->Q)(R);

 if(w[0]==zall || w[0]==zexist || w[0]==zexist1)          // 8. All(x,P(x))(a)
 {
  v = nami(q[1],1);                                       // v = x;
  r = rep2(w[2],v,q[1]); goto ret;
 } // if(red)

 cred_simple: if(m1==abt) goto ret;
 
 if(q[0] == zconj) // move it to general scheme!!!!!   // S1. P & Q
 {
  r1 = cred(q[1]);
  if(r1 == ztrue)
  {
   if(jj) ipp("cred(&): SUCCESS! r1= true!, q[1]= ", q[1], " q[2]= ", q[2]);
   r = cred(q[2]); goto ret;
  } // if(r1 == ztrue)
  r2 = cred(q[2]);
  if(r2 == ztrue)
  {
   if(jj) ipp("cred(&): SUCCESS! r2= true!, q[1]= ", q[1], " q[2]= ", q[2]);    
   r = cred(q[1]); goto ret;
  } // if(r2 == ztrue)
  if(r1 == zfalse || r2 == zfalse)
  {
   if(jj) ipp("cred(&): SUCCESS! r1 or r2 = false!, q[1]= ", q[1], " q[2]= ", q[2]);   
   r = zfalse; goto ret;
  } // if(r1 == zfalse || r2 == zfalse)
 } // if zcong

 if(q[0] == zeq || q[0]==zequ) // move it to general scheme!!!!!   // S2. x=y or P==Q 
 {
  if(mm) ipp("cred:zeq or zequ: z = ", z, " q[1]= ", q[1], " q[2]= ", q[2]);
  if(vterm(q[1],&Q,&M) && Q==q[2])         // Fgr.N = Fgr; scopeden(Fgr) = nsubgr;
  {                                        // nsubgr := {N ; AxN0 := N in subgr; AxN1 := normal(N)}
   S = scopeden(Q);  
   if(M == nami(S,1)) { if(9) ipp("cred:Q.M = Q, z= ", z); r = ztrue; goto ret; }
  } // if(vterm(h,&M,&Q))
  x = cred(q[1]); y = cred(q[2]);
  if(req(x,y))
  {
   if(jj) ipp("cred(==): SUCCESS! discovered p == p, p= ", x);
   r = ztrue; goto ret;
  } // if(q[1] == q[2])
  if(x == ztrue && q[0]==zequ)
  {
   if(jj) ipp("cred(==): SUCCESS! x= true!, y= ", y);
   r = y; goto ret;
  } // if(q[1] == ztrue)
  if(q[2] == ztrue && q[0]==zequ)
  {
   if(jj) ipp("cred(==): SUCCESS! y= true!, x= ", x);    
   r = x; goto ret;
  } // if(q[2] == ztrue)
  /*if(q[1] == zfalse || q[2] == zfalse)
  {
   ipp("cred(&): SUCCESS! q[1 or 2] = false!, q[2]= ", q[2]);   
   r = zfalse; goto ret; }*/

 } // if zequ

 if(q[0] == zimp)                                      // S3. P->Q
 {
  if(mm) ipp("cred: +imp, z= ", z); // goto ret; // changed error to ipp: 2022.11.15
  r1 = cred(q[1]);                    // if(iseq(...) moved to trash.txt
  if(r1==zfalse){ r = ztrue; if(99) ipp("cred:imp:r1==zfalse, z= ", z, " r= ", r);  goto ret; }
  r2= cred(q[2]);
  if(r1==r2){ r = ztrue; if(99) ipp("cred:imp:r1==r2, z= ", z, " r= ", r); goto ret; }
  if(r1==ztrue){ r = ztrue; if(99) ipp("cred:imp:r1==ztrue, z= ", z, " r= ", r);  goto ret; }
  if(r2==ztrue){ r = ztrue; if(99) ipp("cred:imp:r2==ztrue, z= ", z, " r= ", r);  goto ret; }
  goto ret;
 } // if(q[0] == zimp)

 if(q[0]==zincl)
 {
  if(mm) ipp("cred: +incl, z= ", z);
  r1 = cred(q[1]);                    // if(iseq(...) moved to trash.txt
  if (r1 == zemp) { r = ztrue; if (99) ipp("cred:incl:r1==zemp , z= ", z, " r= ", r);  goto ret; }
  r2 = cred(q[2]);
  if(r1==r2 && r1 != zel){ r = ztrue; if(99) ipp("cred:incl:r1==r2, z= ", z, " r= ", r); goto ret; }
  goto ret;
 } // if(q[0]==zincl)

 if(q[0] == zin)                   // S4. x in d;
 {
  headp g; elemp w;  elem Q,P1; int m = mel(q[2],&g,&w); sbst s; 
  if(jj) ipp("cred(in): z= ", z, " q[1]= ", q[1], " q[2]= ", q[2]);
  if(m==abt)
  {
   r = s.redinab(z,q[1],q[2]);         // z === q[1] in q[2];
   goto ret;
  } // if(m==abt)
  if(m==pfs && w[0]==zdconj)           // z: x in d && P; == (Q:= x in d) & P; // x=q[1], d=w]1], P=w[2];
  {
   if(!Dterm(w[1])) error("cred: zin: m==pfs && w[0]==zdconj: not Dterm(w[1]), z= ", z, " w[1]= ", w[1]);
   if(mel(w[2]) != pfs) error("cred: zin: m==pfs && w[0]==zdconj: mel(w[2]) != pfs, z= ", z, " w[2]= ", w[2]);
   Q = trm2(zin,q[1],w[1], zbool);  // q[1]=x, w[1]=d;
   P1 = repd(w[2],w[1],q[1]);       // elem repd(elem z, elem d, elem md);  // replace in z all d.i on md[i];
   r = trm2(zconj,Q, P1, zbool);    // w[2]=P;
   if(99) ipp("cred:zin:m==pfs && w[0]==zdconj: z= ", z, "\nr= ", r);
  } // if(m==pfs && w[0]==zdconj)
  goto ret;
 } // if(q[0] == zin && mel(q[2])==abt )  
 
 if(q[0]==zplint)                                     // S5. x + y
 {
  x = cred(q[1]); y = cred(q[2]);
  if(x==zel0){ r = y; goto ret; }
  if(y==zel0){ r = x; goto ret; }
  if(x.m==ints && y.m==ints){ r = aint(q[1],q[2]); goto ret; }
 } //   
  
  if(q[0]==zmltint)                                     //  x * y
 {
  if(q[1]==zel0 || q[2]==zel0){ r = zel0; goto ret; }
  if(q[1]==zel1){ r = q[2]; goto ret; }
  if(q[2]==zel1){ r = q[1]; goto ret; }
  if(q[1].m==ints && q[2].m==ints){ r = mint(q[1],q[2]); goto ret; }
 } // if(q[0]==zmltint)

  if(q[0]==zmnint)                                      //  x - y
 {
  if(q[1]==zel0 || q[2]==zel0){ r = zel0; goto ret; }   // 0 - 0 = 0;
  // if(q[1]==zel1){ r = q[2]; goto ret; }              // 0 - y = -y; ???
  if(q[2]==zel1){ r = q[1]; goto ret; }                 // x - 0 = x;
  if(q[1].m==ints && q[2].m==ints){ r = sint(q[1],q[2]); goto ret; }
 } // if(q[0]==zmnint)

  if(q[0]==zmnint1)                                     //  -x
 {
  // if(q[1]==zel0){ r = zel0; goto ret; }   // 0 - 0 = 0;
  if(q[1].m==ints){ r = sint(zel0, q[1]); goto ret; }
 } // if(q[0]==zmnint1) 
 /*if(jj) ipp("cred switch n= ", n);
 switch(n)
  {
   case 1:              // typ
   r = typ(q[1]); 
   ipp("cr: switch: -case 1 (typ) q[1]= ", q[1], " r= ", r);
   break;

   case 2:              // Rep(z, d, M)
   //q1 = adrm(q[2], q[3]); // q1 points to M[0]!
   //if(q1 == 0) error("cred: rework this case!!!");
   //ipp("cr: switch: +case 2 (Rep) z= ", q[1], " d= ", q[2], " M[0]= ", q1[0]);
   //r = rep(q[1], q[2], q1-1 );  // M-1 !!!
   error("cred: commented case 2, RRep");
   // r = RRep(z, q);
   ipp("cr: switch: -case 2 (Rep) z= ", z, " r= ", r);
   break;

   case 3:              // inst1(q, p)
   r = inst1(q[1], q[2]);
   ipp("cr: switch: -case 3(inst1) z= ", z, " r= ", r);
   break;

   case 4:
   error("cred: commented case 4, reps");
   // r = reps(q[1], q[2]);
   ipp("cr: switch: -case 4(reps) z= ", z, " r= ", r);
   break;

   case 5:
   ipp("cr: switch: +case 5(Host), not implemented yet, z= ", z);
   r = z;  // r = Pref(q[1], q[2], q[3]);
   ipp("cr: switch: -case 5(Host) z= ", z, " r= ", r);
   break;
   
   case 10:
   if(q[1] == zel0)
   {
    ipp("Success! cred discovered 0 + x, x= ", q[2]);
    r = q[2]; break;
   }  
   if(q[2] == zel0)
   {
    ipp("Success! cred discovered x + 0, x= ", q[1]);    
    r = q[1]; break;
   } 
   if(q[1].m==ints && q[2].m==ints) // +(int,int)
   {
    r = aint(q[1], q[2]);
    ipp("Success! cred discovered c1 + c2, c1= ", q[1], " c2= ", q[2], " r= ", r);  
   }
   break;  // end case 10 +
 
   case 11:        // -
   if(q[2] == zel0)
   {
    ipp("Success! cred discovered x - 0, x= ", q[1]);
     r = q[1]; break; 
   } // -
   if(q[1].m == ints && q[2].m == ints) // -(int,int)
   {
    r = sint(q[1], q[2]);
    ipp("Success! cred discovered c1 - c2, c1= ", q[1], " c2= ", q[2], " r= ", r );  
   }
   break;  // end case 11 -
   
   case 12:   // unary minus
   if(q[1].m == ints) 
   {                  // -1
    r = uint(q[1]); 
    ipp("Success! cred discoverd -c1, r= ", r);
   }
    break;  // end case 12

   case 13:
   if(q[1] == zel0){ r = zel0; break; }  // *
   if(q[2] == zel0){ r = zel0; break; } 
   if(q[1] == zel1){ r = q[2]; break; }
   if(q[2] == zel1){ r = q[1]; break; }
   if(q[1].m == ints && q[2].m == ints) // +(int,int)
    r= mint(q[1], q[2]) ;  break;

   case 14:
   if(q[1] == zel0){ r = zel0; break; } // /
   if(q[1].m==ints && q[2].m==ints) // /(int,int)
    r = dint(q[1], q[2]); break;

   case 15:
   if(q[1] == zel0){ r = zel0; break; } // res
   if(q[1].m==ints && q[2].m==ints) // res(int,int)
    r = rint(q[1], q[2]); break;

   case 16:           //  <
   x = Less(q[1], q[2]);
   if(x != zel) r = x; 
   break; 

   case 17:           // <=
   x = LessOrEq(q[1], q[2]);
   if(x != zel) r = x;
   break;

   case 18:           // >
   x = Less(q[2], q[1]);
   if(x != zel) r = x; 
   break; 

   case 19:           // >=
   x = LessOrEq(q[2], q[1]);
   if(x != zel) r = x;
   break;

   case 20:                                // =
   if(jj) ipp("cred case 20(eq '=') ",q[1], q[2]);
   if(req(q[1], q[2]))
   {
    r = ztrue; 
    ipp("Success! cred discovered x = x, x= ", q[1]);
    break; 
   }
   if(jj) ipp("cred case 20 typ(q[1]) will work q[1]= ", q[1]);
   g = typ(q[1]);
   if(jj) ipp("cred case 20 typ(q[1])= ", g);
    x = typ(q[2]);
   if(jj) ipp("cred case 20 typ(q[2])= ", x);
   if(disjoint(g, x))
   { 
    r = zfalse;
    ipp("Success! cred discovered disjoint(g,x), g= ", g, " x= ", x);   
    break; 
   }
   // add the case when subtypes are not intersect!!
   if(!icon(q[1]) || !icon(q[2])) break;
   r = (q[1] == q[2]? ztrue: zfalse);
   ipp("Success! cred discovered c1 = c2, c1= ", q[1], " c2 = ", q[2], " r= ", r);
   break;

   case 30:
   ipp("cred: sum, z =", z);
   if(k != 3) error("cred: sum k != 3 k=", k);
   x = q[2]; v = q[1]; // sum[q[1], x]  q[1] = dv(i,t) t = a..b
   if(mel(v, &h, &q1) != abt) // || fdv(q1) != pdv || km(q1) != 1)
             error("cred: wrong sum1 z = ", z);
   t = vard(q1[2], 1); 
   if(!isrt(t, zseg, &q2)) break;
   if(q2[1] == q2[2])
   {
    //if(w) cpp("cred: errorSUM: rep, z=",z);  9/4/96
    r = rep2(x, v, q2[1]); break;
   }
   if(q2[1].m != ints || q2[2].m != ints) break;
   //if(mel(x, &h, &q) == pfs && isrt(q[0], zF)) break;
   s = 0;
   for(i1=intval(q2[1]); i1 <= intval(q2[2]); i1++)
   {
    t = elmint(i1);
    //if(w) cpp("cred error:sum before rep t,v=",t,v); 9/4/96
    g = rep2(x,v,t);
         if(aa) ipp("cred sum after rep x,g=",x,g);
    //t = smp(g, mon1, 50);
    t = simp(g);           // 4/30/96
    if(t.m != ints)
    { 
     ipp("cred sum: not ints g,t=", g, t); // was cpp
     return z;
    }
    s += intval(t);
    cout<<"\ncred sum i= "<<i1<<" s= "<<s;
   } // end i1
   r = elmint(s); break;
 
   case 120:                             // rep
   //if(w) cpp("cred: error: rep case 120 z=",z);
   r = rep2(q[1], q[2], q[3]); break; // no changes of ist

   default: if(pp) ipp("cred: error z= ", z, " n= ", n);
  }
  */
 ret:  if(r==z) ipp("-cred: unchanged: z= ", z);  else wrval(z,h,q,r);
 if(jj || mm) ipp("-cred z= ", z, "\nr= ", r);
 if(ist < -1 || ist >= lst)
  error("-cred: overflow of ist, z= ", z, " ist= ", ist);
 return r;
}  // end cred

   elem redimp(elem z,elem P,elem Q,elem R)              // reduction of z === (P->Q)(R); or (P==Q)(R)
{
 sbst s; elem r=z, dpat= zel0; headp h; elemp q; int savemm = mm;
 // if(z.ad==stad2)  mm=1;
 if(mm) ipp("\n+redimp z= ", z, "\nP= ",P,"\nQ= ",Q, "\nR= ", R);
 if(mel(z,&h,&q) != pfs) error("redimp: wrong z = (P->Q)(R), z= ", z); // q[0]: P->Q; q[1]: R;
 dpat = scopeden(q[0]);
 if(h->v){ ipp("redimp: already h->v, z= ", z); r = valrt(z,h,q); goto ret; }
 typ(P); typ(Q); typ(R);
 if(! istr00(R, "redimp")) error("redimp: z= (P->Q)(R) or (P==Q)(R), R is not true, z= ", z, " R= ", R); 
  if(s.instance(R,P,zel0,dpat))
  {
   if(mm) ipp("redimp: R is an instance of P, \nz= ",z, "\nP= ", P, "\nQ= ", Q, "\nR= ", R);
   r = s.rep(Q,"redimp_1"); 
   if((Truth(q[0]) || inlot(q[0])) && (Truth(R) | inlot(R))) mktr(r); // mktr(z); } 
   else ipp("redimp:P q[0] or R are not true, \nz= ", z, "\nq[0]= ", q[0], "\nP= ", P, "\nR= ", R);
  } //   if(s.instance(R,P))
  else{ s.size = 0;
  if(root(q[0])==zequ && s.instance(R,Q))
  {
   if(mm) ipp("redimp: R is an instance of Q, \nz= ",z, "\nP= ", P, "\nQ= ", Q, "\nR= ", R);
   r = s.rep(P,"redimp_2"); 
   // if(Truth(q[0]) && Truth(R)) mktr(r); 
   if((Truth(q[0]) || inlot(q[0])) && (Truth(R) | inlot(R))) mktr(r); // mktr(z); }
   else ipp("redimp:Q q[0] or R are not true, \nz= ", z, "\nq[0]= ", q[0], "\nP= ", P, "\nR= ", R);
  } // if(q[0]==zequ && s.instance(R,Q))
 } // else{
 ret: if(mm) ipp("-redimp z= ", z, "\nr= ", r);  mm=savemm;
 return r;
} // elem redimp(elem z)

 elem redAll(elem z, headp h, elemp q, elemp w)   //  All(x1,...,All(xk,P) ...)(z1,z2, ... , k);
{
 elem r, x; int i, hl1 = h->l - 1; headp g; sbst s;
 if(mm) ipp("+redAll z= ", z);                          
 x = q[0];
 for(i=1; i <= hl1; i++)
 { 
  if(typ(q[i]) == zel) error("redAlls: wrong q[i], z= ", z, "\nx= ", x, " i= ", i);
  x.i = 1; s.adds(x, q[i]);
  x = w[2]; 
  if(fnt2h(x, zall, &g, &w)) continue;  // last x is the formula P;
  if(i < hl1) error("redAlls: too many arguments in z, \nz= ", z, "\nx= ", x, " i= ", i, " hl1= ", hl1);
 } // for(i) 
 r = s.rep(x,"redAll");                          // last x is the formula P;
 if(mm) ipp("-redAll z= ", z, " r= ", r);
 return r;
} // elem redAll(elem z,...)                           // ! Laa2 := (inv(a)*a) * (inv(a)*a) = (inv(a)*a);
                                                       // d= a:elg, Q1= a*a = a, Q2= a=e, Q3=Laa2;
 elem redA(elem z, headp h,elemp q, headp g, elemp w)  // z is A[d, Q1->Q2](Q3); d=w[1], w[2]=Q1->Q2; typ(Q3) = zbool;
{     // ! Tlinv := inv(ax)*ax = e;    is Laaa(Laa2);  // ! Laaa := A[a:elg, a*a = a -> a = e]; 
 int hl1; elem r=zel,d,dpat=zel0, Q1,Q2,Q3;  headp g2,g1; sbst s;
 d = w[1]; Q3 = q[1]; hl1 = int(h->l)-1; 
 if(mm) ipp("+redA: z= ", z, "\nd= ", d, "\nQ3= ", Q3,  "\nhl1= ", hl1);
 if(h->v)
 { 
  ipp("redA: h->v: the value is ready, val= ", r = valrt(z,h,q));  // valrt(h,q) = q[h->l];
  // if(r==zel) error("redA: h->v: wrong r=zel, z= ", z); // moved to valrt;
  goto ret;
 } // if(h->v)
 if(freevar(d)) goto ret;
 if(!Abterm(d,&g1) || g1==0) error("redA: zA: wrong d, z= ", z, "\nd= ", d);
 if(!impequ(w[2], &Q1, &Q2)) error("redA: not imp or equiv in w[2], z= ", z, "\nw[2]= ", w[2]);
 if(g->at) dpat = scopeden(q[0]); 
 if(!s.instance(Q3,Q1,d,dpat)) 
    error("redA: Q3 is not s.instance of Q1, z= ", z, "\nQ1= ", Q1, "\nQ3= ", Q3, "\nd= ", d, "\ndpat= ", dpat);
 r = s.rep(Q2, "redA");
 if(Truth(q[0]))
 {
  h->t = truth;
  if(mel(r,&g2)==pfs) g2->t = truth;   // trtr ??? mktr ??? /// h->t && ... 12.8.21 was replaced with Truth(q[0])
 } // if(Truth(q[0]))
 ret: if(mm) ipp("-redA: z= ", z, "\nr= ", r);
      return r;
} // elem redA(elem z, ...)
                                              // w[0]=zA,zF;   w[1] = d, w[2] = Q2; q[1] = z1;
 elem redAF(elem z, headp h,elemp q, elemp w) // z is A[d,Q2](z1, ... zk), q[0] = A[d,P], q[1]=z1;                                                 // aQ3 points to  
{                                             // hl1 = k;
 int k,k1,hl1; elem r=zel,d,Q2,z1,z2;  headp g,g1; elemp q1,v; sbst* s;
 d = w[1]; Q2 = w[2]; hl1 = int(h->l)-1; z1= q[1]; z2 = hl1>=2?q[2]: zel999;
 if(mm) ipp("\n+redAF z= ", z, "\nd= ", d, "\nQ2= ", Q2, "\nz1 ", z1, "\nz2= ",z2, " hl1= ", hl1);   
 if(h->v && mm){ ipp("redAF: h->v: the value is ready, val= ", r = valrt(z,h,q)); goto ret; } // valrt(h,q) = q[h->l];
 if(freevar(d)) goto ret;
 if(!Abterm(d,&g1) || g1==0) error("redAF: zA: wrong d= ", d, "\nQ2= ", Q2, "\nz1== ", z1);
 k = kmain(g1);   // d-number;  // if k=1 then [a] in F[d, Q2]([a]) means denotes just a sequence: [a] in d must be true!
 if(seqv(z1,&k1,&v) && k != 1)  // v points to [, v[1]=z1;  // k1: the length of the sequence z1 
 {                              //  k != 1: z1 is a model of d // k==1: z1 is just a sequence;
  if(k1 != k) error("redAF: k1 != k, d= ", d, "\n= ", Q2, " k1= ", k1, " k= ", k);
  q1 = v;
 } // if(seqv(q[1],&k1,&v))
 else{ k = hl1; q1 = q; } 
  
 if(!ismd(d,q1,k,&s)) 
	error("redAF: not model, d= ", d, "\nq[1]= ", q[1], "\nk= ", k);
 // r = repq(Q2,d,q1,k);
 r = s->rep(Q2, "redAF");
 if(w[0]==zA)
 {
  if(Truth(q[0]))
  {
   h->t = truth;
   if(mel(r,&g)==pfs) g->t = truth;   // trtr ??? /// h->t && ... 12.8.21 was replaced with Truth(q[0])
  } // if(Truth(q[0]))
 } // if(w[0]==zA)
   // if(!req(Q,Q1)) error("hnis: zA: Model: wrong Q1, J=\n", J, "\nQ =\n", Q, "\nQ1= ", Q1);
   // if(istr(q[0])) mktr(Q);   // ???   // wrdep(Q, q[0])
 ret: if(mm) ipp("-redAF z= ", z, "\nQ2= ", Q2, "\nq[1]= ", q[1], "\nr= ", r);
 return r;  
} // end redAF

// if(isrt(Q1, zin, &v))   // not imp. yet; // from redAF
// {
//  error("redAF: Q1 is z in d, d= ", d, "Q2= ", Q2, " Q1= ", Q1);  // not imp. yet;
//  if(v[2] != d) error("redAF: wrong d in Q3 = (z in d), Q1= ", Q1, "\nd= ", d, "\nQ2= ", Q2); 
//  q1 = v;      // q[1] = v[1] = z;
// } // if(hl1 == 1)

 elem redmeth(elem z, headp h, elemp q, elemp w)      // Q(z1, ... zk), Q is a d-method, k = hl1;
{
 elem r,d, Q = q[0]; int k = h->l - 1;
 if(mm) ipp("+redmeth z= ", z, "\nQ= ", Q, " k(hl1)= ", k);
 d = scopeden(Q);
 if(d==zel || d==zel1 || ! Dterm(d)) error("redmeth: wrong s=scope(Q), z= ", z, "\nQ(q[0])= ", Q, "\nd(scopeden(Q))= ",d);
 if(!ismd(d,q,k)) error("typmeth: not model, z= ", z, " d= ", d, " k= ", k); 
 // t = typ(Q);
 r = Repq(Q,d,q,k); 
 if(Truth(Q)) h->t = truth;
 if(mm) ipp("-redmeth: z= ", z,"\nr= ", r);  h->adt = 1;
 return r;
} // end elem redmeth(elem z, ...)

 elem redRep(elem z)
{
 elem r=z; headp g; elemp w;
 if(mm) ipp("+redRep z= ", z, " ist= ", ist);          // in the next line, changed error to ipp; 2023.01.10;
 if(mel(z,&g,&w) != pfs || w[0] != zRep){ ipp("redRep: z is not Rep(d,P,md), z= ", z); goto ret; }
 if(freevar(w[1])) goto ret;
 r = repd(w[2],w[1],w[3]);   // y1 = cred(y);  // elem repd(elem z, elem d, elem md); // redRep(y)
 ret: if(mm) ipp("-redRep z= ", z, "\nr= ", r, " ist= ", ist);
 return r;
} // end elem redRep(elem z)

   bool isst(elem z, elem* red, elem* main)    // is special term: All(x,P)(y), .... (a=b)(y), m.z, ... ,
{
 bool r = false; headp h,g; elemp q,w; int m,hl1; elem v,P,Q,M,s; // zel999 = undefined
 if(mm) ipp("+isst z= ", z);    
 // if(red) *red = zel;
 m = mel(z,&h,&q);
 if(m != pfs) goto ret;
 if(h->tp == zel) typ(z);                      // error("isst: h->tp == zel, z= ", z);
 if(h->v){ v = valrt(z,h,q); if(99) ipp("isst:h->v, z= ", z, " v= ", v); if(red) *red = v; goto ret1; }  
 hl1 = int(h->l)-1;

 if(q[0]==zTaut)   // wrong: by -Taut(...)
 { 
  if(!Taut(q[1])) error("isst: not tautology in z= ", z);
  if(red) *red = q[1];
  goto ret1;
 } // if(q[0]==zTaut)

 if(q[0]==zif)                                 // if(P, A, B);
 {
  if(mm) ipp("isst:+if: z= ", z);
  elem P = simr(q[1]);
  if(99) ipp("isst:if:after simr z= ", z, " P= ", P);
  if(P==ztrue){ if(red) *red = q[2]; goto ret1; }
 } // if(q[0]==zif)  

 if(vterm(h,&Q,&M))                            // dot or adt term   
 { 
  // assert(hl1==2);
  if(main) *main = q[1];                       // q[1] = m;
  if(red)
  { 
   s = scopeden(Q);                            // Gr.H = Gr;   // 11.22.20
   if(scopeden(M)==s && htbv(M)==s) *red = Q;
   else *red = h->v? valrt(z,h,q): Vdt(z,h,q,Q,M);
   goto ret1;
  } // if(red)
 } // if(vterm(h,&Q,&M))
 
 if(q[0] == zsb)                               // reduction of z = Sb(K, a, b);
 {
  assert(hl1==3);
  if(main) *main = q[1];                       // q[1] = K;
  if(red) *red = redsb1(q[1],q[2],q[3]);  goto ret1; 
 } // if(h->l == 4 ...)
 if(mel(q[0],&g,&w) != pfs) goto ret;
 
 if(w[0]==zA || w[0]==zF)                 // A[d,Q2](z1, ..., zk) or A[d,Q2](z in d);
 {                                        // F[d,Q2](z1, ..., zk) or F[d,Q2](z in d)
  assert(g->l==3);
  if(main) *main = q[0];                  // q[0] = A[d, Q2]; q[1] = z in d or z1;
  if(red) *red = redAF(z,h,q,w);          // w[1] = d, w[2] = Q2;
  goto ret1;
 } // if(w[0]==zA)
 if(hl1!=1) goto ret;
 
 if(w[0]==zimp)                                // (P->Q)(R);
 {
  if(main) *main = q[0];
  if(red) *red = redimp(z,w[1],w[2],q[1]); goto ret1;
 } // if(w[0]==zimp)

 if(w[0]==zall && fnt2(w[2],zimp,&P,&Q) && typ(q[1])==zbool)       // All(x, P->Q)(q[1])
 { 
  if(main) *main = q[0];
  if(red) *red = redimp(z,P,Q,q[1]); goto ret1;
 } //  if(w[0]==zall && ...)

 r = (w[0]==zall || w[0]==zexist || w[0]==zexist1);
 if(!r) goto ret;
 if(main) *main = q[0];
 if(red)
 {
  v = q[0]; v.i = 1;  // v = elm(bvr, 1, Ats(w[1]));
  *red = rep2(w[2],v,q[1]); 
 } // if(red)
 ret1: r = true;
 ret: if(mm) ipp("-isst z= ", z, "\n*red= ", red==0?zel: r?*red:zel999, "\nr= ", r);
 return r;
} // end bool isst(elem z) 

  elem rterm(elem z, headp h, elemp q)    //z(h,q) is special term: All(x,P)(y), .... (a=b)(y), m.z, ... ,
{
 elem r = z; headp g; elemp w; int hl1; elem t,v,P,Q,M,s; // zel999 = undefined
 if(h==0 && mel(z,&h,&q) != pfs) goto ret;
 if(mm) ipp("\n+rterm z= ", z, "\nq[0]= ", q[0]); //  "\nw[0]= ", w[0]);
 if(z.ad==stad2)
 mm=mm;
 if(h->tp == zel && mm) ipp("rterm: h->tp == zel, z= ", z);    // typ(z);   // error("isst: h->tp == zel, z= ", z);
 hl1 = int(h->l)-1;

 if(vterm(h,&Q,&M))                            // 1. dot or adt term   
 { 
  // assert(hl1==2);
  // if(main) *main = q[1];                       // q[1] = m;
  // if(red)
  // { 
  s = scopeden(Q);                            // Gr.H = Gr;   // 11.22.20
  if(scopeden(M)==s && htbv(M)==s) r = Q;
  else r = Vdt(z,h,q,Q,M);
  goto ret;
  // } // if(red)
 } // if(vterm(h,&Q,&M))
 
 if(q[0] == zsb)                             // 2. reduction of z = Sb(K, a, b);
 {
  assert(hl1==3);
  // if(main) *main = q[1];                  // q[1] = K;
  r = redsb1(q[1],q[2],q[3]);  goto ret; 
 } // if(h->l == 4 ...)

 if(mel(q[0],&g,&w) != pfs) goto ret;

 if(w[0]==zA && typ(q[1])==zbool)            // 3.  A[d, Q1->Q2](Q3); d=w[1], w[2]=Q1->Q2;
 {
  assert(g->l==3);
  r = redA(z,h,q,g,w);                       // w[1] = d, w[2] = Q2;
  goto ret;
 } // if(w[0]==zA)
 
 if(w[0]==zA || w[0]==zF)                    // 4. A[d,Q2](z1, ..., zk) or ??? A[d,Q2](z in d);
 {                                           // F[d,Q2](z1, ..., zk) or ??? F[d,Q2](z in d)
  assert(g->l==3);                           // q[0] = A[d, Q2]; q[1] = z in d or z1;                  
  r = redAF(z,h,q,w);                      // w[1] = d, w[2] = Q2;
  goto ret;
 } // if(w[0]==zA || w[0]==zF)
 
 // if(hl1!=1) goto ret;
 
 if(w[0]==zimp || w[0]==zequ)                // 5. (P->Q)(R); (or (P==Q)(R) );
 {
  r = redimp(z,w[1],w[2],q[1]);              // P = w[1], Q = w[2], R = q[1];
  if(r==z)
  { 
   v = valrt(q[1]); 
   if(v==zel) error("rterm:redimp:v==zel: wrong (P ->(==) Q)(R): z= ", z, "\nP= ", w[1], "\nQ= ", w[2], "\nR= ", q[1]);
   r = redimp(z,w[1],w[2],v);
   if(r==z) error("rterm:redimp:2v: wrong (P ->(==) Q)(R): z= ", z, "\nP= ", w[1], "\nQ= ", w[2], "\nR= ", v); 
  } // if(r==z)
  goto ret;
 } // if(w[0]==zimp)

 if(w[0]==zeq)                // 6. (P=Q)(R) === rep2(R,P,Q); // if(P=Q) (P=Q)(Q) = R;
 {
  if(hl1 > 1){ ipp("rterm: case (a=b)(z1,...,zk), k>1: considering z as a method term, \nz= ", z);  goto Meth; }
  r = rep2(q[1], w[1], w[2]);
  goto ret;
 } // if(w[0]==zeq) 
 
 if(w[0]==zall)
 {
  t = typ(q[1]);
  if(fnt2(w[2],zimp,&P,&Q) && t==zbool)  // 7. All(x, P->Q)(q[1])
  { 
   r = redimp(z,P,Q,q[1]);
   goto ret;
  } // if(fnt2(w[2], ...)

  if(t != zbool)                     // 8. All(x1, ...All(xk, P)...)(z1,...,zk);
  {
   r = redAll(z,h,q,w);
   goto ret;
  } // if(t != zbool) 
 } // if(w[0]==zall && ...)

 if(w[0]==zexist || w[0]==zexist1)                 // 9. Exist(x, P(x))(a)
 {
  if(mm) ipp("rterm: exist(x,P(x))(a), z= ", z);
  v = q[0]; v.i = 1;  // v = elm(bvr, 1, Ats(w[1]));
  r = rep2(w[2],v,q[1]); 
  goto ret;
 } // if(w[0]==zexist || ...)
	ipp("rterm: each check failed: r=zel, z= ", z); goto ret;
 ipp("rterm: each check failed, now checking that z is possibly a method term, \nz= ", z);
 Meth: if(9) ipp("rterm: Meth: z= ", z);
 r = redmeth(z,h,q,w);
 ret: if(r != z)  wrval(z,h,q,r);  // was ptt->wrthmtabt(val,z.ad);  h->v = 1; 12.17.21; 
      if(mm) ipp("-rterm z= ", z, "\nr= ", r);
 return r;
} // end elem rterm(elem z) 

/* ats linr(elem z, elemp* w)  // r-linearization of z: w1= z,q[0], root(q[0]), ... while(root is composite); k: last occupied;
{
 ats i; elem y; headp h; elemp q; static elem ar[lsbin];                 // #define lsbin   16
 if(mm) ipp("+linr z= ", z);
 y = z; i = -1;
 while(comp(mel(y,&h,&q)) && comp(q[0]))
 { 
  if(++i >= lsbin) error("linr: too big i >= lsbin, z= ", z, " i= ", i, " lsbin= ", lsbin);
  ar[i] = y; y = q[0];
 } // while(comp(mel(...))
 *w = ar;
 if(mm) ipp("-linr z= ", z,  "\nar[0]= ", ar[0], "\nar[i(last)]= ", ar[i], "\nr(i)= ", i);
 return i;
} // end ats linr

 elem redr(elemp w, ats k, elem v)             // reduction of z(...)(...) ... (...), where z(...) is an rterm;
{
 elem y,v1=v; ats i;
 if(mm) ipp("+redr w[0]= ", w[0], "\nw[k]= ", w[k], "\nv= ", v, " k= ", k);
 for(i=k; i >= 0; i--)
 {
  y = reproot(w[i], v1);
  if(!rterm(y, &v1)) error("redr: not rterm w[0]= ",w[0],"\ny= ",y,"\nv= ",v, "\nv1= ", v1, "\nk= ",k," i= ",i);
 } // for(i)
 if(mm) ipp("-redr w[0]= ", w[0], "\nv= ", v, "\nr(v1)= ", v1, " k= ", k);
 return v1;
} // end elem redr
*/
   elem redsb(elem z, headp h, elemp q)  // reduction of z = Sb(K, a, b);// used only in cr.cpp;
{
 if(99) ipp("+redsb z= ", z); 
 assert(h->l == 4); elem K = q[1]; elem a = q[2]; elem b = q[3]; 
 elem r = redsb1(K,a,b);
 if(99) ipp("-redsb z= ", z, " r= ", r);
 return r;
} //  elem redsb

  elem redsb1(elem K, elem a, elem b)
{
 sbst s; elem ar[maxsynv]; elem Q; int m;
 if(99) ipp("+redsb1 K= ", K, " a= ", a, " b= ", b); 
 s.adds(a, b);
 isynv = -1; m = fsynv(K, ar);
 for(int i = 0; i <= m; i++){ Q = ar[i];  s.adds(Q,trm3(zsb,Q,a,b)); } // ,zel1); }
 elem r = s.rep(K, "redsb1");
 if(99) ipp("-redsb1 K= ", K, " r= ", r);
 return r;  
} // elem redsb1(elem K,a,b)

   elem redst(elem z)    // reduction of special terms: (p->q)(p1), (a=b)(y), All(x,P)(y), .... 
{
 elem v,r=z; headp h,g; elemp q,w;
 // zsb  = ptt -> fden1s("Sb", zel);
 if(mm) ipp("+redst: z= ", z);
 if(mel(z, &h, &q) != pfs) goto ret;  // error("redst: not pfs: z= ", z);
 if(h->l == 4 && q[0] == zsb){ r = redsb(z,h,q); goto ret; }        // Sb(K, a, b);
 if(!fnt2(q[0],&g,&w)) goto ret;      // error("redst: wrong q[0](!fnt2(q[0]) in z= ", z);
 if(w[0]==zA || w[0]==zF){ r = redAF(z,h,q,w); goto ret; } 
 if(h->l != 2) goto ret;
 if(w[0]==zimp){ r = redimp(z,w[1],w[2],q[1]); goto ret; }           // 1. (p->q)(p1)
 if(w[0]==zeq || w[0]==zequ){ r = rep2(redst(q[1]), w[1],w[2]); goto ret; } // 2. (a=b)y;
 if(w[0] == zall || w[0] == zexist || w[0] == zexist1)  // 
 {                    // A
  v = q[0]; v.i = 1;  // v = elm(bvr, 1, Ats(w[1]));
  r = rep2(w[2],v,redst(q[1])); goto ret; 
 } // if(w[0])
 // error("redst: wrong special term z= ", z);
 ret: if(mm) ipp("-redst: r= ", r);
 return r;
} // elem redst(elem z) 

    elem aint(elem a, elem b)
{
 int c = intval(a) + intval(b);
 if(c < INT_MIN16 || c > INT_MAX16) error("aint: big a,b= ",a,b);
 return elmint(c);
} // end aint

    elem sint(elem a, elem b)
{
 int c = intval(a) - intval(b);
 if(c < INT_MIN || c > INT_MAX) error("sint: big a,b= ",a,b);
 return elmint(c);
}

    elem mint(elem a, elem b)
{
 int c = intval(a) * intval(b);
 if(c < INT_MIN16 || c > INT_MAX16) error("mint: big a,b= ",a,b);
 return elmint(c);
} // end mint

    elem dint(elem a, elem b)
{
 if(intval(b) == 0) error("dint b=0");
 int c = intval(a) / intval(b);
 if(c < INT_MIN16 || c > INT_MAX16) error("dint: big a,b= ",a,b);
 return elmint(c);
} // end dint

    elem rint(elem a, elem b)
{
 if(intval(b) == 0) error("dint b=0");
 int c = intval(a) % intval(b);
 if(c < INT_MIN16 || c > INT_MAX16) error("rint: big a,b= ",a,b);
 return elmint(c);
} // end rint

  elem uint(elem z)  // unary -
{
 int c = -intval(z);
 if(c < INT_MIN16 || c > INT_MAX16) error("mint: big z= ", z);
 return elmint(c);
} // end uint
 
/*   elem Less(elem z1, elem z2)
{
 elem r = zel; elemb x(z1); elemb y(z2);
 elem a1 = x.lbound; elem b1 = x.rbound;
 elem a2 = y.lbound; elem b2 = y.rbound;
 if(b1.m == ints && a2.m == ints && intval(b1) < intval(a2)) r = ztrue;
 else if(b2.m == ints && a1.m == ints && intval(b2) <= intval(a1) ||
           z1 == b2 || z2 == a1) r = zfalse;
 if(r != zel) ipp("Less discovered r= ", r);  // zel means "unknown"
 return r;
} // end Less

   elem LessOrEq(elem z1, elem z2)
{
 elem r = zel;  elemb x(z1); elemb y(z2);
 elem a1 = x.lbound; elem b1 = x.rbound;
 elem a2 = y.lbound; elem b2 = y.rbound;
 if(z1 == z2 || b1.m == ints && a2.m == ints && intval(b1) <= intval(a2) ||
     z1 == a2 || z1 == b2 || z2 == a1 || z2 == b1) r = ztrue;
 else if(b2.m == ints && a1.m == ints && intval(b2) < intval(a1) ) r = zfalse;
 if(r != zel) ipp("LessOrEq discovered r = ", r, " z1= ", z1, " z2= ", z2);
 return r;
}  // end LessOrEq  // <=
*/
    int icon(elem z)
{
 if(pp) ipp("icon z=",z);
 return z.m == ints || z == zfalse || z == ztrue;
}

   elem inst1(elem q, elem p) // q is an 1-instance of p  // not used ???
{
 if(mm) ipp("+inst1 q= ", q, " p= ", p);
 error("inst1: not used");
 sbst s; elem r; int k;
 // if(mel(p) == var && int(p.m) == snampl)
 {
  ipp("meta: p is var from snam, q= ", q, " p= ", p);
  r = zel;
  goto ret;
 }
 k = s.instance(q, p);
 r = k == 1? ztrue: zfalse;  // ??? zfalse??? 9/20/00
 ret:
 if(mm) ipp("-inst1 q= ", q, " p= ", p, " r= ", r);
 return r;
} // end inst1

   elem  smpb(elem z, bool p,  int* r1)    // simplification of booleans
{                                       // p == true: z must be true;
 headp h; elemp q; elem a;
 if(mm) ipp("+smpb z= ", z, " p= ", p);
 elem r = z;  int i,k,m,s,x;
 if(smel(z,&h,&q) || typ(z) != zbool ) goto ret;
 if(h->tel==pfs && (q[0]==zall || q[0]==zexist) || q[0]==zA)
 { 
  a = q[0]; z = q[2];
  while(mel(z,&h,&q)==pfs && q[0]==a) z = q[2];
  if(mm) ipp("++smpb z= ", z); 
 } // if(h->tel==pfs && ...)
 ipol = -1; ivarsp = 1;
 varsp[0] = zfalse; varsp[1] = ztrue;
 trbp(z);
 if(mm)
 {
  *pfhis<<"\npol= ";
  for(i=0; i<=ipol; i++) *pfhis<<pol[i]<<' ';
  ipp("smpb: pol!");
 }
 if(ipol < 0) error("smpb: ipol<0, ipol= ", ipol);
 if(ipol == 0){ if(pol[0]==1) r = ztrue; goto ret; }   // 1: true;
 if(ivarsp < 1) error("smpb: ivarsp<1, ivarsp= ", ivarsp);
 k = (2 << ivarsp)-1; // 0: false, 1:true, 2,... - "vars", k: max+1 value of x 
 s = valp(2);   // valp under all false assignments
 if(p && s == 0) { r = zfalse; if(r1) *r1 = 0; goto ret; }
 if(hhh) ipp("smpb: valp(2), s= ", s);
 for(x=6; x < k; x+=4)  // 0:false(0), 1:true(1)
 {
  m = valp(x);
  if(hhh) ipp("smpb: x, m= ", x, m);
  if(p && m == 0){ r = zfalse; if(r1) *r1 = x>>2; goto ret; }
  if(m != s) goto ret; // r = z;
 }
 if(s == 0) r = zfalse; else r = ztrue;
 ret: if(mm) ipp("-smpb r= ", r);
      return r;
}  // end smpb

   void trbp(elem z)    // translation of booleans into Polish
{
 if(mm) ipp("+trbp: z= ", z, " var= ", var, " con= ", con);
 int i, m; headp h; elemp q;  int k=0; elem r; // t1,t2; 
 m = mel(z, &h, &q);
 if(hhh) ipp("trbp:mel: z= ", z, " m= ", m);
 if(m == var || m == con)
 {
  if(z==zemp) z = zfalse;
  wrpol(nomv(z));
  goto ret;
 }
 r = q[0];
 if(r == zeq) //  || r == zequ)
 {
  assert(h->l == 3); 
  if(hhh) ipp("trbp:zeq, z= ", z, " r= ", r);
  // t1 = typ(q[1]); t2 = typ(q[2]);
  // if(t1 == zbool && t2 == zbool || iset(q[1]) && iset(q[2]) )
  {
   trbp(q[1]); trbp(q[2]); wrpol(-5);   // -5 : zequ
  }
  // else { if(hhh) ipp("trbp:comp: z= ", z, " q[1]= ", q[1], " q[2]= ", q[2]); wrpol(nomv(z)); }
  goto ret;
 } // if(q[0] == zeq)
 if(r == znot){ k= -1; goto Next; }
 else if(r == zdis || r == zun){     k = -2; goto Next; }
 else if(r == zconj || r == zinter){ k = -3; goto Next; }
 else if(r == zimp || r == zincl){   k = -4; goto Next; }
 else if(r == zequ || r == zeq){     k = -5; goto Next; }
 else if(r == zxor || r == znequ){   k = -6; goto Next; }
 else if(r == zxor3){ k = -7; goto Next; }
 else if(r == zNI){ k = -8;  goto Next; }  
 else if(r == zsetdif){ k = -9;  goto Next; } 
 Next: if(k)
 {
  for(i=1; i<int(h->l); i++) trbp(q[i]);
  wrpol(k);
 }  
 else wrpol(nomv(z));
 ret: if(mm) ipp("-trbp: z= ", z);
} // end trbp

   int valp(int x)      // value of pol under x
{
 if(hhh) ipp("+valp x= ", x);
 int ip,k,t=0,t1,t2, st = 0;
 for(ip=0; ip<=ipol; ip++)
 {
  k = pol[ip];
  if(hhh) ipp("valp+for: st= ", st, " k= ", k);
  if(k >= 0){ st<<=1; st |= ((x>>k)&1); goto M; } // writing var into stack st // (x>>k)&1 is value var k;
  if(k == -1){ st^=1; goto M; }    //not
  // binary operations             // pq*, top2 = pq; 
  t = st&1; t1 = st & 7;           // t = q; t1 
  st>>=1;                          // now top = p (st&1 = p)
  switch(k)
  {
   case -2:  st |= t; break;                    // or (dis)
   case -3:  if(t == 0) st &= alle15m1; break;  // &
   case -4:  st^=1; st |= t;   break;           // -> : p->q == ~p or q;
   case -5:  st^=t; st^=1;     break;           // ==  : ~(p xor q);
   case -6:  st^=t;            break;           // xor, ~==
   case -7:  t2 = (t1==1 || t1==2 || t1==4);    // xor3(p,q,r)
	         st >>= 1; st &= alle15m1; st |= t2;           
			       if(hhh) ipp("valp: t2 = ", t2, " t1= ", t1); break;
   case -8: st^=1; t^=1; st|=t; break;          // NI X/\Y = {}, p&q == false, ~p or ~q;
   case -9: t^=1; if(t == 0) st &= alle15m1; break; // X -- Y: p & ~q
   default:  error("valp: k= ", k);
  } // end switch
  M:if(hhh) ipp("valp-for: st= ", st, " t= ", t);
 } // end ip
 if(st>1 || st<0) error("valp: wrong st,x= ", st, x);
 if(hhh) ipp("-valp st = ", st);
 return st;
} // end valp

   int nomv(elem z)     // number of "var" z (0 - most right)
{
 if(mm) ipp("+nomv z= ", z);
 int i; int r;
 for(i=0; i<=ivarsp; i++)
  if(req(varsp[i], z)){ r = i; goto ret; }
 if(++ivarsp >= lvarsp) error("nomv: overflow: ivarsp = ", ivarsp);
 varsp[ivarsp] = z;
 r = ivarsp;
 ret: if(mm) ipp("-nomv r= ", r);
 return r;
} // end nomv

   void wrpol(int k)
{
 if(hhh) ipp("wrpol: k= ", k);
 if(++ipol >= lpol) error("wrpol: overflow, ipol= ", ipol);
 pol[ipol] = k;
} // wrpol  

   elem vlot(elem z)      // value of local terms (like eqvl)
{
 elem  r= zel; // elemp w; int i; elem x;
 error("vlot");/*
 if(hhh) ipp("+vlot z= ", z, " ilot= ", ilot);
 sbst s = nulls("+vlot");
 for(i=0; i<=ilot; i++)
 {
  x = lot[i];        // req: because an error in matq!)
  if(hhh) ipp("vlot z, x= ", z, x);//pelm(z,pfhis); pelm(x, pfhis); }
  if(req(x,z) || matq(x, z, &s)) { r = ztrue; goto ret; }
  if(isrt(x, zeq, &w) || isrt(x, zequ, &w))
  {
   if(matq(w[1], z, &s)) { r = rep(w[2], s); goto ret; }
   if(matq(w[2], z, &s)) { r = rep(w[1], s); goto ret; }
  }
 } // end i*/
 // ret:
      if(r != zel) ipp("-vlot r= ", r);
      return r;
} // end vlot

  elem valrt(elem z, headp h, elemp q)  // { elem r h->v? q[h->l]: z; } // value of reduced term;
{
 elem r=zel; 
 if(h==0) if(mel(z,&h,&q) != pfs){ if(mm) ipp("valrt: not pfs, z= ", z); goto ret; }
 if(mm&&kk) ipp("+valrt z= ", z, " h->v= ", h->v);
 if(!h->v){ if(mm&&kk) ipp("valrt: h->v==0: z= ", z, " r= ", r); goto ret; }
 r = q[h->l];
 if(r==zel) error("valrt: r(=q[h->l]==zel, z= ", z);
 ret: if(mm&&kk) ipp("-valrt z= ", z, "\nr= ", r); 
 return r;
} // end valrt

  void wrval(elem z, headp h, elemp q, elem val)    // roughly, q[h->l] = val; 
{ 
 ats hl = h->l, aval=0; elem t;
 if(mm) ipp("+wrval z= ", z, "\nval= ", val);
 if(h->lth == 0) 
   error("wrval: h->lth == 0, z= ", z, "\nval= ", val);
 if(val==zel) error("wrval: val==zel, z= ", z);
 if(h->v)
 {
  ipp("wrval: already h->v == 1 val, z= ", z, "\nval= ", val);   // extra val after h->v == 1: for debugging;
  if(q[hl] != val) 
   ipp("wrval: already h->v == 1, but q[hl] != val, \nz= ", z, "\nq[hl]= ", q[hl], "\nignoring val= ", val);
  goto ret;
 } // if(h->v)
 if(!comp(z)) error("wrval: !comp(z), z= ", z, " val= ", val);
 if(z.m != curm) error("wrval: z.m != curm, z= ", z, " val= ", val);
 aval = ptt->wrthmtabt(val, z, false);                             // q[aval] = val;
 if(aval != 0)
 {                                    // swap q[hl] and q[aval];  changeqi !!!
  t = q[hl];  
  ipp("wrval: changing theorem q[hl] to val, z= ", z, " q[hl] = ", q[hl], "\nval= ", val, " aval= ", aval);
  q[hl] = val; q[hl+aval] = t;
 } // if(aval != 0)
 else if(q[hl+1] != zel) error("wrval:aval==0, q[hl+1] != zel z= ", z, "\nq[hl+1]= ", q[hl+1], "\nval= ", val);    
 h->v = 1;
 if(mm && aval==0) ipp("wrval:aval==0, writing val, z= ", z, "\nval= ", val);
 if(Truth(val))
 {
  if(h->t) ipp(" z is already true, z= ", z, " h->t= ", h->t);
  else h->t = 1;           // ??? mktr(z) ???
 } // if(Truth(val))
 ret: if(mm) ipp("-wrval z= ", z, " val= ", val);
      if(ww) checktabt("wrval", z);
} // end void wrval