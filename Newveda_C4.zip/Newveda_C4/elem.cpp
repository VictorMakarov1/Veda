// elem.cpp    11/23/97 12/22/99 12/15/00 01/08/01 03/09/01 05/09/01
#include "lib.h" 
#include "achs.h"
#include "sbs.h"
#include "tt.h" 
#include "adl.h"
#include "rep.h"
#include "term.h"
#include "typ.h"
#include "etc.h"
#include "elem.h"
#include "err.h"
#include "assert.h"
#include "cr.h"
#include <stdio.h>
// #include <ctype.h>

extern ats aAll, aExist, aExist1, aExistx, aExist1x,adot,aopb,aend;
extern int aa, cc, ee, hhh, kk, mm, oo, rrr, acrl,count,curtritt;
extern char* bnames[];

char* svin(int k);
int prt(char* s);   // precedence
bool unary(elem s);

 struct elemint1
{
 unsigned m:   8;    // mode = ints
 // unsigned rezerv: 8;
 unsigned val: 24;   // value
}; // end elemint

  bool bvel(elem a, elem d, int i) // a is i-th d-bounded variable
{                                  // return (d1 = htbv(a)) == d && a.i == i;
 elem d1 = a;
 d1.i = 0;
 if(d1 != d) return false;
 return (int(a.i) == i);
} // end bvel

  bool inlist(elem z, elem ar[], int last, char ppvar, char* place)  // last: last occupied; uses req;
{   // ppvar=='0': free vars, 'p': look also for predicate variables, 'd': z is qabterm, look in L for d-vars;
 int i; bool r = false; elem  x, Q = zel;
 if(mm && kk){ ipp("+inlist z= ", z, " last= ", last); *pfhis << " place= " << place; }
 if(ppvar=='p'){ Q = pvar(z); if(mm) ipp("inlist Q= ", Q); }
 for(i=0; i <= last; i++)
 {
  x = ar[i]; if(mm && kk) ipp("inlist:for ar[i]= ", x, " i= ", i);                            // ??? 2023.03.27 ???
  if(ppvar=='d'){ x.i = 0; if(root(x)==zdclb){if(mm) ipp("inist:root(x)==zdclb, z= ", z, " x= ", x); continue; }} // ??? 
  if(Q != zel && Q == pvar(x) || req(x, z)){ r = true; break; }   // ar[i] == z
 } // for(i)
 if(mm && kk) ipp("-inlist z= ", z, " last= ", last, " r= ", r);
 return r;
} // end inlist

  bool inList(elem z, elem ar[], int last, int* k)    // k: place in ar, last: last occupied;
{
 int i; bool r = false;
 if(mm && kk) ippq1("+inList z= ", z, " art= ", ar, last+1);
 for(i=0; i <= last; i++) 
   if(z == ar[i]){ r = true; if(k) *k = i; break; }
 if(mm && kk) ipp("-inList z= ", z, " last= ", last, " r= ", r);
 return r;
} // end inlist

  bool find(elem z, elem ar[], int sizear)            // find z in ar
{   
 int i; bool r = false;
 for(i=0; i < sizear; i++) 
   if(z == ar[i]){ r = true;  break; }
 return r;
} // end find

  bool wrlist(elem z, elem ar[], int* iar,  int sizelist) // initially, iar = -1;   // ??? int* iar ???
{                                              // true: new z, was written into ar;
 int i; bool r = false;                        // false: already in ar;
 if(mm && kk) ipp("+wrlist z= ", z, " *iar= ", *iar);
 if(root(z) == zdclb) 
   ipp("wrlist: root(z) == zdclb, z= ", z);
 for(i=0; i <= *iar; i++)
  if(ar[i] == z) goto ret;  // no writing
 if(++(*iar) >= sizelist) 
 { 
  prlist("wrlist ",ar,sizelist-1);
  error("wrlist:overflow: z= ", z, " sizelist= ", sizelist, " *iar= ", *iar);
 } // if(++(*iar) >= sizelist)
 ar[*iar] = z; r = true;
 ret: if(mm && kk) ipp("-wrlist z= ", z, " *iar= ", *iar);
 return r;
} // end wrlist

  void prlist(char* s, elem ar[], int last)
{
 cout<<"\n prlist:"<<s; int i;
 for(i=0; i<=last; i++){ cout<<"\n"<<i;  prp(" ", ar[i]); }
 cout << "\n";
 *pfhis<<"\nprlist:"<<s;
 for(i=0; i<=last; i++){ *pfhis<<"\n"<<i; prp(" ", ar[i], pfhis); }
 *pfhis << "\n";
} // end prlist

  bool qterm(headp h) // Quantification term: All(x,P), Exist(x.P), Exist1(x,P), Existx(x,P)
{                      // see also kboun, actually qterm(h) == kboun(h); 
 bool r = false ;
 if(cc) ipp("+qterm");
 if(h->l != 3 || h->tel != pfs) goto ret;
 elem z = h->son[0];
 r = allex1(z);               // (z==zall || z==zexist || z==zexist1 || z==zexistx);   // || z==zeps);
 if(r) goto ret;
 r = (int(z.m) == ident) && (int(z.ad)== aAll || int(z.ad) == aExist || int(z.ad) == aExist1 || int(z.ad) == aExistx);
 ret: if(cc) ipp("-qterm r= ", r);
 return r;
} // end bool qterm

  att kboun(headp h) // number of bounded names (All, Exist, Exist1: 1, abt : abt.i, else 0;
{                 // use also qterm(h)
 att r=0;
 elem a = h->son[0];
 if(ee) ipp("+kboun a= ", a);
 if(h->tel == abt) { r = a.i; goto ret; }
 if(h->tel == pfs && allex1(a)) r = 1;
 ret: if(ee) ipp("-kboun r= ", r);
 return r;
} // end kboun

  att kboun(elem z)   // number of bounded names (All, Exist, Exist1: 1, abt : abt.i, else 0;
{  
 att r=0; ats a; char* s; 
 if(bb) ipp("+kboun z= ", z);
 if(allex1(z)) { r = 1; goto ret; }                         //  || z== zeps
 if(Abt(z)){ r = z.i; goto ret; }
 if(!Ident(z, &a)) goto ret;
 s = ts[a];
 if(bb) ipp("kboun: s= ", s);
 if(a==aAll || a==aExist || a==aExist1 || a==aExistx || a==aExist1x) r = 1; 
 ret: if(bb) ipp("-kboun r= ", r); 	 
 return r; 
} // end kboun

/*   int qtrm(elem z, elemp* w)  // quantification term
{                              // ??? isdf(q[1] 2/01/01
 if(pp) ipp("+qtrm z= ", z);
 int r=0; headp h; elemp q;
 if(mel(z, &h, &q) == pfs
//     &&(q[0] == zall || q[0] == zexist || q[0] == zF )) r = 1;
 if(w && r) *w = q; 
 if(pp) ipp("-qtrm z= ", z, " r= ", r);
 return r;
} */ // end qtrm

   bool rootname(elem z)
 { 
  bool r= dclname(z) && z.m==0 || cltyp(z) || z==zbool || Abt(z); 
  if(mm)ipp("+-rootname z= ",z," r= ",r);  
  return r;
 }  // end bool rootname(elem z)

   short qabterm(elem z, headp *ah, elemp *aq, int *am) // z={x1,...,xk; ...} -> r = k;
{                                                     // the same as mel, but for qterms returns k;
 short r=0; headp h; elemp q; int m = mel(z,&h,&q);
 if(comp(m)) r = kboun(h);
 if(ah) *ah = h; if(aq) *aq = q; if(am) *am = m;
 return r;
} // end int qabterm

   elem maid(elem z)                                  // main definition: maid(d&&P) = d;
{
 int m; headp h; elemp q;
 m = mel(z,&h,&q);
 if(m == abt) return z;
 if(m != pfs || q[0] != zdconj) return zel;
 return maid(q[1]); 
} // end maid

   bool abterm(elem d, int* knames, elemp* qd, elemp* qax, int* kax)   // d is a real (not var) abterm
{
 headp h; elemp q; int k; bool r = (mel(d,&h,&q) == abt);    //??? NotAxiom ???
 if(r)
 {
  k = kmain(h); assert(k > 0);
  *knames = k; *qd = q; *qax = q + k+1; *kax = int(h->l) - k - 1;
 } // if(r)
 if(mm) ipp("--abterm d= ", d, " kax= ",  r? *kax : -1, " r= ", r);
 return r;
} // bool abterm

   bool finabt(elem d)   // d is a finite abterm;
{
 bool r = false; headp h; elemp q; int i,j,k,n; elem t;
 if(mm) ipp("+finabt d= ", d);
 if(mel(d,&h,&q) != abt) error("finabt: not abterm d= ", d);
 k = kmain(h); n = 2*k;
 if(int(h->l) <= n){ if(9) ipp("finabt: not typed abterm d= ", d, " n= ", n); goto ret; }
 for(i=k+1,j=1; i<=n; i++,j++) 
 {
  if(!typax(d,q[i],j,&t)){ if(9) ipp("finabt: not type axiom in d= ", d, " q[i]= ", q[i], " j= ", j); goto ret; } 
  if(!finset(t)){ if(9) ipp("finabt: not finset t, d= ", d, " t= ", t, " j= ", j); goto ret; }
 } // for(i)
 r = true;
 ret: if(mm) ipp("-finabt d= ", d, " r= ", r);
      return r;
} // end finabt

   bool typax(elem d, elem a, int j, elem* at)      // a is j-th type axiom in d;
{
 bool r = false; elem x; 
 if(mm) ipp("+typax: d= ", d, " a= ", a,  " j= ", j);
 if(typ(a) != zbool) goto ret;
 if(!fnt2(a, zin, &x, at)) goto ret;
 if(!bvel(x, d, j)) goto ret;
 r = true;
 ret: if(mm) ipp("-typax: d= ", d, "\na= ", a,  " j= ", j, " r= ", r);
      return r;
} // end typax

   bool dax(elem x, elem d, int* ak)     // x is an axiom of d;
{
 bool r = false; headp h; elemp q; int i,k,hl;
	if(mm) ipp("+dax: x= ", x, " d= ", d);
 if(mel(d,&h,&q) != abt) error("dax: not abterm d= ", d);
	k = kmain(h); hl = h->l;
	for(i = k+1; i<hl; i++){ if(req(q[i],x)){ r = true; break; } }
 if(ak) *ak = k; 
	if(mm) ipp("-dax: x= ", x, "\nd= ", d, "\nr= ", r, " k= ", k);
	return r;
}	// end dax

   bool Dax(elem x, elem D)     // x is an axiom of D; // D is d, D&&P, D&&D1, like DinD;
{
 bool r = false; headp h; elemp q; int m;
	if(mm) ipp("+Dax x= ", x, " D= ", D);
  m = mel(D,&h,&q);
 if(m==abt){ r = dax(x,D); goto ret; }
 if(m != pfs || q[0] != zdconj || h->l != 3) error("Dax: D: not &&: x= ", x, " D= ", D);
 r = Dax(x,q[1]) || Dterm(q[2]) && Dax(x,q[2]);
 ret: if(mm) ipp("-Dax x= ", x, " D= ", D, " r= ", r);
 return r;
} // end Dax

  elem sbst::remd(elem d, int m)     // remove from d xm, result: new d; *****(absolutely clear);
{                              // used only in freered;
 elem x,y, r; int i, k, kpm, hl; att n = ptt->newtt("remd"); filltabt(n); // ptt->tabt[n] = clad[0]->tabt[0];
 headp h; elemp q; head vh; // sbst s;
 if(9) ipp("+remd: d= ", d, " m= ", m, " n= ", n);
 if(mel(d,&h,&q) != abt) error("remd: not abt, d= ", d, " m= ", m);
 // istqab = -1; wrstqab(d,n,m); // m needed for correct replacement in repbv;
 stqab.init(); stqab.wr(d,n,m);  // m needed for correct replacement in repbv;
 x = q[0]; k = x.i;           // k is the number of names in d, k must be > 1; // same as k = kmain(h);
 if(k < 2) error("remd: wrong d (k < 2), d= ", d, " k= ", k);
 kpm = k+m;                   // kpm is the place of the type axiom for xm in d;
 hl = h->l;
 if(k < 2 && k >= hl) error("remd: wrong k, d= ", d, " k= ", k); 
 x.i = k-1; wrst(x);             // k-1 is the new number of names (without the name xm);
 for(i=1; i<hl; i++)
 {
  x = q[i]; 
  if(mm) ipp("remd:for: x= ", x, " i= ", i, " stqab.iar= ", stqab.iar);
  if(i<=k && i!=m){ if(mm) ipp("remd: i<=k && i!=m,x= ", x);  wrst(x); continue; }  // names without xm;
  if(i>k && i<kpm)               // type axiom for x1,...,xm-1; 
  {
   if(mm) ipp("remd:before y = s.rep(x), x= ", x, " i= ", i, " stqab.iar= ", stqab.iar);
   y = rep(x, "remd1");
   if(mm) ipp("remd: i>k && i<kpm, x= ", x, " y= ", y);
   wrst(y); continue;                   // type axioms until xm in tm;
  } // if(i>k && i<kpm) 
  if(i>kpm)                      // other axioms after xm in tm;
  { 
   y = rep(x, "remd2" );
   if(mm) ipp("remd: i>kpm, x= ", x, " y= ", y);
   wrst(y); continue;
  } // if(i>kpm)  
 } // for(i)
 vh = *h; vh.l = vh.l - 2;      // name xm and type axiom xm in tm;
 if(mm) ipp("remd: end for,d= ", d, " vh.l= ", vh.l, " stqab.iar= ", stqab.iar);
 r = fsegh(vh,n);                                         // was r = fsegh1(h,n)
 popst(r);
 if(9) ipp("-remd: d= ", d, "\nr= ", r, " m= ", m, " stqab.iar= ", stqab.iar, " ist= ", ist);
 return r;
} // end remd;

  elem freered(elem z, int m)    // free-reduction of A[d,Q], E[d,Q], R[d,Q]: result A[d1,Q1], ...; ****
{                             // if Q does not depend from d.m then replace d with d1 by removing d.m from d;
 elem f,xm=zel,x,d,d1,Q,Q1,t,tm=zel, r = z; headp h; elemp q; int i,j,k,k2,hl,savemm=mm; sbst s;
 if(9) ipp("+freered z= ", z, " m= ", m);
 // if(check(z.ad, stad) && m==stad1) mm=1;
 if(mel(z,&h,&q) != pfs) goto ret;
 hl = h->l; 
 if(hl != 3 || q[0] != zA && q[0] != zE && q[0] != zR) goto ret;
 d = q[1]; Q = q[2]; f = q[0];
 if(mel(d,&h,&q) != abt){ ipp("freered: d is not abt, z= ", z, " d= ", d); goto ret; } 
 hl = h->l; k = q[0].i; k2 = k*2;   // kmain(h);    
 if(k2>hl){ ipp("freered: k2>hl, z= ", z, " d= ", d, " k2= ", k2, " hl= ", hl); goto ret; } 
 if(m<1 || m>k) error("freered: wrong m, z= ", z, " m= ", m, " k= ", k);
 xm = nami(d,m); 
 for(i=k+1,j=1; j<=k; i++,j++)
 {
  if(!fnt2(q[i],zin,&x,&t) || x != nami(d,j))
     { ipp("freered: not type axiom, z= ", z, " d= ", d, " j= ", j); goto ret; }
  if(j==m) tm = t;
 } // for(i=k+1,j=1)             // must: tm != {} !!! ff(!istr2(zneq,tm,zemp))
 if(!nonempty(tm)) error("freered: maybe empty set tm, z= ", z, "\ntm= ", tm, "\nm= ", m);
 for(i=k+m+1; i<hl; i++) if(interm(xm, q[i]))  // checking that the rest of d is free from xm = d.m;
  { ipp("freered: xm in q[i], z= ", z, "\nd= ", d, "\nxm= ", xm, "\nq[i]= ", q[i]); goto ret; }
 if(interm(xm,Q))                              // checking that Q is free from xm = d.m;
  { ipp("freered: xm in Q, z= ", z, "\nd= ", d, "\nxm= ", xm, "\nQ= ", Q); goto ret; }
 d1 = s.remd(d,m);                               // removing xm from d, result: d1;
 Q1 = s.rep(Q, "freered");  // uses stqab from remd;
 r = trm2(f,d1,Q1, f==zR?zset:zbool);
 ret: if(9) ipp("-freered z= ", z, " xm= ", xm, "\nr= ", r); mm=savemm;
 return r;
} // end freered;

  elem redconj(elem z, int m)         // Q1 & Q2 == Q1, if Q1 -> Q2;            // by Red("&, 1); // m = 1.2.
{                                     // m=2: x in A & x in B <: A _> x in A & x in B == x in S;
 elem r=zel,Q1,Q2,x,x1,A,B, t=zel, t1;  // temp: Q1 is x in A, Q2 is x in B, B <: A; m = 2; // x1 
 if(mm) ipp("+redconj z= ", z, " m= ", m); // t = typ(B), t in B,  t = P[A]; // 
 if(!fnt2(z,zconj,&Q1,&Q2)) error("redconj: not conjunction, z= ", z);
 if(!fnt2(Q1, zin, &x, &A)) error("redconj: Q1 is not x in t , z= ", z, " Q1= ", Q1);   // temp !!!
 if(!fnt2(Q2, zin, &x1, &B) ) error("redconj: Q2 is not x in t , z= ", z, " Q2= ", Q2);   // temp !!!
 if(x != x1) error("redconj:  x != x1 , z= ", z, " x= ", x, " x1= ", x1);
 if(m==2) t = typ(B); else if(m==1) t = typ(A);
 if(t==zel) error("redconj: wrong m, z= ", z, " m= ", m); 
 if(!fnt1(t,zP,&t1)) error("redconj: wrong t(not P[t1]), z= ", z, " t= ", t, " m= ", m);
 if(m==2) if(t1 == A){ r = Q2; goto ret; } else error("redconj:m=2: wrong t1 in P[...],  z= ", z, " t= ", t, " t1= ", t1);
 if(m==1) if(t1 == B){ r = Q1; goto ret; } else error("redconj:m=1: wrong t1 in P[...],  z= ", z, " t= ", t, " t1= ", t1);
 ret: if(mm) ipp("-redconj z= ", z, "\nr= ", r); 
 return r;
} // end elem redconj(elem z, int m);

   bool finset(elem t)           // t is a finite set
{
 bool r = true; int m; headp h; elemp q;
 if(mm) ipp("+finset: t= ", t);
 m = mel(t,&h,&q);
 if(m==pfs && (q[0]==zcrlf || q[0]==zseg)) goto ret;
 // if(m==var || m==bvar) {  ??? }   LATER !!!
 r = istr2(zin,t,zfinset);
 ret: if(mm) ipp("-finset: t= ", t, " r= ", r);
      return r;
} // end finset

 ats avel(elem z, int* am, headp* ah, elemp* aq)
{
 ats r = -1; int m=0; headp h=0; elemp q=0;
 if(idubs(z,&r)) goto ret;
 if(z==opb){ r = aopb; goto ret; }
 if(z.m >= maxmod || clad[z.m] == 0)
    errorelm("avel: z.m) >= maxmod || clad[z.m] == 0, z= ", z);
 if(freevar(z, &r) || boundvar(z, &r) || dclname(z,&h,&q,&r)) goto ret;
 if(z.i && !adel(z,&h,&q) && (Asop(q[0]) || Dcl(q[0]))){ r = Ats(q[1]); goto ret; }
 m = mel(z,&h,&q);
 if(comp(m)){ r = h->name; if(am) *am = m; if(ah) *ah = h; if(aq) *aq = q; } 
 ret: return r;   // r = -1 for unnamed composite terms !!!
} // end avel

 char* svel(elem z) // symbolic value of element;
{
 if(oo) ippelm("+svel z = ", z, " count= ", count); int m = z.m; char static S[2];
 headp h; elemp q; static char s[100];  char* s1; char* r = "???"; ats a; int i; // w;  elem x,z1; int n,k; 
 if(m==ubs || m==ident || m==strng || m==clp && z.ad==att(aend)) { r = vts(z.ad); goto ret; }   //  || z.m==bvr
 if(m==gpc || m==gcom || m==clp){ S[0] = z.i; S[1] = 0; r = S; goto ret; }
 if(m == ints) { r = svin(intval(z)); goto ret; }
 if(m == emps) { r = "zel"; goto ret; }
 if(m >= maxmod || clad[m]==0 || emptpl(z))
 {
  // ippelm("svel: wrong z(z.m >= maxmod || clad[z.m]==0), z= ", z, " ieul= ", ieul);
  for(i=0; i<=4; i++) s[i] = '*';  s[5] = 0;  // s = "*****"; 
  strcat(s, svin(z.m)); r = s;
  goto ret; 
 }
 a = avel(z);
 if(a != -1){ r = vts(a); goto ret; }; 
 if(adel(z,&h,&q)) errorelm("avel: wrong z(adel), z= ", z);
 if(h->l > 1 && freevar(q[1], &a)) goto ret1;
 /*{
  r = vts(a); 
  error("svel: strange case: z= ", z);
  goto ret; 
 } */ // if(h->l > 1 && freevar(q[1], &a))
 if(q[0]==ymn || q[0]== zmnbool)                    // EqProof(-Tx; ...);
 {
  if(oo) ippelm("svel: q[0]==ymn || q[0]== zmnbool, z= ", z, " q[0]= ", q[0], " q[1]= ", q[1] );
  if(q[1].m==ints){ r = concat("-", svin(intval(q[1]))); goto ret; };
  a = avel(q[1]);
  if(a != -1){ r = concat("-", vts(a)); goto ret; }; 
 } // if(q[0]==zmnbool)
 // ippelm("svel: ERROR: wrong z= ", z);             // was ippelm; errorelm
 ret1: if(m==0) 
        r = svin(z.ad); else
        { 
         s1 = svin(m);
         strcpy(s, s1); 
         strcat(s,"."); 
         strcat(s,svin(z.ad));
         r = s;
        } // else
 ret: if(oo) ipp("-svel r= ", r);
 return r;   // change to vts(q[n]) = if(idubs(q[n])) ts[q[n].ad] else error;
} // end svel 

   char* vts(elem z)               //   ??? svel ???
{
 int m = z.m, i=z.i, a=z.ad ;  static char ar[2]; // was ar[1] 6.5.19
 if(m==ints) return svin(intval(z)); 
 if(m == ident || m == ubs || m == strng || m==clp && a == aend)  //  && z.m != bvr) 
 {  
  if(a > its)
  { 
  cout<<"\nvts: wrong z.ad > its   z= ("<<m<<','<<i<<','<<a<<") its= "<<its;
  *pfhis<<"\nvts: wrong z.ad > its   z= ("<<m<<','<<i<<','<<a<<") its= "<<its;
  return "*****"; // err();
  } // if(a > its)
  return ts[a];
 } // if(m = ident || ...)
 if(m==gcom || m==gpc || m==clp){ error("vts: gcom, gpc,clp: z= ", z ); ar[0] = i; ar[1] = 0; return ar; } // ???
 cout<<"\nvts: wrong z.m   z= ("<<m<<','<<i<<','<<a<<')';
  *pfhis<<"\nvts: wrong z.m   z= ("<<m<<','<<i<<','<<a<<')';
 err(); 
 return "***";   //err();

} // vts(elem z)

   char* vts(ats a)
{
 if(a < 0 || a > its)
 { 
  errmsg("vts:*******error: wrong a= ", a, " its= ", its); 
  return "******";   // svin(a);
 }
 return ts[a];
} // vts(ats a)

   elem elm(att m, att i, att a)
{
 elem b;
 if(ee)cout<<"elm"<<m<<' '<<i<<' '<<a; 
 if(m >= CAPm) error("elm: Wrong m = ", m);    // CAPm = 256; CAPacity;
 if(i >= CAPi) error("elm: Wrong i = ", i);    // CAPi = 256;
 if(a > maxlltt)  error("elm: Wrong a = ", a); // maxlltt = 65530
 b.m = m; b.i = i;  b.ad = a ; 
 return b;
} // end elm 

   elem elma(int m, int a)
{
 elem r;
 if(m < 0 || m >= CAPm)
    error("elm: error: Wrong m = ", m); 
 if(a < 0 || a >= CAPi*CAPad)
    error("elm: error: Wrong a = ", a);
 r.m = m;
 r.i = a / CAPad;
 r.ad = a % CAPad;
 return r;
} // end elma

   att Att(elem z)
{
 att r = z.ad, k, m = z.m;
 if(ee)ippelm("+Att z= ", z);
 if(badm(m))
   errorelm("Att: wrong z.m, z = ", z, " z.m = ", m); 
 k = clad[m]->lltt;
 // if (!a.vc) r += a.i * CAPad;  // CAPad - capacity of ad (2**12 = 4096)
 if(r > k)
    error("Att: big address r= ", r, " lltt= ", k);
 if(ee) ipp("-Att r= ", r);
 return r;
} // end Att

   ats Ats(elem z)    // if(z.m == ident || z.m == ubs) return check(z.ad);
{
 if(ee) ippelm("+-Ats z= ", z); ats a;
 if(int(z.m) == ident || int(z.m) == ubs || z.m == strng) return z.ad;
 if(boundvar(z, &a) || freevar(z, &a)) return a;
 errorelm("Ats:  wrong a (not ident,ubs,bvar,var), z=  ", z);
 return 0;
} // end Ats

   bool idubs(elem x, ats* a, int* pr) 
{      
 bool r;
 if(ee) ippelm("+idubs x= ", x);
 r = x.m == ident || x.m == ubs;
 if(r && a) *a = x.ad;
 if(r && pr) *pr = prt(ts[x.ad]);
 if(ee) ipp("-idubs r= ", r);
 return r;
} // end idubs

   bool Ident(elem x, ats* a) 
{        
 bool r;
 //if(1) cout<<"\n+Ident: x.m = "<<int(x.m)<< " ident= "<<ident;
 r = (x.m == ident);
 if(r && a) *a = x.ad;
 //if(1) cout<<"\n-Ident r= "<<r;
 return r;
} // end Ident

   bool Ints(elem x, ats* a) 
{        
 bool r;
 r = (x.m == ints);
 if(r && a) *a = intval(x);
 return r;
} // end Ints

  elem elmint(int c)
{
 elem r;  int c1;  void* pr = &r;  elemint* pr1 = (elemint*)pr;
 if(c < INT_MIN16 || c > INT_MAX16) error("elmint: big c= ", c); // ??? INT_MAX23,24 ??? rework !!!
 c1 = c;
 r.m = ints;
 pr1->val = c1;
 assert(r.m == ints);
 if(ee) *pfhis<<"\n-elmint c= "<<c<<" r.i= "<<r.i<<" r.ad= "<<r.ad;
 return r;
} // end elmint

  ats intval(elem z)
{
 if(z.m != ints) error("intval: not ints, z= ", z); 
 void* pz = &z;
 elemint* pz1 = (elemint*)(pz); 
 int r1 = int(pz1->val);               // ((elemint*)&z) ->val;
 // ats r = z.ad;
 ats r = r1;
 if(ee)
 {
  // cout << "\nsizeof elemint= " << sizeof(elemint) << " sizeof elem= " << sizeof elem;
  // *pfhis << "\nsizeof elemint= " << sizeof(elemint) << " sizeof elem= " << sizeof elem;
  cout << "\n-intval z.m= " << z.m <<" z.i= "<<z.i<<" z.ad= "<<z.ad<<" r= "<< r;
  *pfhis << "\n-intval z.m= " << z.m<<" z.i= "<<z.i <<" z.ad= "<<z.ad<<" r= "<< r;   // ipp,ippelm cause recursion !!!
 }
 return r;
} // end intval

  char* strval(elem z)
{
 if(z.m != strng) error("strval: not strng, z= ", z);
 char* s = vts(z.ad); char* r; static char ars[200];
 int k = strlen(s); assert(k>0);  // s = "string", k = 8, s[0]='"', s[7]='"';
 if(k >= 200) error("strval: too big string (> 200), z= ", z);
 strcpy(ars,s);  // ars := s;
 ars[k-1] = 0;  // instead of last '"';
 r = ars+1;
 if(9) ipp("-strval z= ", z, " r= ", r);
 return r;
} // end strval

/*   bool Ubs(elem x, ats* a, int* pr) 
{       
 bool r; headp h,g; elemp q,w;
 if(aa) ipp("+Ubs x = ", x); // *pfhis << " x.i = " << char(x.i); }
 if(mel(x,&h,&q)==pfs)          // TT1 := A *@mltSS.H B;
 { 
  if(h->l == 2 && Binary(q[0]) && !unary(q[0]) )
  { ipp("Ubs1: changing x= ", x, " to q[0]= ", q[0]);  x = q[0]; goto M; }  // *(mltSS), <=(leint)
  if(h->l == 3 && q[0]==zat){ ipp("Ubs@:  changing x= ", x, " to q[1]= ", q[1]);  x = q[1]; goto M; }  // 
  if(h->l==3 && (q[0]==zdot))
  { 
   if(mel(q[1],&g,&w)==pfs)
   {
    if(g->l == 2 && Binary(w[0]) && !unary(w[0]) )
    { ipp("Ubs2: changing x= ", x, " to w[0]= ", w[0]);  x = w[0]; goto M; }  // *(mltSS).G, <=(leint).M
	   if(g->l==3){ ipp("Ubs3: changing x= ", x, " to w[1]= ", w[1]); x = w[1]; goto M; }      // <|.M * @ mltSS
   } // if(mel(q[1],&g,&w)==pfs)
   ipp("Ubs4: changing x= ", x, " to q[1]= ", q[1]); x = q[1];       // <|.M * @ mltSS
  } // if(h->l==3 && q[0]==zdot)
 } // if(mel(x,&h,&q)==pfs), <(model);
 M: r = (x.m == ubs);
 if(r && a){ *a = x.ad; if(aa) ipp("Ubs x.ad= ", ts[x.ad]);};
 if(r && pr){ *pr = prt(ts[x.ad]); if(aa) ipp("-Ubs *pr= ", *pr); }
 if(aa)ipp("-Ubs r= ", r, " x= ", x);
 return r;
} // end Ubs
*/

  bool Ubs(elem x, ats* a, int* pr, bool* alfa) 
{       
 bool r; headp h; elemp q; int p;  char* s;
 if(aa)
  ipp("+Ubs x = ", x, " mm= ", mm); // *pfhis << " x.i = " << char(x.i); }
 while(mel(x,&h,&q)==pfs)          // TT1 := A *@mltSS.H B;
 { 
  if(aa) ippelm("Ubs:while: x= ", x);
  if(h->l == 2 && Binary(q[0]) && !unary(q[0])){ x = q[0]; break; }
  if(h->l == 3)
  { 
   if(q[0]==zat){ x = q[1]; break; }  // 
   if(Binary(q[0])){ x = q[1]; continue; }
  } // if(h->l == 3)
  break;
 } // while(mel(x,&h,&q)==pfs)
 s = svel(x);
 p = prt(s);  r = (p > 0);
 if(r && a){ *a = x.ad; if(aa) ipp("Ubs x.ad= ", ts[x.ad]) ;};
 if(r && pr){ *pr = p; if(aa) ipp("Ubs *pr= ", *pr); }
 if(r && alfa){ *alfa = isalpha(s[0])? true:false; if(aa) ipp("Ubs *alfa= ", *alfa); }
 if(aa) ipp("-Ubs x= ", x, " r= ", r);
 return r;
} // end Ubs
 
   bool Binary(elem x)
{
  int pr; ats a;
  if(aa) ipp("+Binary x= ", x);
  bool r = Ubs(x, &a, &pr) && pr != 0; 
  if(aa) ipp("-Binary x= ", x, " r= ", r);
  return r;
} // end Binary

   bool Bname(elem z)   // Bracket name: Qname, dcl
{
 ats a; 
 if(!Ident(z,&a)) return false;
 return findst(ts[a], bnames);
}

  bool isvar(elem z)   // z is a variable, used only in rnam;
{
 headp h; elemp q;
 return z.i && !adel(z,&h,&q) && h->tel == pfs && q[0] == yvar;
} // end bool isvar(z)

   bool isneg(elem x, elem y)   // x is negation of y: ~(x=y) == x~=y, ~(x~=y) == x=y
{                               // ~(x in y) == x nin y, ~(x nin y) == x in y;
 headp h,g; elemp q,w; int mx, my; bool r=false;
 if(mm) ipp("+isneg: x= ", x, " y= ", y);
 mx = mel(x,&h,&q);
 my = mel(y,&g,&w);
 if(mx != my || mx != pfs) goto ret;                              // return false;
 if(q[0]==znot && req(q[1], y) || w[0]==znot && req(w[1], x)) goto ret1;    // return true;
 if(h->l == g->l && h->l == 3)
 {
  if(q[0]==zeq && w[0]==zneq || q[0]==zneq && w[0]==zeq)
  if( req(q[1],w[1]) && req(q[2],w[2]) || req(q[1],w[2]) && req(q[2],w[1])) goto ret1;
  if(q[0]==zin && w[0]==znin || q[0]==znin && w[0]==zin && req(q[1],w[1]) && req(q[2],w[2])) goto ret1;
  goto ret;                                                       // return false;
 } else goto ret; // if(h->l)
 ret1: r = true;
 ret: if(mm && r) ipp("-isneg: x= ", x, " y= ", y, " r= ", r);
      return r;
} // end bool isneg

   int ldev(elem d) // wrong if
{                                         // kt = 0, rework!
 headp h; elemp q; // int j;                       // 11/11/97
 if(adel(d, &h, &q) || h->tel != abt) return 0; 
 if(d.i) error("ldev: wrong d=  ", d);
 return kmain(h);
} // end ldev

   bool boundvar(elem z, ats* a, headp* ah)
{
 bool r = false;  headp h; elemp q;  // elem H= htbv(z);// static int depth = 0; char c='8';
 //if(mm) ipp("+boundvar htbv(z)= ", H);
 // if(++depth > 1){ cin >> c; errorelm("boundvar: looping z= ", z); }
 if(adel(z, &h, &q) || z.i == 0) goto ret;
 if((qterm(h) || h->tel == abt) && Ident(q[1]))
 {
  if(a) *a = q[z.i].ad;
  if(ah) *ah = h;
  r = true;
 } // if
 ret: // r = qabterm(H);
 // if(mm) ippelm("-boundvar z= ", z, " r= ", r);
 // if(mm) *pfhis << "\n+-boundvar z.m= "<<z.m<<" z.ad= "<<z.ad<<" r= "<<r; 
 // if(mm) cout << "\n+-boundvar z.m= "<<z.m<<" z.ad= "<<z.ad<<" r= "<<r; 
 return r;
} // end bool boundvar(elem z)

   bool boundvar1(elem z, ats* a)
{
 headp h; elemp q; bool r = false;
 if(adel(z, &h, &q) || z.i == 0) goto ret;
 if((qterm(h) || h->tel == abt))   //  && Ident(q[1])
 {
  if(a) *a = q[z.i].ad;
  r = true;
 } // if
 ret: return r;
} // end bool boundvar1(elem z)

  bool freevar(elem z, ats* adts, elem* atype)  // adts: address in ts
{ 
 bool r = false; headp h; elemp q; att hl1; 
 if(mel(z,&h,&q) == var)
 {
  hl1 = h->l - 1;
  if(z.i==0 || z.i >= hl1)
     errorelm("freevar: wrong z= ", z);
  if(adts) *adts = q[z.i].ad;
  if(atype) *atype = q[hl1];
  r = true;
 } // if(mel)
 return r;
} //  end bool freevar(elem z, ... )

   bool freebvar(elem z, elemp av)   // M: All(xx, P) xx can be referenced also as (curm, 1, M) <-- freebvar;
{
 headp h; elemp q; bool r = false;
 if(adel(z, &h, &q) || z.i == 0) goto ret;
 if(qterm(h) && freevar(q[1]))       // ??? always false ???
 {
  *av = q[1];
  r = true;
 } // if
 ret: return r;
} // end bool freebvar

   bool gvar(ats a)
{
 char* s = vts(a); 
 bool r = strlen(s) >= 2 && isalpha(s[0]) && s[0] == s[1]; 
 if(rrr) ipp("+-gvar: a= ", a, " s= ", s, " r= ", r);
 return r;
} // end bool gvar(ats a)

   bool syntvar(elem z)    // ?Large(capital) var? of types bool or any;
{
 bool r;  ats a; char* s; 
 if(z == opb){ r = false; goto ret; }   // ??? rework ???
 r = freevar(z, &a);
 if(r)
 { 
  s = vts(a); // P,Q usually have type bool, W_... - other types;
  r = (s[0]=='P' || s[0]=='Q' || s[0]=='R') && (s[1]==0 || isdigit(s[1])) || 
       (s[0]=='G' || s[0]=='F' || s[0]=='W') && (s[1]==0 || s[1]=='_'); }  
 ret: if(mm && kk) ipp("+-syntvar z= ", z, " r= ", r);
      return r;
} // end syntvar(elem z)

   elem pvar(elem z, elemp*w, int* k)   // predicate var, pvar(z)=Q == z is Q or z is Q(p1, ,,,, pk);
{   // bool Lvar(elem z){ats a; return freevar(z,&a) && isupper(vts(a)[0]) && tp(z)==zbool,zany; }
 headp h; elemp q; elem r = zel; int savemm=mm; static elem ar[1]; ar[0] = zel; //  mm=0;
 if(mm&&kk) ipp("\n+pvar: z= ", z);
 if(syntvar(z)){ if(w) *w = ar; if(k) *k = 0; r = z; goto ret; }
 if((mel(z,&h,&q) == pfs) && syntvar(q[0])) // prognum != numrnam && h->tp != zel && (typ(q[0])==zfnsetbool || 
 {
  if(k) *k = int(h->l)-1;
  if(w) *w = q; r = q[0];
 } // if((mel(z,&h,&q) == pfs) && ...)
 ret: if(mm&&kk) ipp("-pvar: z= ", z, " r= ", r, " *k= ", k==0? 999: *k); mm=savemm; 
      return r;
} // end elem pvar(elem z,...)

/*   elem vname(elem z, headp h, bool* pv)  // virtual name not used
{
 if(!qabterm(h)) error("vname: not qterm, z= ", z);
 elem r, x = h->son[1]; if(pv) *pv = false;
 if(mel(x) == var){ r = x; if(pv) *pv = true; } else{ r = z; r.i = 1; }
 if(mm) ipp("-+vname z= ", z, " r= ", r);
 return r; 
} // end vname
*/

   bool ploop(elem z)           // potentially looping formula
{
 bool r; elem d,P,ax1,x,f,A,A1;
 // 1. A[x:A, f(x) in A];
 r = fnt2(z,zA,&d,&P) && abt1(d,&ax1,&x,&A) && fnt2(P,zin,&f,&A1) && req(A,A1);
 if(r){
     ipp("ploop: pot.looping formula: z= ", z); goto ret; }
 // 2. All(x, P(x) -> P(f(x);
 ret: return r;
} // end ploop

    bool isfnt(elem t)
{ 
 headp h; elemp q; 
 return mel(t,&h,&q)==pfs && inseqv(zfntypes, q[0]);
} // end isfnt

   bool twav(elem z) // term with abt vars
{
 bool r = false; int i,k; elem L[maxvars];
 if(hhh) ipp("+twav: z= ", z);
 k = freenames(z,L,maxvars);
 for(i=0; i<=k; i++) if(varabt(L[i])){ r = true; break; }
 if(hhh) ipp("-twav: r= ", r);
 return r;
} // end twav
// end elem.cpp

   elem typbvar(elem v)           // type of bvar: Exist(x, Q): look in Q for "x in t";
{                                 // All(X,P(x)), Exist(X,P(X)): tp(X) = set; (capital X); 
 elem r=zany; headp h; elemp q; elem z = v; z.i = 0;
 if(mm) ipp("+typbvar: v= ", v, " z= ", z);
 if(mel(z,&h,&q) != pfs || !qterm(h)) error("typbvar: not qterm, z= ", z);
 if(q[0]==zall){ if(Capital(q[1])) r = zset; goto ret; }   // ??? 2022.11.09 use findtf(q[2], v); 
 if(q[0]==zexistx || q[0]==zexist1x || q[0]==zexist || q[0]==zexist1) r = findtf(q[2], v);     //  Existx(x, q[2]): look in q[2] for "x in t";
 if(r==zel) r = zany;
 if(r==zany && Capital(q[1])) r = zset;
 ret: if(mm) ipp("-typbvar: v= ", v, " r= ", r);
 return r;
} // elem typbvar(elem z)

   elem findtf(elem y, elem v)    // find type formula (v in t) in y, return t;
{
 elem a,b, r = zel;
 if(mm) ipp("+findtf: y= ", y, " v= ", v);
 if(fnt2(y,zin,&a,&b) && a==v){ r = b; goto ret; }
 if(fnt2(y,zconj,&a,&b))
 {
  r = findtf(a,v);
  if(r != zel) goto ret;
  r = findtf(b,v);
  if(r != zel) goto ret;
 } // if(fnt2(y,zconj,&a,&b))
 r = zel;
 ret: if(mm) ipp("-findtf: y= ", y, " v= ", v, " r= ", r);
 return r;
} // elem findtf(elem y, elem v)

/*  elem mdln(elem z, elem M, elem T)   // modelization of z: replace each T-method y in z with y@M;
{
 if(9) ipp("+mdln: z= ", z, " M= ", M, " T= ", T);
 sbst s; elem r;
 s.AddMethods(z,M,T);
 r = s.rep(z);   // emptt3(65533) used in rep to block vals2: vals(vals(z));
 if(9) ipp("-mdln: z= ", z, " M= ", M, " r= ", r, " s= ", &s);
 return r;
} //  elem mdln(elem z, elem M, T) 
*/
                           // case i=1 and M is not a sequence: currently: r=M; PROBLEM: [...] cannot be 1-model???
  elem valm(elem M, int i)       // if M is [m1,...,mk] then m_i+p else M;
{                                       // ??? if i==0 then r=M else M must be a sequence and r = M[i+p] ??? 
 if(9) ipp("+valm M= ", M, " i= ", i); elem r = M; int k; elemp q;
 if(seqv(M,&k,&q))
 {
  if(i<1 || i>k) error("valm: wrong i or p, M= ", M, " i= ", i);
  r = q[i];  
 }
 else ipp("valm: M is not a sequence, M= ", M, " i= ", i);
 if(9) ipp("-valm M= ", M, " r= ", r, " i= ", i); 
 return r; 
} // end elem valm                value in model

 elem valm(elem z, elem T, elem M) // if(htbv(z)==T) then valm(M,z.i) else trm2(zdot,z,M,t1);
{
 elem r;
 if(9) ipp("+valm3: z= ", z, " T= ", T, " M= ", M);
 if(htbv(z)==T) r = valm(M,z.i); else r = trm2(zdot,z,M,zany);
 if(9) ipp("-valm3: z= ", z, " T= ", T, " M= ", M, "\nr= ", r);
 return r;
} // elem valm(elem z, elem T, elem M)

   elem valm4(elem M, elem d, int kd, int i)  // if(K(T)==1) r=M; if(seqv(M,&kM,&q) r = q[i]; plus CHECKS !!! 
{                                    // PROBLEM: [...] cannot a model of d, if kd=1; ??? d= SEQ1, M=[x]
 elem r=zel; int j,k,kM; elemp q,eqsM; bool is_seq_M; att m;
 if(mm) ipp("+valm4 M= ", M, " d= ", d, " kd= ", kd, " i= ", i);
 // kd = kmain(d);  
 // if(kd <= 0) 
 // error("valm: wrong kd, M= ", M, " d= ", d, " kd= ", kd);
 is_seq_M = seqv(M,&kM,&q);
 if(!is_seq_M)   // check if is true M = [...]
 {
  if(mm) ipp("valm4: M: not sequence, M= ", M);
  k = eqthms(M,&eqsM);  // eqsM: list of the eqauls to M, k == 1: no equals to M;
  for(j=0; j<=k; j++)
   if(seqv(eqsM[j],&kM,&q))
   {
    if(mm) ipp("valm4: eqthms found seqv M1, equal to M, M= ", M, " M1= ", eqsM[j]);
    goto M_is_Seqv;
   } // if(seqv(eqsM[j] ...)
 } // if(!s_seq_M)
 if(kd==1 && (!is_seq_M || kM==1 && d==zSEQ1)){ r = M; goto ret; } // below kd != 1 or is_seq_M
 if(is_seq_M)
 {
  M_is_Seqv: if(i<=0 || i > kM) error("valm4: wrong i, M= ", M, "\nd= ", d, " i= ", i);
  if(kd != kM) ipp("valm3: kd != kM, M= ", M, " d= ", d, " kd= ", kd, " kM= ", kM); 
  m = fntype(d);
  r = (m==3 || m==4)? M: q[i]; goto ret;                  // 3:SEQ,...; 4: seq,...
 } // if(is_seq_M)                   // below kd != 1 && !is_seq_M; var 
 //if(i==1) r = M;   // M is a var or a comp, should return m.M; because this valm used only in hnis, it's impossible;
 r = trm2(zdot, nami(d,i),M, zel);   // zany): ERROR, no typ(r) and therefore, no val !!!;
 ret: if(mm) ipp("-valm4 M= ", M, " d= ", d, "\nr= ", r, " i= ", i);
      return r;
} // elem valm4(elem V, elem d, int i)

   bool fntP(elem z, elemp x)  // use in disjoint
{
 headp h; elemp q;
 bool r = (mel(z,&h,&q) == pfs && h->l == 2 && (q[0] == zP || q[0] == zP1));
 if(r && x) *x = q[1];
 return r;
} // bool fntP

   bool atomset(elem z)
{
 bool r=true; headp h; elemp q; elem d,a,b; int k;
 if(z==zint || z==zbool) goto ret;
 if(abtbvar(z,&d,&h) && z.i == 1)           // if(z.i==1 && mel(htbv(z),&h,&q)==abt)
 {
  k = kmain(h); q = &(h->son[0]);
  if(fnt2(q[k+1],zin,&a,&b) && a==z && b==zset) goto ret; // first axiom: z in set; 
 } // if(z.i==1)
 r = false;
 ret: return r;
 return r;
} // bool atomset

   bool conjunct(elem z, elem C)        // z is a conjunct of C;
{
 bool r = false; elem C1, C2; int savekk=kk;
 // if(mm) kk=1;
 if(mm) ipp("+conjunct z= ", z, "\nC= ", C, "\nkk= ", kk);
 if(req(z,C)){ r = true;  goto ret; }
 if(!fnt2(C,zconj, &C1, &C2)) goto ret; 
 r = conjunct(z,C1) || conjunct(z,C2);
 ret: if(mm) ipp("-conjunct z= ", z, "\nC= ", C, "\nr= ", r);  kk=savekk;
      return r;
} // bool conjunct(elem z, elem C)

  int indelem(elem z, elemp q, int beg, int maxq) // index of z in q[beg..maxq): q[r]==z,else -1;   
{
 int i, r = -1;
 for(i = beg; i < maxq; i++) if(q[i]==z){ r = i; break; }
 return r;
} // int indelem

  bool Capital(elem x)
{
 ats a;
 if(!Ident(x,&a)) error("Capital: not Ident(x,&a), x= ", x);
 return isupper(vts(a)[0]) != 0; 
} // bool Capital(elem x)

 int cmpt(elem z, elem z1)        // compare terms: for qsort;
{
 int i,j,hl,gl,k,k1,m,m1,m0,m01,M,r= -1; headp h,g; elemp q,w; unsigned a,a1;  // char* s; char* s1;
 if(mm) ipp("+cmpt: z= ", z, " z1= ", z1);
 bool p = idubs(z); bool p1 = idubs(z1);
 if(p){ if(p1) goto Mvar; goto ret; }   // p&p1: Mvar; p & ~p1: z < z1; r = -1; 
 if(p1){ r = 1; goto ret; }             // ~p & p1: z > z1: r=1;
 m = mel(z,&h,&q); m1 = mel(z1,&g,&w);  // ~p & ~p1;
 switch(m)
 {
  case var: 
  if(m1==var)                          // var,var
  {
   Mvar: a = unsvalelm(z); a1 = unsvalelm(z1);                         // s = svel(z); s1 = svel(z1);
   if(a==a1) r = 0; else if(a > a1) r = 1; // else r already == -1;    //  r = strcmp(s,s1);
  } // if(m1==var)
  goto ret;                       // otherwise r = -1;  vars precede bvars,cons,pfss,abts;

  case bvar: 
  if(m1==var){ r = 1; goto ret; } // bvar,var
  if(m1==bvar) goto Mvar;         // bvar,bvar
  goto ret;                       // otherwise r = -1;  bvars precede cons,pfss,abts;

  case con:
  if(m1==var || m1==bvar){ r = 1; goto ret; } // con,var; con,bvar; // con > bvar > var;
  if(m1==con) goto Mvar;          // con,con;
  goto ret;                       // otherwise r = -1;  con < pfs < abt;

  case pfs:
  if(m1==var || m1==bvar || m1==con){ r = 1; goto ret; }  // pfs > con > bvar > var;
  if(m1==abt) goto ret;          // pfs < abt;
  if(m1 != pfs) error("cmpt: wrong m1, \nz= ", z, "\nz1= ", z1, "\nm1= ", m1);
  m0 = mel(q[0]); m01 = mel(w[0]); // pfs,pfs
  // if(m0==abt || m01==abt) 
  //   error("cmpt: wrong(abt) m0 or m01, \nz= ", z, "\nz1= ", z1, "\nm0= ", m0, " m01= ", m01); 
  if(comp(m0) && !comp(m01)){ r = 1; goto ret; } // f(x)(y) > f(y)
  if(!comp(m0) && comp(m01)) goto ret;             // r = -1; f(y) < f(x)(y)
  if(comp(m0) && comp(m01))
  {
   if(m0==pfs && m01==abt) goto ret;               // f(x)(y) < {x;P(x)}(y)
   if(m0==abt && m01==pfs){ r = 1; goto ret; }     // {x;P(x)}(y) > f(x)(y)
   if(m0==abt) goto Mabt;
  } // if(comp(m0) && comp(m01))
  k=0; k1=0;
  Mpfs: hl = h->l; gl = g->l;  M = min(hl,gl);
  for(i=k,j=k1; i<M && j<M; i++,j++)
  {
   r = cmpt(q[i], w[j]);
   if(r!=0) goto ret;
  } // for(i)
  if(hl==gl) goto ret;              // r=0;
  if(hl < gl){ r = -1; goto ret; }  // hl < gl -> z < z1;
  r = 1; goto ret;                  // hl > gl -> z > z1;
  
  case abt:
  if(m1!=abt){ r = 1; goto ret; }   // abt>pfs>con>bvar>var;  
  Mabt: k = kmain(h); k1 = kmain(g); goto Mpfs;
  default: error("cmpt: wrong m, \nz= ", z, "\nz1= ", z1, "\nm= ", m);
 } // end switch(m)

 ret: if(mm) ipp("cmpt: z= ", z, " z1= ", z1, " r= ", r);
      return r;
} // end int cmpt

 bool abtbvar(elem z, elem* d, headp* ah, elemp* aq)   // aq : points to d-axioms, not to d-names;
{
 bool r; headp h; elemp q; elem d1 = htbv(z); 
 r = mel(d1,&h, &q) == abt;
 if(r){ if(d) *d = d1;  if(ah) *ah = h; if(aq) *aq = q + kmain(h); }
 return r;
} // end bool abtbvar;

 bool isname(elem x, elem d0, elem dpat)   // TEMP !!! 7.5.21;
{ 
 bool r; elem d1,d2, dx=htbv(x); 
 if(mm) ipp("+isname x= ", x, " d0= ", d0, " dpat= ", dpat);
 r =  dx==d0 || dx==dpat || fnt2(d0,zdconj,&d1,&d2) && (dx==d1 || dx==d2) || 
                            fnt2(dpat,zdconj,&d1,&d2) && (dx==d1 || dx==d2);
 if(mm) ipp("-isname x= ", x, " d0= ", d0, " dpat= ", dpat, " r= ", r);
 return r;
} // bool isname(elem x, elem d

 bl blev(elem z)     // (base, level) for z; struct bl{ ats lev;  elem base; } 
{
 bl r; r.lev = -1; elem t; headp h; elemp q;  att m,k,hl; static ats count=0;
 if(mm) ipp("+blev z= ", z);  // , " zREL= ", zREL);
 if(++count > 10) 
   error("lev: recursive looping, z= ", z);
 if(z.m==ints){ r.lev = 0; r.base = zint; goto ret; }  // add chara, strng
 if(z==znat){ r.lev = 1; r.base = zint; goto ret; }                     
 if(z==zbool || z==zint || z==zelg){ r.lev = 1; r.base = z; goto ret; }    // ??? elg: separately !!!
 if(seqv(z)){ r.lev = 0; r.base = zany; goto ret; }
 if(z==zset){ r.lev = 2;  r.base = zany; goto ret; } 
 if(z==zany){ r.lev = 1;  r.base = zany; goto ret; } 
 if(z==zREL || z==zFN || z==zFFN || z==zAFN ){ r.lev = 1; r.base = zREL; goto ret; }         // ??? termorarily !!! 
 m = mel(z,&h,&q); hl = h->l;
 if(m==pfs)
 {
  if(hl == 2 && (q[0]==zP || q[0]==zP1)) { r = blev(q[1]); ++ r.lev; goto ret; } 
  goto M;
 } // if(m==pfs)
 if(m==abt)
 {
  k = kmain(h);
  if(k==1){ t = Abt1a(z,h,q); if(t != zel) r = blev(t); else error("blev: no type in z, z= ", z); goto ret; }
  r.lev = 1; r.base = z; goto ret;
 } // if(m==abt)
 M: t = typ(z);                                             // dcl[abterm,abterm]; was looping! 04.20,23
 if(t==zabterm){ r.lev = 1;  r.base = zany;  goto ret; }    // typ(elg) = set; lev(set) = 2; r = 2 + 0 - 1 = 1;
 r = blev(t);  -- r.lev;
 // while( (m = mel(t,&h,&q)) == pfs && h->l == 2 && (q[0]==zP || q[0]==zP1) ) { ++count; t = q[1]; }
 // while( m==abt && kmain(h)==1 )                 // ??? fingroup { t = tp(nami(t,1)); m = mel(t,&h,&q); }
 
 // else if(t==zany) r = 1; for all base t (except set) r = 1;
 // r = r + count - 1;   // typ(5) = int, lev(int) = 1;r = 0; // z is a sequance: typ(z)=SEQ, r=1 + 0 - 1 = 0;;
 ret:  if(mm) ipp("-blev z= ", z, " r.base= ", r.base, " r.lev= ", r.lev);    --count;
      return r;
} // end bl blev(elem z) // new

 att adtv(elem z, elemp* v)  // if z is an adt term Q(z1,...,zk) & host(Q) = d := {x1,...xk; ...} & xi=zi, r=k; 
{
 att r=0,i,k,m; elem d; headp h; elemp q;
 if(mm) ipp("+adtv z= ", z);
 if(mel(z,&h,&q) != pfs || !h->adt) goto ret;
 k = h->l - 1;
 d = scopeden(q[0]); m = ldev(d);
 if(m != k) error("adtv: wrong ldev(d), z= ", z, "\nd= ", d, " ldev(d)= ", m, " hl1(z)= ", k);
 for(i=1; i <= k; i++)
  if(q[i] != nami(d,i)) goto ret;
 r = k; *v = q;
 ret: if(mm) ipp("-adtv z= ", z, " r= ", r);
 return r;
} // end att adtv(elem z, elemp* v);

 bool trivdt(elem z, elem Q, elem M)  // trivial dot term; z = Q.M or z = Q(M);
{
 bool r = false; elem s; headp h; elemp q;
 if(mm) ipp("+trivdt z= ", z, " Q= ", Q, " M= ", M);
 s = scopeden(M);
 if(mel(s,&h,&q) == abt && kmain(h)==1 && nami(s,1)==M && scopeden(Q)==s) r = true;
 if(mm && r) ipp("-trivdt z= ", z, " s= ", s, " r= ", r);
 return r;
} // end  bool trivdt;

/*  int lev(elem z, elem* base)  // new: 5/31/20
{
 int r= 1, m, count=0; elem t; headp h; elemp q;
 if(9) ipp("+lev z= ", z);  // , " zREL= ", zREL);
 
 if(z==zREL || z==zFN || z==zFFN || z==zAFN ){ r = 1; t = zREL; goto ret; }         // ??? termorarily !!! 
 t = typ(z);
 while( (m = mel(t,&h,&q)) == pfs && h->l == 2 && (q[0]==zP || q[0]==zP1) )
      { ++count; t = q[1]; }
 while( m==abt && kmain(h)==1 )                 // ??? fingroup
      { t = tp(nami(t,1)); m = mel(t,&h,&q); }
 if(t==zset) r = 2;   // typ(elg) = set; lev(set) = 2; r = 2 + 0 - 1 = 1;
 // else if(t==zany) r = 1; for all base t (except set) r = 1;
 r = r + count - 1;   // typ(5) = int, lev(int) = 1;r = 0; // z is a sequance: typ(z)=SEQ, r=1 + 0 - 1 = 0;;
 ret: *base = t;
      if(9) ipp("-lev z= ", z, " base= ", t, " lev= ", r);
      return r;
} // end int lev(elem z, elem* base) // new

   int lev(elem z)   // old
{
 elem tz; headp h; elemp q; int m, r = -1;
 if(mm) ipp("+lev z= ", z);

 if(z == zset || z == zset1){ r = 2; goto ret; }
 if(z == zany) { r = 1; goto ret; }
 if(z.m == ints) { r = 0; goto ret; }

 if(adel(z, &h, &q)) error("lev: wrong z= ", z);

 if(seqv(z)) { r = 0; goto ret; }  // ???more checks! 12/17/99

 if(q[0] == zP || q[0] == zP1) { r = lev(q[1]) + 1; goto ret; }

 tz = typ(z); m = mel(z,&h,&q);
 if(fnt1(tz, zP)) { r = 1; goto ret; }
 // if(tz == Tdefs || tz == Tsetdefs) { r = 1; goto ret; }  // def is a possible type
 if(tz == zany) { r = -1; goto ret; };  // -1 means "unknown"
 if(tz.m == ints) error("lev: tz.m == ints, z= ", z, " tz= ", tz);
 
 r = lev(tz) - 1;

 ret: if(mm) ipp("-lev of z= ", z, " is r= ", r); 
      return r;
} // end lev
*/

// end elem.cpp