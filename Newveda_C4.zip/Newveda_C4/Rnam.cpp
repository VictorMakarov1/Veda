#include "lib.h"  // 11/21/97  12/09/99 5/23/00 6/7/00 7/22/00  NEW RNAM !!!
#include "achs.h"
#include "sbs.h"  // 04/16/01 11/25/15 12/14/15
#include "tt.h"
#include "adl.h"  
#include "term.h"
#include "typ.h"
#include "elem.h"
#include "etc.h"
#include <assert.h>
#include "err.h"
ats ndfn;                // count of not defined names
ats ndfns[lndfns];
ats lnndfns[lndfns];
ats* arid;               // array for indices in den, is parallel to vin;
ats aTaut;
elem scp;                // previous scope for wvin;
char* ovnames[maxvars];  // overloaded names
extern ats acrlf;
extern char* extm[1];
extern char prname[1];
extern ats acol, aexc, adot, adcol, avar, asop, adclb; 
extern int ttt,yy, cc, ee, mm, zz, rrr,istscp;
extern int it, ivin, dd; // rr  - only for rr!;
extern elem yasop,yexc, zProof, zsuppose,zassume,yfn,yif; // ,yby,ybyeq;
extern ofstream* pfmainhis;
extern int iarel;
extern elem arel[];
extern achs* pntu;
elem goal;                        // for Prood, EqProof, assume;
elem stgoals[lach];
int jvin, nconf=0, nstr1, iovnames,lexcount;
elem vden(ats a, tt* p);          // 
void wvin(elem z,int k=0,ats id= -1 ); // writing z to vin (visible names), s: scope;
// void pvin(char* s= " ");               // printing of vin
void rassall(headp h);            // replacing names before assume for All-formulas
int fndr(ats a);    // find inference rule in arul         
                    // h - parent, p - place, a - ident
bool seard(elem s, ats x, int k= -1);  // search in all dens, .a=x, .scope = s;k: # of actuals, not used ?
bool seardc(elem z, ats x);            // same as seard, z can be an &&-term (dconj term);
bool lpus(elem s);
bool spms(elem s);
int wrts(char* s);
inline int qname(headp h) { return Ats(h->son[1]); }  // the bounded variable of a quantification term
inline bool dscope(elem z, elemp ad)
  { bool r=  fnt2h(z, zdcol, 0, &ad); if(rrr){ ipp("dscope: z= ",z, " r= ", r); }  return r; }
inline bool pscope(headp h){ return h->tel==pfs && (h->son[0]==zProof || h->son[0]==zEqProof); } // return fnt(z, zProof); }
inline bool eqpscope(headp h){ return h->tel == pfs && h->son[0] == zEqProof; }
inline bool asscope(headp h) { return (h->son)[0] == yasop && comp((h->son)[1]); }
inline bool fnscope(headp h, elem* d) { bool r = h->son[0] == zfn && mel(h->son[1])==abt; if(r) *d = h->son[1]; return r; }
inline void prstgoals(){ for(int i=0; i <= pntu->iach; i++) if(stgoals[i] != zel) ipp(" stgoals[i]= ", stgoals[i], " i= ", i); } 
 
  void wrovnames(char* s)
{ 
 for(int i=0; i<= iovnames; i++) if(strcmp(s,ovnames[i])==0) goto ret;   // s is already in ovnames;
 if(++iovnames >= maxvars) error("wrovnames: overflow of ovnames, iovnames= ", iovnames);
 ovnames[iovnames] = s;
 ret:;
} // end void wrovnames(char* s)

  bool isovname(char* s)
{
 bool r = false; int i;
 for(i=0; i <= iovnames; i++) if(strcmp(s,ovnames[i])==0){ r = true; break; }
 return r;
} // end bool isovname(char* s)
// inline bool mterm

   void wrndfns(ats ln, ats x)   // occurence list ??? make in future
{
 if(rrr) ipp("+wrndfns ln= ", ln, " x= ", vts(x)); 
 // for(int i = 0; i <= ndfn; i++)
 //     if(ndfns[i] == x) goto Found; 
  // Not Found:
 if(++ ndfn >= lndfns) error("wrndfns: too many undefined names ndfn= ", ndfn);
lnndfns[ndfn] = ln; ndfns[ndfn] = x;
if(rrr) ipp("-wrndfns ndfn= ", ndfn);  
} // void wrndfns(ats ln, ats x)

   void achs::rnam()   // used only for ptt!
{
 ipp("\n+rnam curm= ", curm, " prname= ", prname, " iach= ", iach); // ippelm("rnam: zdebug= ", zdebug);
 // *pfhis << "\nznatm= "; pelm(znatm, pfhis);
 dd=0;  nstr1 = 0;  iovnames = -1; lexcount = 0; ats a1,a2,id,m; charp s,s1="", name; // char*  name;
 each a; elem f,z,Z,x,y,r,P,Q; headp h; elemp q; int i,k,j,p,p1,line_num; bool pproofs;
 aTaut = wrts("Taut"); goal = zel;          // iach = -1;      
 for(i=0; i < lach; i++) stgoals[i] = zel; 
 if(istscp != 0) error("rnam: wrong istscp= ", istscp);
 ndfn = -1;
 vin = (elemp) fylloc("rnam:vin", lvin * sizeof(elem));
 arid = (ats*) fylloc("rnam:arid",lvin * sizeof(ats));
 for(i=0; iach >= 0; i++)                   // actually, while(iach >= 0) MAIN LOOP !
 {
  if(rrr) ipp("rnam: while iach= ", iach, " p= ", ach[iach].p, " nstr= ", nstr, " i= ", i);
  if(++ach[iach].p >= int(ach[iach].h->l))
  {  
	  // if(ach[iach].e.ad == stad2) rrr = 0;
   popach(); 
   if(iach >= 0)
   { 
    if(rrr) ipp("rnam: before goal = stgoals[iach], goal = ", goal, "\nstgoals[iach]= ", stgoals[iach], " iach= ", iach);
    goal = stgoals[iach];   // if(f==zProof || f==zEqProof)
   } // if(iach >= 0)
	  if(rrr) ipp("rnam: after popach: goal= ", goal, " iach= ", iach, " p= ", ach[iach].p);
	  continue; 
  } // if(++ach[iach].p >=
  a = ach[iach]; Z =  a.e;
  h = a.h; q = &(h->son[0]); p = a.p; z = q[p];  //  h->son[p];
  // if(stad2 != 0 && z.ad == stad2 && z.i==0) rrr=1; 
  int hl1 = h->l - 1; // number of actual parameters;
  f = q[0];  // h->son[0];
  // a1 = h->name;
  // if(a1 != noname)
  // {
  //  s1 = vts(a1); 
  //  *pfhis << "\ns1= "<< s1 << " prname= " << prname;
  // } // if(a1 != noname)
  // rrr = (strcmp(s1,prname)==0); 
  // if(rrr==0) rrr = check(Z.ad, stad2);
  if(rrr)  ipp("rnam: for: Z= ", Z, " son z= ", z, "\nf= ", f, " p= ", p, " i= ", i); 
  nstr = h->ln;
  if(nstr != nstr1)
  {
   nstr1 = nstr;                                      // nstr1: preceding nstr;
   if(nstr % 16 == 0) cout << '*';
  }
  pproofs = ( q[0]==zProof || q[0]==zEqProof);             // ??? pscope(h) ???
  if((p==1 || p==2) && pproofs) // goal = q[1]; // else goal = zel;  // p==1
  { 
   stgoals[iach] = q[1]; 
   if(rrr) ipp("rnam: after stgoals[iach] = q[1], q[1]= ", q[1], " iach= ", iach);
   goal = q[1]; // p==1: wrong, not handled yet!
   if(rrr) ipp("rnam: proofs: goal= ", goal, " zassume= ", zassume," yassume= ", yassume ) ;
  } //if((p==1 || ...)
  else if(!pproofs)
  { 
   stgoals[iach]=zel; goal = zel; 
   if(rrr) ipp("rnam: if(!pproofs): stgoals[iach]=zel; goal = zel, iach= ", iach); 
  } // else if(!pproofs )
   
  if(z==yassume && pproofs) // assume also can be only in dcl[assume. ...], check !!!
  {
   if(p<3 || goal==zel) error("rnam: p<3 or goal==zel, Z= ",Z," z= ", z, " yassume= ", yassume, " goal= ",goal," p= ", p); // Proof:0(T:1;F0:2; assume:3,...);
   if(rrr) ipp("rnam:assume: goal= ", goal, " q[p-1]= ", q[p-1], " p= ", p, " i= ", i);
   if(fnt2(goal,zimp,&P,&Q) && req(P,q[p-1]))
   {
    goal = Q; stgoals[iach] = Q;
    if(rrr) ipp("rnam:assume:implication: changed stgoals[iach] and goal to Q= ", goal, " iach= ", iach);
   } // if(fnt2(...))
   // other cases (zA,...) are possible !!!;
  } // if(z==zassume)    
  if(rrr)  ipp("rnam:while a.e= ", Z, ", f= ", f, ", p= ", p, ", nstr= ", nstr);
  if(p==2 && pscope(h)) rassall(h);                   // Proof(Q; this_place; ...);
  if(h->tel == pfs && f==yvar)
  {
   if(p < hl1)
   {
    if(rrr) ipp("rnam: var names skipped a.e= ", a.e );
    ach[iach].p = hl1-1;  // but not the type in the end!
    continue;
   } // if(p < hl1)
   if(rrr) ipp("rnam: type of vars z= ", z);
  } // if(h->tel == pfs && f==yvar)
  if(h->tel == pfs && f == zdclb && p == 1)
  {
   if(rrr) ipp("rnam: dcl-name skipped z= ", z );
   // ach[iach].p = ach[iach].h->l;
   continue;
  }
  if(p <= 1 && h->tel == pfs && Asop(f))                    // := ??? p==0 ??? 
  {
   y = h->son[2]; x = h->son[1]; m = y.m;
   if(idubs(y,&a1))                                  //  x := y; y is ident or ubs
   {
    ipp("rnam: ident or ubs y in x := y, x= ", x, " y= ", y, " a.e= ", a.e, " a1= ", a1);
    y = fnam(a1); m = y.m;
    if(m == emps)
    {
     // s = vts(a1);
     ipp("rnam: not defined name= ", vts(a1) );
     wrndfns(nstr, a1);
    } // if(y.m == emps)
    h->son[2] = y;
   } // if(idubs(y,&a1))
  
   popach(); p1 = ach[iach].p; 
   assert(p1 >= 0);
   ach[iach].h->son[p1] = y;
   ach[iach].p = p1-1;
   if(rrr) ipp("rnam: :=,defname skipped = ", z, " y= ",y);
   continue;
  } // if(p <= 1 ...)
  if(p == 1 && h->tel == pfs && kboun(f) > 0)   // was p == 0, Qname(f)
  {
   // h->lev = Qlev()+1;
   if(z.m != ident) error("rnam: wrong bvar in qterm a.e= ", a.e);
   if(gvar(z.ad)){ if(rrr) ipp("rnam: global var in qterm a.e= ", a.e);  goto Main_case; }
   if(rrr) ippelm("rnam: bound var skipped a.e= ", a.e);
    continue;    // ++ach[iach].p;
  } // if(p == 1... kboun(f))
  if(h->tel == abt)                   // p == 0 &&
  {
   int k = kmain(h);
   if(p==0) continue;                 // abt(k) will be not changed
   if(p <= k)
   {
    if(gvar(z.ad)){ if(rrr) ipp("rnam: global var in abterm vars a.e= ", a.e);  goto Main_case; }
    if(rrr) ipp("rnam: abt: skipped name k= ", k, " p= ", p);
    continue;
   } // if(p <= k)
  } // if(h->tel == abt) 
  if(p == 1 && h->tel == pfs && h->l == 3 && f==zdot && idubs(q[1],&a1)) // dot term m.z;
  {                                                                      // the restwill be checked in typ
   if(rrr) ipp("rnam: zdot: idubs(q[1],&a1)), a.e= ", a.e, " a1= ", vts(a1));
   fdent(a1);       // total search for a1 in Den with abterm scopes;
   if(iarel == -1) goto Nondef;
   if(iarel == 0)
   { 
    q[1] = arel[0];
    ipp("rnam: zdot: s-unique a1 in Den, changed q[1],  Z= ",Z, " q[1]= ", q[1], " a1= ", vts(a1));
   } // if(iarel == 0)
   continue;  
  } // if(p == 1 && ...)
  if(p == 0 && h->tel == pfs && h->l == 3 && Aat(f) )             // module  term: A@M
  { 
   // rrr=1; mm=1;
   r = spterm2(q[1],q[2]);   // q[1] = A, q[2] = M; A @ M; -------------- spterm
   // rrr=0; mm=0;
   if(r != zel) { popach(); wapl(r);  continue; } 
  } // if(p==0 && ...&& Aat(f) MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    Main_case:      // Main case ident, ubs     //    Main case:  *(mltSS), z = q[0] = *;
  if(rrr) ippelm("rnam: Main case, z= ", z, " i= ", i);
  if(idubs(z, &a1))                             // z = *, a1 = *; // z = q[p];
  {
   if(rrr) ippelm("rnam:idubs z= ", z, " a1= ", a1);
   if(p==0 && hl1==1 && Ident(q[1],&a2))    // CHECK for f(d) and f(M): f(d),f(M) => proper f; -----------
   {                                             // a2 = mltSS;
    // error("rnam: special terms *(mltSS), <(storder),II(indset)... handled in repn, Z= ", Z);
    r = spterm1(a1,a2); // -------------------------------spterm1
    if(r != zel){ popach(); wapl(r); continue; } // r=zel: not a special term;
    // error("rnam: possibly wrong spterm1 A(M), A= ", vts(a1), " M= ", vts(a2)); 
   } // if(p==0 && ivin > 0 && ...)                            // p1+1: namber of names to find;
   if(p==0) { p1 = lvin-1; k = hl1; } else {p1 = 0; k = -1; }  // -1 : no action for k; 
   s = vts(a1);
   
  // rrr =  (strcmp(prname, s)==0); //  && (nstr==stad); // zz = rrr;//  mm = rrr; && strcmp(prname, "***end") != 0)
  // if(nstr==4209 && a1==1172 && rrr==0)
  // cpp("rnam: input string r, rrr=0");
  //if(rrr) *pfhis<<"<<\nrnam:4209: nstr= "<<nstr<<" stad= "<< stad<<" prname= "<< prname<< " s= "<< s<<
  //               " (nstr==stad && (strcmp(prname, s)==0))= " << (nstr==stad && (strcmp(prname, s)==0));
   y = fnam(a1, p1, k, p==0 && h->postfix, &id);   // lvin = 64; p1+1 : how many names to  find, ??? 10 ???
   if(rrr) ipp("rnam:after fnam: a.e= ", a.e, " y= ", y, " a1= ", a1, " id= ", id);
   if(y.m != emps) 
   {
    M: if(rrr) ipp("rnam: writing to active place, y= ", y, " q[p]= ", q[p]);
	   q[p] = y;
   }  // if(y.m != emps) 
    else        // y.m != emps == correct(y)
   {
     if(p==0 && ivin==1 && freevar(vin[1]) && !syntvar(vin[1]) )//  && vin[1].ad !=27) // { r = vin[0]; if(id) *id = arid[0]; goto ret; }
        { y = vin[0]; goto M; }
     // ipp("fnam: ivin==1 && freevar(vin[1]) && !syntvar(vin[1]), vin[0]= ", vin[0], " vin[1]= ", vin[1]);

    if(a1 == adclb) continue; // && h->l == 2 was p==0;
    if(ivin > 0){ wrovnames(vts(a1)); continue; }
    if(ivin<0 && p==0)
    {
     if(9) ipp("rnam: ivin<0 && p==0: adt term, Z= ", Z, " z= ", z);
     ipp("rnam: not found a1, trying total search fdent(a1), a1= ", vts(a1));
     y = fdent(a1);  // commented on 3.15.20
     if(y != zel){ h->adt = 1;  ipp("rnam: making adt-term, fdent found y= ", y); goto M; }
     continue;   // h->adt = 1;
    } // if(ivin<0 && p==0)
	   // if(hl1==1 && p==0) continue;          // method(model)
   
   	Nondef: *pfhis << "\nLine "<<nstr<<' '<<" p= "<<p<<' '<<a1<<' '<<vts(a1)<<" i= "<<i; //i:occurence number
    prp(" NOT DEFINED: IN ", a.e, pfhis); 
    cout << "\nLine "<< nstr << ' ' << a1<<' '<<vts(a1)<<" i= "<<i;;
    prp(" NOT DEFINED: IN ", a.e); 
    pvin("not def");
    // error("rnam: not def");
    prach("not def");
    wrndfns(nstr, a1); 
   } // end else
    continue; 
  }  // if(idubs(a) // Main case ident, ubs
  
  // if(rrr) ippelm("rnam: comp z= ", z);
    // 3. a - composite  if(z.ad == stad2) rrr=1;
  if(comp(z)){   wach(z); if(rrr) ippelm("rnam: comp z= ", z); }  // a is composite, in current module       	   
 } // end for(i)  // while
 // *pfhis << "\nrnam: stgoals<< "\n";
 // for(i=0; i < lach; i++)
 // if(stgoals[i] != zel) { *pfhis << "\n"<< i; prp(": ", stgoals[i], pfhis); }  
 for(i=0; i < lach; i++) stgoals[i] = zel;
 ipp("-rnam, lexcount= ", lexcount, " term count i= ", i);
 if(ndfn >= 0) 
 {	 
  cout << "\n   Undefined names \n";
  *pfhis << "\n   Undefined names \n";
  for(j=0; j<=ndfn; j++)
  {
   line_num = lnndfns[j]; name = vts(ndfns[j]); s = strvalue[line_num];
   cout << "\nline number= "<<line_num << " name= "<< name;  // <<ndfns[j] << ' '
   cout << " line:\n"<< s<<"\n";
   *pfhis << "\nline number= " << line_num << " name= "<<' ' << name;
   *pfhis << " line:\n"<< s << "\n";
  } // for(j)
  error("-rnam: the number of undefined names is ", ndfn+1);
 } // if(ndfn >= 0) 
 cout << "\n There are no undefined names",
 *pfhis << "\n There are no undefined names ";
 cout << "\n Overloaded names: iovnames= "<< iovnames;
 for(i=0; i<=iovnames; i++) cout<<' ' << ovnames[i];
 *pfhis << "\n Overloaded names: iovnames= "<< iovnames;
 for(i=0; i<=iovnames; i++) *pfhis <<' '<< ovnames[i];
 // free(nad);
 // free(har);
 time_rnam = myclock("-rnam finished ");
} // end rnam

   void achs::wapl(elem y) // write y into the active place
{                 // if apl is z in M := z then replace z on y
 if(rrr || bb) ipp("+wapl: y= ", y);
 if(iach <= -1 || iach > lach) error("wapl: wrong iach, y= ", y, " iach= ", iach);
 // headp h; elemp q=0;
 each g = ach[iach];
 elem x = g.h -> son[g.p];
 (g.h -> son[g.p]) = y; 
 if(rrr || mm) ipp("rnam:wapl: replacing in g.e= ", g.e, " p-son x= ", x, " on y= ", y, " p= ", g.p);
 if(rrr || bb) ipp("-wapl: x= ", x);
} // end wapl

/*    elem fnex()      // does not depend on x!
{
 elem r;
 if(vv) ipp("+fnex: jvin= ", jvin); 
 if(jvin > ivin){ r = zel; goto ret; }
 r = vin[jvin++];
 ret: if(vv) ippelm("-fnex r= ", r);
      return r;
} // end fnex
*/
                                                      // k: number of actual parameters,
   elem achs::fnam(ats x, int p, int k, bool postfix,  ats* id)      // p+1: how many names to find,  
{         // q: actuals                                           // id: index in den;
 char* sx = vts(x); elem r=zel; int i; ats n0,n1; // elemp qt;  ats n0,n1; int j, kt; elem t, r = zel, art[maxvars];
 ++lexcount;
 // rrr = nstr > 5290 && (x==1804 || x==2577 || x==3641); //  1804 Ax2 2577 Ax3 3641 L7
 if(rrr)
 {
  assert(0 <= x && x <= its); 
  *pfhis<<"\n+fnam:x= " << x << " sx= "<< sx << " p= " << p<<" k= "<<k<<" postfix= "<<postfix;
  cout<<"\n+fnam:x= " << x << " sx= "<< sx << " p= " << p<<" k= "<<k<<" postfix= "<<postfix;
  // prch();
 } 
 visn(x, p, k);           // was ptt->visn(x, p); 11/16/97
 if(ivin < 0) goto ret;           // not found   
 if(ivin == 0)            // success! a unique name found!
 {
  r = vin[0];
  if(id) *id = arid[0]; goto ret;
 } // if(ivin==0)

 // if(ivin==1 && freevar(vin[1]) && !syntvar(vin[1]) && vin[1].ad !=27) // { r = vin[0]; if(id) *id = arid[0]; goto ret; }
 // ipp("fnam: ivin==1 && freevar(vin[1]) && !syntvar(vin[1]), vin[0]= ", vin[0], " vin[1]= ", vin[1]);
 if(postfix)    // postfix term;
 {
  for(i=0; i<=ivin; i++)
  {
   r = vin[i];
   if(postfixname(r))
   { 
    if(9) ipp("fnam: postfix name chosen r= ", r);
    if(id) *id = arid[i]; goto ret;
   } // if(postfixname(r))
  } // for(i)
  ipp("fnam: no postfix name, sx= ", sx);
  r = zel; goto ret; 
 } // if(postfix)
 if(ivin==1)
 {
  n0 = npar(vin[0]);    // mistake npar(group::inv) = 0, npar(REL::inv) = 1
  n1 = npar(vin[1]);    // because of allowing adt-terms
  if(rrr) ipp("fnam:ivin==1, n0= ", n0, " n1= ", n1, " k= ", k);
 
  if(n0 == n1 || n0==0 || n1==0)  // 0 - unknown number of pars;
  { 
   goto ret;
  } // if(n0 == n1)
  if(n0==k){ r = vin[0]; if(id) *id = arid[0]; goto ret; }
   else if(n1==k){ r = vin[1]; if(id) *id = arid[1]; goto ret; }
 } // if(ivin==1)
 /*assert(k < maxvars); j = -1;
 for(i=1; i<=k; i++)
 {
  t = tp1(q[i]);                      // tp1(x): if(x.m==ints):znat,...,if(z.i==0):zel, else tp(x);
  // if(t==zel){ p1 = true; break; }  // p1==true: check only k==kt
  art[++j] = t;
 } // for(i=1; i<=kt) 

 for(i=0; i<=ivin; i++)  // not checking the case, when only one kt == k;
 {
  if(tpon(vin[i],&qt,&kt) && kt==k)
  for(j=0; j < k; j++) if(qt[j] != art[j]) goto Conti;  // zel cannot occurre in qt !!! 
  r = vin[i]; 
  if(id) *id = arid[i];
  goto ret;
  Conti: ;
 } // for i
 */
 ret: if(rrr) ipp("-fnam r= ", r, " x= ", sx, " *id= ", id==0? 999: *id); 
 return r;
}  // end fnam

   void achs::visn(ats x, int p, int k)    // p+1 : number of names to find; k: number of actual parameters;
{
 char* sx = vts(x); bool p1 = true;  int count;  scp = zel1;
 each v; int i, j, m; elem P,Q,T,y,z,d,r; ats a; headp h; elemp q; 
 if(rrr) *pfhis << "\n+visn x= " << x << " sx= "<< sx << " p= " << p << " k= "<<k;
 if(rrr) cout << "\n+visn x= " << x << " sx= "<< sx << " p= " << p ;
 ivin = -1; 
 if(ptt->aden[x] < 0) { if(rrr) ipp("visn: x not in den, x= ", sx); p1 = false; }
 if(rrr) prach("visn");
 for(i=iach; i>=0 && ivin < p; i--)
 {                                             // ??? seq-scope ??? [ ... ]
  v = ach[i]; 
  if(rrr) ipp("visn:for v.e= ", v.e, " ivin= ", ivin);
  
  if(v.h->tel == abt && p1)     //  1. abstraction term  // p1==false: x is not in den
  {
   if(rrr) ipp("visn: abt, v.e= ", v.e);
   if(gvar(x)) {  ptt->sdens(zel,x,k); continue; }
   r = fnabt(x, v.e, v.h);   // find name x in A-term and return the inner name
   if(r != zel){ wvin(r,k); goto ret; }   // "r == zel" is not wrong
   ptt->sdens(v.e,x,k);
   continue;  } // end if(v.h->tel == abt)
  
  if(qterm(v.h) && p1)       // 2. Quantification terms:
  {                         // All(x, P), Exist(x,P), Exist1(x,P);
   if(rrr) ipp("visn:qterm v.e= ", v.e); 
   if(ats(v.h->son[1].ad)==x){ wvin(nami(v.e,1), k); goto ret; }  // ptt->sdens(gvar(x)? zel : v.e, x);     
   continue;
  } // if(qterm(v.h))
  if(dcld(v.h, &d))           // not used ???
  {
   if(rrr) ipp("visn:dcld, v.e= ", v.e, " x= ", vts(x));
   seard(d,x,k); continue;
  } // if(dcld(v.h, &d))       // d!=zel: group.afingroup :: [...];
                               // 4. d-terms: A[d,P], E[d,P], Ex[d,P], E1[d,P], F[d,P],R[d,f],U[d,w],S[d,f], d::, d&&
  if(dterm(v.h, &d) || d!=zel) 
  {                            // fn(d,t);
   if(rrr) ipp("visn:dterm, v.e= ", v.e, " x= ", vts(x));
   // save = ivin;
   seardc(d,x);  count = 0; // ptt->sdens(d, x); // was seard(d,x,k);
   // if(ivin != save) goto ret; 
   /*while(fnt2(d,zdconj,&d, &y))
   { 
    seard(d,x,k); 
    if(++count > 100) error("visn: dterm: recursion: count > 100, x= ", vts(x), " count= ", count);
   } */ // while
   // y = lbr(i);      // left brother of ach[i].e;
   // if(rrr){ ipp("rnam: lbr: y= ", y);  prach("lbr"); }
   //if(y != zel && fnt12(y,yexc,zincl,&A,&B) && d==A && ivin < 0)
   //{
    // if(rrr) prach("lbr1");
	   //if(9) ipp("visn: lbr: y= ", y, " d= ", d, " B= ", B);
	   //seard(B,x,k);
   //} // if(y != zel && ...
   
   if(v.h->son[0]==zdcol)
   {
    T = v.h->son[1];                         // T::[ ...] // T - Theory
    if(fnt2(T,zdot, &z))                      // added on 6.23.19;
    {
     if(rrr) ipp("visn: +zdcol:zdot: z= ", z, " x= ", vts(x));
     if(z.m==ident)
     {
      z = ptt->fdent1(z.ad, zel1);  // zel1 means find unique z.ad in den;
      if(z != zel && ivin == -1) seard(z,x,k);  // ivin == -1: because we are looking for unique x in den;
      if(rrr) ipp("visn: -zdcol:zdot: new z= ", z, " x= ", vts(x));
     } // if(z.m==ident)
    } // if(fnt2(v.h->son[1],zdot, &z))
    z = lbr(i);                                       // added on 6.23.19
    if(rrr) ipp("visn:zdcol: lbr(i)= ", z, " i= ", i);
    if(fnt2h(z,zincl,&h,&q) && h->t && q[1]==T && ivin == -1) seard(q[2],x,k);  // T <: q[2], so search in q[2]
   } // if(v.h->son[0]==zdcol )	
   continue;
  } // if(dterm(v.h, &d))

  if(asscope(v.h) && p1) //  || v.e.ad == 768)              // 3a. assignment scope
  {
   if(rrr) ipp("visn:asscope v.e= ", v.e);
   // ippelm("visn: asscope v.h->son[0] = ", v.h->son[0]);
   // ippelm("visn asscope zasop = ", zasop);
   // ippelm("visn asscope v.h->son[1]= ", v.h->son[1]);   
   ptt->sdens(v.e, x);        // search x in den with scope v.e
   continue;
  } // if(asscope(v.h))
 
  if(pscope(v.h) && p1)       // 5. Proof(P; ...) or EqProof(P; ...)
  {
   if(rrr) ipp("rnam:visn:pscope v.e= ", v.e, " x= ", vts(x));  // " goal= ", goal, " k= ", k); // was rrr
   ptt->sdens(v.e, x);        // search x in den with scope v.e
   // Now we should check for assume if P(goal) is A[d,Q] and we search at first in d;
   P = stgoals[i];                  // was P = v.h->son[1];
   // if(rrr) ipp("visn:pscope:stgoals: P= ", P, " i= ", i, " istgoals= ", istgoals);
   if(P==zel) P = v.h->son[1];
   if(rrr) ipp("visn:pscope P= ", P, " v.e= ", v.e, " v.h->son[1]= ", v.h->son[1], " i= ", i);
   // if(p2 && P != goal){ ipp("visn: changing P to goal, P= ", P, " goal= ", goal); P = goal; p2 = false;  }
   //  error("visn: P != v.h->son[1], P= ", P, " v.h->son[1]= ", v.h->son[1]);
   if(fnt1(P,ymn,&Q)) P = Q;  // 5.1
   if(fnt2(P,zA, &d, &Q))     // 5.2
   {
    if(rrr) ipp("visn: pscope:P = A[d,Q]: P= ", P, " k(i)= ", k);  // ??????? 6.23.22
    if(!seardc(d,x) && fnt2(Q,zA, &d)) // && mel(d)==abt)          // will not work for A[d,A[d1,A[d2,P]]]; 6.23.22
       { if(rrr) ipp("visn:pscope: searching the deeper A[d in P= ", P, "\nQ= ", Q); seardc(d,x); }
    //if(mel(d)==abt)
    //{ 
    // if(!seard(d,x,k) && fnt2(Q,zA, &d) && mel(d)==abt)
    //   { if(rrr) ipp("visn:pscope: searching the deeper A[d in P= ", P, "\nQ= ", Q); seard(d,x,k); }
    //} // if(mel(d)==abt)
    // continue;                     // commented on 2022.10.18
   } //  if(fnt2(P,zA, d, Q))
   
   if(rrr) ipp("visn: Now we should check assume(x) and Ex[d,P], ach[i].e= ", ach[i].e, " ach[i].p= ", ach[i].p); 
   for(j=ach[i].p; j>1; j--)   // search in Proof(goal, ..., assume or assume(x)
   {                           // goal = v.h->son[1]; 
    z = v.h->son[j]; elem host;
    if(rrr) ipp("visn:assume:checking for(j=ach[i].p, ach[i].e= ", ach[i].e, " z= ", z, " j= ", j);
    if(fnt1(z, zassume, &y))   // 5.3  looking for all assume(x) ??? : for first assume(x)
    {
     if(rrr){ ipp("visn:assume(y) found, z= ", z, " y= ", y, " x= ", x); prstgoals(); }
     if(!boundvar(y, &a)) error("visn:assume: not boundvar y in z= assume(y),  z= ", z, " y= ", y, " x= ", x); 
     if(a==x){ wvin(y); continue; }
     host = htbv(y);
     if(rrr) ipp("visn:assume(y) found, looking in den for x with scope host = htbv(y), \nz= ", z,
                                                     " y= ", y, " htbv(y)= ", host, " x= ", x); 
     if((y = ptt->uniqden(x, host)) != zel){ wvin(y); continue; } 
    } // if(fnt1(z, zassume, &y))
   
    if(fnt2(z, zEx, &d))       // 5.4 Ex[d,P];
    {                          // elem fnabt(ats x, elem v, headp h);   // Find name x in abterm (v,h)
     if(rrr) ipp("visn:+Ex, z= ", z, " d= ", d); int m;
     if(seek(z) != -1) continue; // z is in ach, not handled yet completely;
     if((m=mel(d,&h)) != abt)  
          error("rnam:visn:zEx: (temporarily): d is not abt, z= ", z, " d= ", d, " m= ", m);     
     y = fnabt(x,d,h);
     if(y != zel) wvin(y);
     if(rrr) ipp("visn:-Ex, z= ", z, " d= ", d, " y= ", y);  
    } // if(fnt2(z, zEx, &d))
     
   } // end for(j)
   continue;    // for(i=iach; i>=0; i--)
  }  // end if(pscope(v.e))

 if(eqpscope(v.h) && p1) // commented because pscope includes eqpscope:
 {                       //   bool pscope(headp h){ return h->tel==pfs && (h->son[0]==zProof || h->son[0]==zEqProof); }
  if(9) error("visn:eqpscope v.e= ", v.e, " k= ", k);
  ptt->sdens(v.e, x);        // search x in den with scope v.e
  continue;
 } // if(eqpscope(v.h) && p1)

 if(fnscope(v.h, &d)) seard(d,x);          // fn(d, t), x in t;
 }; // end for(i=iach; i>=0; i--) // no search in module scope (= zel);
 
 if(ivin > p)    // trying to find in vin the unique named abtbvar; ??? unnamed bvars ??? 5.13.21
 { 
  elem r=zel, x,d; headp h;
  if(ivin==1 && req(vin[0],vin[1])){ ivin=0; goto ret; }  // added 2023.02.03
  for(i=0; i<=ivin; i++)
  {
   x = vin[i];
   if(!abtbvar(x,&d,&h) || h->name == noname) continue;
   if(r == zel){ r = x; continue; };
   r = zel; break;                   // 2 named abtbvars
  } // end for(i=0; ...)
  if(r != zel){ vin[0] = r; ivin = 0; goto ret; }
  pvin();  error("visn: ivin > p, x= ", x, " ivin= ", ivin, " p= ", p);
 } // if(ivin > p)
 if(ivin == p) goto ret;   //  Ok, done ! // was ivin == p;
 if(rrr) ipp("rnam:visn: checking curm and externals x= ", x, " curm= ", curm, " ieul= ", ieul, " ivin= ",ivin," p= ", p);  
 assert(eul[0] == curm);
 for(i = 0; i <= ieul && ivin<p; i++) // 1. Externals, module curm uses names from eul[1],eul[2], ,...
 {                          // eul[0] = curm, eul[1] = uselist[0], ...
  m = eul[i];
  tt* pnt = clad[m];
  if(rrr) ipp("visn: for: i= ", i, " m= ", m);
  // if(rrr) ipp("visn checking pnt, iden= ", pnt->iden);
  int save = ivin;
  pnt->sdens(zel, x, k);   // zel: scope = module // 5.22.22: added 3 lines below;
  // if(ivin != -1) goto ret;
  // z = pnt->fdent1(x, zel1,-2,&s);  // zel1 means find unique z.ad in den;  // because 
  // if(z != zel) wvin(z,s);
  // if(ivin >= p) goto ret;
 } // end for(m),    5. Externals
 ret: if(rrr) pvin("-visn:rnam");
} // end void achs :: visn(ats x, int p)

   bool seard(elem s, ats x, int k)  // search in all dens, .a=x, .scope = s; return true if it found something;
{
 bool r=false; int i,m,save=ivin;
 if(rrr){ ipp("+seard s= ", s, " vts(x)= ", vts(x), " k= ", k, " ieul= ", ieul); }  // peul(); 
 // ptt->sdens0(d,x);   // At first we search in current den eul[0] = curm!!!
 for(i=0; i <= ieul; i++)         // Then we search in all external dens
 {
  m = eul[i];
  clad[m] -> sdens(s, x, k);
 } // for(i)
 r = (ivin != save);
 if(rrr) ipp("-seard s= ", s, " x= ", x, " r= ", r);
 return r;
} // end void seard(elem s, ats x, int p)
 
    bool seardc(elem z, ats x) // same as seard, z can be an &&-term (dconj term);
{
 bool r=false; int m,m1,m2; headp h,h1,h2; elemp q,q1,q2;
 if(rrr){ ipp("+seardc z= ", z, " vts(x)= ", vts(x), " ieul= ", ieul); }  // peul();
 seard(z,x);   
 m = mel(z,&h,&q);
 if(m==abt) goto ret;
 if(m!=pfs || q[0] != zdconj) error("seardc: wrong z= ", z, " zdconj= ", zdconj);
 m1 = mel(q[1],&h1,&q1); m2 = mel(q[2],&h2,&q2);
 if(m2==abt) seard(q[2],x);
 if(m1==abt){ seard(q[1],x); goto ret; }
 if(simple(m1)) goto ret;                       // d && ...
 if(m1!=pfs || q1[0] != zdconj) error("seardc: wrong q[1], z= ", z, " zdconj= ", zdconj, " m1= ", m1);
 seardc(q[1],x);
 ret: if(rrr) ipp("-seardc z= ", z, " vts(x)= ", vts(x), " r= ", r);
      return r;
} // end void seardc

   void tt::sdens(elem s, ats x, int n)  // search in den for scope s, ats = x (?n? not needed ?)
{                                         // was fexn
 ats k;
 if(x < 0 || x > its) error("tt::sdens: wrong x, s= ", s, " x= ", x);;
 if(rrr){ ipp("+tt::sdens scope= ", s, " x= ", vts(x), " mym= ", mym, " ivin= ", ivin); *pfhis << " k= " << n; }        // rrr
 if(x > lastaden) goto ret;
 k = aden[x];
 if(k > iden) 
	  error("tt::sdens: k > iden, s= ", s, " x= ", vts(x), " k= ", k, " iden= ", iden); 
 if(k < 0){ if(rrr) ipp("tt::sdens: aden[x] < 0, k= ", k); goto ret; }
 while( k <= iden && den[k]->a == x) 
 {
  edenp y = den[k];
  if(y->scope == s)                   // || s==zel: added on 2022.05.30;
   if(mym == curm || !isvar(y->inn) || s==zel)  wvin(y->inn,n,k); // k will be written into arid (parallel with vin);
  k++ ;
 } // end while(k) 
 ret: if(rrr) ipp("-sdens scope= ", s, "  x= ", vts(x), " ivin= ", ivin);
} // end void tt::sdens

/*   void tt::sdens1(elem d, char* s, int p)  // search in den for scope d, ats = x
{
 if(vv) ipp("fexn s = ", s);
 ats x = findts(s);
 if(x != emptyts) sdens0(d,x,p);
} */ // end void tt::sdens1

 void wvin(elem z, int k, ats id)  // s: scope, k: number of actual parameters: NOT USED ???;
{                                          // id: address in den for z;
 if(rrr) ipp("+wvin z= ", z, " ivin= ", ivin, " k= ", k, " id= ", id); int i; // n; headp h; elemp q;
 // if(scp==zel1) scp = s;   // ??? writing into vin only with first scope ???
 // else if(s != scp){ ipp("wvin: not writing z= ",z, " s= ", s, " ivin= ", ivin); goto ret; }
 // headp h; elemp q;
 /*if(z.namt == 0) 
 if(adel(z, &h, &q) || h->tel != pdf || q[0].m != def)
 {
  ippelm("wrong z= ", z);
  error("wvin: wrong z(see above ippelm) ");
 }*/
 // if(dclname(z,&h,&q) && q[1] != yfn && q[1] != yif && q[1] != yby && q[1] != ybyeq)
 // { 
 //  n =  h->l - 3;   // number of parameters in dcl;
 // if(k != -1 && n != k){ if(rrr) ipp("rnam:wvin: skipping z= ", z, " k= ", k, " n= ", n); goto ret; }
 // } // if(dclname(z,&h))
 for(i=0; i<=ivin; i++) if(eqel(vin[i], z)) goto ret; 
 if(++ivin >= lvin) error("rr:wvin overflow ivin=",ivin);
 vin[ivin] = z; arid[ivin] = id;
 ret: if(rrr) ipp("-wvin: z= ", z, " ivin= ", ivin);
} // end wvin

   void pvin(char* s)
{
 elem x; cout << "\npvin: s= " << s << " ivin= " << ivin; 
 *pfhis << "\n+pvin: s= " << s << " ivin= " << ivin;
 for(int i=0; i<=ivin; i++)
 {
  x = vin[i]; prp("\n", x, pfhis); prp("\n", x); pelm(x);  pelm(x, pfhis);
  x.i = 0; prp(" ", x, pfhis); prp(" ", x);
 } // for(i)
 //{ pelm(vin[i], pfhis); prp(" ", vin[i], pfhis);}
} // end pvin

   void rassall(headp h)       // replace name x before assume, if x is a bvar in All-formula;
{
 elem z=zel,z1,x,x1,Q; elemp w;   // assume(x,y,z) ??? assume(F1,F2,F3); ???
 elem goal1 = h->son[1];  // goal1: All-formula (add later implications);
 if(rrr) ipp("+rassall: h->son[0] = " , h->son[0], ", h->son[1]= ", h->son[1]);
 for(int i=2; i < int(h->l); i++)
 {
  z1 = z; z = h->son[i];
  // if(z == yassume)    // later !!!
  if(!fnt1(z, yassume, &w)) continue;
  x = w[1]; 
  if(rrr) ipp("rassal: found z=assume(x), z= ", z, ", x= ", x);
  if(!fnt2(goal1,zall,&x1, &Q)) error("rassall: goal1 is not All-formula, goal1= ", goal1, " zall= ", zall);
  if(x != x1)
   error("rassall: in assume(x), x != x1, x1 in All(x1,Q), x= ", x, ", x1= ",x1, ", goal1= ", goal1);
  ippelm("rassall: changing x= ", x, " to w[1]= ", w[1]); 
  w[1] = nami(goal1,1); 
  goal1 = Q;
 } // end for(i)
 if(rrr) ipp("-rassall: goal1= ", goal1);
} // end rassall


// end of file Rnam