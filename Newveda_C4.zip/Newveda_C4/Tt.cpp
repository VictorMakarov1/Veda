#include "lib.h"   // 11/21/97 11/28/99 3/4/00 3/16/00 7/22/00 12/13/00
#include "myio.h"  // 03/13/01 
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h"  
#include "typ.h" 
#include "elem.h" 
#include "term.h" 
#include "lot.h" 
#include "err.h"
#include "etc.h"
#include "assert.h"
//#include "smp.h"

extern ofstream* pftbt;
extern char source[80];
extern char source1[80];
extern char dirname[80];
extern int iallm, dd,ii,qq,uu,yy,zz,aa,bb,kk,mm,hhh,numtopt,prognum,numtrm,ilot,sumDj;
extern att maxits;
extern sbst ssss1;
extern ofstream* pftbt; 
extern int istscp;
extern int countctruth;   // count of ctruth (declared, but unproved) theorems;
extern achs* pntu;
extern elem scpe;
int badelem = 0;          // number of bad elements in tabt: used in tt::futt;
int zeltype = 0;          // number of zel types in tabt: used in tt::futt;
char c;
int mergecount;           // merge count in findtabt
int findcount;            // number of searches in findtabt;
int countbadthms;
extern int maxDj;         // maximium number of tries in fintabt;
extern att lthms;         // maximum number of theorems in tabt; (actually, size of thms[]);
extern bool errprint;
int len(headp);
char* mytime();
#define sizepage 50

int wrts(char* s);
bool isovname(char* s);

   tt::~tt()
{
 for(int i=0; i<=itt; i++) myfree(tabt[i]);
 myfree(tabt);  myfree(uselist);
 myfree(den); myfree(aden); // myfree(lonef);
 // myfree(truf); 
}

    tt::tt(att lasttabt,ats kul, ats kden, ats kaden)    //  ptt = new tt(lasttt,ieul, lden, laden);
{    // ptt = new tt(lasttt,ieul, lden, laden);  // lasttt: from dd;
 int i;
 cout<<"\n+tt::tt mym= "<<mym<<" lasttabt= " <<lasttabt<<" kul="<<kul<<" kden= "<<kden<<" kaden= "<<kaden;
 *pfhis<<"\n+tt::tt mym= "<<mym<<" lasttabt= " <<lasttabt<<" kul="<<kul<<" kden= "<<kden<<" kaden= "<<kaden;
 cout << "\nsizeof(modsize_t)= " << sizeof(modsize_t)<< " sizeof(att)= "<< sizeof(att);
 *pfhis << "\nsizeof(modsize_t)= " << sizeof(modsize_t)<< " sizeof(att)= "<< sizeof(att);;
 lltt = lasttabt;
 itt = emptt; // emptt = 65535 = -1;
 itt1 = lltt + 1;
 tabt = (headp*) fylloc("tabt", (lasttabt+1)*sizeof(void*));
 uselist = (att*) fylloc("uselist", (kul+1) * sizeof(att));
 kuselist = kul;
 iden = -1;  
 den = (edenp*)  fylloc("den", (kden+1)*sizeof(void*));
 aden = (ats*)   fylloc("aden", (kaden+1)*sizeof(ats));
 har = (att*) fylloc("har", sizehar*sizeof(att));             // sizeof(att) = 2;
 for(i=0; i < sizehar; i++) har[i] = emptt;  // emptt = 65535, sizehar = 65536 * 4;
 freqts = (int*) fylloc("freqts", (maxits+1)*sizeof(int));
 for(i=0; i <= maxits; i++) freqts[i] = 0;
 lastaden = kaden;
 // itruf = -1; atrim = -1; ltrim = -1;  // lonef = 0; 
 for(i=0; i <= kaden; i++) aden[i] = emptyaden;
 for(i=0; i<=lasttabt; i++) tabt[i] = 0;
 for(i=0; i<=kul; i++) uselist[i] = -1;
 ithms = -1; 
 ithmsic = -1; 
 beg_impconj = -1;                // beginning of (->,&) segment in thms;  int => ats ???
 end_impconj = -1;                // end of (->,&) segment in thms;
 beg_rimpin = -1;                 // beginning of (<-,in) segment in thms;
 end_rimpin = -1;                 // end of (<-,in) segment in thms;
 beg_equin = -1;                  // beginning of (==,in) segment in thms;
 end_equin = -1;                  // end of (==,in) segment in thms;
 beg_exist = -1;                  // beginning of (Exist)- segment in thms;
 end_exist = -1;                  // end of (Exist)- segment in thms;
 thms = (att*) fylloc("thms", lthms * sizeof(att));         // lthms taken from dd.d; currently 5000;
 thmsic = (att*) fylloc("thmsic", lthmsic * sizeof(att));   // lthmsic: see lib.h #define lthmsic 1000
 indthms = (att*) fylloc("indthms", (lden) * sizeof(att));
 for(i=0; i<lden; i++) indthms[i] = emptt;   // ??? iden ??? // emptt = -1;
 cout<<"\nfinished tt: created tt last = "<<lltt<<" uselist last= "<< kul
     <<" den last= "<<kden<<" aden last="<<kaden; 
 *pfhis<<"\nfinished tt: created tt last = "<<lltt<<" uselist last= "<< kul
     <<" den last= "<<kden<<" aden last="<<kaden; ;
} // end tt::tt(att lasttabt, ,,,)

  elem tt::elmstr(char* s)
{
 elem r = zel;
 error("tt::elmstr");
 // ats a = ts::wr(s);
 // elem r= elm(strng, mym, a);
 return r;
} // end elmstr

   att tt::newtt(char* s, bool pritt)   // s: place, pritt==true: r = ++itt; else r = --itt1; init(itt) = 
{
 bool p=false; att r;  // int p1 = (itt != emptt && itt >= pait && itt <= endpait); // int savemm=mm;
 /*if((prognum == numtyp) && pait && endpait)
 { 
  if(itt==pait) mm=1;
  if(itt==endpait) mm=0; 
 }; // if((prognum == numtyp ...)
 */
 if(mm || zz==5) 
    ipp("+newtt s= ", s, " itt= ", itt);
 /*if(prognum != numtrm && prognum != numtopt)
 {
  if(!mm)
  {
   *pfhis << "\nnewtt s= "<< s << " itt= "<<itt; ++ippcount;  // << " mm= "<<mm; <<" itt1= "<<itt1<<" pritt= "<<pritt; 
   cout << "\nnewtt s= "<<s<<" itt= "<<itt; // << " mm= "<<mm; // <<" itt1= "<<itt1<<" pritt= "<<pritt; 
  } // if(!mm)
  // if(itt%100 == 0) pntu->prach("newtt");
 } */ // if(prognum != numtrm)     
 if(pritt) ++itt; else --itt1;
 if(itt==stad2)
 mm=mm;
 if(itt >= itt1 && itt != 65535)   // ??? research ???
 { 
  pntu->prach("overflow of tabt"); 
  cout<<"\nnewtt: overflow of tabt, s= "<<s<<" itt= "<<itt<<" itt1= "<<itt1<<" lltt= "<<lltt<<" pritt= "<<pritt; 
  *pfhis<<"\nnewtt: overflow of tabt, s= "<<s<<" itt= "<<itt<<" itt1= "<<itt1<<" lltt= "<<lltt<<" pritt= "<<pritt; 
  error("newtt: overflow of tabt: itt= ", itt, " itt1= ", itt1);
 } // if(itt >= itt1) 
 if(curm != mym) error("newtt: curm != mym, is it possible ?, curm= ", curm, " mym= ", mym);
 // p = pait != 0 && (inseg(itt,pait,pait+30) || inseg(itt1,pait,pait+10));  // (curm==mym) && 
 // if(prognum==numtrm && pait != 0) aa = p; // for printing in pars
 //else if(prognum==numrnam && pait != 0) zz = p;
 // else if(prognum==numtyp && pait != 0){ mm = p; ttt = mm; }
 r = pritt? itt: itt1;
 if(prognum != numtrm && ff) ipp("-newtt: pritt= ", pritt, " r= ", r); // mm=savemm;
 return r;
}  // end tt..newtt()

   headp tt::fsq1(int pfsabt, int l, elem* a, att lev, att isz)
{
 if(mm&&sss) ipp("+-fsq1 tel= ", pfsabt, " l= ", l);
 if(l > sizel || l == 0) 
    error("tt::fsq: wrong sizel= ", l);
 if(pfsabt==pfs && Abt(a[0]))
  error("fsq1: pfs & Abt(a[0], a[1]= ", a[1], " a[2]= ", a[2]);
 head h; headp g; 
  // h.tel = q; h.t   = undef; h.postfix = 0;  h.adt = 0; h.levsct = istscp; h.l   = l; h.tp  = zel;
 //h.ln  = nstr; h.name = -1; h.scp = scpe;  h.levsct = levsct;  // scope (see scpe)
 inith(&h, pfsabt, l, zel, nstr, lev, isz);
 g = fsq(h, a);
 return g;
} // end fsq1

   headp tt::fsq(head h, elem* a)
{
 long k; headp pnt; elemp q; ats i,lh1,lh = h.l; // bool p = (h.tel == pfs && a[0]==zdot); // char c; 
 if(mm&&sss) ippelm("+fsq a[0]= ", a[0]);
 // if(p) ++lh;                          // one extra element for reduced value of dot term;
 // lh1 = lh + p; 
 lh1 = lh + (h.lth);                     // lth elements for theorems;
 k = sizeof(head) + sizeof(elem)*lh1;
 if(pp) cout<<"+fsq "<<h.tel<<' '<<h.l;  
 pnt = (headp) fylloc("fsq", k);  q = &(pnt->son[0]);           
 *pnt = h;
 for(i=0; i < lh; i++) q[i] = a[i];
 for(i=lh; i < lh1; i++) q[i] = zel; // one extra element for reduced value of dot term; 
 if(aa)cout<<"\n-fsq h.tel= "<<h.tel<<" h.l= "<<h.l<<" k= "<<k << " pnt= "<< int(pnt);
 if(mm&&sss){ *pfhis<<"\n-fsq h.tel= "<<h.tel<<" h.l= "<<h.l<<" k= "<<k; prp(" pnt->tp= ", pnt->tp, pfhis); }
 return pnt;
} // end fsq

  att tt::wrtt(int m, int l, elem* a, att n, att lev, bool fixed, att isz)  // m: mode(pfs,abt), l: l in head;
{                   
 if(mm) ipp("+wrtt tel= ", m, " l= ", l, " n= ", n); 
 // if(m==pfs && !defname(a[0])){ n = findtabt(l,a); goto ret; }  // prognum==numtrm &&
 if(n==emptt) n = newtt("wrtt_mla", fixed); // if(fixed) ++itt; else --itt1;
 if(m==pfs && Abt(a[0])) error("wrtt: m==pfs && Abt(a[0], a= ", a, l-1);
 tabt[n] = fsq1(m,l,a,lev,isz);
 if(aa)ipp("wrtt n= ",n, " tabt[n]= ", int(tabt[n]));
 // if(l==2 && int(a[0].ad)==wrts("Gr") && int(a[1].ad)==wrts("K")) ipp("wrtt: Gr(K), n= ", n);
 // if(isz==0) ipp("wrtt: isz==0: z= ", elm(curm,0,n));
 // if(n==stad2)
 // mm=mm;
 return n;
} // att tt::wrtt(int m, int l, elem* a, att n)

/*   elem tt::findtt(int k, elem* a)    // find in tabt (a0,a1,...,ak-1); for not creating additional terms;
{
 int i,j,n, save=sss; headp h; elemp q; elem x,y,r = zel;  sss = 0;
 if(mm) ipp("+tt::+findtt: k= " , k, " itt= ", itt);
 for(i=0; i < k; i++)                      // ???
 {
  if(mm) pelm(a[i], pfhis); n = a[i].ad;
  if(n > itt) ipp("findtt:  a[i].ad >= itt,  a[i].ad = ", n, " itt= ", itt);
 } // for(i: checking a);
 if(k < 2) error("tt::findtt: wrong k= ", k);
 y = a[1];
 if(int(y.m)==mym && int(y.ad)==itt && mm) ipp("findtt0: y= ", y, " i= ", i); 
 for(i=root; i<itt; i++)                                 // was i<=itt;
 {
  h = tabt[i]; q = &(h->son[0]);
  if(kmain(h)) continue;                                 // qterm or abt term;
  x = q[1]; 
  if(int(x.m)==mym && int(x.ad)==itt && mm) ipp("findtt0: x= ", x, " i= ", i);
  if(k == int(h->l) && q[0]==a[0] && req(q[1], a[1]))
  {
   for(j=2; j < k; j++)
   {
    x = q[j]; y = a[j];
    if(int(x.m)==mym && int(x.ad)==itt && mm) ipp("findtt: x= ", x, " i= ", i);
    if(int(y.m)==mym && int(y.ad)==itt && mm) ipp("findtt: y= ", y, " i= ", i); 
    if(!req(x, y)) goto contfor;
   } // for(j=2);
   r = elm(mym,0,i);
   if(mm) ipp("findtt: found! r= ", r); 
   break;
  } // if(k == h->l ...)
  contfor: ; 
 } // for(i)
 if(mm) ipp("-tt::findtt: r= " , r); sss = save;
 return r; 
} //end tt::findtt
*/
                       // w: write, f: find, h: find and write only atabt, i: find using instance;
 att tt::findtabt(int k, elem* a, char mode, att atabt,elemp az, elem test ) // find in tabt (a0,a1,...,ak-1); 
{                                     // else just find in tabt, return found or emptt,if not found;      
 int i,j=0,j0,jtest= -1,Dj=0, decr,at,count,saveff=ff; bool p,padt=false; headp h; elemp q; att r;  //  ats a1;
 elem z, sc; sbst s;
 if(zz==5) ff=2;
 bool pf = ff && mm; // (prognum!=numtopt && mm);  // printing in findtabt[
 if(pf)
 mm=mm;
 if(k<0){ padt = true; k = -k; }     // ff = (mode=='i');
 if(test != zel)
 {
  if(mel(test, &h,&q) != pfs) error("tt::findtabt:wrong test(not pfs), test= ", test, " a[0]= ", a[0], " a[1]= ", a[1]);
  jtest = hash(h->l, q, &decr);
 } // if(test != zel)
 if(pf) ipp("\n+findtabt: mode= ", mode, " padt= ", padt, " a= ", a, k-1);   // ipps(char* s0, elemp q, int k)
 // if(pf) for(i=206627; i<= 206632; i++) *pfhis << "\n"<< i << ' ' << har[i];
 if(Abt(a[0]) || allex1(a[0])) // bool allex1(elem a){ return a==zall || a==zexist || a==zexist1 || a==zexistx || a==zexist1x; }
    error("findtabt: Abt(a[0] || allex1(a[0])), a= ", a, k-1);
 if(prognum < numtopt) error("findtabt: prognum < numtopt, prognum= ",prognum," numtopt= ",numtopt);
 // if(p){ if(wr) ipp("findtabt: wr==1 ???, a= ", a ,k);  goto ret1; }  // p -> ~wr; == ~p or ~wr == ~(p&wr);
 j = hash(k,a,&decr);   
 count = 0;                                  // count: for checking har overflow;
 ++ findcount;                               // number of calls of findtabt;
 j0 = j;  // wr -> ~p; if(wr) p must be false;
 if(pf) ipp("findtabt: j= hash(k,a), j= ", j, " jtest= ", jtest, " atabt= ", atabt, " ff= ", ff);
 while((at = har[j]) != emptt)
 {
  ++Dj; z = elm(mym,0,at); sc = zel0;
  if(mode=='i'){ sc = scopeden(z); if(sc==zel || sc==zel1) sc = zel0; }
  if(pf) ipp("findtabt:while z:at= ", z, " sc= ", sc, " at= ", at, " j= ", j);
  h = tabt[at]; q = &(h->son[0]);   // scp = h->scp; // was (mode != 'w' || h->name == noname): 4.27.20 
  if((h->tel)==pfs && int(h->l)==k) // && (mode != 'w' || h->name == noname))  // named h not merged, so skipped; 
  {                                 // commented above on 10.17.20
   s.size = 0;
   for(i=0; i<k; i++)
   {
    if(mode=='i')
    { 
     p = s.instance(a[i],q[i],zel0,sc); 
     if(pf) ipp("findtabt:'i' a[i]= ", a[i], " q[i]= ", q[i], " p= ", p, " i= ", i, " at= ", at);
    } // if(mode=='i')
    else p = (a[i] == q[i]);   // 'i': find using instance; 
    if(!p) goto Nxt;                                 // ??? req(a[i],q[i]) ???
   } // for(i)
   z = elm(mym,0,at);                                // Found !!!
   if(mode=='i')
   { 
    if(h->t == truth || h->t == truth3)
           { if(pf)ipp("findtabt:'i': found true z, z= ", z, " a[0]= ", a[0], " a[1]= ", a[1]); r = at; goto ret; }
    if(pf)ipp("findtabt:'i': found z, but not true, continue search, z= ", z); 
    goto Nxt;
   } // if(mode=='i')
   if(pf) ipp("findtabt: found z in har, z= ", z, " j= ", j, " j0= ", j0, " h->adt= ", h->adt, " padt= ", padt);  // ," scp= ", scp );
   if(mode=='w') ++ mergecount; 
   r = at; goto ret;  // found, no writing !!!
  } // if(int(h->tel) == pfs ...)   // named terms cannot be merged: not with named or unnamed terms !!!
  Nxt: if(++count >= sizehar) error("findtabt: overflow of har, sizehar= ",sizehar," count= ",count);
  j = (j + decr) % sizehar;
 } // while(har[j] != emptt)
 
 if(pf) ipp("findtabt: not found, j= ", j);   // har[j] == emptt
 if(mode=='f' || mode=='i'){ r = emptt; goto ret; }
 if(mode=='h')  // change only har: indexation;
 {
  if(pf) ipp("findtabt:h: har[j] = atabt, j= ", j, " atabt= ", atabt);
  har[j] = atabt; r = atabt; goto ret; 
 } // if(mode=='h'
 if(mode != 'w') error("findtabt: wrong mode, mode= ", mode, " a= ", a, k);  // mode = "w", not found, so writing;
 r = newtt("findtabt");
 if(prognum==numtyp && itt==stad2)
  mm=mm;
 har[j] = r;
 if(pf) ipp("findtabt:w: har[j] = r, j= ", j, " r= ", r);
 if(Abt(a[0])) error("findtabt:pfs & Abt(a[0]), a= ", a, k-1);
 h = fsq1(pfs,k,a);
  assert(h->lth != 0);
 if(padt)
 {
  h->adt = 1;
  ipp("findtabt:padt: assigned h->adt = 1, h->son[0]= ", h->son[0], " h= ", int(h));
 } // if(padt)  
 if(vterm(h))
 {
  if(h->lth == 0) error("findtabt: h->lth == 0, h->son[0] = ", h->son[0], " h->son[1]= ", h->son[1] );
  //  --(h->lth);   //  = (att(h->lth) - 1);  2022.01.23
 } // if(vterm(h))
 tabt[r] = h;
 ret:  if(Dj > maxDj) maxDj = Dj;  sumDj += Dj;  // Dj: the number of collisions;
       if(mode=='f' && r != emptt && az != 0) *az = z;
       if(pf) ipp("-findtabt: r= ", r, " Dj= ", Dj); ff = saveff;
       return r; 
} //end tt::findtabt

   elem tt::wrtt(head h, elem* a, att n1)
{ 
 if(mm) ipp("+wrtt a[0] ", a[0], " h.l= ", h.l); 
 att n = n1; elem r=zel; bool p = (prognum > numrnam);
 if(n1==emptt)
 {
   //if(h.tel == pfs) r = findtt(h.l, a);
  // if(r != zel) goto ret;
  n = newtt("wrtth", p);  // in bdef, n will be in itt1..lltt;
 } // if(n1 == -1)
 h.name = noname;  // noname = -1;
 tabt[n] = fsq(h, a);
 r = elm(mym,0,n);
 if(mm) ipp("-wrtt r= ", r); 
 return r;
} //  elem tt::wrtt(head h, elem* a, att n1)

   att tt::wtrm(head h, elem* a, att az, elem t)  // write term into tabt, t: type of the new term( if t != zel);
 { 
 int m = h.tel, hl= h.l; bool p = (prognum > numrnam); elem z;          // int saveff = ff
 if(mm) *pfhis<<"\n+wtrm m= "<< m << " h.t= " << h.t << " hl= " << hl<< " h.tp.ad= "<< h.tp.ad<<" az= "<<az;  
 if(mm) ipp("+wtrm a[0]= ", a[0], "\na[1]= ", a[1], "\na[2]= ", hl < 3?zel:a[2], " t= ", t);
 if(m!=pfs) error("wtrm: wrong m, a[0]= ", a[0], " a[1]= ", a[1], " m= ", m);
 // if(h.tp==zel) error("wtrm:h.tp==zel:test: a[0]= ", a[0], "\na[1]= ", a[1], "\na[2]= ", hl < 3?zel:a[2], " t= ", t,
 //                  " h.l= ", h.l); 
 if(az == emptt)
 {
  if(p)
  { 
   az = findtabt(hl,a);     // findtabt will write(if necessary) to tabt because mode=='w'!!
   if(mm) ipp("wtrm:after findtabt, a[0] ",a[0], " a[1]= ",a[1], "\nh.tp= ", h.tp, " tabt[az]->tp= ", tabt[az]->tp,
                                                  " az= ",az, " itt= ",itt);
   if(az < itt)
   {
    if(mm) ipp("wtrm: az < itt, a[0]= ",a[0], " a[1]= ",a[1], "\nh.tp= ", h.tp,
                         " tabt[az]->tp= ", tabt[az]->tp,  " az= ",az, " itt= ",itt);
    if(tabt[az]->tp == zel)
    {
     if(99) ipp("wtrm: az<itt:tabt[az]->tp==zel  \na[0]= ",a[0]," a[1]= ",a[1], "\nh.tp= ", h.tp," az= ",az," itt= ",itt);
     if(h.tp != t) ipp("wtrm: h.tp != t, h.tp= ", h.tp, " t= ", t);
     if(h.tp != zel) tabt[az]->tp = h.tp;
    } // if(tabt[az]->tp == zel)
    goto ret;
   } // if(az < itt)
   if(az != itt) error("az != itt, a[0]= ",a[0], " a[1]= ",a[1], "\na[2]= ", hl < 3?zel:a[2], "\nh.tp= ", h.tp,
                                                  " az= ",az, " itt= ",itt);  
   tabt[az]->tp = h.tp; goto ret;
  } // if(p)
  if(mm) ipp("wtrm: prognum <= numrnam, a[0]= ", a[0], "\na[1]= ", a[1], "\na[2]= ", hl < 3?zel:a[2]);
  az = newtt("wtrm",p); tabt[az]->tp = h.tp;
  // goto ret;
 } // if(az == emptt)
 if(mm) ipp("wtrm:az != emptt, using fsq(h,a) a[0]= ", a[0], "\na[1]= ", a[1], "\na[2]= ", hl < 3?zel:a[2], " az= ",az); 
 tabt[az] = fsq(h, a); 
 if(mm) ipp("wtrm: after fsq(h,a), a[0]= ",a[0], " a[1]= ",a[1], "\nh.tp= ", h.tp,
                         " tabt[az]->tp= ", tabt[az]->tp,  " az= ",az, " itt= ",itt);                   
 ret: z = elm(mym,0,az);
 if(mm) ipp("-wtrm z= ", z, " tabt[az]->tp= ", tabt[az]->tp, " az= ", az); // ff = saveff;
 if(h.postfix && (h.l != 2)) 
       error("tt::wtrm: z= ", z);
 return az;
}

 // if(az == emptt) az = p? findtabt(hl,a): newtt("wtrm",p); // findtabt will write to tabt because mode=='w'!!
 // else tabt[az] = fsq(h, a); 

/*   elem tt::wrtt(int m, int i, elem* a, att n)
{
 if(pp)cout<<"wrtt"<<m<<' '<<i<<' '<<a<<' '<<n;
 if(n==emptt){ n = newtt("wrtt_emptt"); tabt[n] = fsq1(m,i,a); }
 return n;
}
*/
   att tt::trm1(elem f, elem x1, int line)
{
 if(pp)ipp("+tt::trm1 f= ", f, " x1= ", x1);
 head h; att n; elem z[2];
 z[0] = f; z[1] = x1;  
 // h.tel = pfs; h.l = 2; h.t = undef; h.tp = zel; h.ln = line;
 inith(&h, pfs, 2, zel, line);
 n = newtt("trm1");   // 1 - terms, 0: definitions
 tabt[n] = fsq(h, &z[0]);
 if(pp) ipp("-tt::trm1 n= ", n);
 return n;
} // end tt::trm1

   elem tt::trm1e(elem f, elem x1, elem t)
{
 if(pp) ipp("+tt::trm1e f= ", f, " x1= ", x1);
 headp h;
 int a = trm1(f, x1, 999);
 elem r = elma(0, a);
 if(adel(r, &h)) error("trm1e: r= ", r);
 h->tp = t;
 if(pp) ipp("-tt::trm1e r= ", r);
 return r;
} // end tt::trm1e

   att tt::trm2a(elem f,elem x1,elem x2,int k)
{
 if(pp){cout<<"\ntt::trm2:";pelm(f);pelm(x1);pelm(x2);
        cout<<k; pcin();}
 head h; att n; elem z[3];
 z[0] = f; z[1] = x1; z[2] = x2; 
 // h.tel = pfs; h.l = 3; h.t = undef; h.tp = zel; h.ln = k;
 inith(&h, pfs, 3, zel, k);
 n = newtt("trm2a");   // 1 - terms, 0: definitions
 tabt[n] = fsq(h, &z[0]);
 return n;
} // end trm2

   elem tt::trm2e(elem f, elem x1, elem x2, elem t)
{
 headp h;
 int a = trm2a(f, x1, x2, 999);
 elem r = elma(0, a);
 if(adel(r, &h)) error("trm2e: r= ", r);
 h->tp = t;
 return r;
} // end trm2e  

   void tt::ptbt(int i)
{
 headp h; // char c; 
 cout<<"tabt("<<i<<")=(";
 *pfhis<<"tabt("<<i<<")=(";
 h = tabt[i]; 
 if(h==0) { cout << "h-ERROR i= "<<i; *pfhis << "h-ERROR i= "<<i; goto ret; } 
 ph(h, pfhis); 
 ret:;
} // end ptbt

   void tt::ptbtp(int i)
{
 headp h; int j; // char c;
 
 cout<<"\nptbtp i= "<<i<<" tel=";  // mym="<<mym
 *pfhis<<"\nptbtp i= "<<i<<" tel="; // mym="<<mym<<" 
 h = tabt[i]; if(h==0) error("ptbtp h=0 i=",i);
 cout<<h->tel<<" t="<<h->t<<" h->l="<<h->l;
 *pfhis<<h->tel<<" t="<<h->t<<" h->l="<<h->l;
 
 for(j=0; j<len(h); j++)
 {
  *pfhis <<"\n"<<j<<") "; prp(h->son[j], pfhis);
 } // for(j)
} // end ptbtp

   elem tt::eqvl(elem z, int p, sbst* as)  // p=1: find an instance of x 
{ 
 return zel;   // see tot.cpp
}

   // void tt::incr(int *) { error("incr"); }; // see tot.cpp

   void tt::prht(class ofstream *) { error("prht"); } // see tot.cpp

 //   int tt::hash(struct head,struct elem *) { return 0; }

/*   int tt::check(char* b, int b1)
{
 //static long s;
 ipp("check: rework!"); return 1;
} // end check
*/
  bool tt::istr2(elem f,elem a1, elem a2, elem d,elemp az)         // is true f(a1,a2): search in tabt
{
 bool r = false; att a; elem z, q[2]; // int saveff = ff;// q[0] = f; q[1] = a1; q[2] = a2;
 if(mm) ipp("+tt::istr2: f= ", f, " a1= ", a1, " a2= ", a2, " mym= ", mym);
  if(check(f.ad, stad) && check(a1.ad, stad1) && check(a2.ad, stad2))
  mm=mm;
 q[0] = f; q[1] = a1; q[2] = a2;
 // ff = mm;
 a = findtabt(3,q,'f',emptt,az);              // 'f' means: only find, not write;
 // ff = saveff;
 if(a==emptt){ if(mm) ipp("tt::istr2: not found, f= ", f, " a1= ", a1, " a2= ", a2); goto ret; }
 z = elm(mym,0,a); // tr = tabt[a]->t;
 if(Truth(tabt[a])){ if(mm)ipp("tt::istr2: found!!!, f= ", f, " a1= ", a1, " a2= ", a2, " z= ", z); r = true; goto ret; }
 if(mm) ipp("tt::istr2: found, but not true, f= ", f, " a1= ", a1, " a2= ", a2, " z= ", z, " tr= ", tabt[a]->t);
 r = istr0(z,d);                    // look for possible theorem z (or A[z,d]) in lot and thmbase
 if(r==true) if(mm) ipp("tt::istr2: f= ",f," a1= ", a1, " a2= ", a2);
 ret: if(mm) ipp("-tt::istr2: f= ", f, " a1= ", a1, " a2= ", a2, "\nr= ", r);
 return r;
} // end bool tt::istr2

  bool tt::istrf(elem z, char mode, elem test)      // look in tabt for a theorem z, using findtabt; mode = f,i;
{
 bool r = false; att a=emptt,m;  headp h; elemp q;  int savesumDj = sumDj;   // int saveff = ff;
 if(mm) ipp("+tt::istrf z= ", z, " test= ", test, " mode= ", mode);
 if(mode != 'f' && mode != 'i') error("istrf: mode is not 'f' or 'i', z= ", z, " mode= ", mode);
 m = mel(z,&h,&q);
 if(simple(m)){ ipp("tt::istrf: simple(m), z= ", z, " m= ", m); if(z==ztrue) r = true; goto ret; } 
 if(m != pfs) error("tt::istrf: m != pfs, z= ", z, " m= ", m);
 if(typ(z) != zbool)  error("tt::istrf: typ(z) != zbool, z= ", z);
 // if(mm) ff=2;
 a = findtabt(h->l,q,mode,emptt,0,test);
 if(a==emptt){ ipp("tt::istrf: not found, z= ", z, " mode= ", mode); goto ret; }
 if(tabt[a]->t == truth) r = true; else ipp("tt::istrf: found, but not true, z= ", z, " mode= ", mode);
 ret: if(mm) ipp("-tt::istrf z= ", z, " a= ", a, " Dj= ", sumDj-savesumDj, " r= ", r);  // ff=saveff;
      return r;
} // end bool tt::istrf(elem z)

  bool tt::istr2inst(elem f, elem a, elem b)  // looking for the theorem "f(a,b)",using instance;
{
 bool r = false; att at; elem z, q[2]; int saveff = ff; // q[0] = f; q[1] = a1; q[2] = a2;
 if(mm) ipp("+tt::istr2inst: f= ", f, " a= ", a, " b= ", b, " mym= ", mym);
 // if(mm) ff=2; 
  if(check(f.ad, stad) && check(a.ad, stad1) && check(b.ad, stad2))
  mm=mm;
 q[0] = f; q[1] = a; q[2] = b;
 at = findtabt(3,q,'i');              // 'f' means: only find, not write; // 'i' means "use instance";
 if(at==emptt){ if(mm) ipp("tt::istr2inst: not found, f= ", f, " a= ", a, " b= ", b); goto ret; }
 if(Truth(tabt[at])) { r = true; goto ret; }
 if(mm) ipp("tt::istr2inst: found, but not true, f= ", f, " a= ", a, " b= ", b);
 z = elm(mym,0,at);
 // r = istr0(z,d);
 ret: if(mm) ipp("-tt::istr2inst: f= ", f, " a= ", a, " b= ", b, "\nr= ", r); ff=saveff;
 return r;
} // end bool tt::istr2

  bool nonempty(elem z)
{
 elem t; bool r;
 if(mm) ipp("+nonempty: z= ", z);
 t = typ(z);
 r = fnt1(t,zP1) || istr2(zneq,z,zemp);
 if(mm) ipp("-nonempty: z= ", z, " t= ", t, "\nr= ", r);
 return r;
} // bool nonempty(elem z)

 bool notempty(elem z)              // looking for the theorem "z ~= {}",using instance???
{
 bool r = true; headp h; elemp q; elem z1;
 if(mm) ipp("+notempty: z= ", z);
 if(mel(z,&h,&q) == pfs)
 {
  if(q[0]==zfn) goto ret;
 } // if(mel(...)
 z1 = strip(z, zP);
 r = istr2(zneq,z1,zemp);        // was  r = istr2inst(zneq,z,zemp);  // zemp: {}
 ret: if(mm) ipp("-notempty: z= ", z, " z1= ", z1, " r= ", r);
 return r;
} // bool notempty(z)

/*   bool istr3(elem x, elem f1, elem f2, elemp Q, elemp M)  // istr3(x,zin,zdot,&Q,&M): x in Q.M is true;
{
 ats i,k; headp g; elemp q,w; elem z; bool r = false;
 if(mm) ipp("+istr3: x= ", x, " f1= ", f1, " f2= ", f2);
 // k = thmbase(x, &q);
 for(i=0; i<k && (z=q[i]) != zel; i++)
  if(fnt2h(z,f1,&g,&w) && g->t && x==w[1] && fnt2(w[2],f2,Q,M)) { r = true; break; }
 if(mm) ipp("-istr3: x= ", x, " f1= ", f1, " f2= ", f2, " r= ", r);
 return r;  
} // end bool istr3
*/
   bool istr2(elem f,elem a, elem b, elem d,elemp z)         // is true f(a,b): search in tabt
{
 bool r=false; int i; elem x,y,a1,a2,b1,b2,t; int static rec_count = 0;
 if(mm) ipp("+istr2 f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 if(f.m==0 && f.ad==0 || a.m==0 && a.ad == 0)
  error("istr2: wrong(0,0,0) f or a, f= ", f, " a= ", a, " b= ", b); // group && finite <: group
 if(++rec_count > 50) error("istr2: rec_count > 50, f= ", f, " a= ", a, " b= ", b, "\nd= ", d);
 t = Abt1(b);                      //   ??? remove comment ??? 2.1.20 move to f==zin ???
 if(t!=zel){ ipp("istr2:t := Abt1(b): b := t, b= ", b, " t= ", t); b = t; } 
 if(f==zin)
 {
  if(b==zset || b==zany){ r= true; goto ret; }
 } // if(f==zin)  
 if(f==zincl)
 { 
  if(a==b){ r = true; goto ret; }                            // X <: X;
  if(b==zFN && fntype(a)){ r = true; goto ret; }  // fn(X,Y) <: FN
  if(fnt2(a, zdconj, &x,&y) && b==x){ r = true; goto ret; }  // d&&P <: P;
  if(fnt2(a,zdp,&a1,&a2) && fnt2(b,zdp,&b1,&b2) && istr2(zincl,a1,b1) && istr2(zincl,a2,b2))
    { r = true; goto ret; }                                  // a1<:b1 && a2 <: b2 -> a1#a2 <: b1#b2;  
  if(fnt1(a,zcrlf,&x) && istr2(zin,x,b)){ r = true; goto ret; }          // {x} <: b == x in b;                         
 } // if(f==zincl)
 r = invith2(f,a,b); if(r) goto ret;
 for(i=0; i <= ieul; i++)
  if(clad[eul[i]]->istr2(f,a,b,d,z)){ r = true; goto ret; } 
 r = inlot2(f,a,b);
 ret: if(mm) ipp("-istr2 f= ", f, " a= ", a, " b= ", b, " r = ", r);
 if(--rec_count < 0) error("istr2: rec_count < 0, f= ", f, " a= ", a, " b= ", b, "\nrec_count= ", rec_count);
 return r;
} // bool istr2

   bool istr2c(elem f,elem a, elem b)  // same as istr2, but search only in current tabt;
{
 bool r; // int i; 
 if(mm) ipp("+istr2c: f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 if(f.m==0 && f.ad==0 || a.m==0 && a.ad == 0)
  error("istr2c: wrong(0,0,0) f or a, f= ", f, " a= ", a, " b= ", b);
 r = invith2(f,a,b); if(r) goto ret;
 // for(i=0; i <= ieul; i++)
 if(ptt->istr2(f,a,b)){ r = true; goto ret; } 
 r = inlot2(f,a,b);
 ret: if(mm) ipp("-istr2c: f= ", f, " a= ", a, " b= ", b, " r = ", r);
 return r;
} // bool istr2c

 bool istr2inst(elem f, elem a, elem b)  // looking for the theorem "f(a,b)" in the current tab,using instance;
{                                        // then
 bool r; // int i; 
 if(mm) ipp("+istr2inst: f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 if(f.m==0 && f.ad==0 || a.m==0 && a.ad == 0)
  error("istr2c: wrong(0,0,0) f or a, f= ", f, " a= ", a, " b= ", b);
 r = invith2(f,a,b); if(r) goto ret;
 // for(i=0; i <= ieul; i++)
 if(ptt->istr2inst(f,a,b)){ r = true; goto ret; } 
 r = inlot2(f,a,b);
 if(r) ipp("istr2inst: inlot2 found f(a,b) in lot, f= ", f, " a= ", a, " b= ", b, " ilot= ", ilot);
 ret: if(mm) ipp("-istr2inst: f= ", f, " a= ", a, " b= ", b, " r = ", r);
 return r;
} // bool istr2inst


  elem tt::istr2a(elem f, elem a)                       // is true f(a,r);
{
 int i; elem a1,P,Q,t, r = zel; headp h; sbst s; // curtritt !!!
 achs g(a); pntu->copy(&g);
 if(mm) ipp("+tt::istr2a: f= ", f, " a= ", a, " mym= ", mym, " ilot= ", ilot);
 for(i=0; i <= lview; i++)
 { 
  Q = g.prevt(pntu, i);
  if(Q==zel ) break;   //if(separ(Q)) break;  // { p = false; if(T==zel) break; continue; }
  if(hhh) ipp("tt::istr2a: found in tabt true  Q= ", Q, " f= ", f, " a= ", a, " i= ", i);
  h = tabt[Q.ad];
  if(h->l==3)
  {
   s.size = 0;
   if(h->son[0] == f && s.instance(a, h->son[1]))   // was req // was false: stripped bvar can be; 
   {
    // if(hhh) ipp("tt::istr2a: f= ", f, " son1= ", h->son[1], " p1= ", p1, " ilot= ", ilot); 
    r = s.rep(h->son[2],"tt::istr2a_1"); break;
   } // if(h->son[0] == f ...)
   s.size = 0;
   if(fnt22r(h->son[0],zimp,f,&P,&a1,&t) && s.instance(a,a1) && inlot(s.rep(P,  "tt::istr2a_2")) )
   { 
    r = s.rep(t,"tt::istr2a_3");  break;
   } // 
  } // if(h->t)
 } // for(i)
 if(mm) ipp("-tt::istr2a: f= ", f, " a= ", a, " r= ", r, " i= ", i);
 return r;
} // end elem tt::istr2a(elem a)

   elem istr2a(elem f, elem a)            // is true in(a,r); total search in all tabts
{
 elem r = zel; int i; 
 if(mm) ipp("+istr2a: f= ", f, " a= ", a, " ieul= ", ieul);
 for(i=0; i <= ieul; i++)
 {
  r = clad[eul[i]]->istr2a(f,a);
  if(r != zel) goto ret;
 } // for(i)
 r = inlot2a(f,a);
 ret: if(mm) ipp("-istr2a: f= ", f, " a= ", a, " r= ", r);
 return r;
} // end elem istr2a(elem f, elem a)

 int comparfreqts(const void* p1, const void* p2)
{
 int i1 = *(int*)p1; int i2 = *(int*)p2; 
 int val1 = ptt->freqts[i1];
 int val2 = ptt->freqts[i2];
 int p = 0;
 if(val1 < val2) p = 1;
 else if(val1 > val2) p = -1;
 return p;
} // end comparfreqts

 void tt::prfreqts()                // sorting freqts, creating file source.freq and writing freqts to the file;
{
 char y[80]; int i,j; int ar[6000];          // make #define
 ipp("+prfreqta source= ", source, " its= ", its);
 if(its >= 6000) error("prfreqts: its >= 6000, its= ", its);
 for(i=0; i<=its; i++) ar[i] = i; 
 qsort(ar, its+1, sizeof(int),comparfreqts);
 strcpy(y,source);    // char c; 
 strcat(y, ".freq");
 ofstream f(y,ios::out);
 if(!f)cerr<<"\ncannot open file "<<y, exit(1);
 f << "\n       Sorted ar using freqts "<<"\n";
 for(i=0; i<=its; i++)
 {
  j = ar[i];
  f << "\n"<<i<<"  " << vts(j) << "  " << freqts[j];
 } // for(i)
 f.close();
 ipp("-prfreqta source= ", source, " its= ", its); 
} // end void tt::prfreqts()

   void tt::futt(char* y1)                 // printing tabt // y1 = source
{
 aa=0; cout<<"\n+futt: y1= "<<y1<<" lltt= "<<lltt<<" itt= "<<itt; char y[80];
 *pfhis<<"\n+futt: y1= "<<y1<<" lltt= "<<lltt<<" itt= "<<itt;
 strcpy(y,y1);    // char c; 
 strcat(y, ".tbt");
 ofstream ftt(y,ios::out);
 if(!ftt)cerr<<"\ncannot open file "<<y,exit(1);
 pftbt = &ftt;
 futt(&ftt);
 cout << "\n-futt "<< y1;
 *pfhis << "\n-futt "<< y1;
} // end futt()

   void tt::futt(ofstream* f)              // printing tabt
{
  att i,k,j; att hl,last; headp h; elemp q;  elem z,y,T; static int countrec = 0;  
 char* heading1 = "tel t pf adt at v l ln "; mm=0; 
 zeltype = 0;  countctruth = 0; countbadthms = 0; errprint = 0; 
 char* heading2 = "name       tp    lth lev      elements"; // tp:4, scp:1;
 *f <<"\ndirname= "<<dirname<<"  ieul= "<<ieul<<" eul= ";
 for(i=0; i<=ieul; i++) *f << i << ':'<<eul[i]<<' ';
 i = 0; last = itt;
 if(prognum <= numtopt) last = lltt;
 cout<<"\n+futt f= "<<f<<" mym=" <<mym<<" lltt= "<<lltt<<" itt= "<<itt<<" last= "<<last; 
 *pfhis<<"\n+futt f= "<<f<<" mym=" <<mym<<" lltt= "<<lltt<<" itt= "<<itt<<" last= "<<last; 
 *f<<"time = "<<mytime()<<"\nitt="<<itt<<"\nlltt= "<<lltt << " mym=" << mym <<
      "\niden="<<iden<<"\nroot="<<root<<"\niallm="<<iallm; // <<"\nmym="<<mym;
  cout<<"\n+futt itt= "<<itt<<" lltt= "<<lltt;
 if(++countrec > 1) 
 {
  *pfhis << "\nfutt: Error recursive call\n\n\n ";
  cout << "\nfutt: Error recursive call\n\n\n ";
  pfhis->close();
  int x=0; beep(2); 
  if(9) x = 1/x; //cpp("exit1: 1/0"); //???11/27/99
  exit(1);
 }
 while(i <= last)
 {
  h = tabt[i];
  if(h == 0){ *f << "\nERROR: futt: tabt[i]=0, i= " << i;   goto Cont; }
  hl = h->l;
  z = elm(mym,0,i);
 /* if(h->t == ctruth)
  { 
   *pfhis << "\nfutt: h->t == ctruth: "<< ++countctruth; 
   prp(" z= ", z, pfhis) ;  
  } // if(h->t == ctruth)
		*/
  if(yy) *f <<"futt i= " << i;
    //if(itt>1000 && i%100 == 0) cout<<'*';
   // s = vts(i);
  q = &(h->son[0]); 
  // cout<<'\n'<<(i==root?"RRR":"s")<<'('<<i<<')';
  // cout<<h->tel<<' '<<h->t<<' '<<h->levsct<<' '<<h->l<<' '<<h->ln<<' '<<h->name; pelm(h->tp,f); 
  // cout<<": "; k=len(h); 
  if(i % sizepage == 0)
  { 
   *f<<"\n";  spacesf(f, numdig(i)-1); *f << heading1;
   spacesf(f, numdig(h->ln)-1); *f << heading2;

   if(yy){ *pfhis<<"\n";  spacesf(pfhis, numdig(i)-1); *pfhis << heading1;
   spacesf(pfhis, numdig(h->ln)-1); *pfhis << heading2; }
  } // if(i % sizepage == 0)

  *f<<'\n'<<(i==root?"RRR ":"")<<i<<':';  if(yy) *f<<'\n'<<(i==root?"RRR ":"")<<i<<':';
  // cout<<'\n'<<(i==root?"RRR ":"")<<i<<':';
  // s = "888";  // s = svel(h->scp);
  *f<<h->tel<<' '<<h->t<<' '<<h->postfix<<"  "<<h->adt<<"   "<<h->at<<"  "<<h->v<<" "<<h->l<<' '<<h->ln<<' '<<h->name;
  spacesf(f, 4 - numdig(h->name));
  pelm(h->tp,f); *f<<": "<< h->lth <<" "<<h->levsct<<" ";
  if(yy){
  *pfhis<<h->tel<<' '<<h->t<<' '<<h->postfix<<"  "<<h->adt<<"   "<<h->at<<"  "<<h->v<<" "<<h->l<<' '<<h->ln<<' '<<h->name;
  spacesf(pfhis, 4 - numdig(h->name));
  pelm(h->tp,pfhis); *pfhis<<": "<< h->lth <<" "<<h->levsct<<" "; }
 
   k = numsonthm1(h);     // len(h);   // <<':'
  /*if(k > int(h->l))    // int(p->l)+2
  {
   ptbt(i);
   *pfhis << "\futt: wrong k= " << k;
  	*f << "\nwrong k= " << k;
  } // end if(k)
  */
  for(j=0; j<hl; j++)
  { 
  y = q[j];
  pelm(y, f); *f << " "; if(yy){ pelm(y, pfhis); *pfhis << " "; }
  if(prognum > numtopt && (badm(y.m) || y.m <= mym && y.ad > clad[y.m]->itt) )
  {
   *f << "\nERROR:wrong y.m or y.ad, i= " << i <<" j= "<<j << " y.m= " << y.m << " y.i= " << y.i<< " y.ad= "<<y.ad; 
   *pfhis << "\nERROR:futt:wrong y.m or y.ad, i= "<<i << " j= "<<j<< " y.m= " << y.m << " y.i= " << y.i<< " y.ad= "<<y.ad; 
   ++badelem;   
   // f->close(); pfhis->close(); beep(2); exit(1); continue;
  } // if(badm ...)
  // *f << ' ';
  } // for(j)
  if(h->name != noname) *f << vts(h->name)<<"  ";
  if(hl < 5) prp(" ", z, f);                       // make 5 variable (dd) ???
  if(h->tel==pfs && Abt(q[0]) || (h->tel==abt && !Abt(q[0])))
  { 
   *f << "\nERROR: pfs & Abt(q[0]) or abt & not Abt(q[0])\n";
   *pfhis << "\nfutt: i= "<<i << " ERROR: pfs & Abt(q[0]) or abt & not Abt(q[0])\n";
  } // if(h->tel==pfs && Abt(q[0]) || h->tel==abt && !Abt(q[0]))

  if(h->tp == zel) ++zeltype;
  if(h->tp == zel || comp(h->tp) ) prp("\ntype: ", h->tp, f);

  if(h->lth == 0) goto Cont;
  // if(h->lth > 100) ipp("futt: block size > 100, z= ", z, " bsz= ", h->lth);
  
  *f << "\nthms: ";
  for(j=hl; j<k && q[j] != zel; j++)
  { 
   T = q[j]; 
   if(badel(T))
   { 
    *f << "\n\nbadel:thms: tabt: i= "<< i<< " k(thms)= "<< k<< " j= "<< j<< " T.m= "<< T.m<< " T.i= "<<T.i<<
         " T.ad= "<<T.ad;
    *pfhis << "\n\nbadel:thms: tabt: i= "<< i<< " k(thms)= "<< k<< " j= "<< j<< " T.m= "<< T.m<< " T.i= "<<T.i<<
     " T.ad= "<<T.ad;
    ++badelem; 
   } // if(badel(T))
   prp(" ", T,f);  // pelm(y,f); *f << " ";
   if(j==hl && h->v) continue;              // value element;
   if(badthm(T))                            // not bool, not truth;
   { 
    ++countbadthms; 
    *f<<"\nfutt: Bad theorem T, i= "<< i; prp(" T= ", T, f); *f<<"\n"; 
    *pfhis<<"\nfutt: Bad theorem T, i= "<< i; prp(" T= ", T, pfhis); *pfhis<<"\n";
    cout<<"\nfutt: Bad theorem T, i= "<< i; prp(" T= ", T);  cout<<"\n";
   } // if(badthm(T))
  } // for(j)
  Cont: if(++i == itt+1 && prognum <= numtopt) i = itt1;   // skipping free space
 } // end while i
 *f << "\n\ncountctruth= " << countctruth;
 *pfhis << "\n\ncountctruth= " << countctruth;
 cout << "\n\ncountctruth= " << countctruth;
 f->close();
 *pfhis << "\nfinished futt, itt= " << itt << " badelem= " << badelem<< " zeltype= " <<zeltype<<" countbadthms= "<<countbadthms; 
  cout << "\nfinished futt, itt= " << itt << " badelem= " << badelem<< " zeltype= " <<zeltype<<" countbadthms= "<<countbadthms; 
       --countrec;
  if(badelem || countbadthms)   // || prognum==numtyp && zeltype 
  { 
   *pfhis<<"\n ERROR: badelem || countbadthms";
   cout<<"\n ERROR: badelem || countbadthms"<<"\n\n";
    uden(); 
    fprp(source);
    //   prlot("myexit"); 
    // if(prognum==numtrm) prstcont("myexit");
    // else pntu->prach("myexit");
    finish("futt: badelem || countbadthms: ERROR in ", source); // pfhis = pfmainhis;    // pfmainhis->close(); 
    beep(2);                           // cout << '\a';    // beeping
    *pfhis<<"\n ERROR: badelem || countbadthms"<<"\n\n\n"; // || zeltype
    pfhis->close(); 
    cout<<"\n ERROR: badelem || countbadthms"<<"\n\n\n";    //  || zeltype // pfmainhis->close(); 
    exit1();
   }  // if(badelem || countbadthms)                        //  || zeltype
} // end futt(ofstream* f)

   elem newp(headp h, elemp* q)
{       
 headp g;   // ??????
 int n = 0; // ptt->newtt(h->tel != pdf);  // 1 - terms, 0 - definitions
 if(mm) ipp("newp h->l= ", h->l, " tel= ", h->tel, " n= ", n);
 // assert(n >= 0 && n <= ptt->ittd);
 g = (headp)fylloc("newp", sizeof(head) + (h->l)*sizeof(elem));
 ptt->tabt[n] = g;
 *g = *h;
 g->tp = zel; g->ln = 999; //  g->t = 0 g->b = 0;
 *q = &(g->son[0]);
 return elma(0, n);
} // end newp

  void Constnames(elem z, elem ar[], int sizear, int* iar)
{
 int i,m,hl; headp h; elemp q;
 if(zz==4) ipp("+Constnames z= ", z, " sizear= ", sizear);  // , " iar0= ", iar0);
 if(emptpl(z)) goto ret;
 if(Const(z))
 { 
  Wr: if(++(*iar) >= sizear)
  {
   ipp("Constnames: overflow of ar, z= ",z," *iar= ", *iar, " sizear= ",sizear);
   *iar = sizear/10;        // ??? 2022.09.20 ???
  } else ar[*iar] = z;
  goto ret;
 } // if(Const(z))
 m = mel(z,&h,&q); 
 if(m==abt) goto Wr;
 if(m==pfs) 
 {
  hl = h->l;
  if(q[0]==zcol)
  { 
   if(zz==4) ipp("Constnames: skipping conv.term type z= ", z);
   Constnames(q[1], ar, sizear, iar); goto ret; 
  } // if(q[0]==zcol)
 
  if(q[0]==zdot){ Constnames(q[0], ar, sizear, iar);  Constnames(q[2], ar, sizear, iar); goto ret; }  // skipping q[1]
   
   // q[0] != "*" && q[0] != "!"
  if(!isovname(svel(q[0])))   Constnames(q[0], ar, sizear, iar);
  for(i=1; i<hl; i++) Constnames(q[i], ar, sizear, iar);
 } // f(m==pfs)  
 ret: if(zz==4) ipp("-Constnames z= ", z, " iar= ", *iar);  // " sizear= ", sizear
} // end void Constnames

  int hashel(elem z)
{
 int r, zm = z.m, zi = z.i, zad = z.ad;
 if(zm >= maxmod) r= (zm*4096 + zad)*16; // because z.ad <= 4096; // size of ts;
 else r = (zm + zi + zad)*32 + 1;  //   * 4;
 return r;
} // end hashel

/*  int hash(int k, elemp a, int* decr) 
{
 int r, sum = 0, i,m; elem x;

 for(i=0; i < k; i++)
 { 
  x = a[i]; m = mel(x); 
  if(m==var || m==bvar) continue;
  sum = sum + hashel(x);
 } // for(i)
 r = (sum % sizehar);                  //  & all1but31;      // even
 *decr =   1;                          // (sum / 4096) | 1;  // odd (r%8) | 1;  try !!!;
 return r;
} // end hash
*/
  int hash(int k, elemp q, int* decr) 
{                                                  // a1= GrH#8838  a2= fingroup#10751  mym= 0
 int r,i,h, sum = 0, iar = -1; elem x; elem ar[maxvars];
 // bool p = (k==3 && q[0]==zin && q[1].ad==8838 && q[2].ad==10751);
 // if(p) ipp("+hash: q[0]= ", q[0], " q[1]= ", q[1], " q[2]= ", q[2], " k= ", k);
 if(ff==2) ipp("+hash, q= ", q, k);
 for(i=0; i < k; i++)  Constnames(q[i], ar, maxvars, &iar);
 if(ff==2) ipp("hash: Constant names k= ", k, " iar= ", iar); 
 for(i=0; i <= iar; i++)
 { 
  x = ar[i]; 
  if(ff==2){ *pfhis << "\n"<<i<<' '; prp(ar[i], pfhis); }
  sum = sum + (h=hashel(x));
//  if(p) ipp("hash: x= ", x, " i= ", i, " h= ", h, " sum= ", sum);
 } // for(i)
 r = (sum % sizehar);                  //  & all1but31;      // even
 *decr =   1;                          // (sum / 4096) | 1;  // odd (r%8) | 1;  try !!!;
 // if(p) ipp("-hash: q[0]= ", q[0], " q[1]= ", q[1], " q[2]= ", q[2], " iar= ", iar, " r= ", r);
 if(ff==2) ipp("-hash r= ", r, " mm= ", mm);
 return r;
} // end hash