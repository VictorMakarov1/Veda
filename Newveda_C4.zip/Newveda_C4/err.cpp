#include "lib.h"   //9/12/97  01/08/00 05/08/00 07/13/00 08/08/00
#include "achs.h"
#include "sbs.h"   //05/15/01
#include "tt.h" 
#include "adl.h"
#include "glex.h"
#include "lot.h"
#include "err.h"
#include "elem.h"
extern int errlines[maxerrmsg];
extern int maxl;                  // maximal size of v-line;
extern char* errmsgs[maxerrmsg]; 
extern ofstream* pfhis;
extern ofstream* pftbt;
extern ofstream* pfmainhis;
extern int icont,iallm,counterrmsg,Maxipp;
extern char cont[lcont];
extern char cont1[lcont];
extern char cont2[lcont];
extern char source[80];
extern bool errprint;
extern int prognum,numtrm,nummacr,numbdef,numrnam,numtopt,numtyp,ee,ilot,mergecount,findcount;
extern achs* pntu;
extern clock_t start, end;
void print_stparinst();
void prlot(char* s);
// ostream& prp1(elem z, ostream& f=&cout);
// void prp(elem z, ofstream* f = 0);
// std::ostream& dump(std::ostream &o, const point<T>& p)
// {
//    return o << "x: " << p.x << "\ty: " << p.y << std::endl;
// }
// void prp1(elem z, ofstream* f);
// ostream& operator<<(ostream &out,  elem z) // output
// {
//  prp1(z, &out);   // error: cannot cast ostream* to ofstream*; 
//  return out;
//} // end operator<<

     void exit1()
{
 // cout<<"\nexit1: exit1() is working ";
 // *pfhis<<"\nexit1: exit1() is working ";
 //pfhis->close(); //pfprp->close(); // problem! 7/25/97
 // int x=0; beep(2);
 // x = 1/x; //cpp("exit1: 1/0"); //???11/27/99
 exit(1);
}

    void myexit(int k)    // k=1: ADEL
{
 int static count = 0; // char c;
 if(prognum==numtyp) time_typa = myclock("-typa: error exit ");
 if(++count > 1) return;  
 //  errprint = false;
 cout<<"\nmyexit: prognum= "<<prognum<<" source = "<<source<<"\nerr:";
 *pfhis<<"\nmyexit: prognum= "<<prognum<<" source = "<<source<<"\nerr:";
  ptt->futt(source);  
  ptt->uden(); 
  ptt->fprp(source);
 // if(k==0 && count == 1 && prognum != numtrm) ptt->fprp(source);//  ptt->uden(); }
 prlot("myexit"); 
 if(idep != -1) prdep();
 if(prognum==numtrm) prstcont("myexit");
 else pntu->prach("myexit");
 finish("ERROR in ", source);
 beep(2);                           // cout << '\a';    // beeping
 -- count;
 exit1();
} // myexit


    void err()
{
 // cout<<"\nerr:\n\n\n";
 //*pfhis<<"\nerr:\n\n\n";
 //ipp("err() is working");
 // cont[icont+1]=0;
 if( prognum == numtrm)
 {
  cout<<"\nnstr= "<<nstr<<" context(3 lines): \n"<<cont2 <<"\n"<<cont1<<"\n"<<cont <<
       "\nicont= "<<icont<<"\nmicrocontext from icont-2 until EOL: ";
  *pfhis<<"\nnstr= "<<nstr<<" context(3 lines): \n"<<cont2 <<"\n"<<cont1<<"\n"<<cont <<
       "\nicont= "<<icont<<"\nmicrocontext from icont-2 until EOL: ";
 
  // pst("err");
  for(int i = icont-2; cont[i] != 0 ; i++)
  {
   if(i >= maxl)                        // was lcont
   {
    cout<< "\nerr: no end zero in cont, icont=  "<< icont;
    *pfhis<< "\nerr: no end zero in cont, icont=  "<< icont;
   } //  if(i >= lcont)
   cout << cont[i];
   *pfhis << cont[i];
  } // for(i)
 } // if( prognum == numtrm)
 // if(dd)cout<<"err: dd="<<dd;
 // if(dd)*pfhis<<"err: dd="<<dd;
 myexit();
} 

   void err(elem z)
{
  int m = z.m; // headp h;
 //if(m >= namt) m = m - namt;
 if(m > iallm)
 {
  //cout<<"err:wrong element";
  pelm(z); //prp(z); prp(z, pfhis);
   goto L;
 }
 //adel(z,&h);
 L: if(prognum < numtopt)
    {
     cout << "\nLINE-1= " << nstr-1 << ' ' << strvalue[nstr-1];
     cout << "\nLINE= " << nstr << ' '<< strvalue[nstr];
     cout << "\nLINE+1= " << nstr+1 << ' ' << strvalue[nstr+1];
     *pfhis << "\nLINE-1= " << nstr-1 << ' ' << strvalue[nstr-1];
     *pfhis << "\nLINE= " << nstr << ' ' << strvalue[nstr];
     *pfhis << "\nLINE+1= " << nstr+1 << ' ' << strvalue[nstr+1];
     err();
    } // if(prognum < numtopt)
    if(prognum == numrnam) err();
    // if(dd)cout<<" dd="<<dd; if(dd)*pfhis<<" dd="<<dd;
    myexit();
}

 void err1(char* s)        // for msg
{ 
 if(++ counterrmsg >= maxerrmsg) 
  { if(counterrmsg == maxerrmsg)ipp("err1: too many errmsgs, s= ", s, " counterrmsg= ",  counterrmsg); }
 else{ errmsgs[counterrmsg] = s; errlines[counterrmsg] = nstr; }
} // end err1

   char pcont()
{
 cont[icont+79]=0;
 cout<<'\n'<<cont;
 *pfhis<<'\n'<<cont;
 return ' ';
}

  void errmsg(char* s)
{
 cout<<"\nERRMSG LINE: "<<nstr<<' '<<s;
 cerr<<"\nERRMSG LINE: "<<nstr<<' '<<s;
 *pfhis<<"\nERRMSG LINE: "<<nstr<<' '<<s;
 err1(s);
}

  void errmsg(char* s, int m)
{
 cout<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<m;
 cerr<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<m;
 *pfhis<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<m;
 err1(s);
}

   void errmsg(char* s, int i, char p)
{
 cout<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<i<<' '<<p;
 cerr<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<i<<' '<<p;
 *pfhis<<"\nERRMSG LINE: "<<nstr<<' '<<s<<' '<<i<<' '<<p;
 err1(s);
}

   void errmsg(char* s, int p, char* s1, int p1)
{
 cout<<"\nERRMSG LINE: "<<nstr<<' '<<s<<p<<s1<<p1;
 cerr<<"\nERRMSG LINE: "<<nstr<<' '<<s<<p<<s1<<p1;
 *pfhis<<"\nERRMSG LINE: "<<nstr<<' '<<s<<p<<s1<<p1;
 err1(s);
}

    void errmsg(char* s, elem z)
{
 cout<<"\nERRMSG:"<<s; prp(" ", z);
 cerr<<"\nERRMSG:"<<s; prp(" ", z);
 *pfhis<<"\nERRMSG:"<<s; prp(" ", z,pfhis);
 err1(s);
}

   void errmsg(char* s, elem x, char* s1, int y)
{
 cout<<"\nERRMSG:"<<s; prp(" ", x); cout << ' ' << s1 << ' ' << y; 
 cerr<<"\nERRMSG:"<<s; prp(" ", x); cerr << ' ' << s1 << ' ' << y; 
 *pfhis<<"\nERRMSG:"<<s; prp(" ", x,pfhis);
 *pfhis << ' ' << s1 << ' ' << y;
 err1(s);
}

   void errmsg(char* s, elem x, char* s1, char* s2)
{
 cout<<"\nERRMSG:"<<s; prp(" ", x); cout << ' ' << s1 << s2;
 cerr<<"\nERRMSG:"<<s; prp(" ", x); cerr << ' ' << s1 << s2;
 *pfhis<<"\nERRMSG:"<<s; prp(" ", x,pfhis);
 *pfhis << ' ' << s1 << s2;
 err1(s);
}

   void errmsg(char* s, elem x, char* s1, elem y)
{
 cout<<"\nERRMSG:"<<s; prp(" ", x); cout << ' ' << s1; prp(y);
 cerr<<"\nERRMSG:"<<s; prp(" ", x); cerr << ' ' << s1; prp(y);
 *pfhis<<"\nERRMSG:"<<s; prp(" ", x,pfhis);
 *pfhis << ' ' << s1; prp(y,pfhis);
 err1(s);
}

    void error(char* s, int p)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 err();
}

    void error(char* s, int p1, int p2)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p1<<' '<<p2;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p1<<' '<<p2;
 err();
}

/*void error(char* s,size_t p)
{
 cout<<"\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 err();
} */

   void errorc(char* s, char p)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 err();
}

   void error(char* s, char* p)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p;
 err();
}

   void error(char* s, char* p, int a)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<a;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<a;
 err();
}

   void error(char* s)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s;
 err();
}

/*void error(char* s, int p, size_t q)
{
 cout<<"\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q;
 err();
} */

   void errorci(char* s, char  p, int q)
{
 cout<<"\n\nERROR LINE: "<<nstr<<s<<p<<' '<<q;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<s<<p<<' '<<q;
 err();
}

   void error(char* s, char  p, char* q)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q;
 err();
}

   void error(char* s, char*  p, char* q)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q;
 err();
}

   void error(char* s, char* p, char* q, int k)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k;
 err();
}

   void error(char* s, char* p, char* q, int k, char* q1, int k1)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k<<q1<<k1;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k<<q1<<k1;
 err();
}

   void error(char* s, char* p, char* q, char* k)
{
 cout<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k;
 *pfhis<<"\n\nERROR LINE: "<<nstr<<' '<<s<<' '<<p<<' '<<q<<' '<<k;
 err();
}
   void error(char* s, elem z)
{  
//  int static depth;
//  if(++depth > 1)
// { 
//  cout << "\n"<<s; *pfhis << "\n"<<s; 
//   ippelm("recursive error(elem), z= ", z);
//   myexit();
//  }
 cout<<"\n\nERROR "<<s; prp(" ",z); //cout<<' ';
 *pfhis<<"\n\nERROR "<<s; prp(" ",z,pfhis); //cout<<' ';
 err(); // decrease of depth not needed!
}

    void error(char* s, elem z, int i)
{
 // errprint = true;
 cout<<"\n\nERROR:"<<s; prp(" ", z); cout<<", "<<i;
 *pfhis<<"\n\nERROR:"<<s; prp(" ", z, pfhis); *pfhis<<", "<<i;
 err(z);
}

     void error(char* s, elem z, elem f)
{
 // errprint = true;
 cout<<"\n\nERROR:"<<s; prp(" ", z); prp(" ", f);
 *pfhis<<"\n\nERROR:"<<s; prp(" ", z, pfhis); prp(" ", f, pfhis);
 err(z);
}

    void error(char* s, int p1, char* s1, int p2)
{
 cout<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2;
 *pfhis<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2;
 err();
}
   void error(char* s, int p1, char* s1, int p2, char* s2, int p3)
{
 cout<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2<<s2<<p3;
 *pfhis<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2<<s2<<p3;
 err();
}

   void error(char* s, int p1, char* s1, int p2, char* s2, int p3, char* s3, int p4)
{
 cout<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2<<s2<<p3<<s3<<p4;
 *pfhis<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2<<s2<<p3<<s3<<p4;
 err();
}

    void error(char* s, int p1, char* s1, char* p2)
{
 cout<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2;
 *pfhis<<"\n\nERROR:"<<s<<' '<<p1<<' '<<s1<<' '<<p2;
 err();
}

    void error(char* s, int p, char* s1, elem z)
{
 // errprint = true;
 cout<<"\n\nERROR: "<<p;  prp(s1, z);
 *pfhis<<"\n\nERROR: "<<p; prp(s1, z, pfhis); 
 err();
}  // end error

   void error(char* s, elem x, char* s1, int y)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout<<s1<< y;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << y;
 err();
}  // end error

   void error(char* s, elem x, char* s1, char* y)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout<<s1<< y;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << y;
 err();
}  // end error

void error(char* s, elem x, char* s1, char* s2, char* s3, int x1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << s2<<s3<<x1;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << s2<<s3<<x1;
 myexit();                                                 // err(x);
}  // end error

   void error(char* s, elem x, char* s1, int x1, char* s2, int x2, char* s3, int x3)
{
 
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << x1<<s2<<x2<<s3<<x2;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << x1<<s2<<x2<<s3<<x3;
 myexit();
}  // end error

   void error(char* s, elem x, char* s1, int x1, char* s2, int x2, char* s3, int x3, char* s4, int x4)
{
 
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << x1<<s2<<x2<<s3<<x3<<s4<<x4;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << x1<<s2<<x2<<s3<<x3<<s4<<x4;
 myexit();
}  // end error


   void error(char* s, elem x, char* s1, int x0, char* s3, int x1, char* s4, elem x2)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << x0<<s3<<x1; prp(s4,x2);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << x0<<s3<<x1; prp(s4,x2,pfhis);
 myexit();
}  // end error

   void error(char* s, elem x, char* s1, char* s2, char* s3, int x1, char* s4, int x2)
{
 cout<<"\nERROR: "; prp(s, x); cout << s1 << s2<<s3<<x1<<s4<<x2; 
 *pfhis<<"\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << s2<<s3<<x1<<s4<<x2; 
 myexit();
}  // end error

void error(char* s, elem x, char* s1, int y, char* s2, int z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout<<s1<<y<<s2<<z;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); 
 *pfhis<<s1<<y<<s2<<z;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, char* z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); cout<<s2<<z<<"\n";
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z;
 myexit();                                  // err(x); // char* elem char* elem char* int
}  // end error

   void error(char* s,  elemp q, int k)
{
 int i; // errprint = true;
 cout<<"\n\nERROR: ";  cout<<s<< k;
 for(i=0; i<=k; i++) prp(" ", q[i]); ;
 *pfhis<<"\n\nERROR: ";  *pfhis << s << k;
 for(i=0; i<=k; i++) prp(" ", q[i], pfhis);
 err();
}  // end error

  void error(char* s, int k0, char* s1, elemp q, int last)
{
 int i; // errprint = true;
 cout<<"\n\nERROR: " <<s<< k0<<s1;
 for(i=0; i<=last; i++) prp(" ", q[i]); ;
 *pfhis<<"\n\nERROR: "<< s << k0<<s1;
 for(i=0; i<=last; i++) prp(" ", q[i], pfhis);
 err();
}  // end error


   void error(char* s, elem x, char* s1, elemp q, int k)   // k is the size of q;
{
 int i; // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout<<s1<< k; 
 for(i=0; i<k; i++) prp(" ", q[k]); ;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << k;
 for(i=0; i<=k; i++) prp(" ", q[k], pfhis);
 err();
}  // end error

  void error(char* s, elem x, char* s1, elem x1, char* s2, elemp q, int k)    // k: last in 1;
{
 int i; // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1,x1); cout<<s2<< k;
 for(i=0; i<=k; i++) prp(" ", q[k]); ;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, x1, pfhis); *pfhis << s2 << k;
 for(i=0; i<=k; i++) prp(" ", q[k], pfhis);
 err();
}  // end error

void error(char* s, elem x, char* s1, char* y, char* s2, elemp q, int k)      // k is the last in q;
{
 int i; // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout <<s1<<y<<s2<<k;
 for(i=0; i<=k; i++) prp(" ", q[k]); ;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis <<s1<<y<<s2<<k;
 for(i=0; i<=k; i++) prp(" ", q[k], pfhis);
 err();
}  // end error

 void error(char* s, elem x, char* s1, elem y)              // char* elem char* elem
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x);  prp(s1, y); // pelm(y);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis); //  pelm(y, pfhis);
 myexit();                                                 // err(x);
}  // end error

 void error(char* s, elem x, char* s1, elem y, char* place)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); cout << " place= "<<place;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis << " place= "<<place;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, int z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); cout<<s2<<z<<"\n";
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z;
 myexit();                                  // err(x); // char* elem char* elem char* int
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, int z, char* s3, int z1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); cout<<s2<<z<<s3<<z1;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1;
 myexit();                                  // err(x); // char* elem char* elem char* int
}  // end error


/*void error(char* s, elem x, char* s1, char* s2)              // char* elem char* elem
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << s2;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << s2;
 myexit();                                                 // err(x);
 }  */ // end error

 void error(char* s, elem x, char* s1, elem y, char* s2, int z, char* s3, int z1, char* s4, int z2)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); cout<<s2<<z<<s3<<z1<<s4<<z2;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1<<s4<<z2;
 myexit();                                  // err(x); // char* elem char* elem char* int
}  // end error


void error(char* s, elem x, char* s1, elem y, char* s2, elem z)   // elem elem elem
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis);
 myexit();                                  // err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis); prp(s3,z1,pfhis);
 myexit();                           //  was err(x): no printing of st;
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, int k)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<k;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis); *pfhis << s3 << k;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, char* k)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<k;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis); *pfhis << s3 << k;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, int k, char* s4, int k1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<k<<s4<<k1;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis); *pfhis << s3 << k << s4 << k1;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, int k, char* s4, char* k1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<k<<s4<<k1;
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 prp(s2, z, pfhis); *pfhis << s3 << k << s4 << k1;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, int k)   // ----0
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); cout<<s4<<k;
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis); *pfhis<<s4<<k;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, int k, char* s5, int k1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); cout<<s4<<k<<s5<<k1;
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis<<s4<<k<<s5<<k1;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, int k, char* s5, int k1,
                                                               char* s6, int k2)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); cout<<s4<<k<<s5<<k1<<s6<<k2;
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis<<s4<<k<<s5<<k1<<s6<<k2;
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, int k, char* s5, int k1,
                         char* s6, int k2, char* s7, int k3)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); cout<<s4<<k<<s5<<k1<<s6<<k2<<s7<<k3;
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis<<s4<<k<<s5<<k1<<s6<<k2<<s7<<k3;
 err(x);
}  // end error


void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); prp(s4,z2);
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis); prp(s4,z2,pfhis);
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2, char* s5, elem z3)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); prp(s4,z2); prp(s5,z3);
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis); prp(s4,z2,pfhis);
 prp(s5,z3,pfhis); err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2, char* s5, int k1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1); prp(s4,z2); cout << s5 << k1;
 *pfhis<<"\n\nERROR: "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); 
 prp(s3,z1,pfhis); prp(s4,z2,pfhis); *pfhis << s5 << k1;
 err(x);
}  // end error


void error(char* s, elem x, char* s2,  sbst* z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); //prp(s1, y); 
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); //prp(s1, y, pfhis);
 z->psbs(s2);
 err(x);
}  // end error

void error(char* s, elem x, char* s1, elem y, char* s2, sbst* z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); 
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis);
 z->psbs(s2);
 err(x);
}  // end error

void error(char* s, elem x, char* s1, int y, char* s2, sbst* z)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << y; 
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << y; 
 z->psbs(s2);   
 err(x);
}  // end error

void error(char* s, elem x, char* s1, int y, char* s2, int z, char* s3, sbst* z1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); cout << s1 << y<<s2<<z; 
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); *pfhis << s1 << y<<s2<<z; 
 z1->psbs(s3);   
 err(x);
}  // end error

  void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, sbst* z1)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2,z);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis);
 z1->psbs(s3);   
 err(x);
}  // end error

 void error(char* s, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, sbst* z2)
{
 // errprint = true;
 cout<<"\n\nERROR: "; prp(s, x); prp(s1, y); prp(s2,z); prp(s3,z1);
 *pfhis<<"\n\nERROR: "; prp(s, x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);
 z2->psbs(s4);   
 err(x);
}  // end error


  void errorelm(char* s, elem z)
{
 cout<<"\n\nERRORelm: "<<s;  
 pelm(z);
 *pfhis<<"\n\nERRORelm: "<<s; 
 pelm(z, pfhis);
 err(); // myexit(1); 
}

  void errorelm(char* s, elem z, char* s1, int k)
{
 cout<<"\n\nERRORelm: "<<s;   pelm(z); cout << s1 << k;
 *pfhis<<"\n\nERRORelm: "<<s; pelm(z, pfhis); *pfhis << s1 << k;
 err(); // myexit(1); 
}

  void errorelm(char* s, elem z, char* s1, char* s2)
{
 cout<<"\n\nERRORelm: "<<s;   pelm(z); cout << s1 << s2;
 *pfhis<<"\n\nERRORelm: "<<s; pelm(z, pfhis); *pfhis << s1 << s2;
 err(); // myexit(1); 
}

void errorelm(char* s, elem z, char* s1, char* s2, char* s3, int k)
{
 cout<<"\n\nERRORelm: "<<s;   pelm(z); cout << s1 << s2 << s3 << " k= "<< k;
 *pfhis<<"\n\nERRORelm: "<<s; pelm(z, pfhis); *pfhis << s1 << s2 << s3 << " k= " << k;
 err(); // myexit(1); 
}

  void errorelm(char* s, elem z, char* s1, elem z1)
{
 cout<<"\n\nERRORelm: "<<s;   pelm(z); cout << s1; pelm(z1);
 *pfhis<<"\n\nERRORelm: "<<s; pelm(z, pfhis); *pfhis << s1; pelm(z1,pfhis);
 err();  // myexit(1); 
}

  void errorelm(char* s, elem z, char* s1, elem z1, char* s2, elem z2)
{
 cout<<"\n\nERRORelm: "<<s;   pelm(z); cout << s1; pelm(z1); cout << s2; pelm(z2);
 *pfhis<<"\n\nERRORelm: "<<s; pelm(z, pfhis); *pfhis << s1; pelm(z1,pfhis);
 *pfhis << s2; pelm(z2,pfhis);
 err();  // myexit(1); 
}

   char* newlskip(char* s1)
{
 static char s[100]; strcpy(s, s1); char* r = s1; // int k =  maxipp * 100000;
 // cout << "\n+newlskip s1= "<< s1; *pfhis << "\n+newlskip s1= "<< s1;
 {
  if(s[0] == '\n')
  {
   s[0] = ' '; cout << "\n";
   *pfhis << "\n"; r = s;
  }
 }
 if(++ippcount >= Maxipp )
 { 
  beep(2);
  if(ippcount > Maxipp) 
  // exit(1);
   error("newlskip: big ippcount= ", ippcount, " maxipp= ", maxipp);   
 }
  return r;
}

  void ipp(char* s0)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s;
 *pfhis<<"\nipp! "<<s;
}

  void ipp(char* s0, char* x)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x;
 *pfhis<<"\nipp!"<<s<<x;
}

   void ipp(char* s0, char* x, char* y)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<y;
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<y;
}

   void ipp(char* s0, char* x, char* y, char* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<z;
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<z;
}

   void ipp(char* s0, char* x, char* y, int k, char* y1, int k1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<k<<y1<<k1;
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<k<<y1<<k1;
}

 void ipp(char* s0, char* s1, elem y, char* s2, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<s1; prp(y); 
 *pfhis<<"\nipp!"<<s<<' '<<s1; prp(y,pfhis);
 z->psbs(s2);
}

 void ipp(char* s0, int x, char* s1, elem y, char* s2, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x <<s1; prp(y); 
 *pfhis<<"\nipp!"<<s<<' '<<x<<s1; prp(y,pfhis);
 z->psbs(s2);
}

    void ipp(char* s0, char* x, int k)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<k;
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<k;
}

    void ipp(char* s0, char* x, char* y, int k)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<k;
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '<<k;
}

void ipp(char* s0, elem x, char* s1, char* s2, char* s3, char* s4)
{
  char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); cout << s1 << s2<<s3<<s4;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); *pfhis << s1 << s2<<s3<<s4;
}  // end ipp

void ipp(char* s0, elem x, char* s1, char* s2, char* s3, int x1)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); cout << s1 << s2<<s3<<x1;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); *pfhis << s1 << s2<<s3<<x1;
}  // end ipp

void ipp(char* s0, elem x, char* s1, char* s2, char* s3, int x1, char* s4, int x2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); cout << s1 << s2<<s3<<x1<<s4<<x2;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); *pfhis << s1 << s2<<s3<<x1<<s4<<x2;
}  // end ipp

   void ipp(char* s0, int p, char* s1, char* s2, char* s3, int p1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<p<<' '<<s1<<' '<<s2<<' '<<s3<<p1;
 *pfhis<<"\nipp!"<<s<<p<<' '<<s1<<' '<<s2<<' '<<s3<<p1;
}

   void ipp(char* s0, elemp q, int k)                     //  k is the number of elems, not k is the last
{
 char* s = newlskip(s0);
 *pfhis<<"\nipp! "<<s<< " now k is the last,  k= "<<k; 
 for(int i=0; i<k; i++) prp("\n", q[i], pfhis);
 // {
 // *pfhis<<"\n"<<i<<") ";
 // prp(q[i], pfhis);
 // } // for(i)
} // end ipps 


  void ipp(char* s0, int k, char* s2, elemp q, int k1)      // k1 is the last in q;
{
 int i;
 char* s1 = newlskip(s0);
 cout<<"\nipp!"<<s1<< k<<" k(last:q)= "<<k1<< s2;
 for(i=0; i<=k1; i++) prp("\n", q[i]);
 *pfhis<<"\nipp!" << s1 << k <<" k(last:q)= "<<k1 << s2;
 for(i=0; i<=k1; i++) prp("\n", q[i], pfhis);
}  // end ipp

  void ipp(char* s0, int k1, char* s2, int k2, char* s3, elemp q, int k3) // k3 is the last in q;
{
 int i;
 char* s1 = newlskip(s0);
 cout<<"\nipp!"<<s1<< k1<<s2<<k2<<" k(last:q)= " <<k3<<s3;
 for(i=0; i<=k3; i++) prp("\n", q[i]); 
 *pfhis<<"\nipp!" << s1 << k1 << s2<<k2<<" k(last:q)= " <<k3<<s3;
 for(i=0; i<=k3; i++) prp("\n", q[i], pfhis);
}  // end ipp

  void ipp(char* s0, int k1, char* s2, int k2, char* s3, int k3, char* s4, elemp q, int k4)    // k4 is the last in q;
{
 int i;
 char* s1 = newlskip(s0);
 cout<<"\nipp!"<<s1<< k1<<s2<<k2<<s3<<k3<<" k(last:q)= " <<k4<<s4;
 for(i=0; i<=k4; i++) prp("\n", q[i]); 
 *pfhis<<"\nipp!" << s1 << k1 << s2<<k2<<s3<<k3<<" k(last:q)= " <<k4<<s4;;
 for(i=0; i<=k4; i++) prp("\n", q[i], pfhis);
}  // end ipp

 void ipp(char* s0, elem x, char* s2, elemp q, int k)   // k: last occupied;
{
 int i;
 char* s1 = newlskip(s0);
 cout<<"\nipp!"<<s1; prp(x); cout << s2;
 for(i=0; i<=k; i++) prp("\n", q[i]); 
 *pfhis<<"\nipp!" << s1; prp(x, pfhis); *pfhis << s2;
 for(i=0; i<=k; i++) prp("\n", q[i], pfhis);
}  // end ipp


 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elemp q, int k)   // k is the last in q;
{
 int i;
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); prp(s1,y); cout << s2;
 for(i=0; i<=k; i++) prp("\n", q[i]); 
 *pfhis<<"\nipp!" << s; prp(x, pfhis); prp(s1,y, pfhis); *pfhis << s2;
 for(i=0; i<=k; i++) prp("\n", q[i], pfhis);
}  // end ipp



void ipp(char* s0, elem z, char* s1, elem d, char* s2, char* s3)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"; prp(s, z);  prp(s1, d); cout<<s2<<s3;
 *pfhis<<"\nipp!"; prp(s, z, pfhis); prp(s1, d, pfhis); *pfhis << s2 << s3;
}  // end ipp

void ipp(char* s0, elem x, char* s1, int k, char* s2, elemp q, int k1)  // k1: last occupied;
{
 int i;
 char* s = newlskip(s0);
 cout<<"\nipp!"; prp(s, x); cout<<s1<< k<<s2;
 for(i=0; i<=k1; i++) prp("\n", q[i]); ;
 *pfhis<<"\nipp!"; prp(s, x, pfhis); *pfhis << s1 << k<<s2;
 for(i=0; i<=k1; i++) prp("\n", q[i], pfhis);
}  // end ipp

void ippq1(char* s0, elem x, char* s1, elemp q, int k)                  // k: the number of elements to print !
{                                                                      // q points to q[0];
 int i;
 char* s = newlskip(s0);
 cout<<"\nippq1! k= "<<k; prp(s, x); cout<<s1;
 for(i=0; i<k; i++) prp("\n", q[i]); ;
 *pfhis<<"\nippq1! k= "<<k; prp(s, x, pfhis);
 for(i=0; i<k; i++) prp(i, q[i], pfhis);
}  // end ippq1

void ippq2(char* s0, elem x, char* s1, elem y, char* s2, elemp q, int k)  
{             // k is the number of elements in q;  model is q[0], ... , q[k-1], NOT LAST PRINTED !
 int i;
 char* s = newlskip(s0);
 cout<<"\nippq2! k="<<k; prp(s, x); prp(s1, y); cout<<s2;
 for(i=0; i<k; i++) prp("\nq= ", q[i]);
 *pfhis<<"\nippq2! k="<<k; prp(s, x, pfhis); prp(s1, x, pfhis); *pfhis << s2;
 for(i=0; i<k; i++) prp("\nq= ", q[i], pfhis);
}  // end ipp

    void ipp(char* s0, char* x, char* y, elem z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '; prp(z);
 *pfhis<<"\nipp!"<<s<<' '<<x<<' '<<y<<' '; prp(z,pfhis);
}

    void ipp(char* s0, int p)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<p;
 *pfhis<<"\nipp!"<<s<<' '<<p;
}

    void ipp(char* s0, char c, int p)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<c<<' '<<p;
 *pfhis<<"\nipp!"<<s<<' '<<c<<' '<<p;
}

    void ipp(char* s0, int p, char* s1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<p<<' '<<s1;
 *pfhis<<"\nipp!"<<s<<' '<<p<<' '<<s1;
}

    void ipp(char* s0, bool p)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<' '<<p;
 *pfhis<<"\nipp!"<<s<<' '<<p;
}

    void ipp(char* s0, int p1, int p2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<' '<<p2;
 *pfhis<<"\nipp! "<<s<<' '<<p1<<' '<<p2;
}

    void ipp(char* s0, int p1, char* s1, int p2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<s1<<p2;
 *pfhis<<"\nipp! "<<s<<p1<<s1<<p2;
}

    void ipp(char* s0, int p1, char* s1, int p2, char* s2, int p3)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<s1<<p2<<s2<<p3;
 *pfhis<<"\nipp! "<<s<<p1<<s1<<p2<<s2<<p3;
}

   void ipp(char* s0, int p1, char* s1, int p2, char* s2, int p3, char* s3, int p4)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<s1<<p2<<s2<<p3<<s3<<p4;
 *pfhis<<"\nipp! "<<s<<p1<<s1<<p2<<s2<<p3<<s3<<p4;
}

   void ipp(char* s0, int p1, char* s1, int p2, char* s2, int p3, char* s3, int p4, char* s4, int p5)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<s1<<p2<<s2<<p3<<s3<<p4<<s4<<p5;
 *pfhis<<"\nipp! "<<s<<p1<<s1<<p2<<s2<<p3<<s3<<p4<<s4<<p5;
}

    void ipp(char* s0, int p1, char* s1, elem p2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p1<<s1; prp(p2);
 *pfhis<<"\nipp! "<<s<<p1<<s1; prp(p2, pfhis); 
}

    void ipp(char* s0, int p, elem z)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p<<' '; prp(z); cout<<' ';
 *pfhis<<"\nipp! "<<s<<' '<<p<<' '; prp(z,pfhis); *pfhis<<' '; 
}

   void ipp(char* s0, int p, char* s1, elem z, char* s2, elem z2) 
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '<<p<<s1; prp(z);  cout<<s2; prp(z2);
 *pfhis<<"\nipp! "<<s<<' '<<p<<s1; prp(z,pfhis); *pfhis<<s2; prp(z2,pfhis);
}

    void ipp(char* s0, elem z)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s;
 prp(z);
 *pfhis<<"\nipp! "<<s;
 prp(z, pfhis);
}

    void ipp(char* s0, elem x, char* s1)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '; prp(x); cout << ' '<<s1;
 *pfhis<<"\nipp! "<<s<<' '; prp(x, pfhis); *pfhis << ' '<<s1;
}       
    void ipp(char* s0, elem x, char* s1, int y)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x);  cout<<s1<<y;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<y; 
}

  void ipp(char* s0, elem x, char* s1, int x1, char* s2, int x2)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<x1<<s2<<x2;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<x1<<s2<<x2;
}

  void ipp(char* s0, elem x, char* s1, int x1, char* s2, int x2, char* s3, int x3)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<x1<<s2<<x2<<s3<<x3;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<x1<<s2<<x2<<s3<<x3;
}

  void ipp(char* s0, elem x, char* s1, int x1, char* s2, int x2, char* s3, int x3, char* s4, int x4)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<x1<<s2<<x2<<s3<<x3<<s4<<x4;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<x1<<s2<<x2<<s3<<x3<<s4<<x4;
}

void ipp(char* s0, elem x, char* s1, int x1, char* s2, int x2, char* s3, int x3, char* s4, int x4, char* s5, int x5)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<x1<<s2<<x2<<s3<<x3<<s4<<x4<<s5<<x5;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<x1<<s2<<x2<<s3<<x3<<s4<<x4<<s5<<x5;
}

 void ipp(char* s0, elem x, char* s1, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s; prp(x); 
 *pfhis<<"\nipp! "<<s; prp(x, pfhis);
 z->psbs(s1);      // ??????
}

    void ipp(char* s0, elem x, char* s1, elem y,  char* s2, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); 
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1,y,pfhis);
  z->psbs(s2);   
}
    void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, sbst* z1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); cout<<s2; prp(z);
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis);
  z1->psbs(s3);   
}

   void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z0, char* s4, sbst* z1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); cout<<s2; prp(z); cout << s3; prp(z0);
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z0,pfhis);
  z1->psbs(s4);   
}

   void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int k, char* s4, sbst* z1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); cout<<s2; prp(z); cout << s3 << k;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); *pfhis << s3<<k;
  z1->psbs(s4);   
}

   void ipp(char* s0, elem x, char* s1, elem y)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s;  prp(x); cout<<s1; prp(y); // pelm(y);
 *pfhis<<"\nipp!"<<s;  prp(x, pfhis);  prp(s1,y,pfhis); // pelm(y,pfhis);
}

    void ipp(char* s0, elem x, char* s1, elem y, char* s2, int z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x);  cout<<s1; prp(y);  cout << s2<<z;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis);  prp(s1,y,pfhis);  *pfhis<<s2<<z;
}

  void ipp(char* s0, elem x, char* s1, elem y, char* s2, int z, char* s3, int z1)
{
 char* s = newlskip(s0);
 cout<<"\nipp! ";
 prp(s, x); 
 prp(s1, y); 
 cout<<s2<<z<<s3<<z1;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1;
}  // end ipp

void ipp(char* s0, elem x, char* s1, elem y, char* s2, int z, char* s3, int z1, char* s4, int z2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); cout<<s2<<z<<s3<<z1<<s4<<z2;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1<<s4<<z2;
}  // end ipp

void ipp(char* s0, elem x, char* s1, elem y, char* s2, int z, char* s3, int z1, char* s4, int z2, char* s5, int z3)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); cout<<s2<<z<<s3<<z1<<s4<<z2<<s5<<z3;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1<<s4<<z2<<s5<<z3;
}  // end ipp

void ipp(char* s0,elem x,char* s1,elem y,char* s2,int z,char* s3,int z1,char* s4,int z2,char* s5,int z3,char* s6, int z4)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); cout<<s2<<z<<s3<<z1<<s4<<z2<<s5<<z3<<s6<<z4;
 *pfhis<<"\nipp! "; prp(s, x, pfhis); prp(s1, y, pfhis);
 *pfhis<<s2<<z<<s3<<z1<<s4<<z2<<s5<<z3<<s6<<z4;
}  // end ipp
  
    void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z);
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis);
}

    void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int n)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); cout << s3 << n;
 *pfhis<<"\nipp!: "; prp(s, x, pfhis); prp(s1, y, pfhis); 
 prp(s2, z, pfhis); *pfhis << s3 << n; 
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int n1, char* s4, int n2)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<n1<<s4<<n2;
 *pfhis<<"\nipp!: "; prp(s, x, pfhis); prp(s1, y, pfhis); 
 prp(s2, z, pfhis); *pfhis << s3 << n1 << s4 << n2; 
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int n1, char* s4, int n2, char* s5, int n3)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<n1<<s4<<n2 << s5 << n3;
 *pfhis<<"\nipp!: "; prp(s, x, pfhis); prp(s1, y, pfhis); 
 prp(s2, z, pfhis); *pfhis << s3 << n1 << s4 << n2 << s5 << n3; 
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int n1, char* s4, int n2, char* s5, int n3, char* s6, int n4)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<n1<<s4<<n2 << s5 << n3<< s6 << n4;
 *pfhis<<"\nipp!: "; prp(s, x, pfhis); prp(s1, y, pfhis); 
 prp(s2, z, pfhis); *pfhis << s3 << n1 << s4 << n2 << s5 << n3<< s6 << n4; 
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, int n1, char* s4, char* s5)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); cout<<s3<<n1<<s4<<s5;
 *pfhis<<"\nipp!: "; prp(s, x, pfhis); prp(s1, y, pfhis); 
 prp(s2, z, pfhis); *pfhis << s3 << n1 << s4 << s5; 
}

    void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);
}

void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1,  char* s4, int k, char* s5, int k1)
{
 char* s = newlskip(s0);
 cout<<"\n\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1);  cout << s4 << k << s5 << k1;
 *pfhis<<"\n\nipp! "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis << s4 << k << s5 << k1;
}  // end ipp

void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1,  char* s4, int k,
         char* s5, int k1, char* s6, int k2)
{
 char* s = newlskip(s0);
 cout<<"\n\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1);  cout << s4 << k << s5 << k1<< s6 << k2;
 *pfhis<<"\n\nipp! "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis << s4 << k << s5 << k1<< s6 << k2;
}  // end ipp

void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1,  char* s4, int k,
         char* s5, int k1, char* s6, int k2, char* s7, int k3)
{
 char* s = newlskip(s0);
 cout<<"\n\nipp! "; prp(s, x); prp(s1, y); prp(s2, z); prp(s3,z1);
 cout << s4 << k << s5 << k1<< s6 << k2 << s7 << k3 ;
 *pfhis<<"\n\nipp! "; prp(s,x,pfhis); prp(s1,y,pfhis); prp(s2,z,pfhis); prp(s3,z1,pfhis);
 *pfhis << s4 << k << s5 << k1<< s6 << k2 << s7 << k3;
}  // end ipp


  void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2)
 {
  char* s = newlskip(s0);
  cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);  prp(s4,z2); 
  *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);  prp(s4,z2,pfhis); 
 }

  void ipp(char* s0,elem x,char* s1,elem y,char* s2,elem z,char* s3,elem z1,char* s4,elem z2,char* s5, int k)
 {
  char* s = newlskip(s0);
  cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);  prp(s4,z2); cout << s5 << k;
  *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); 
  prp(s3, z1, pfhis);  prp(s4,z2,pfhis); *pfhis << s5 << k;
 }

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2, char* s5, elem z3)
{
  char* s = newlskip(s0);
  cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);  prp(s4,z2);  prp(s5,z3); 
  *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);  prp(s4,z2,pfhis); prp(s5,z3,pfhis); 
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2, 
                            char* s5, elem z3, char* s6, int k)
{
  char* s = newlskip(s0);
  cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);  prp(s4,z2);  prp(s5,z3); cout << s6 << k;
  *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);  prp(s4,z2,pfhis); 
      prp(s5,z3,pfhis); *pfhis << s6 << k;
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, elem z2, 
                            char* s5, elem z3, char* s6, int k, char* s7, int k1)
{
  char* s = newlskip(s0);
  cout<<"\nipp!"<<s; prp(x); cout<<s1; prp(y); prp(s2, z); prp(s3,z1);  prp(s4,z2);  prp(s5,z3); 
  cout << s6 << k<< s7 << k1;
  *pfhis<<"\nipp!"<<s; prp(x, pfhis); prp(s1, y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);  prp(s4,z2,pfhis); 
      prp(s5,z3,pfhis); *pfhis << s6 << k<< s7 << k1;
}

 void ipp(char* s0, elem x, char* s1, elem y, char* s2, elem z, char* s3, elem z1, char* s4, int k)
{
 char* s = newlskip(s0); headp hx, hy; ats nmx, nmy;
 // *pfhis<<"test"<<s<<"endtest";
 char* p = strstr(s, "+insteqt");
 if(p)
 {
  nmx = name(x, &hx); nmy = name(y, &hy);
  if(nmx != -2) hx->name = noname;
  if(nmy != -2) hy->name = noname;
 } // if(p)
 cout<<"\nipp!"<<s; if(nmx >= 0) cout << vts(nmx);
 prp(x); cout<<s1;  if(nmy >= 0) cout << vts(nmy);
 prp(y); prp(s2, z); prp(s3,z1); cout << s4 << k;
 *pfhis<<"\nipp!"<<s; if(nmx >= 0) *pfhis << vts(nmx);
 prp(x, pfhis); *pfhis << s1; if(nmy >= 0) *pfhis << vts(nmy);
 prp(y, pfhis); prp(s2, z, pfhis); prp(s3, z1, pfhis);
 *pfhis << s4 << k;
 if(p)
 {
  if(nmx != -2) hx->name = nmx;
  if(nmy != -2) hy->name = nmy;
 } // if(p)
} // end ipp

    void ipp(char* s0, elem x, char* s1, int y, char* s2, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<y;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<y;  z->psbs(s2);  
}

    void ipp(char* s0, elem x, char* s1, int y, char* s2, int y1, char* s3, sbst* z)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<y<<s2<<y1;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<y<<s2<<y1;  z->psbs(s3);  
}

    void ipp(char* s0, elem x, char* s1, char*  s2)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<s2;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<s2; 
}

/*    void ipp(char* s0, elem x, char* s1, char* s2, char* s3, char* s4)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s; prp(x); cout<<s1<<s2<<s3<<s4;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<s2<<s3<<s4; 
}
*/
    void ipp(char* s0, int x, char* s1, char*  s2)
{
 char* s = newlskip(s0);
 cout<<"\nipp!"<<s<<x<<s1<<s2;
 *pfhis<<"\nipp!"<<s<<x<<s1<<s2; 
}

    void ipp(char* s0, elem z, int p)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '; prp(z); cout<<' '<<p<<' ';
 *pfhis<<"\nipp! "<<s<<' '; prp(z,pfhis); *pfhis<<' '<<p<<' ';
}

    void ipp(char* s0, elem x, elem y)
{
 char* s = newlskip(s0);
 cout<<"\nipp! "<<s<<' '; prp(x); cout<<' '; prp(y);
 *pfhis<<"\nipp! "<<s<<' '; prp(x, pfhis); prp(" ", y, pfhis);
}
  
/*   void ipp(char* s0, elem d, char* s2, elemp q)
{
 char* s = newlskip(s0);
 int kq = 1;  // ldev(d);
 *pfhis<<"\nipp! ";
 prp(s, d, pfhis); *pfhis<<s2<<" kq= "<<kq<<" ";
 for(int i = 0; i<kq; i++) prp(" ", q[i], pfhis);
} // end ipp(d, q) 
*/
   void ipp(char* s0, elem z, char* s1, elem d, char* s2, elemp q)
{
 char* s = newlskip(s0);
 int kq = 1; // ldev(d);
 *pfhis<<"\nipp! ";
 prp(s, z, pfhis); prp(s1, d, pfhis); *pfhis<<s2;
 for(int i = 0; i<kq; i++) prp("; ", q[i], pfhis);
} // end ipp(z, d, q) 

   void ipp(char* s0, elem z, char* s1, int k, char* s2, elemp q)
{
 char* s = newlskip(s0);
 *pfhis<<"\nipp! ";
 prp(s, z, pfhis); *pfhis<<s1<<k<<s2;
 for(int i = 0; i<k; i++) prp(" ", q[i], pfhis);
} // end ipp

    void ippelm(char* s, elem z)
{
 cout<<"\nippelm! "<<s<<' '; pelm(z);
 //if(z1 != zel) prp(" ", z1);
 *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis); ++ippcount;
 // if(z1 != zel) prp(" ", z1, pfhis);
}

    void ippelm(char* s, elem z, char* s1, int k)
{
 cout<<"\nippelm! "<<s<<' '; 
 pelm(z);
 cout<<s1<<k;
 
 *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis);
  *pfhis<<s1<<k;  ++ippcount;
}

    void ippelm(char* s, elem z, char* s1, int k1, char* s2, int k2)
{
 cout<<"\nippelm! "<<s<<' '; 
 pelm(z);
 cout<<s1<<k1<<s2<<k2;
 
 *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis);
  *pfhis<<s1<<k1<<s2<<k2;  ++ippcount;
}

    void ippelm(char* s, elem z, char* sz1, elem z1, char* s1, int k1, char* s2, int k2)
{
 cout<<"\nippelm! "<<s<<' ';  pelm(z); cout<<sz1; pelm(z1);
 cout<<s1<<k1<<s2<<k2;
 
 *pfhis<<"\nippelm! "<<s<<' ';  pelm(z, pfhis); *pfhis << sz1; pelm(z, pfhis);
  *pfhis<<s1<<k1<<s2<<k2;   ++ippcount;
}

    void ippelm(char* s, elem z, char* s1, elem z1)
{
 cout<<"\nippelm! "<<s<<' '; pelm(z); cout<<s1; pelm(z1);
  *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis); *pfhis<<s1; pelm(z1, pfhis);  ++ippcount;
}

    void ippelm(char* s, elem z, char* s1, elem z1, char* s2, int k)
{
 cout<<"\nippelm! "<<s<<' '; pelm(z); cout<<s1; pelm(z1); cout<<s2<<k;
  *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis); *pfhis<<s1; pelm(z1, pfhis); *pfhis<<s2<<k;  ++ippcount;
}

    void ippelm(char* s, elem z, char* s1, elem z1, char* s2, elem z2)
{
 cout<<"\nippelm! "<<s<<' '; pelm(z); cout<<s1; pelm(z1); cout<<s2; pelm(z2);
  *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis); *pfhis<<s1; pelm(z1, pfhis); *pfhis<<s2; pelm(z2, pfhis); ++ippcount;
}

    void ippelm(char* s, elem z, char* s1, elem z1, char* s2, elem z2, char* s3, elem z3)
{
 cout<<"\nippelm! "<<s<<' '; pelm(z); cout<<s1; pelm(z1); cout<<s2; pelm(z2); cout<<s3; pelm(z3);
  *pfhis<<"\nippelm! "<<s<<' '; 
 pelm(z, pfhis); *pfhis<<s1; pelm(z1, pfhis); *pfhis<<s2; pelm(z2, pfhis); *pfhis<<s3; pelm(z3, pfhis); ++ippcount;
}

    void cpp(char* s)
{
 cout<<"\ncpp! "<<s; 
 *pfhis<<"\ncpp! "<<s;
 pcin();
}
    void cpp(char* s, elem x)
{
 cout<<"\ncpp!"<<s; prp(x);
 { *pfhis<<"\ncpp!"<<s; prp(x,pfhis); }
 pcin();
}
    void cpp(char* s, int x)
{
 cout<<"\ncpp!"<<s<<' '<<x;
 *pfhis<<"\ncpp!"<<s<<' '<<x;
 pcin();
}
    void cpp(char* s, char* x)
{
 cout<<"\ncpp!"<<s<<' '<<x;
 *pfhis<<"\ncpp!"<<s<<' '<<x;
 pcin();
}
    void cpp(char* s, char* x, char* y)
{
 cout<<"\ncpp!"<<s<<' '<<x<<' '<<y;
 *pfhis<<"\ncpp!"<<s<<' '<<x<<' '<<y;
 pcin();
}
    void cpp(char* s, elem x, elem y)
{
 cout<<"\ncpp!"<<s; prp(x);cout<<' '; prp(y);
 *pfhis<<"\ncpp!"<<s; prp(x, pfhis); prp(y, pfhis);
 pcin();
}

    void cpp(char* s, int x, elem y)
{
 cout<<"\ncpp!"<<s<<' '<<x<<','; prp(y);
 *pfhis<<"\ncpp!"<<s<<' '<<x<<','; prp(y, pfhis);
 pcin();
}

    void cpp(char* s, elem x, int y)
{
 cout<<"\ncpp!"<<s<<' '; prp(x); cout<<','<<y;
 *pfhis<<"\ncpp!"<<s<<' '; prp(x,pfhis); *pfhis<<','<<y;
 pcin();
}

    void cpp(char* s, int x, int y)
{
 cout<<"\ncpp!"<<s<<' '<<x<<','<<y;
 *pfhis<<"\ncpp!"<<s<<' '<<x<<','<<y;
 pcin();
}

    void cpp(char* s, elem x, char* s1, elem y)
{
 cout<<"\ncpp!"<<s; prp(x); cout<<s1; prp(y);
 *pfhis<<"\ncpp!"<<s; prp(x, pfhis); prp(s1,y,pfhis);
 pcin();
}

    void cpp(char* s, elem x, char* s1, int y)
{
 cout<<"\ncpp!"<<s; prp(x); cout<<s1<<y;
 *pfhis<<"\nipp!"<<s; prp(x, pfhis); *pfhis<<s1<<y; 
 pcin();
}
   
    void cpp(char* s, int x, char* s1, elem y)
{
 cout<<"\ncpp!"<<s<<' '<<x<<s1; prp(y);
 *pfhis<<"\ncpp!"<<s<<' '<<x<<s1; prp(y, pfhis);
 pcin();
}

    void cpp(char* s, int x, char* s1, int y)
{
 cout<<"\ncpp!"<<s<<' '<<x<<s1<<y;
 *pfhis<<"\ncpp!"<<s<<' '<<x<<s1<<y;
 pcin();
}

    void pcin()
{
  char s[80];  // char c;
  cout << " dd= " << dd;
  cin >> s;  //cout<<"iach="<<prr->iach;  if(ppp == 0) cin >> s;
  for(int i = 0; i < int(strlen(s)); i++) debs(s[i]);
}
// end err.cpp