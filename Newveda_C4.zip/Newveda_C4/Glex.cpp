#include "lib.h"      //11/15/97 11/07/99 12/09/99 4/19/00
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h"
#include "typ.h"
#include "elem.h"     //11/2/99
#include "glex.h"     //07/04/96  09/03/96  03/11/97
#include <limits.h>    //03/19/97(-- -> //)  05/6/97(snam)
#include "myio.h"
#include <assert.h>
#include "etc.h"
#include "err.h"
// #include "cr.h"

#define lrb   80
#define nqs   2
#define nil1 -1
#define TAB   9
#define EOL   10
#define lcont 200 

extern int yy, aa, gg,hh,nn,ppp,its,maxl;
extern att maxits;
extern ats aend, asop;
extern ifstream* pfin;
extern tt* ptt;
int rstr(ifstream* f, char* s);
void inops();
ats name(ats a);
void wrb(char c);
void wrbs();
void wrbs(char c);
int irb;
char sym,sym1;
elem sp1,s,s0,s01,s02; // sp1: before s; s: current lexem, s0: next after s, s01: next after s0, s02: next after s01;
int nstr = -1;
int lim  = 3;
int icont;
int glexcount;
char rb[lrb];
char cont[lcont];
char cont1[lcont];   // previous value of cont
char cont2[lcont];   // previous value of cont1

extern char* sbin[lsbin]; // = {":=","! !!", ": " "==", "->",// 1,2,3,4,5;
//* 6,7,8, */    "or","& ","= ,~=",
//* 9 */         "< <= > >= ~* % in nin ::",
//*10,11,12*/    ":>", "..", "+ - ",
//* 13,14,15. */ "* / ^ ", "** ",". " };

int  prt(char* s);

char ops[256];

   void	getsym()
{
 char c = ' ';  int i;  bool p;              
 if(sym == EOF) goto ret;
 sym1 = sym; 
 if(pp) ipp("+getsym: sym= ", sym, " icont= ", icont);
 sym = cont[++icont];
 if(icont >= lcont) error("getsym: too long line ", cont);
 //cpp("getsym sym= ", sym);
 if(sym == 0)                      // EOL
 {
  if(gg) 
  {
   ipp("getsym cont= ", cont);
   pst("getsym");
  }
  for(i=0; i < maxl; i++ ) cont2[i] = cont1[i];
  for(i=0; i < maxl; i++ ) cont1[i] = cont[i];
  p = rwcm(pfin, cont, maxl);                    // must: maxl <= lcont
  {
   int k = strlen(cont);
   if(k >= lcont-2) error("getsym: too long line k= ", k);
   cont[k] = p? EOF:EOL; cont[k+1] = 0;
  }
  icont = 0;
  //cpp("getsym cont= ", cont);
  sym = cont[icont];
 }      
 ret: if(sym == EOF && lim-- == 0) error("getsym:EOF");
	  if(pp) ipp("-getsym sym = ", sym, " icont= ", icont);
} // end getsym
 
   void skip(char c)
{
 if(sym!=c)error("skip:must be ",c);
 getsym();
}
   void	skips()
{
 if(pp) cout << "\n+skips "<< sym << int(sym);
 if(pp) *pfhis<< "\n+skips "<< sym << int(sym);
 while (  sym == ' ' || sym == EOL || sym == TAB) getsym();
}

   void wrb(char c)
{
 //if(pp)cout<<"wrb:"<<c;
 if(++irb>=lrb)error("wrb:",irb);
 rb[irb]=c;
}
   void wrbs()
{
 //if(pp)cout<<"wrbs";
 wrb(sym);
 getsym();
}
   void wrbs(char c)
{
 if(ppp)cout<<"wrbs:"<<c<<sym;
 if(sym!=c)errorc("wrbs: must be ", c); 
 wrb(sym);
 getsym();
}

   inline bool isltr(char c)
{
 //if(pp)cout<<"isltr:"<<c;
 return isalpha(c) || c=='_' || c=='$'; // ??? $
}
   void wrid()
{
  irb=-1;
  while(isltr(sym)||isdigit(sym))wrbs(); wrb(0);
}

   void	glex()  // sym already exists 
{
 int prt1, count=0; char c, savesym;            // for dot; sp1: lexem before s;
 sp1 = s; s = s0; s0 = s01; s01 = s02;          // s0 - next lexem, s01 - next next lexem, s02 - next next next lexem;
 ++glexcount;
 if(aa){ *pfhis<<"\n+glex: nstr= "<<nstr<<" glexcount= "<<glexcount<<" ss="; microcont(pfhis); } 
 if(s.m == meof) return;
 glex1: skips();
 long v = 0;
 irb= -1;
 s02.i = 0; s02.ad = 0;
 if(aa) *pfhis<<"\n+glex sym= " << int(sym)<<' '<<sym;
 if(sym == EOF){ s02.m = meof; goto ret;}
 
 if(sym == '/' && cont[icont+1] == '/') //----- line comments
 {
  icont = strlen(cont) - 1; getsym();     // line is skipped
  goto glex1;
 } // end line comments

 if(sym=='/' && cont[icont+1]=='*') //---------/* */) comments
 {
  getsym(); getsym();               // skipped /*
  while(sym != '*' || cont[icont+1] != '/')
  { 
   if(++count > 999999) error("glex: too big count, cont= ", cont, " count= ", count);
   getsym();
   if(sym == EOF) error("glex: EOF inside /* */ comment");
  } // while(sym != '*'
  getsym(); getsym(); // skipped */
  goto glex1;
 }; // end /* */ comments
 if(sym == '"')        // -----------------strings
 {
  wrb(sym);
  while((c=cont[++icont]) != '"')
  {
   if(c==0) error("glex: wrong(no end \") string ");
   if(c==EOL) error("glex: EOL in string ");
   wrb(c);
  }  
  wrb('"'); 
  wrb(0);
  s02.m = strng; s02.ad = wrts(rb); s02.i = 0;
  getsym();  // skipped the last "
  if(99) ipp("glex:strng s02= ", vts(s02.ad));
  goto ret;
 } // end strings
 if(isltr(sym)) //-------------------------------ident
 {
  // irb=-1;
  M: while(isltr(sym)||isdigit(sym))wrbs(); wrb(0);// wrid();
  s02.m = ident; s02.ad = wrts(rb); s02.i = 0;
  if(s02.ad==att(aend)){ s02.m = clp; goto ret; }
  int k= prt(rb);
  if(k>0){ s02.m = ubs; s02.i = k; }
  goto ret;
 } // -----------------------------end ident

 if(isdigit(sym)) //-----------------------numbers
 {
  while(isdigit(sym))
  {
   if(v < INT_MAX24) v=v*10+sym-'0';
   wrbs();
  }; 
  if(isltr(sym)) goto M;   // 0z is ident;
  wrb(0);
  if(v > INT_MAX24) error("glex: too big number: ", rb);
  //s.m = ints; s.a = v;
  s02 = elmint(v);   // 11/2/99
  goto ret;
 } //end numbers 
 
 if(sym=='(' || sym=='[' || sym=='{')   // || sym==',' || sym==';' )
 {
  s02 = elm(gpc, sym, 0); getsym();
  if(sym1=='{' && sym=='}'){ s02 = elm(ident, 0, wrts("{}")); getsym(); }
  if(sym1=='[' && sym==']'){ s02 = elm(ident, 0, wrts("[]")); getsym(); }
  goto ret;
 } // end gpc
 
 if(sym==',' || sym==';' ){ s02 = elm(gcom, sym, 0); getsym(); goto ret;}
 
 if(ops[sym]) // ------------------------operators
 {
  savesym = sym;
  wrbs();              // dot at the end of long operator symbols is not allowed;
  while(ops[sym] && (savesym=='.' || sym != '.')) wrbs();        // ??? ..# : one lexem, not two: .. ,  #
  wrb(0);
  while(prt(rb)==0)  // wrong sequence
  {
   if(rb[irb-1] != '@') ipp("glex: possibly wrong sequence ", rb, " rb[irb-1] = ", rb[irb-1] );
   if(irb==1) error("glex: wrong symbol: ", rb[0]);
   rb[--irb] = 0; 
   if(--icont < 0) error("glex: no success to go back");  // goback();
   sym = cont[icont];
  } // if(prt(rb)==0) 
  prt1 = prt(rb);
  if(sym=='_')       // _ can be inside operators;
  { 
   --irb;    // removed 0 from rb;
   wrbs(sym); while(isltr(sym)||isdigit(sym))wrbs(); wrb(0);
  } // if(sym=='_')
  s02.m = ubs; s02.ad = wrts(rb);
  s02.i = prt1;
  goto ret;
 } // end operators
 if(sym==')' || sym==']' || sym=='}')// ---parenthesis
 {
  s02.m=clp;
  s02.i=sym; 
  s02.ad = icont; 
  // if(9) ippelm("glex: s02= ", s02);
  wrbs(); goto ret;
 } //  else if(sym==')'

 cout<<"nsym="<<sym;
 error("glex:incorrect sym ASCII= ",int(sym));
 
 ret: skips();
 if(glexcount==stad2)
 aa=aa;
 if(aa ) ippelm("-glex s= ", s, " s0= ", s0, " s01= ", s01, " s02= ", s02);   //pp
 // if(aa) cin>>c;  //gg
}  // end glex

   void stp(char c)            // not used
{
 if(sym!=c)
 {
  cout<<"\nsym= "<<sym;
  errorc("stp:must be ",c);
 }
 getsym();
 glex();
} // end void stp(char c)

   void stp1(char c, char* q, int k)            // s must be clp or gcom
{
 if(aa) *pfhis << "\n+stp1 c= "<<c<< " place= "<<q<<" k= ", k;
 if(s.m != clp && s.m != gcom)
 { 
  pst("stp1"); 
  ipp("stp1: s= ", s, " c= ", c); 
  errorelm("stp1: s is not clp and not gcom, s= ", s, " place= ", q, " k= ", k);
 } // if(s.m != clp && s.m != gcom)
 if(char(s.i) != c)
 {
  pst("stp1c");
  cout<<"\nstp1:must be "<<c<<" ,not "<<char(s.i)<<" q= "<<q;
  *pfhis<<"\nstp1:must be "<<c<<" ,not "<<char(s.i)<<" q= "<<q;
  errorelm("stp1: s= ", s, " s0= ", s0, " s01= ", s01);
 } // if(char(s.i) != c)
 glex();
 // if(c==']') ipp("\nstp1:top= ", top," top1= ",top1," s= ",s," s0= ",s0);
} // void stp1(char c, char* q)

   int prt(char* s)
{
 if(pp) ipp("+prt s= ", s);
 int i, r = 0; char s1[80]; char s0[80]; char c;
 strcpy(s0, s);
 for(i=0; i < 80; i++)
 {
  c = s[i];
  if(c==0) goto M;
  if(c=='_'){ s0[i] = 0; goto M; } 
 } // for(i)
 error("prt: no end zero in s= ", s);
 M: strcpy(s1,","); strcat(s1,s0); strcat(s1,",");
 for(i=0; i<lsbin; i++)
 {
  // if(pp) ipp("prt i= ", i);
  if(sis(s1, sbin[i])) { r = i+1; goto ret; }
 } // end i
 ret: if(pp) ipp("-prt r= ", r);
      return r;
} // end  int prt(char* s)

   void inops()    // initialization ops[]
{
 int i,j; char c;

for(i=0; i<256;i++) ops[i]=0;
for(i=0; i<lsbin; i++)
{
 if(gg) *pfhis<<"\n"<<i<<' '<<sbin[i]; 
 for(j=0; c = sbin[i][j]; j++)
   if(c != ' ' && c != ',' && !isalpha(c)) ops[c] = 1;
}
 if(gg) *pfhis<<"\ninops: sun= "<<sun;
 for(j=0; c=sun[j]; j++) 
   if(c != ' ' && c != ',' && !isalpha(c)) ops[c] = 1;

ops['?'] = 1; ops['!'] = 1;

} // end inops

   bool isident(char* s1)
{
 ats sa;
 return Ident(s, &sa) && strcmp(ts[sa], s1) == 0;
}

   bool isname(char* s)
{
 char q[80]; int i, j; 
 while(sym == ' ') getsym();
 q[0] = 0;
 if(pp) ipp("+isname s= ", s);
 if(!isalpha(sym)) return false;
 for(i = icont, j = 0; cont[i] &&
     (isalpha(cont[i]) || isdigit(cont[i]) ); i++, j++)
  q[j] = cont[i];
 q[j] = 0; 
 bool r = (strcmp(s, q) == 0);
 if(pp) ipp("-isname q= ", q);
 if(pp) ipp("-isname r= ", r);
 return r;
} // end isname

   int findts(char* s)
{
 int r = emptyts, i;
 if(pp)ipp("+findts s,its =  ", s, its);
 for(i=0; i<=its; i++)
	 if(strcmp(ts[i], s) == 0) { r = i; goto ret; }
 ipp("findts: not in ts, s, its= ", s, its);
 ret: if(pp)ipp("-findts r =  ", r);
 return r;
}  // end findts

   int wrts(char*s)
{
 int i;
 // if(pp) ipp("+wrts s= ", s);
 if(strlen(s)==0)
  error("wrts: empty string s= ", s);
 i = findts(s);
 if(i >= 0) goto ret;
 if(++its >= maxits) error("ts::overflow ts s, its=", s, its);
 ts[its] = clon(s);
 // if(pp) ipp("-wrts s,its= ",s,its);
 i = its;
 ret: if(ptt && prognum==numtrm) ++(ptt->freqts[i]);
 return i;
}  // end wrts

