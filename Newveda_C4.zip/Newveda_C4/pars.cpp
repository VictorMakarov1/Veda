#include "lib.h"  // 11/17/97 11/09/99 11/29/99 07/13/00
#include "rep.h"  // fixed terms go to beginning of tabt, else: to end of tabt;
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h"
#include "typ.h"
#include "glex.h"  //10/96  8/28/96  3/11/97  5/8/97
#include "term.h"
#include "elem.h"
// #include "df.h"
#include "etc.h"
#include "err.h"

#define maxnp 64
#define maxinhl 2  // inheritance list
att amn;           // minus: -
elem zmn;
elem zend;
extern int ab,cc,zz, glexcount;
extern ats acol, adcl, aconj,anot,aend; // ,depthst;
// extern ats* stdepth_pars;
extern att aexc, adexc;
extern int aa,its;  // aa is only for term!
extern elem sp1,s,s0,s01,s02; // sp1: before s; s: current, s0: next after s, s01: next after s0, s02: next after s01;
extern elem zel1; 
extern elem ydcl;   // elm(ident,0,adcl);
extern elem opp;    // openning  parenthesis
extern elem opb;    // openning  bracket
extern elem opc;    // openning  curly brace
// extern elem clpar;  // closing  parenthesis
extern elem comma;  // comma
extern elem semicolon; // semicolon
extern elem yexc;   // ! exclamation mark
extern elem yfn;   // 
extern elem ydexc;  // !! double exclamation mark
extern elem zpostfix;  // dcl[ elm(ident,0,wrts("postfix"));
elem abtermp;       // abstraction term parenthesis
elem ycomma;          // elm(clp, ']', 0); // elm(gcom,'.',0);
ats acrlf;
// extern elem mid ;  // | 
extern ats aProof, aEqProof, anot1;
extern elem zexist1, st1[1];
extern int ist1;
extern intp stdf;           // stack for def ( the type number) 3/8/97
int istdf = -1;                // 3/8/97
extern int lstdf; 
extern elemp auxn;          // auxiliary (hidden) names  3/8/97
int iauxn = -1;
int lockist = 0;
int istscp = 0;
elem stscp[sizestscp];      // sizestscp = 31
#define topstscp stscp[istscp]
elem scpe;                  // scope
bool pAx;                   // for finding !! T-__ (T- is not Ax)
// bool pnn;                   // for printing nn in seqt  
extern int lauxn ;
extern int icont,kk ;
extern int mergecount;      // merge count in findtabt;
extern int findcount;       // number of calls of findtabt;
extern char cont[];
extern char source[kdirname];
extern char* arlpus[];
extern char* arspms[];
extern char* arpostfix[];
extern ifstream* pfin;
// void wrst1(elem z);
bool rwcm(ifstream* f, char* s, int ssize=80);// read without emp. l-s and com-s
void pcin();
// void check(char* s);        // in adl
void term(bool u = false);
void smpt(bool u = false);
int seqt(char sp);
void brsq();
void crlf();
// elem fseg(int k, int tel = pfs) ;
void pseg(int k, att lev=sizestscp);
void clb(int p);
void movs();
//void movs(char m, char i, int a);
//void wrauxn(elem z);               // 3/8/97
void wrstdf(int k);
int inhl();
int list(char c);
void checkgpc(char* s, char c);
bool isinst(elem z);
int seqsimpcomma();
inline bool uns(char* s){ return sis(s,sun); }    // unary symbol must be 1-sym
inline bool Underscored(elem z){ return z.m == ubs && strchr(vts(z.ad), '_') != 0; }
bool unary(elem s);   // s is unary symbol
bool lpus(elem s);    // lowest precedence unary symbol
bool spms(elem s);                                // special multiple symbol
bool postfix(elem s); // postfix: must be 1-sym
elem fseg2();  // normAEF: x,y:t,a,b,c:t1 in st converts to abt(5),x,y,a,b,c,x in t,y in t, a in t1, ...
att  normAEF(int a, bool pabt); // a: index of a in st, top = c:t1, pabt: write abt(5); 
inline bool gcomclp(elem s){ return s.m==gcom || s.m==clp; }  // end of postfix
inline att valexc(elem s){ att r=0; if(s==ydexc) r=truth3; else if(s==yexc) r=ctruth; return r; }
inline att valexc1(elem s){ att r=0; if(s.m==ubs && s.i <= truth3 && (s.ad==adexc || s.ad==aexc)) r=s.i; return r; }
inline bool endterm(elem s){ att m = s.m; return m==clp || s.m==gcom; }
inline bool clpar(elem z){ return z.m==clp && z.i==')'; }
inline bool clbr(elem z){ return z.m==clp && z.i==']'; }

/*  bool allex1(elem z)                     // moved to lib.h
{
 if(aa) ipp("+allex1: z= ", z, " itt= ", ptt->itt);
 bool r = (z==zall || z==zexist || z==zexist1 || z==zexistx || z==zexist1x);
 if(aa) ipp("-allex1: z= ", z, " r= ", r, " aa= ", aa); 
 return r;
} // bool allex1(elem z)
*/
  char comsem()             // comma or semicolon
{        // if top = opp & (st[ist-1] == yproof or ...) 
 if(aa) ipp("+comsem top= ", top, " top1= ", top1);
 char r = ','; ats a; elem x = top; x.ad = 0;
 if(x == opb && (ist==0 || top1==zdcol)){ r = ';'; goto ret; }  
 if(x != opp) goto ret;
 if(ist < 1) error("comsem: wrong ist= ", ist);
 a = top1.ad;
 if(top1.m != ident) goto ret;
 if (a == aProof || a == aEqProof) r = ';';
 ret: if(aa) ipp("-comsem r= ", r);
 return r;
} // end comsem

   void wrstscp(elem s)
{
 int m=s.m; int i=s.m; int ad= s.ad;
 if(aa)cout<<"\n+wrstscp s= "<<'('<<m<<' '<<i<<' '<<ad<<") "<<" istscp= "<<istscp<<" itt= "<<ptt->itt;
 if(aa)*pfhis<<"\n+wrstscp s= "<<'('<<m<<' '<<i<<' '<<ad<<") "<<" istscp= "<<istscp<<" itt= "<<ptt->itt;
 if(++istscp >= sizestscp)
  error("wrstscp: overflow of stscp,s= ",s," istscp= ",istscp," sizestscp= ", sizestscp);
 stscp[istscp] = s; scpe = s;
 if(aa) ipp("-wrstscp s= ", s, " istscp= ", istscp);
} // end wrstscp

   void popstscp()
{
 int m=topstscp.m; int i=topstscp.i; int ad= topstscp.ad;
 if(aa) *pfhis<<"\n+popstscp topstscp= "<<'('<<m<<' '<<i<<' '<<ad<<") "<<" istscp= "<<istscp;
 if(--istscp < -1) error("popstscp: istscp= ", istscp);
 scpe = topstscp;
} // end void popstscp()

  bool fixed(elem z, int k, bool* ar1)  // don't merge these terms !     // || bdname(z)
{                            // k: from fseg, ist-k+1 points to f; 
 int n; bool r,r1; // bool p = (z==zis);
 if(aa){ ipp("+fixed z= ", z, " k= ", k); pst("fixed "); }        
 r1 = z==zdcol || z==zdclb || z==yvar || allex1(z) || Abt(z) || z==zdconj || z==zby || z==zbyeq ||     //  || z== yasop
      z==zwith || z==zis || z==zProof || z==zEqProof  || z==opb && ( st[ist-k] == zdcol || ist==k-1) ; // ist==k-1: root term;
 r = r1; // ltt = 0 for r1==true; dcl,::, var,Proof, EqProof: OK, allex1(z) || Abt(z): ??? 
 if(!r)
 {
  n = ist-k;                  // n points to just below f // f(x,...);
  r = z==yasop || n > 0 && (st[n] == yasop && endterm(s) || st[n]==opp && valexc1(st[n-1])) ;  // s - current symbol; ???
  // if(r) ipp("pars:fixed z= ", z, " k= ", k); // pst("pars:fixed");
 } // if(!r)                     // endterm(s):  (s.m==clp || s.m==gcom)
 *ar1 = r1; 
 // if(p) ipp("-fixed: z= ", z, " st[ist-k+2]= ", st[ist-k+2], " r= ", r);
 return r;  
} // bool fixed

    void trm()
{
 ipp("+trm source=", source, " numtrm= ", numtrm);
 amn = wrts("-");  zmn = elm(ubs,prt("-"),amn); zend = elm(clp,0,aend);
 icont = -1; pAx = false; lockist = -1; glexcount = 0; // pnn=false;
 if(rwcm(pfin, cont, 120)) error("trm: waits term,gets EOF ", cont);
 ipp("trm: cont= ", cont);
 istscp = 0;  scpe = zel; stscp[0] = scpe;  // #define levs  istscp 
 sym = 'x'; s0 = zel; s01 = zel; s02 = zel;
 getsym(); // s0.m = 0; s01.m = 0;  s02.m = 0;
 glex();         // s = s0; s0 = s01; s02 = s01; now s = s0; s02 = [
 glex();         // now s = s01; s01 = [
 glex();         // now s = s02;, s0 = [
 glex();         // now s = [
 ist = -1;  // depthst = -1;
 term();
 if(s0.m != meof){ ptt->root = ptt->itt; ipp("trm:must be eof, cont= ", cont, "\ns0.m= ", s0.m); }
 // clb(0);
 if(ist != 0) error("trm:ist must be 0, not ",ist); 
 ptt->root = ptt->itt;
 ptt->prfreqts();
 time_trm = myclock("-trm finished ");
}  // end trm
 
 void hdcl()                                                          // handling dcl;
{
 int k; ats sa; att n; elem y;
 if(aa) ipp("+hdcl: s= ", s, " s0= ", s0);
 s = elm(ident,0, wrts(concat(vts(s),"[")));                          // dcl[x
 movs();   assert(s==opb);                                            // s = '['
 glex();         // skipped dcl,[;                                    // s = x
 if(s.m == ubs) s.m = ident;                                          // otherwise clb works wrong;
 if(!Ident(s,&sa) && s != opc) error("term: wrong dcl: not idubs, s= ", s);       // dcl[A[,
 if(s==opc)	s = elm(ident,0,acrlf);
 else if(lpus(s)) s.m = ident;   // lpus(s) == s = ! or s == !!;
 if(s.m==ident && s0==opb){ s = elm(ident,0, wrts(concat(vts(s),"["))); movs(); glex();} // skipped s,'['
 else movs();   // here s is ',' or ']';
 if(clbr(s)){ stp1(']'); fseg(2); goto ret; }
 stp1(',');
 n = ptt->newtt("dcl");              // qabterms cannot be in dcl !!!
 y = elm(curm,0,n); 
 filltabt(n);  // ptt->tabt[n] = ptt->tabt[0]; // wrstscp(y); // scpe = y;
 k = seqt(','); 
 stp1(']'); // popstscp();  
 fseg(k+2,n);
 ret: if(aa) ipp("-hdcl s= ", s, " s0= ", s0);
} // void hdcl() ------------------------ dcl[x,t1,t2,...,tk];

   void hprs(ats aP)  // handling proofs: Proor (or EqProof) z1=T; z2, ...zk; end  Proof (or EqProof) {-} T;
{
  int ik,k; att n;  elem x, P,T;      // s:  Proof or EqProof,s0: T // n: the fixed address of Proof(...) in tabt;
  if(zz==2) ipp("+hprs s0= ", s0, " s01= ", s01, " s02= ", s02 , " aP= ", aP);
  T = s0;
  if(T.m==ubs && T.ad==amn) T = s01;
  if(!Ident(T)) error("hprs: not an ident T= ", T);  // make errmsg like as in rnam;
  movs();                // ow sp1 = Proof, s = T or -, top = Proof or EqProof;
  wrst(opp);             // now st: ...Proof,(
  n = ptt->newtt("hprs"); // reserved n as the fixed address of Proof(...) in tabt;
  k = seqt(';');         // now st: ....,Proof,(,T,z2,..., zk; // s: end, s0: Proof or EqProof,s01,s02:{-}T
  ik = ist-k;            // ik points to '('; s:end,s0:Proof,s01:T
  if((x = st[ik]) != opp) error("hprs: st[ist-k] != opp, st[ist-k] = ", x, " ist= ", ist, " k= ", k);
  if(s != zend)
			error("hprs: expecting end of proof, but s != end, s= ", s, " s0= ", s0, " sp1= ", sp1);
  glex();                // skipped end; now s = Proof or EqProof, s0,s01: {-}T
  P = st[ik-1];          // st[ik-1] is Proof or EqProof
  if(P != s)	error("hprs: not same Proof or EqProof, P= ", P, " s= ", s);
  glex();                // skipped Proof or EqProof, now s,s0 = {-}T;
  T = st[ik+1];          // T is T or -T; 
  if(fnt1(T,zmn,&x))     // T is actually -T;
  { 
   if(s != zmn) error("hprs: s01 is not minus, s01= ", s01, " x= ", x);
   T = x;
   glex();               // skipped - now s = T;
  } // if(fnt1(T,zmn,&x))-
  if(s != T) error("hprs: s != T= ", T, " s= ", s); // 
  glex();                // skipped T; 
  st[ik].ad = n;         // n for fseg;
  pseg(k+1); 
  if(s != semicolon) error("pars: no ; (semicolon) after end", vts(T)); 
  if(zz==2) ipp("-hprs s= ", s, " s0= ", s0, " s01= ", s01);
 } // end void hprs

   void term(bool u)     // after term(), s is the next lexem after the term;
{
 int k,pr,save = lockist; ats sa = -1; headp h; bool p; lockist = ist;  // lockist: for clb;
 att n; elem x,y,z;
 // aa = (nstr >= stad2 && nstr <= stad2 + 20);  //  && (prognum==numtrm);
 if(aa) ipp("\n+term s= ", s, " sp1= ", sp1, " aa= ", aa);
 if(s.m == gcom || s.m == clp)
 {
  // pst("if(s.m == gcom || s.m == clp)");
  ipp("term: cont= ", cont);
  error("term: can not begin with gcom or clp s= ", s);
 } //  if(s.m == gcom || ...)
 if(idubs(s,&sa) || s.m==ints)                               // ??? 5;6; ???
 {                                                           // alone ubs will be changed to ident;
  if(gcomclp(s0)){ if(s.m==ubs) s.m = ident; movs(); goto ret; }
  if(sa==adcl && s0==opb) { hdcl(); goto ret; }  // handling dcl[...];
 } // if(idubs(s,&sa))
 if(lpus(s) && top != zdclb) // lowest precedence unary symbol s == yexc || s == ydexc
 // if(s == yexc || s == ydexc)
 { 
  if(u) errorelm("term: unary after unary s= ",s); 	
  k = valexc(s); // att valexc(elem s){ att r=0; if(s==ydexc) r=truth3; else if(s==yexc) r=ctruth; return r; }
  if(k)
  { /*ipp("pars:valexc: s= ", s, " top= ", top, " top1= ", top1);*/ s.i = k;
  if(k==truth3)
  { 
   char* ss = vts(s0); 
   if(strcmp(ss, "Tconstseq1")==0 || curm != 0) pAx = true;
   if(ss[0] != 'A' || ss[1] != 'x') if(pAx) ipp("pars:term: not Ax---name after !!, s0= ", ss);
   } // if(k==truth)
  } // if(k) // k == truth3 or ctruth;
  movs();
  wrst(opp); 
  term(true);     // st: ...,!,(,top;
  if(k)
  {               // remove "!,( // "truth, ctruth was assigned in fseg;
   if(aa) ipp("term:  remove !,(, k= ", k, " ist= ", ist);
   if(top1 != opp || top2.ad != aexc && top2.ad != adexc) 
      error("term: top1 != opp or top2 != '!', '!!',  top1= ", top1, " top2= ", top2, " k= ", k);
   x = top; 
   popst(2); 
   top = x; 
  } // removed "!,( // "truth3, ctruth was assigned in fseg;
  else pseg(2); 
  if(aa) ipp("term: -if(lpus), s= ",s);
  goto ret;
 } // if(lpus(s) && top != zdclb)
 if(spms(s) && !isinst(zdclb))    // special multiple symbol, was top != ydclb
 {                        // "var", "by", "is",  "with", "byeq", "byimp", "add", "*end*"Tffn6
  if(aa) ipp("term: spms(s) && !isinst(zdclb s= ", s);
  movs();
  wrst(opp);
  int k = seqt(',');
  if(aa) ipp("term:spms: k= ", k); 
  pseg(k+1); 
  goto ret;
 } // if(spms(s) && !isinst(zdclb))------------end special multiple symbols;
 if(int(s.m) == ubs && (s0.m == gcom || clpar(s0))) // --------- alone ubs;
 { 
  if(clpar(s0)) s.m = ident;
  if(aa) ipp("term: ubs as an ident, s= ", s);	 
  movs(); goto ret; 
 } // if(int(s.m) == ubs && s0==clpar)---------end of alone
 // if(s.m==ident && ats(s.ad)==anot1)
 // s=s;                                    //
 if(aa) ipp("\nterm: waiting for smpt binary ... binary smpt,s= ", s); 
 do{
  if(aa) ipp("\nterm: begin of do s= ", s, " top= ", top);
  smpt();     // x *(group).Gr(H) y = x * y error: *: was clb(pr) movs();
  // waiting for end of term ( gcomclp(s)) or a binary: *, *(group), *(group).Gr: this is the end of the binary  
  if(aa){ ipp("\nterm: do: after smpt, s= ", s, " top= ", top); pst("term: do: after smpt"); }
  if(s==zdot)                               // smpt.X is smpt; // not if but while ???
  {
   wrst(top);
   top1 = s;   glex(); // s==zdot;
   if(Ident(s)) movs(); else smpt();
   fseg(3); 
   if(aa)
   { 
    ipp("pars:term: do after fseg: -zdot top1= ", top1, " top= ", top);
    pst("pars:term: do after fseg: -zdot"); 
   } // if(aa)
   if(Ubs(top) && !isrt(top, zdot) ) goto M1;
  } // if(s==zdot)   // end of binary
  if(ist == 0) break;
  if(gcomclp(s)) break;         // added: 6.16.19;
  while(s == opp || postfix(s)) // f(x)(y) or f(x)-; 
  {
   if(aa) ipp("\nterm: begin of while: top= ", top, " s= ", s, " s0= ", s0);
   if(s == opp){ movs(); k = seqt(comsem()); pseg(k+1); stp1(')'); continue; }
   // here postfix(s) is true;
   if(gcomclp(s0) || Binary(s0))  //  s is a postfix lexem;
   { 
    if(aa) ipp("\nterm: while: postfix(s), s= ", s, " s0= ", s0);
    wrst(top);                   // top is term before -
    st[ist-1] = s;               // because s is prime;
    z = fseg(2,emptt,pfs,&h);
    h->postfix = 1;
    if(aa) ipp("\npars:postfix z= ", z);
    glex(); continue;
   } // if(s0==clpar || Binary(s0))
   goto M;   // postfix is binary, // postfix must be followed by gcom: ,; or clp: (]}
  } // end while(s == opp || postfix(s))                     
  // waiting for a binary s or s(...)
  if(prime(s))      // s.m==ident||s.m==ints||s.m==chara||s.m==strng; 
  {
   if(aa) ipp("\nterm: do: prime(s), s= ", s, " s0= ", s0);
   if(Binary(top1)){ fseg2(); goto M; }	  // F1 := A[x_H, x *(group).Gr e.Gr = x];
   if(Ubs(top)) goto M1;
   // if(fnt1(top, zmn, &x) && x==zbyeq )
   // {
   // }
   error("pars: term: ident or const after simple term, top1= ", top1, "\ntop= ", top, " s= ", s); // , " s= ", s);
  } // if(prime(s))
  M: if(aa) ipp("\nterm:M,  s= ", s, " top= ", top);
  if(Ubs(s, &sa, &pr))
  { 
   bool pzdcol = (s==zdcol);
   clb(pr); movs(); 
   if(pzdcol)          // sp1 precedes s;
   {                       // d::[ ... d:: ... ] is impossible!!!
    n = ptt->newtt("::");  // fill tabt[n] in clb;
    y = elm(curm,0,n); ptt->tabt[n] = ptt->tabt[1]; wrstscp(y); // popstscp in clb!
    if(aa) ipp("term: zdcol: n= ", n, " itt= ", ptt->itt);
   } // if(sp1==zdcol)
  } // if(Ubs(s, &sa, &pr))
  if(aa){ pst("term: after M"); ipp("term: after M: s=",s); }
  
  if(s == zdot || s == zat)              // a < .T b;  * @ mltSS  // s0: next after s; // R(X *.(elg/N) Y) = R; 
  {                                      // ! Tfgr6 := K0 <|.(elg/N) K1 -> union(K0) <| union(K1);
  if(aa) ipp("\npars:term : zdot or zat, top1 = ", top1, " top= ", top, " s0= ", s0);
   if(! idubs(top)) error("term: zdot or zat, not(idubs(top), top= ", top, " s= ", s);
  //  wrst(top); top1 = s; glex();  // skipped '.' or '@'; 
   wrst(s); glex();                 // dot or at is now top
   if(s==opp) smpt(); else movs();             // s0 is now s;
   // if(top1==zdot){ smpt(); if(9) *pfhis << "\n\n$$$ "<<strvalue[nstr]; if(9) pst("pars:dot"); }       // now old s = top1; was with else;
   if(top1==zat && !Ident(top)) error("term: zat: not ident s= ", s); 
   // movs(); fseg(3);
   fseg2();
   if(Binary(s)) movs();
  } // if(s == zdot || s == zat)

  M1: p = Ubs(top, &sa, &pr) && pr; //  && s.m != clp;
  if(aa) ipp("\nterm: before end while: top= ", top, " s= ", s, " p= ", p);
  if(p && Underscored(top) && Binary(s))   // top != ":=";
  {
   elem saves = s; 
   if(aa) ipp("\nterm: +M1: top= ", top, " s= ", s, " s0= ", s0);  // M1
   movs();              // top = s;
   smpt();              // ??? term();
   if(top1 != saves) ipp("\nterm:M1: top1 != saves, top1= ",top1, " top= ", top, " saves= ", saves); 
   fseg2();
   if(!Binary(top)) error("term:M1: !Binary(top), top= ", top, " top1= ", top1, " s= ", s);
   if(aa) ipp(" term: -M1: top= ", top, " s= ", s, " s0= ", s0); // M1
  } // if(Binary(top))
  if(p) p = (s.m != clp);
 }while(p); // end do; top.m == ubs && top.i)
 if(ist>0 && Ubs(st[ist-1]))
 {
  if(aa) ipp("term:clb(0), s= ", s);
  clb(0); // remove all binary symbols from st (clear binary)
 }
ret: lockist = save; if(aa) ipp("-term s=", s, " lockist= ", lockist);
} // end term

   void smpt(bool u)
{
 int k=0; bool p,p1,p2,pun = false,pmovs; char c; att n; elem x,y; 
 if(aa) ipp("\n+smpt s= ", s);  //cin>>c;
 if(lpus(s) && top != zdclb && s0 != zat)  // 1. lowest precedence unary symbol s == yexc || s == ydexc
 { 
  if(u) errorelm("smpt: unary after unary s= ",s); 	
  k = valexc(s); // att valexc(elem s){ att r=0; if(s==ydexc) r=truth3; else if(s==yexc) r=ctruth; return r; }
  if(k) s.i = k; 
  movs();
  wrst(opp); 
  term(true);     // st: ...,!,(,top;
  if(k){ x = top; popst(2); top = x; } // truth3, ctruth was assigned in fseg;
  else pseg(2);
 //  movs(); wrst(opp); term(true); pseg(2); 
  if(aa) ipp("smpt: -if(lpus), s= ",s);
  goto ret;
 } // if(lpus(s))
 if(unary(s) && s0 != zat)                 // 2. special unary symbol (~,#,-)
 {
  if(u) error("smpt: unary after unary s= ", s); 
  movs(); pun = true;         // st: -; s = (, s0 = mint1, s01 = )
  if(s==opp && s0.m==ident && clpar(s01))  // 2.1 ~(x)  ??? 1.3.21
  {
   if(aa) ipp("smpt: s==opp && s0.m==ident && clpar(s01), u= ", u);
   wrst(s0);
   fseg(2);
   glex();   // skipped (, s = ident
   glex();   // skipped ident, s = )
   glex();   // skipped )
   goto ret1;
  } // if(s==opp && s0.m==ident && s01==clpar)
  smpt(true);
  if(top.m == ident && s.m == gpc) goto M;   // || top.m == curm
  goto ret;
 } // end if(unary(s))
 switch(s.m)
 {
  case ident:   // ------------------------------ 3. ident
  if(s.ad == att(aProof) || s.ad == att(aEqProof)) { hprs(s.ad); goto ret1; }
  if(s0 == opb )    // opb: "[" ----------------- 3.1 ident[   ??? make hidbr(); 1.3.21 ???
  {                               // Bnames: dcl, A, E, E1, R, F,... 
   if(aa) ipp("smpt:case ident:s0==opb: s= ", s, " s0= ", s0);
   if(s == ydcl){ hdcl(); goto ret1; }      //--------3.1.1 dcl[...          
   movs();     // char* bnames[] = {"A","E","Ex","E1","R","U","F","dcl","P","P1","S","II", "*end*"};
   if(!Bname(top)) error("term: not Bname before '[', top=  ", top);  // was Bname(top), Ident(top)
   char* s1 = vts(top);                     // s1 = "A"[
   glex();                                  // skipped '['
   top = elma(ident, wrts(concat(s1,"["))); // top = "A[" , "P[", ...   
   p = bdname(top); // bdnames: zA, zE, zEx, zE1, zF, zR, zU, zS; 
   if(p)      // ----------------------3.1.2  // top = A[, E[, E1[, R[, F[,...
   { 
    n = ptt->newtt("opb"); x = opp; x.ad = n; wrst(x);  // st: A[,(, ...
    y = elm(curm,0,n); ptt->tabt[n] = ptt->tabt[2]; wrstscp(y); // scpe = y;
   } // if(p)
   if(aa) ipp("term: Bname: top= ",top, " s= ", s); // pnn=true;
   k = seqt(',');   // ??? DONT USE seqt !!! 2023.01.14
   if(aa) pst("Bname",k);
   if(k>10) error("smpt:Bname: k>10, k= ", k);
   if(aa) ipp("smpt::case ident:s0==opb,after seqt: s= ", s, " k= ", k);
   stp1(']',"smpt::case ident:s0==opb:Bname");
   if(p)
   { 
    pseg(k+1, istscp);
    popstscp(); // scpe = topstscp;
   } // if(p) 
    else fseg(k+1);
   if(aa) pst("Bname pfseg");
   // if(s==opp){ smpt(); fseg(2); }   // ??? leave in term ??? 12.27.20
   if(s==opp)
   {
    glex();        // skipped '('    
    k = seqt(','); 
    fseg(k+1); 
    stp1(')', "Bname[...]( " ); 
   } // if(s==opp)
   goto ret; 
  } // if(s0 == opb)
  
  if(s0 == opp)  // opp: "(" ----------------------------3.2 ident(
  {
   y = s;
   if(aa) ipp("smpt:case idubs:s0==opp: s= ", s, " s0= ", s0, " top= ", top, " ist= ", ist);
   movs();                  // top = s; s = opp (s0) 
   movs();                  // top = '('; s = "symbol after 
   p1 = allex1(y) && y != zexistx;                          // ??? y != zexistx ???
   if(p1)  //--------------------------------------------3.2.1 All,Exist
   { 
    n = ptt->newtt("opp"); x = opp; x.ad = n; top = x;
    y = elm(curm,0,n); ptt->tabt[n] = ptt->tabt[3]; wrstscp(y); // scpe = y;
   } //  if(p1)
   c = comsem(); // if (ats(top1.ad) == aProof || ats(top1.ad) == aEqProof) c = ';';
   k = seqt(c);           // st: ...,ident par1, ... , park (was error if c==',', 2.13.19;)
   if(aa) ipp("smpt:case ident: after seqt: s0==opp: s= ", s, " k= ", k);
   stp1(')', "allex1");               // skipped ')'
   x = st[ist-k-1]; 
   if(x == zProof || x == zEqProof)
   {
    // ipp("smpt: after stp1(')', st[ist-k-1]= ", x, " st[ist-k+1]= ", st[ist-k+1]," ist= ", ist, " k= ", k, " sp1.ad= ", sp1.ad);
    if(sp1.ad > 5)  // closing parenthesis for Proof or EqProof must be in beginning of line;
     error("smpt: possibly wrong closing parenthesis for Proof or EqProof= ",st[ist-k+1]," sp1.ad= ", sp1.ad);
   } // if(x == zProof || x == zEqProof). It means that proof embeddeness must be 5 or less;
   pseg(k+1, p1? istscp: sizestscp); 
   if(p1) popstscp(); // scpe = topstscp; }
   if(aa) pst("smpt:case ident: s0==opp:");
   goto ret;
  } // if(s0 == opp)------------------- end case 2.ident
  
  case ubs:                           //            3. s: ubs
  if(s0==zat)  // s @ x, s is ident or ubs;         // 3.1 ubs @ x
  {
   if(aa) ipp("smpt:(idubs):zat,s= ", s);  // s0 - next lexem, s - current lexem;
   wrst(zat); movs();    // st: ... @,s, // s = @, s0 = x;
   if(!Ident(s0) && s0.m != strng) error("smpt:ubs:zat: not ident, s0= ", s0);
   glex();    // skipped @; s = x;
   movs(); fseg(3); goto ret;   // movs(x);  fseg(@,s,x)
  } // case ubs: if(s0==zat)
  
  if(s0 == opp)                       //        3.2 ubs(
  {
   if(aa) ipp("smpt:opp ,s= ", s);    // *(group), but AxlE := (<==) = F[x:Y, S:P[Y], A[u:S, x <= u]];
   movs();                            // move '*' to st; s = '('; move ":=" to st, s = '('
   // movs();                         // move '(' to st; s = group
   glex();        // skipped '('    
   k = seqt(','); 
   fseg(k+1); 
   stp1(')', "ubs( " ); 
   goto ret; 
  } // if(s0 == opp)
 
   
   /*if(clpar(s0))                
   {
    M1clpar: movs();                 // move group to st; st: *,(,group or :=,(,<==
    if(top.m == ident) pseg(2); else{ top1 = top; --ist; } // else: removed '(' from st; 
    stp1(')');
    goto ret1;
   } // if(s0==clpar) // else: s (now the symbol after '(' will be movSed() to st; seems OK, 
  } // if(s0 == opp)              // wrst must check, if s.m = clp or gcom: error! 
  */
  if(aa) ipp("???smpt: ubs: s0 is not '@', not '(', s= ", s, " s0= ", s0);
  case strng:
  case chara:
  case ints:  movs();  goto ret;
  case gpc: M: if(aa)cout<<"smpt:gpc "<<s.i; if(aa)*pfhis<<"smpt:gpc "<<s.i;
  switch(s.i)
  {
   case '(':
   movs();      // move '(' to st;
   if(aa){ ipp("smpt: case '(' s= ", s, " s0= ", s0, " top= ", top);  pst("smpt: case '('"); }                 
   if(pun){ k = seqt(','); pseg(k+1); }
   else {     // s==group                       // sp1 = s; s = s0; s0 = s01; s01 = s02;
   if(Binary(top1) && clpar(s0) && s01==zdot)   // goto M1clpar; // because of x *(group).Gr(H) y = x, 2/12/19
   {
    if(aa) ipp("pars:Binary(top1) && clpar(s0) && s01==zdot, top1= ", top1, " top= ", top, " s= ", s);
    movs();    // s0=zdot;             // move group to st; st: *,(,group or :=,(,<==
    if(top.m == ident) pseg(2); else{ top1 = top; --ist; } // else: removed '(' from st; 
    stp1(')'); // if(9) *pfhis << "\n\n$$$ "<<strvalue[nstr]; // if(9) pst("pars:dot:s01");
    goto ret1;
   } //  if(Binary(top1) && ...)
   term(); // ? tuple terms ?
   if(top1 != opp) error("smpt: case gpc: wrong (not opp) \ntop1=  ", top1 );
   --ist; top = st[ist+1];
   } // else
   stp1(')', "smpt:case '(' "); 
   goto ret;

   case '[': if(aa) ipp("smpt: case [,  pun= ", pun); p2 = false; pmovs = false;
          /*if(top==zdcol)
          {
           if(ist > 0)
           {
            if(!Ident(top1)) error("smpt: case 'ident::[', top1= ", top1, " top= ", top);
            p2 = true; wrstscp(top1); // scpe = top1;
           } // if(ist > 0)
          } */ // if(top==zdcol) 
		  if(pun && Bname(top)) error("smpt: +case [, s= ", s, " s0= ", s0);
          // { 
          // top = elm(ident,0, wrts(concat(vts(top),"["))) ; glex(); 
          // } // skipped '['
          else{
           movs(); pmovs = true;  // ++ depthst;  
           // assert(ist>=0); stdepth_pars[ist] = depthst; // cont[icont+1] = 0;
           // if(9) *pfhis << "\n+case '[': depthst= "<<depthst<<' ' << "\n"<<cont; // pcont();
          } // else 
	         k = seqt(comsem());    
		        stp1(']',"smpt: case [",k);
	         fseg(k+1); if(p2) popstscp(); // scpe = topstscp; } 
          // if(pmovs){ --depthst; if(9) *pfhis << "\n-case '[': depthst= "<<depthst<<' ' <<cont; }
          goto ret; // end case '['

   case '{': wrst(zcrlf); glex(); crlf(); goto ret;

   default: error("smpt: wrong switch(s.i) s= ", s); // 11/3/99
  } // end switch(s.i)

   case meof: error("smpt: case meof");

   default : errorelm("smpt: default: s= ", s, " s0= ",s0);
  } // end switch(s.m)
 ret:  if(pun) fseg(2); 
 ret1: if(aa) ipp("-smpt top= ", top, " s= ", s);
} // end smpt

   int seqt(char sp)   // sp: separotor, seqt: sequence of n terms, returns n;
{
 int n=0, saveist=ist; bool p; headp h; elemp q; int static depth=0; 
 if(aa) *pfhis<<"\n+seqt ist= " << ist << " sp= " << sp;  ++depth;
 if(aa) cout<<"\n+seqt ist= " << ist << " sp= "<<sp;
 if(aa) ipp("+seqt s= ", s);
 if(aa) pst("+seqt");
 do
 {
  term();    // s is the next lexem after the term;
  if(s0==zpostfix && mel(top,&h,&q)==pfs && q[0]==zdclb) h->postfix = 1;
  ++n;
  // if(pnn) ipp("seqt:pnn top= ", top, " n= ", n);
  if(ist-saveist != n) 
    error("seqt: ist-saveist != n, top= ", top, " n= ", n, " ist= ", ist, " saveist= ", saveist);
  // if(depth==1 && n != ist) error("seqt: n != ist, top= ", top, " n= ", n, " ist= ", ist);
  if(aa) ipp("seqt:do: after term(), s= ", s, " n= ", n);
  // if(n>10 && n != ist) error("pars: seqt: n != ist, top= ", top, "ist= ", ist, " n= ", n);
  p = (s.m == gcom);
  if(p)
  {
   if(sp == ',' && s.i == ';') break; // no glex: because if sp==',', then ';' - finish;
   if(sp == ';' && s.i == ',' && n > 7) errmsg("seqt: not ';' , top= ", top, " cont= ", cont); // 7: ???
   glex(); // skipped "," or ";"
   if(s.m == clp ) break;                            // || s == mid
  } // end if(p)
 }while(p);
 if(aa) *pfhis<<"\n-seqt  sp= "<<sp<<" n= "<<n;
 if(aa) cout<<"\n-seqt n= "<<n<<" s.m= "<<s.m;
 // if(aa) ipp("-seqt s= ", s);
 if(aa) pst("-seqt");      --depth; // pnn=false;
 return n;
} // end seqt

   void crlf()               //  {x,y:t,a,b,c:t1; Ax1, ....} or {x,y.z} or {x; Ax1(x), 
{
 if(aa) ipp("+crlf: s= ", s, " s0= ", s0, " s01= ", s01);
 int l,a,k,m,t = pfs; att n=emptt; elem y;
 k = seqt(','); a = ist - k;   // a: index in st of {; // k = 5;
 if(s == semicolon)              // semicolon, was mid: | vertical bar
 {
  st[a] = abtermp; t = abt; // {x,y; P} -> abt(x,y,P); (abt.i = 2) ??? will be rewrote in normAEF ???
  st[a].i = k;              // kmain
  glex();                   // skipped mid // stp1('|'); // normAEF(a,false): false: dont write abt(k)
  if(fnt2(top,zcol))
  {                      // false: DONT write abt(k): already in st !
   l = normAEF(a+1,false); // changes st from a to ist: abt(5), x,y,a,b,c, x in t, y in t, a in t1, ...
   if(l != k) error("crlf: l != k, l= ", l, " k= ", k);
   k = k*2;              // x:t -> x, x in t;
  } // if(fnt2(top,zcol))
  n = ptt->newtt("crlf"); // x = opp; x.ad = n; wrst(x);  // st: A[,(, ...
  y = elm(curm,0,n); ptt->tabt[n] = ptt->tabt[4]; wrstscp(y); // scpe = y;
  m = seqt(';');           // axioms
  k = k+m;
 }
 stp1('}');
 fseg(k+1,n,t,0,t==abt? istscp: sizestscp);
 if(t==abt) popstscp(); // scpe = topstscp; }
 if(aa) ipp("-crlf s= ", s);
} // end crlf

   elem fseg(int k, att n, int tel, headp* ah, att lev) // in C++ == is stronger &&;
{
 int l,j; att k1; headp h; elemp q; int static count; bool pexc,pfixed=false,pfixed1=false;
 elem b,P,d; att isz=iszthmb; // ats a;
 if(aa)
 {
  ippelm("+fseg sp1= ", sp1, " s= ", s, " s0= ", s0);
  *pfhis<<"\n\n+fseg k= "<<k<<" ist= "<<ist<<" istscp= "<<istscp<<" itt= "<<ptt->itt;
  pst("+fseg: ");
 } // if(aa)
 j = ist-k+1;          // j points to q[0]; // st: !!,(,Tcaret1,:=,term
 q = &st[j]; b = q[0]; // b = st[j];
 // if(b==yasop && Ident(q[1], &a) && a==368)
 // mm=mm;
 pexc = j>2 && st[j-1]==opp && valexc1(st[j-2]) || j>4 && st[j-1]==yasop && st[j-3]==opp && valexc1(st[j-4]);
 if(k==2 && (b==yexc || b==ydexc))       // k==2: unary;
  ipp("fseg: unary ! or !!, top1= ", top1, " top= ", top); // was error 11.28.19, because n!: postfix;
 else pfixed = fixed(b, k, &pfixed1);  // pfixed1:   fixed, but not due to asop;
 if(pfixed1) isz = 0;          // || pexc
 if((bdname(b) || b==yfn)  && fnt2(top1,zcol))
 {
  P = top; --ist;
  l = normAEF(j+1, true) * 2 + 1;         // l : size of normalized abt term;
  d = fseg(l,emptt,abt,0,lev+1);  // remove tel from head ??? // ??? lev+1 ??? 
  if(top1 != b) error("fseg: wrong top1 != b, d= ", d, " top1= ", top1, " b= ", b, " l= ", l);
  wrst(P);
  k = 3;
 } // if((bdname(b)...)                          //  pfixed==true: ++itt else --itt1;
 n = ptt->wrtt(tel, k, q, n, lev, pfixed, isz);  //  p = fixed(b, k);
 h = ptt->tabt[n];
 // if(stopd != 0 && n == stopd) ipp("pars:fseg: after wrtt: elm= ", elm(curm,0,n), " n= ", n, " h->lth= ", h->lth); 
 if(ah) *ah = h;
 popst(k);
 if(top==opp && (k1 = valexc1(top1)) && endterm(s))
 { 
  if(top1.m == ubs && (top1.ad == aexc && k1==truth3 || top1.ad == adexc && k1==ctruth))
    error("fseg: ! or !! but wrong k1, top1= ", top1, " k1= ", k1); 
  h->t = k1; // h->t1 = 1;
  // if(9) ipp("pars:fseg:tead z= ", elm(0,0,n));
 } // h->t1: see mktr;
 wrst(elm(curm, 0, n)); // stprm[ist] = prm;
 if(aa) pst("-fseg"); 
 return top;
} // end fseg

 elem fseg2()
{
 if(aa) ipp("+fseg2: ist= ", ist); elem r;
 // if(ist<2) error("fseg2: ist < 2,  ist = ", ist);
 swapst(2,1);  // x = st[ist-m]; st[ist-m] = st[ist-k]; st[ist-m] = x;
 // st[ist-2] = top1; top1 = x; 
 r = fseg(3);
 if(aa) ipp("-fseg2: s= ", s);
 return r;
} // end elem fseg2()

    void pseg(int k, att lev)  // p: parenthesis, k is the same in fseg and in pseg;
{
 int ik = ist-k+1;  att n; elem x;   // ik points to '('
 if(aa) ipp("+pseg k= ", k, " ist = ", ist);
 if(ik<0) error("pseg: k= ", k, " ist= ", ist);
 if((x=st[ik]).m!=gpc)
     error("pseg:gpc: wrong(not gpc) st[ik]= ", st[ik], " ik= ", ik, " k= ", k); 
 n = x.ad; if(n==0) n = emptt;
 for(int i=0; i<k; i++) st[ik+i] = st[ik+i+1];  // moving k-1 top elements by 1 down stack; (wiping '(');
 popst(); // st[ik+1] = st[ik]; stprm[ik+1] = stprm[ik];
 fseg(k,n,pfs,0,lev); 
 // top1=top; stprm[ist-1] = stprm[ist]; popst();
 if(aa) pst("-pseg",k);
 if(aa) ipp("-pseg k= ", k, " ist= ", ist);
} // end pseg

   void clb(int p)
{
 ats sa; int pr; att lev,n=emptt; elem x,y;
 if(aa) ipp("+clb p= ", p, " lockist= ", lockist);  
 if(aa) pst("+clb");  
 if(ist <= 1) goto ret;    // 8/27/96
 while (Ubs(x=st[ist-1], &sa, &pr) && pr >= p && st[ist-2].m != gpc && st[ist].m != gpc && ist-1 > lockist)
 {
  swapst(1,2);
  n = emptt; lev = sizestscp;
  if(x == zdcol)
  {
   if(aa) ipp("clb:zdcol: topstscp= ", topstscp);
   y = topstscp;
   if(int(y.m) != curm) error("clb: y.m != curm, y= ", y);
   n = y.ad; 
   if(aa) ipp("clb:zdcol, y= ", y, " n= ", n, " itt= ", ptt->itt);
   lev = istscp;
   popstscp();
  } // if(x==zdcol)
  fseg(3,n,pfs,0,lev);    // 0: ah;
  if(ist <= 1) goto ret;  // 8/27/96  
 }; // while (Ubs(st[ist-1], &sa, &pr) && pr >= p) 
 ret: if(aa) pst("-clb"); if(aa) ipp("-clb top= ", top, " lockist= ", lockist); 
} // end clb
   
   void movs()
{
 if(aa) ipp("+-movs: s= ", s);
 //wrst(s.m, s.i, s.a);
 wrst(s);
 glex();
 if(aa)pst("-movs", 2);
} // 

  int list(char c) // c must be gen. comma (, or ;)  // not
{
 int p, k = 0;
 if(aa) ipp("+list c= ", c);
 do{
    term(); ++k;                  
    p = (int(s.m) == gpc && char(s.i) == c);
    if(p) glex();
   }while(p);
 if(aa) ipp("-list k= ", k);
 return k;
} //end list

   void checkgpc(char* s1, char c)     // not used
{
 char z[80];
 strcpy(z, s1);
 strcat(z, ":");
 strcat(z, " must be ");
 int k = strlen(z);
 z[k] = c; z[k+1] = 0;
 if(int(s.m) != gpc || char(s.i) != c) error(z, rb);
} // end checkgpc

   bool lpus(elem s)    // lowest precedence unary symbol: currently ! and !!;
{ 
  if(aa) ipp("+lpus s= ", s);
  bool r = (idubs(s) && findst(ts[s.ad], arlpus));
  // bool r = (s==yexc || s==ydexc);
  if(aa) ipp("-lpus r= ", r);
  return r;
}  

  bool spms(elem s)                    // special multiple symbol
{ 
 if(aa) ipp("+spms = ", s);
 bool r = (s.m == ident && findst(ts[s.ad], arspms));   // find string
 // bool r = (s==yvar || s==yby || s==yis || s==ywith);
 if(aa) ipp("-spms r= ", r);
 return r;
}  

   bool postfix(elem s)                        // must be 1-sym
{ 
  if(aa) ipp("+postfix s = ", s);
  bool r = (s.m == ubs && findst(ts[s.ad], arpostfix)); 
  if(aa) ipp("-postfix r= ", r);
  return r;
}

   bool isinst(elem z)
{
 for(int i = ist; i>=0; i--)
	 if(st[i] == z) return true;
 return false;
}

  bool insideqabt()    // inside of qab terms
{
 elem z;
 for(int i = ist; i>=0; i--)
 {
	 z = st[i]; 
  if(allex1(z) || bdname(z) || Abt(z)) return true;
 } // for(i)
 return false;
}

  
   int seqsimpcomma()
{
 int n = 0;
 if(aa) ipp("+seqsimpcomma s= ", s); 
 while(idubs(s))
 {
  movs(); ++n;
  if(s == comma) { glex(); continue; }
  else break;
 }
 if(aa) ipp("-seqsimpcomma s= ", s, " n= ", n); 
 return n;
} // end int seqsimpcomma()

   void pst(char* place, int k, ofstream* f)
{
 elem z;  k = 12; int m,i,ad; 
 *f<<"\n\n+pst: "<<place<<" ist=" << ist << " s= "; 
 pelm(s,f); *f << " itt= " << ptt->itt<<" mm= "<<mm<<"\n";  
 cout<<"\n\n+pst: "<<place<<" ist="<<ist<< " k= "<<k<<" s= "; pelm(s); cout<<" itt= "<<ptt->itt<<" mm= "<<mm<<"\n";  
 k = ist-k;
 if(k < 0) k=0;
 for(int j=ist; j>=k; j--)
 {
  z = st[j]; m = z.m; i = z.i; ad = z.ad; //  d = stdepth_pars[j];
  *f<<'\n'<<j<<" ("<<m<<','<<i<<','<<ad<<')';  prp(" ", z, pfhis);  // '<<d<<' '
  cout<<'\n'<<j<<" ("<<m<<','<<i<<','<<ad<<')'; prp(" ", z);           // <<d<<' '  
  if(m == ident || m == ubs || m == strng) // || z.m == bvr)
  *f<<' '<< ts[ad], cout<<' '<< ts[ad];
  if(z.m == gpc) *f<<' '<<char(i),cout<<' '<<char(i);
  if(m == curm) ptt->ptbt(ad);
  *f <<"\n"; cout << "\n";
 } // for(int i=k;
 ipp("-pst place= ", place, " mm= ", mm);
}  // end pst

  bool unary(elem s)               // special unary symbol (~,#,-)
{
 if(aa) ipp("+unary: s= ", s, " s.ad= ", s.ad); 
 bool r = (s.m == ubs && sis(vts(s), sun));
 if(aa) ipp("-unary: s= ", s, " s.ad= ", s.ad, " r= ", r);
 return r;
}

  void microcont(ofstream* f)
{
 prps(sp1,f); 
 prps(s,f);
 prps(s0,f);
 prps(s01,f);
 prps(s02,f);
}

 void prstcont(char* s1)
{
 cout << "\nstr= "<< nstr;
 cout << "\ncont= "<<cont;
 cout << "\nicont= "<<icont;
 cout << " microcont= "; microcont();
 cout << "\n";
 *pfhis<<"\nsp1ss0s01s02= "<<svel(sp1)<<svel(s)<<svel(s0)<<svel(s01)<<svel(s02);
 *pfhis << "\nnstr= "<< nstr;
 *pfhis << "\ncont= "<<cont;
 *pfhis << "\nicont= "<<icont;
 *pfhis << " microcont= "; microcont(pfhis);
 *pfhis << "\n";
 pst(s1);  cout <<"\n\n"; *pfhis <<"\n\n";
} 

 void swapst(int k, int m)
{ 
  if(k<0 || k>ist || m<0 || m>ist || k==m)
      error("swapst: wrong k or m, k= ",k," m= ", m," ist= ",ist);
  elem x = st[ist-k];     // bool p = stprm[ist-k];
  st[ist-k] = st[ist-m];  // stprm[ist-k] = stprm[ist-m];
  st[ist-m] = x;          // stprm[ist-m] = p;
} // end void swapst(int k, int m)                      
                                 // a - beginning in st of a0; pabt: write abt(k);
   att normAEF(int a, bool pabt) // normalization of A,...,F[a0,a1:t1,a2,a3:t2,...,P];
{  // pabt=true: A[d,P];         // or pabt=false: {a0,y:t, ...; Ax1, ...};
 int i, j=-1, k=-1, iR=-1, kpabt = pabt?2:1; headp g; elemp w; // j: index of A; k: "index" of T 
 elem x,y, A[maxlevqt], T[maxlevqt], R[maxvars];   // maxlevqt = 20, maxvars = 100;
 if(aa) 
 ipp("+normAEF: a= ", a, " pabt= ", pabt); // assert(hl >= 3);  // so no checks for iR;
 if(pabt) iR = 0;                 // 0 rezerved for abtermp(k+1) 
 for(i=a; i<=ist; i++)   
 {
  x = st[i]; 
  if(Ident(x))
  {
   if(++j >= maxlevqt) error("normAEF: overflow of j, a= ", a, "j= ", j, "maxlevqt= ", maxlevqt);
   A[j] = x;  R[++iR] = x; 
   if(aa) ipp("normAEF: for:ident x= ", x, " i= ", i, " j= ", j, " iR= ", iR); 
   continue;  // A = a0,a1,a2,a3;  j = 3;
  } // if(Ident(x))
  if(!fnt2h(x,zcol,&g,&w) || !Ident(w[1]) )
     error("normAEF: wrong x: not a:t, x= ", x, " zcol = ", zcol, " i= ", i);
  if(++j >= maxlevqt) error("normalAEF: overflow1 of j, a= ", a, "j= ", j, "maxlevqt= ", maxlevqt);  
  g->tp = zel1; // to avoid zel in futt;
  if(aa) ipp("normAEF x= ", x, " g->tp = ", g->tp);                
  A[j] = w[1]; 
  R[++iR] = w[1];  //  wrst(w[1]);  
  x = w[2];                 //  changing x = t from  x = a:t; was w[0] = zin;
  if(aa) ipp("normAEF: for:zcol x= ", x, " i= ", i, " j= ", j, " iR= ", iR); 
  while(k < j) T[++k] = x;  // T = t1,t1,t2,t2;  // k=0: only one a:t; 2*(k+1): size of names and axioms;
 } // for(i=a, i<=ist)      // j,k; number of names - 1;
 if(j != k) error("normAEF: the last x is not a:t, a= ", a, " j= ", j, " k= ", k);  // j = 3;
 if(pabt){ x = abtermp; x.i = k+1; R[0] = x; }   // abtermp = elm(ident, 0, wrts("abt"));
 for(i=0; i<=k; i++)for(j=i+1; j<k; j++)         // checking for repeating names in A;
  if(A[i] == A[j]) error("normAEF: repeating name A[i]= ", A[i], " i= ", i, " j= ", j);
 for(i=0; i<=k; i++)                             // writing axioms;
 {
  x = A[i]; y = T[i];   // elem trm2(elem f, elem x, elem y, elem t=zel, att n = emptt);
  // scpe = z;  
  y = trm2(zin,x,y,zbool);
  R[++iR] = y;          // wrst(y);
 } // for(i=0; i<=k);
 if(iR != 2*k+kpabt) error("normAEF: iR != 2*k+2, a= ", a, " iR= ", iR, " k= ", k, " pabt= ", pabt);
 // lev = qablev() + 1;               // ??? qablev() + 1: because d was not in ach;
 // d = fseg(ist+1,emptt,abt,0,lev);  // 0: ah;
 // if(9) ipp("normAEF: z= ", z, " d= ", d);
 // P = q[hl1];
 // q[a] = d; q[a+1] = P;  // h->l will be changed in bdef;
 ist = --a; // removed from st a0,y:t, ...;
 for(i=0; i<=iR; i++) wrst(R[i]);  // writing to st normalized version;
 if(aa) ipp("-normAEF: a= ", a, "pabt= ", pabt, "iR= ", iR, " k= ", k); 
 return k+1;     // k+1 : the number of names;
} // end void achs::normAEF


// end pars