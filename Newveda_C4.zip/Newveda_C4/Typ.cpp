#include "lib.h"  //  5/30/00 6/21/00 8/2/00 10/27/00 12/08/00 01/10/01
#include "achs.h"
#include "sbs.h"  // 01/29/01 02/17/00 03/14/01 04/24/01  05/31/01
// #include "rep.h"  // 06/13/01
#include "tt.h"
#include "adl.h"  
// #include "ismd.h" 
#include "etc.h"
#include "term.h"
#include "typ.h"     
#include "elem.h"
#include "lot.h"
#include "prf.h"
#include "styp.h"
#include "assert.h"
#include "rep.h"
#include "cr.h"
#include "err.h" 
#define abtval true
#define dcolval false
extern int ivin, jvin, kk, progress, mm, rrr, ilot,idep,proofdepth, repcount,sbstcount,instcount;
extern ats adot, aconj, aREL1;
extern bool nowlotinf, wasassume;
extern elem zcol,scpe;
extern achs* pntu;
elem mftp[lmftp];              // multiple function types. used in typtabt
elem savetyp;
int imftp;
int itt10;            // ditt = p->itt - itt10;
att itt_topt;         // itt after topt;
int maxditt;
elem lastseq;
elem maxdittlastseq;  // for eq proofs;
int maxditt1;         // for all other terms, except of M::[];
int maxd;             // if(ditt > maxd) then print y1, ditt 
int tead;
headp chtabt;            // for checking changing Tabt
att h_tel;
att h_l;
elem h_tp;            // to check changing h->tp;
elem archtabt[maxvars];  // ar for checking changing Tabt
int hlchtabt;
elem maxdittz;           // for terms in typseq: see typ: maxz = y1, ditt is max;
elem maxdittz1;          // for all other terms;
elem pred;   
extern elem yexc,ydexc;               
// void pvin(char* s=" ");
void pcin();
void checkr(char*);
bool abbr(elem z);
// bool Adot(elem z);
elem fnex();
char* svel(elem z);
inline abs(int x){ return x<0? -x: x; }
// void mktr(elem z);
int zelt,curtritt=0;

   void typa(elem z)
{
 // mm=1;
 pntu->iach = -1; ist = -1; zelt = 0; idep = -1; lastseq = zel;  int i; elemp q; 
//  maxditt = 0;  maxdittp = 0;  maxditteqp = 0; maxditt1 = 0;
 ippelm("+typa z= ", z, " stad2= ", stad2, " itt_topt= ", itt_topt); scpe = zel;  //{pelm(z); pcin(); }
 if(stad && inseg(stad, pait, endpait)) 
    error("typa: stad && inseg(stad, pait, endpait), stad= ", stad, " pait= ", pait, " endpait= ", endpait);
 itt_topt = ptt->itt; savetyp = zel;
 // chtabt = clad[stad1]->tabt[stad2]; 

 if(ww)
 { 
  // prthms(elm(stad1,0,stad2));
  chtabt = clad[stad1]->tabt[stad2];
  if(chtabt==0){ ipp("typa: chtabt=0, stad1= ", stad1, " stad2= ", stad2); goto M; }
  q = &(chtabt->son[0]); elem elmcurm = elm(stad1,0,stad2);
  h_tel = chtabt->tel;
  h_l = chtabt->l;
  h_tp = chtabt->tp;
  ipp("typa:chtabt:begin elmcurm= ", elmcurm, "h_tp= ", h_tp, " stad2= ", stad2, " chtabt->l= ", chtabt->l, " chtabt->lth= ", chtabt->lth);
  hlchtabt = numsonthm1(chtabt);                         // h->l + h->lth
 // k = thmbase(elm(curm,0,stad2), &w) + 1;              // 1: for possible val
  // if(hlchtabt+=k > maxvars) hlchtabt = maxvars; 
  for(i=0; i < hlchtabt; i++){ archtabt[i] = q[i]; *pfhis << "\ni= "<< i; prp(" q[i]= ", q[i], pfhis); }
  for(i=hlchtabt; i < maxvars; i++)  archtabt[i] = zel9;
  ipp("typa: finished initializarion of archtabt, archtabt[hlchtabt]= ", archtabt[hlchtabt]);
  M: ;
 }
 // */
 elem r = typ(z); 
 time_typa = myclock("-typa finished ");
 ipp("-typa r= ", r);
} // end typa

    att checktabt(char* s, elem z)
{
 att r= 0; int k,m; headp h; elemp q; elem elmcurm = elm(stad1,0,stad2); int static count = 0;
 ++ count; if(mm) ipp("+checktabt z= ", z, " s= ", s, " count= ", count);
 if(clad[stad1]->tabt[stad2] != chtabt)
 { 
  if(chtabt != 0) errorelm("checktabt: chtabt != 0, elmcurm= ", elmcurm);
  ipp("checktabt:change h: clad[stad1]->tabt[stad2] != chtabt, elmcurm= ",elmcurm, " stad2= ",stad2," count= ", count);
  *pfhis << "\n"<<s; if(z!=zel999) prp(z, pfhis); *pfhis << " itt= "<< ptt->itt; 
   chtabt = clad[stad1]->tabt[stad2]; *pfhis << " PLACE= " << s; r = 16;
   h_tel = chtabt->tel;
   h_l = chtabt->l;
   h_tp = chtabt->tp;
   goto ret;
 } // if(clad[stad1]->tabt[stad2] != chtabt)
 // else // chtabt is same;
 if(chtabt==0) goto ret;
  
 if(chtabt->tel != h_tel)
 { 
  ipp("checktabt:change h_tel,  elmcurm= ", elmcurm, " h_tel= ", h_tel, " chtabt->tel =", chtabt->tel," itt= ", ptt->itt);
  h_tel = chtabt->tel; pelm(" z= ", z, pfhis);
  ipp(" last_y1= ", last_y1, " last_y= ", last_y); 
  *pfhis << " PLACE= " << s;
  r |= 1;
 } // if(chtabt->tel != h_tel)
  
 if(chtabt->l != h_l)
 { 
  ipp("checktabt:change h_l,  elmcurm= ",elmcurm, " h_l= ", h_l, " chtabt->l =", chtabt->l, " itt= ", ptt->itt);
  h_l = chtabt->l;  pelm(" z= ", z, pfhis);
  ipp(" last_y1= ", last_y1, " last_y= ", last_y); 
  *pfhis << " PLACE= " << s;
  r |= 2;
 } // if(chtabt->tel != h_tel)

 if(chtabt->tp != h_tp)
 { 
  ipp("checktabt:change h_tp,  elmcurm= ",elmcurm, " h_tp= ", h_tp, " chtabt->tp= ", chtabt->tp, " itt= ", ptt->itt); 
  *pfhis << "\n"<<s; if(z!=zel999) prp(z, pfhis);
  h_tp = chtabt->tp; pelm(" z= ", z, pfhis);
  ipp(" last_y1= ", last_y1, " last_y= ", last_y); 
  *pfhis << " PLACE= " << s;
  r |= 4;
 } // if(chtabt->tp != h_tp)
    
 m = mel(elmcurm, &h, &q);
 if(!comp(elmcurm)) error("typ:stad2: !comp(elmcurm), z= ", z, " elmcurm= ", elmcurm);
 k = numsonthm1(h);
 if(k >= maxvars) k = maxvars;
/*
 for(i=0; i<k; i++)    // add check < maxvars !!! 1.2.22
 {
  if(q[i].i == 253) { ippelm("checktabt:253 q[i]= ", q[i], " i= ", i); prp(s,z,pfhis); continue;  } 
  if(archtabt[i] != q[i])
  {
   ipp("checktabt:change q[i], z= ", z, "\nq[i]= ", q[i], "\narchtabt[i]= ", archtabt[i], " i= ", i," count= ", count );
   *pfhis << "\n"; prp(s, z, pfhis);
    if(99){ *pfhis<<"\nchecktabt:change q[i]: Theorems"; for(i=0; i<k; i++){ *pfhis<<"\ni= "<<i; pelm(q[i], pfhis); } } 
    archtabt[i] = q[i];
  } // if(archtabt[i] != q[i])
 } // for(i=0)   // void ipp(char* s, elem x, char* s1, char* s2, char* s3, int x1);
*/    
ret: if(r) ipp("-checktabt z= ", z, " place= ", s, " r= ", r);   
     return r;               
} // end att checktabt(char* s, elem z)

  void prthms(elem z)
 {
  int i,k,m; elem x; headp h; elemp q,w;
  prp("\n+prthms z= ", z, pfhis);
  m = mel(z, &h, &q);
  if(simple(m)) goto ret;
  
  prp("\ntyp(z)= ", comp(z)? h->tp: tp(z), pfhis);
  k = h->lth;
  w = &(h->son[0]) + h->l;    // thmbase(z,&w);
  *pfhis << "\nk= "<<k; 
  for(i=0; i<k && (x = w[i])!=zel; i++)
     { *pfhis << "\n"<<i<<"  "; pelm(w[i], pfhis); }
  if(comp(z))
  { 
   *pfhis << "\n\nh->t= "<<h->t<<" h->adt= "<<h->adt<< " h->at= "<<h->at<< " h->v= "<<h->v;
   *pfhis << "\nval= "; pelm(w[0], pfhis);
  } // if(comp(z)
  ret: prp("\n\n-prthms z= ", z, pfhis);   
 } // void prthms(elem z) 

   elem typ(elem z, headp* ah, elemp* aq) // if simple(z) then return *ah = 0! 
{                                                   // p: to lessen printing;  // pv: was valued subterm;         
 elem r,t,t0=zel,t1,t2,t3,tt,f0,y,v,Q,M,T,z1; int static depth = 0;  bool p =  true, pv=false; 
 headp h,g,g1; elemp q,w,w1; ats a1,pid; att m = z.m;
 int ditt, saveitt = ptt->itt, savemm=mm; // savettt=ttt, savesss=sss; 
 int a,i,hlast,iar = -1;  sbst s;  elem ar[maxvars]; // ar,iar: for rterm;
 ++typcount;
 if(ist < -1 || ist >= lst) error("typ wrong ist, z= ", z, " ist= ", ist);  
 if(pait <= ptt->itt && ptt->itt <= endpait) mm=1;
 if(mm) 
  ippelm("+typ z= ", z, " itt= ", ptt->itt, " typcount= ", typcount);
 if(z.ad == stad1 && ptt->itt==stad2)
 mm=mm;  
 if(ww) checktabt("+typ");
 if(++depth > 100)
 {
  pntu->prach("typ");
  errorelm("typ: recursive term z= ", z);
 }
 if(ah) *ah = 0; if(aq) *aq = 0;
 // if(z.ad == stad2)
 //  ipp("typ:stad2 z= ", z, " zdbsl= ", zdbsl);
 if(m == ints ){ r = znat; goto ret1;}
 if(m == strng){ r = TPstring; goto ret1;} 
 
 if(adel(z,&h,&q))                       // z is simple;
 {
  if(z==zopsqbr){ ipp("typ z= [, r= zel0 , z= ", z); r = zel0; goto ret1; }
  if(Abt(z)){ ipp("typ Abt(z), r= zel0 , z= ", z); r = zel0; goto ret1; }   // addded on 2023.01.22
  errorelm("typ: wrong term(adel) z=", z); 
 } //  if(adel(z,&h,&q))
 if(z.i)                                          // z is var(???) or bvar
 {                                                // ?????? rework !!!!! 2.3.21
  r = tp(z, &m);
 // if(m==abt)                                      // z is an abt bvar
 // {
 //  t = typlot(z);                                 // move to ret??? 9.16.20 // must: t << r ???
 //  if(t != zel && t != r && r != zFN && r != zREL )
 //    { ipp("typ: after tp: changing type from r to t= ", t, "\nr= ", r); r = t; }
 // } // if(m==abt)
  goto ret1;
 } // if(z.i)
 if(ah) *ah = h; if(aq) *aq = q;   // below z is composite;
 // if(ptt->itt > 4138){
 //  r1 = ptt->tabt[4138]->tp; if(r1 != savetyp){ 
 //  ipp("+typ: r1 != savetyp= ", savetyp, "\nr1= ", r1); savetyp = r1; } } //
 r = h->tp; a = h->name; hlast = int(h->l)-1;
 if(mm) ipp("typ(h->tp): r= ", r, " q[0]= ", q[0], " h->t= ", h->t, " h->tel= ", h->tel, " h->at= ", h->at, " h->v= ", h->v);
 if(q[0]==zanyd && h->l == 2)
 { 
  if(pntu->seekdtd(zA,q[1]) != zel) r = q[1]; else r = zany; 
  goto ret1; 
 } // if(q[0]==zanyd && h->l == 2)
 if(curm==0 && a == aREL1)  nowlotinf = false;
 if(r != zel) // && r != zbool)
 { 
  // if(z.ad==tead) 
  if(vterm(h,&Q,&M) && !h->v) r = typdot(z,h,q);
 /* { 
   v = s.rep(Q,1);            // make a separate proc if(vterm(z
   if(99) ipp("typ:vterm:!h->v, z= ", z, "\nQ= ", Q, "\nM= ", M, "\nv= ", v);
   wrval(z,h,q,v);    
   if(Truth(Q) && mel(v,&g)==pfs) g->t = 1; 
  } // if(vterm(h,&Q,&M) && !h->v) 
*/
  goto ret1;           // type is already ready
 } // if(r != zel)
 // chtead(z, "------------0+TYP ");  // if(tead != 0 && int(z.ad) == tead)   mm=1;
 if(check(z.ad ,tead)) mm=1;
 if(mm){
   ipp("\n+TYP z= ", z, "\ntopach= ", pntu->iach<0? zel999: pntu->topach().e, " iach= ", pntu->iach,
      " wasassume= ",  wasassume, " ippcount= ", ippcount);
   // prext("+TYP");
   if(h->v) prp("\nval= ", valrt(z,h,q), pfhis);
 } // if(mm){
  pntu->wach(z);    // // typ: all types, TYP - only unhandled yet comp. types.
 for(i=pntu->iach-1; i>0; i--) 
 if(pntu->ach[i].e == z){ ipp("TYP: z is already being handled, z= ", z, " place in ach= ", i); pntu->prach("TYP"); }
 if(h->tel==pfs && q[0]==zdebug && h->l == 2 && q[1].m == strng){ r = zany; debug(q[1].ad); goto ret; } 
 if(h->tel == abt) { r = typabt(z, h, q); goto ret; }
 if(h->tel != pfs){ pntu->prach("typ: not pfs"); error("typ: not pfs",z); }
 if(q[0]==zRed){ ipp("typ: q[0]==zRed, no checking,z= ", z); r = zbool; goto ret; }
 if(Dcl(q[0]))
 {
  if(mm) ipp("typ dcl, z= ", z); r = zel1; 
  for(i=2; i <= hlast; i++)
  { 
   t = typ(q[i]);
   if(t==zel) error("typ Dcl wrong Dcl = ", z, " i= ", i);
   if(t==zbvar || t==zset || t==zassume || t==zany || t==zby || t==zbyeq || t==zbyimp || t==zadd || t==zbool ||
      t==zwith || t==zis || t==zvariable || t==zabterm || t==zfinabterm || isrt(t,zP) || notempty(t)) continue;
   error("typ: no theorem t ~= {}, t= ", t);
  } // for(i=2)
  goto ret;
 } // if(Dcl(q[0]))
 if(Var(q[0]))
 {
  if(mm) ipp("typ var, z= ", z); 
  if(typ(q[hlast])==zel) error("typ wrong type t in var x1, ..., xk, t; z= ", z, " q[hlast]= ", q[hlast]);
  r = zel1; goto ret; 
 } // 
 if(q[0] == zopsqbr)
 {
  r = typseq(z, h, q); 
  goto ret; 
 }   // [z1,z2, ... ,zk]
 if(syntvar(q[0]))
 {
  for(i=1; i <= hlast; i++)
     if(typ(q[i]) == zel) error("typ:syntvar: wrong q[i], z= ", z, " i= ", i);
  r = tp(q[0]); 
  goto ret;
 } // if(syntvar(q[0]))
 m = q[0].m;
 if( m == ints || m == strng || m == chara || m != ident && m != ubs && q[0].i == 0)
 {
  t0 = typ(q[0]); 
  if(mm) ipp("typ: t0 = typ(q[0]); z= ", z, "\nq[0]= ", q[0], " t0= ", t0); 
  if(t0==zint || t0==znat || t0==znat1) h->adt = 1;   // MAKE a general proc: add t == a..b, "string", ... 2022.08.18;
  // if(mel(t,&g,&w) == pfs && fntypn(w[0])) goto M2a;  // 2022.11.14;
 } // if(q[0].m == ints || ...)
 if(h->adt){ r = typmeth(z,h,q); goto ret; }
 if(q[0] == zconj) { r = typconj(z, h, q); goto ret; }
 if(q[0] == zimp) { r = typimp(z, h, q); goto ret; }
 if(q[0] == zif) { r = typif(z, h, q); goto ret; }
 if(q[0] == zrestr) { r = typrestr(z, h, q); goto ret; }
 if(q[0] == zdot) { r = typdot(z, h, q); goto ret; }
 if(q[0] == zF) { r = typF(z, h, q); goto ret; }
 if(q[0] == zR) { r = typR(z, h, q); goto ret; }
 if(Asop(q[0])) { r = typabbr(z, h, q); goto ret; }
 if(q[0] == zcol) { r = typcnv(z, h, q); goto ret; }
 if(q[0] == ymn && h->l == 2 && q[1].m == ints){ r = zint; q[0] = zmnint1; goto ret; }
 if(q[0] == zcrlf) { r = typcrl(z, h, q); goto ret; } 
 if(q[0] == zfn) { r = typfn(z, h, q); goto ret; } 
 if(q[0] == zTaut){ r = typTaut(z,h,q); goto ret; }    //  z \\ a=b: each inst a' of a pn z replace with b';
 if(q[0] == zdbsl)
  { r = typdbsl(z,h,q); goto ret; }    //  \\ double back slash; z //  z \\ a=b: each inst a' of a pn z replace with b';
 if(dclname(q[0],&g,&w,&a1) && int(g->l) >= 3) // q[0] is d.i & d is dcl[a1, ..., t]
 {                                             // g,w point to dcl[a1, ... , t]
  assert(g); assert(w); 
  if(mm) ipp("typ:dclname(q[0]), z= ", z, " q[0]= ", q[0], " q[1]= ", q[1]);
  if(g->l == 3 && isrt(w[2], zfn))
    { if(mm) ipp("typ:dclname: goto Common_Case, z= ", z, "\nw[2]= ", w[2]); goto Common_Case; } // dcl[id, fn(A:set, fn(A,A))];
  r = typdclterm(z,h,q,g,w,a1);
  if(r != zel && q[0]==zdconj && typ(q[2],&g,&w)==zbool)
  {
   if(99) ipp("typ:q[0]==zdconj, z= ", z, " q[2]= ", q[2], " itt= ", ptt->itt);
   mktr(q[2]);   if(comp(q[2])) g->t = truth;       // T := d && P; // P is an axiom in T; 
  } // f(r != zel && ...)
  goto ret; 
 } // if(dclname(q[0],&g,&w,&a1) && int(g->l) >= 3)
 if(q[0] == zProof){ r = prf(z, h, q); goto ret; }  // ??? no wrp
 if(q[0] == zEqProof){ r = eqprf(z, h, q); goto ret; }
 // if(mm) ipp(typ:+Common_Case z= ", z, "\nq[0]= ", q[0]);
 m = mel(q[0],&g,&w);
 if(m==abt || m==pfs && g->at && hlast > 1){ r = typmeth(z,h,q); goto ret; } // error("typ:test:m==abt, z= ", z);                                       // composite q[0]; 
 // if((!pid) && m!=pfs) error("typ: mel(q[0]) != pfs, z= ", z, "\nq[0]= ", q[0]);
 ///// types of subterms
 Common_Case: if(mm) ipp("\ntyp Common_Case z= ", z, "\nq[0]= ", q[0], " q[1]= ", q[1]); // , " pid= ", pid);
 pid = idubs(q[0]); pv = false; v = zel;
 for(i=pid; i <= hlast; i++)                       // was i=1; 2021.12.11
 {
  pntu->wrp(i);   
  t = typ(y=q[i], &g1, &w1);       // inline void achs::wrp(int p){ assert(iach>=0); ach[iach].p = p; }
  if(mm) ipp("\ntyp:for Common_Case z= ", z, "\ny=q[i]= ", y, "\ntyp(y)= ", t, "\nv= ", v, " i= ", i);
  if(i==0)
  { 
   t0 = t;
   v = valrt(y,g1,w1);
   if(v==zel) ar[0] = y; else{ ar[0] = v; pv = true; };  // pv: valued term;
   continue;
  }  // if(i==0);
  // if(t==zel) error("typ: wrong subterm, z= ", z, " i= ", i);
  // v = valrt(y,g1,w1);
  // if(++iar >= maxvars) error("typ:for:v: Common_Case z= ", z, "\ny=q[i]= ", y, "\nt= ", t,"\nv= ", v);
  // if(v==zel) ar[iar] = y; else{ ar[iar] = v; pv = true; };
  // if(mm) ipp("typ:for Common_Case z= ", z, "\ny=q[i]= ", y, "\ntyp(y)= ", t, "\nv= ", v, " i= ", i);
  ar[i] = y;
 } // for(i);
 if(q[0].m == strng){ r = zel1;  if(99) ipp("typ:string term, z= ", z); goto ret; }
 if(pid)            // pid = idubs(q[0]);  if(idubs(q[0])) 
 { 
  if(mm) ipp("typ entering idubs(q[0]): z= ", z, " q[0]= ", q[0]);
  r = typidu(z, h, q); 
  if(r != zel) goto ret; 
  if(hlast == 1){r = mdt(z, h, 0); if(r!=zel) goto ret; }  // r = meth(z,h,q)    // mdt : method or dot term ???
  // if(hlast == 2){r = typmeth(z,h,q);  if(r != zel) goto ret; }                // r = meth2(q[0],q[1],q[2]); 
  error("typ: idubs: wrong type of term z= ", z, " hlast= ", hlast); 
 } // if(idubs(z,h,q));

 if(syntvar(q[0])){ r = typvarp(z,h,q);  goto ret; }   // P(x1,...,xk), xi is a bvar // r = t;
 if( impequ(q[0]) && hlast > 1){ r = typmeth(z,h,q); goto ret; }   //if(typ(q[0])==zbool)  // checking for adt terms
 if(mel(t0,&g,&w) == pfs && fntypn(w[0])) goto M2a;
 if(comp(q[0]))
 {
  if(mm) ipp("\ntyp:+comp(q[0]), z= ", z, " q[0]= ", q[0]);
  // if(w[0]==zTaut)                // Taut(P)(Q) // q[0] = Taut(P) // w[0]=Taut; // w[1] = P; q[1]
  // {
  //  if(!Taut(w[1])) error("typ: not Tautology P, z= ", z, "\nP= ", w[1]);
  //  q[0] = w[1];
  //  if(mel(q[0], &g1, &w1) != pfs) error("typ: w[0]=Taut(P), z= ", z); // z,h,q are same ???
  // } // if(w[0]) == zTaut)
  
  // v = valrt(q[0],g,w);
  if(pv)                      // if(v != zel && v != q[0])
  {
   z1 = trmk(hlast+1, ar);      // z1 = trmk1(v,h->l,q);    // use a fixed place at the end of tabt ???
   if(mel(z1, &g1, &w1) != pfs) error("typ:comp(q[0]):trmk:mel(z1, &g1, &w1) != pfs, z1= ", z); 
   v = rterm(z1,g1,w1) ;   // typ(v); ???
   if(v != z1){ wrval(z,h,q,v); r = typ(v); goto ret; }
   if(mm) ipp("typ:composite q[0] not reduced, z= ", z, "\nz1= ", z1);
   goto M0;
  } // if(v1 != zel)

  if((v = rterm(z,h,q)) != z)                // q
  {
   if(mm) ipp("typ:comp(q[0]): rterm(z), z= ", z, "\nq[0]= ", q[0], " v= ", v);
   T = typeth(q[0],&t3);
   if(T != zel && fnt2(t3,zfn, &t1,&t2)){ r = t2; ipp("typ: typeth: r = t2, z= ", z, " r= ", r); }
   else r = typ(v);   // ??? add h,q !!!
   goto ret;  
  } // if((v = rterm(z,h,q) != z) 
 } // if(comp(q[0]))
 M0:
 if(mm) ipp("typ:M0: not comp(q[0]) or not rterm(z), z= ", z, "\nq[0]= ", q[0], " t0= ", t0);
 assert(t0 == typ(q[0]));    // remove later !!!
 // if(mm) ipp("typ: not comp(q[0]), ready: t0 = typ(q[0]), z= ", z,  "\nq[0]= ", q[0], "\nt0= ", t0);
 // if(t==zbool)
 // { 
 //  r = typbool(z,h,q);
 //  if(r==zel) goto retmeth; goto ret; // ???????????????????????????????????????????
 // } // if(t==zbool); 
 t1 = t0; // r = adt(z,h,q,t); 
 if(t0==zREL && htbv(q[0])==zFN){ t0 = zFN; goto M2; }          // ??? 2022.11.14
 if(t0==zREL || t0==zset || t0==zany || fnt2(t0,zdot)){ t0 = typtlot(q[0],true); if(t0==zel) t0 = t1; } // t = findfunt(q[0]);
 // t = typtlot(q[0],true);  // true: look for all function types: FN, fn(...), bfn(A,B), ???
 // { ipp("typ: t==zel after idubs: z= ", z, " t= ", t); goto ret; } 

 M2: if(mm) ipp("typ:M2: checking z is possible function term,\nz= ", z, "\nt= ", t);  // ??? rework !!!
 if(mel(t0,&g,&w) == pfs && fntypn(w[0])) // (w[0]==zfn || w[0]==zifn || w[0]==zsfn || w[0]==zbfn) || w[0]==zafn )
 {     // here t0 = typ(q[0]), t0 is fn(w1,w2), ..., 
  if(mm) ipp("typ:M2 z= ", z, " q[0]= ", q[0], " t0= ", t0);
  t1 = typlot(q[0]);
  if(t1 != zel)
  {
   if(t1 != t0) ipp("typfnt: t != t1 = typlot(t), z= ", z, " t= ", t, " t1= ", t1);
   if(mel(t1,&g1,&w1) != pfs || !fntypn(w1[0])) goto M1; // fntypn:fn,ifn,sfn,bfn,afn ONLY!
   t0 = t1; g = g1; w = w1;  // type t1 from lot is stronger t;
  } // if(t1 != zel)

 M2a: if(mm) ipp("typ:M2a: before r = typfnt(z, ...), z= ", z, "\nq[0]= ", q[0], " t0= ", t0, " w[0]= ", w[0]);
 r = typfnt(z, h, q, t0,g,w);  // z: f(q1,...); t:fn(w1,w2); t: ifn(...), ...
 if(r != zel) goto ret;
  error("typ: typfnt returned zel, will try typFNseq, z= ", z, " t0= ", t0);
 } // if(mel(t,&g,&w) == pfs ...)

 M1: if(mm) ipp("typ:M1, here t1 was FN, SEQ, ..., or typfnt returned zel, z= ", z, " t= ", t, " t1= ", t1); // 
 if(mel(t0,&g,&w) == pfs && (w[0]==zseq || w[0]==zseq1))
 {
  r = typFNseq(z,h,q,w[1],w[0]); // 1. t0 = seq(t) or seq1(t) -> typ(f(x)) = t; w[1]=t, w[0]=seq or seq1;
  goto ret; 
 } // M1: if(mel ...)
 if(inseqv(zFNtypes,t0) || istr2(zincl,t0,zFN)) 
 {
  t1 = trm1(zim, q[0], zany);
  if(mm) ipp("typ: inseqv(zFNtypes,t0) || istr2(zincl,t0,zFN)), z= ", z, "\nt0= ", t0, " t1= ", t1 );
  r = typFNseq(z,h,q,t1,t0);    // 2. t is FN -> typ(f(x)) = im(f); 05.06.21 
  goto ret;
 } //  if(inseqv...)
 tt = typ(t0);
 if(fnt1(tt,zP, &t1) && fntype(t1, &t2,&t3,&f0)) // fntype: t1 in FNtypes or t1 in fntypes
 {
  if(mm) ipp("typ: fnt1(tt,zP, &t1) && fntype(t1, &t2,&t3,&f0), z= ", z, "\nt0= ",t0, " t1= ",t1, "\nt2= ",t2, " t3= ", t3);
  r = typFNseq(z,h,q,t3,f0);    // 3. t in P[t1] (== t<:t1), t1
  goto ret;
 } // if(fnt1(tt, ... )
 if(mm) ipp("typ: before if(istr2(zin,q[0],zFN) && h->l == 2), z= ", z, " q[0]= ", q[0]);
 if(istr2(zin,q[0],zFN) && h->l == 2){ r = zany; goto ret; }   // ab(a): 3.13.20
 // retmeth: r = typmeth(z,h,q);     // adt(z,h,q,t);  // t = typ(q[0]) // abridged dot term,t: for printing only!
 // SET : if(iset(q[0])) r = typcnv(z, h, q); // goto ret; }
 ret:	 
 if(r==zREL)
 {
  t = typmod(z,h,q);                      // type modification using lot
  if(t != zel) r = t;
 } // if(r==zREL)

 if(r==zint && h->l==3 && ( (q[0]==zplint || q[0]==zmltint) && typ(q[1])==znat && typ(q[2])==znat) || 
    q[0]==zmnint && typ(q[1])==znat1 && q[2]==zel1 ) r = znat;      // ??? add case q[2] is a..b (a>=1, b>=a)
 
 if(r==zset && h->l==3 && q[0]==zun && typ(q[1])==zREL && typ(q[2])==zREL) r = zREL;   // ???  || q[0]==zinter ???
//  if(r==zset){ k = eqthms(z, &q); if(k>=0) r = trm1(zP,q[0], zset); }   // moved to typ0
 pntu->popach();
 // if(r==zset){ t = typt(z); if(t!=zel) r= t; } 
 h->tp = r;
 ditt = ptt->itt - saveitt;
 if(q[0]==zmnbool && Truth(q[1])) h->t = truth;
 if(mm){ ipp("-TYP z= ", z, "\nr= ", r, " ilot= ", ilot); p = false; }
 if(ditt > maxd) ipp("-TYP: ditt exceeds maxd, z= ", z, "\nditt= ",ditt);
 if(q[0] != zdcol && q[0] != zopsqbr && q[0] != zProof && q[0] != zEqProof && ditt > maxditt1)
   { maxdittz1 = z; maxditt1 = ditt;  maxdittlastseq = lastseq; }  
	ret1: if(mm){ if(p) ipp("-typ z= ", z, "\n     r= ", r, " ilot= ", ilot); /*prext("-typ");*/ }
 if(r == zel || r.m==0 && r.ad==0)
 {
  time_typa = myclock("myclock:typ:error"); 
  error("typ: wrong r, z= ", z, " r= ", r);
 } // if(r == zel || r.m==0 && r.ad==0)
 if(--depth < 0) error("typ: depth < 0, z= ", z);
 //  endchtead(z, " -typ ");
 // if(tead != 0 && int(z.m)==curm && int(z.i)==0 && int(z.ad)==abs(tead) && tead!=stad)
 // {
 // if(r==zset){ k = eqthms(z, &q); if(k>=0) r = trm1(zP,q[0], zset); } 

 mm = savemm; // ttt = savettt; sss = savesss;
 // } // if(tead != 0 && ...)
 // if(h->t && a != -1){ ++numthm; ptt->wrthm(z); } // move to the end !!!
 return r;
}  // end typ --------------------------------------

 elem typ0(elem z) // if typ(z) == zet then r = typt(z):  look for type of z in thms and then in tabt; 
{
 elem t, r; int k; elemp q;   // dom(h) = elg.G typ(dom(h)) = set; so the new typ(dom(h)) = P[elg.G];
 if(mm) ipp("+typ0 z= ", z);
 r = typ(z);
 if(r==zset)
 {
  k = eqthms(z, &q);                   // ??? move to typt ??? or to ron ???
  if(k>=0){ r = trm1(zP,q[0], zset); goto ret; }
 } // if(r==zset)
 if(r==zset || r==zREL){ t = typthms(z); if(t!=zel) r= t; }
 ret: if(mm) ipp("-typ0 z= ", z, " r= ", r);
 return r;
}  // end elem typ0(elem z)

   elem tp(elem x, att* m) // type of a simple name,  cannot call typ indirectly !!! m : mode x (var,abt,bvar,con)
{
 if(mm) ipp("+tp x= ", x); ats a1; int hl; headp h=0; elemp q=0; elem r=zany; 
 if(x.i == 0)     // ??? if(comp(x)) ??? x.m == ints ???
  error("tp: wrong(composite) x= ", x);
 if(freevar(x, &a1, &r)){ if(m) *m = var;  goto ret; }  // if(false) r is not changed: r == zany;
 if(mel(x,&h,&q) == bvar)
 {
  if(h==0) error("tp: wrong x= ", x);
  if(m) *m = bvar;
  if(h->tel == abt)                                     // abstraction term {x1,x2,...,xn ; x1 in t1; ...}
  { 
   if(m) *m = abt; 
   r = typabtvar(x,h,q,x.i); goto ret; 
  } // if(h->tel == abt)
  if(h->tel != pfs) error("tp: not pfs, x= ", x); 
  r = typbvar(x);
  goto ret;
 } // if(mel(x) == bvar) 
 if(q==0) error("tp: wrong x= ", x);
 if(Dcl(q[0]))           // dcl[f,t1,t2,t3]; q[0]=dcl
 { 
  if(m) *m = con;
  hl = h->l;             // elem trm2(elem f, elem x, elem y, elem t=zel, att n = emptt);
  if(hl<3){ if(mm) ipp("tp: unusual Dcl name(no type) x= ", x); r = zbool; goto ret; }
  if(hl>=3){ r = q[hl - 1]; goto ret; }  // constants: dcl[c,type];
  // if(hl==4){ r = trm1(zfn,q[2],q[3]); goto ret; }
  // if(hl==5){ r = trm2(zfn,q[2],q[3],q[4]); goto ret; }
  error("tp: hl>5, not imp.yet, x= ", x, " hl= ", hl);
 } // if(Dcl(q[0]))
 ret: // if(r==zany){ elem t = typlot(x); if(t != zel) r = t; }   // move to -typ??? 04.20.23;
 if(mm) ippelm("-tp x= ", x, " r= ", r);	 return r;
} // end tp

  elem typseq(elem z, headp h, elemp q) 
{
 elem r = zSEQ1, x, y=zel,y0=zel,y1=zel,y1a=zel,y2,t,F,G,tpred = zel; static elem tpcheck = zel;
 headp g,g1; elemp w,w1; int i,k,m, pitt = ptt->itt, ditt, hl1 = int(h->l)-1; char* s;
 bool p1=false, p = false; hint = zel;
 int saveidep = idep;  // int save=ilot; // int saveilot = ilot;
 assert(seqv(z));    // h->tel == pfs && q[0] == opb : not good(?opb?)
 if(mm){ ippelm("+typseq z = ", z, " topach= ", pntu->topach().e); }
 k = pntu->iach;
 for(i=1; i <= hl1; i++)
 {
  pntu->wrp(i);
  if(k<=2) ilot = -1;  // ??? rework !!!
  y0 = y1; y1 = y; y = q[i]; y2 = zel; hint = zel;
  if(namet(y) != -1) lastseq = y; else
  if(mel(y,&g,&w)==pfs && Truth(g) &&  g->l == 2 && namet(w[1]) != -1) lastseq = w[1];
  itt10 = pitt; pitt = ptt->itt; ditt = pitt - itt10;   // search  true itt until curtritt;
  if(mm && ditt > maxd) ipp("typseq: ditt exceeds maxd, y1= ", y1, "\nditt= ", ditt, " maxd= ", maxd);
  if(ditt > maxditt){ maxdittz = y1; maxditt = ditt; }
  if(k <= 2) curtritt = y.ad==0? 0 : y.ad - 1;
  if(curtritt < 0 || curtritt >= ptt->lltt) 
     error("typseq: wrong curtritt, y= ", y, " curtritt= ", curtritt , " itt= ", ptt->itt);
  if(i < hl1) y2 = q[i+1];
  if(y.ad==10008)
  mm=mm;
  if(y2.m == strng){ s = vts(y2.ad) ; *pfhis <<"\n\ntypseq: s= " << s; }
 
  if(pait <= ptt->itt && ptt->itt <= endpait) mm=1;
  else mm= check(y.ad,stad);
  if(mm) ipp("typ: ptt->itt in pait..endpait, z= ", z, " itt= ", ptt->itt, " pait= ", pait, " endpait= ", endpait);
  if(y1.m==strng){ ipp("typseq: changing y1 to y0= ", y0, " y1= ", y1); y1 = y0; }
  *pfhis <<"\n\ntypseq: y1= ", prp(y1, pfhis); prp("\ny= ", y, pfhis);
  *pfhis << "\nitt= "<<ptt->itt<< " ilot= "<<ilot<< " mm= "<<mm<<" kk= "<<kk; //" maxditt= "<<maxditt <<" wasassume= "<<wasassume
  cout <<"\n\ntypseq: y1= ", prp(y1); prp("\ny= ", y);
  cout << "\nitt= "<<ptt->itt<< " ilot= "<<ilot<< " mm= "<<mm<<" kk= "<<kk;
  ++ ippcount;
  last_y1 = y1; last_y = y; 

  if(mm) ipp("typseq:checking mm, mm= ", mm);
   chint(q,i,hl1); // calculating hintstr, hint;  //  if(i < hl1-1 && mystring(q[i+1],"hint")) hint = q[i+2];
  if(hint != zel) prp("\nhint= ",hint, pfhis);
  if(ww) checktabt("typseq y= ", y);               // if(hl1 > 5)
  if(mm)
  mm=mm;
  if(hl1 > 20 && proofdepth==0)              // why 2 ??? TT:: [..] ??? check k = iach ???
  {
   if(wasassume)
     error("typseq: wrong wasassume or ilot, \ny1= ",y1,"\ny= ", y,"\nwasassume= ",wasassume);
   if(ilot != -1){ ipp("typseq: ilot != -1, \ny1= ",y1, "\ny= ", y); prlot("typseq"); ilot = -1; }
  } // if(hl1 > 20)
  if(fnt(y1, zby) && fnt1(y,zis)) continue;  // already was handled
  if(mm || ff) ipp("typseq: for: q[i]= ", y, " q[i+1]= ", y2, " i= ", i, " iach= ", k);
 
  if(y==zrecdef){ recdef(q,i, hl1); continue; }  // i+=5;
  if(mel(y, &g1)==pfs && g1->t && y.m != curm && g1->name != noname) ptt->wrthm(y);  // writing y into tabt and den
  t = typ(y); //   i->0;y=trm2(zin, x,t0,zbool);
  if(t == zel){ error("typ: wrong term in sequence q[i]= ", y); p = true; }  // was errmsg
  //else // t != zel
  // {
  if(mm)ipp("typseq: after recdef: y=  ", y);
  
  if(mel(y,&g,&w)==pfs && g->t == truth3) // Truth(g) === g->t == truth || g->t == truth3;
  {                                 // that is, y is an axiom !
   mktr(y);   
   ilot = -1; // y1 = w[1]: ydexc,yexc:
   // if(g->t == truth || ! isispr(y2)) mktr(y,g->t); // separate axiom or ctheorem:  next:y2 is not is(...) or Proof(...) or EqProof(...)
   if(mm) ipp("typseq: after mktr: y= ", y); goto M_endfor;
  } // if(mel(...)
  if(isrt(y,zis,&w,&g))    // is(J)
  {
   y1a = y1;
   if(mm) ipp("typseq:is y= ", y);   // , " t= ", t);
	  if(g->l != 2) error("typseq:is: wrong y = is(J), g->l != 2, y= ", y);
   if(i==1) error("typseq:is: i==1, y= ", y); 
  	hnis(y1, w[1], "typ:is(J)", true); goto M_endfor;   // true: use istr at once, dont use wrdep;
  } // if(isrt(y,zis))
  
  if(isrt(y,zby,&w,&g))    // y1; by(w,g); y2;
  {
   ipp("+typseq:by y1= ", y1, " y= ", y, " t= ", t);
   if(i==1) error("typseq:by: i==1, y= ", y); 
   if(i == hl1) error("typseq:by: i==h->l-1, y= ", y); 
   if(y1==zTaut || y1==zStaut || isrt(y1,zis) || isrt(y1,zbyeq)) y1 = y1a;
   else if(isproof(y1,&x)) y1 = x;
   y2 = q[i+1];
    // if(!isrt(y2,zis) && !istr0(y1)) error("typseq:by: wrong(not true) y1= ", y1, "\nby(...)= ", y , "\ny2= ", y2);
   hnby(y1,y,g,w,y2);            // y1; by(y,h,q); y2;  !!! RESEARCH 3 lines below; 2023.04.02;
   if(!istr0(y)) error("typseq:by: wrong(not true) by-element, y1= ", y1, "\nby(...)= ", y , "\ny2= ", y2);
   if(!Truth(y1) && !Truth(y2)) error("typseq:by: wrong(not true) both y1 and y2,  y1= ", y1, "\nby(...)= ", y , "\ny2= ", y2);
   if(!Truth(y2) && root(y2) != zis) error("typseq:by: wrong(not true) y2= ", y2, "\nby(...)= ", y , "\ny1= ", y1);
    // mktr(y2);   // if(istr0(y1)) mktr(y2); already in hnby;
    // else{ if(istr0(y2)) mktr(y1); else error("typseq:by: none of y1,y2 is true, \ny1= ", y1, "\ny2= ", y2); }
    // if(isrt(y2,zis,&w,&g)) wrdep(y1,y,(w[1]==zTaut || w[1]==zStaut)?zel:w[1]);
    // else{ wrdep(y1,y,y2); wrdep(y2,y,y1); }
   if(mm) ipp("-typseq: by");
    // if(mm) error("typ:by: end chtead y= ", y);
   goto M_endfor;
  } // if(isrt(y,zby,...)
   
   if(isrt(y,zbyeq,&w,&g))    // y1;  byeq E1, E2, ..., Ek; y1 must be a (strippable) equality;
   {
    y1a = y1;
    if(mm) ipp("typseq:byeq y1= ", y1, "\ny= ", y);
    if(!istrbyis(y,g,w)) error("typ: byeq(...) is not true, y1= ", y1, "\nbyeq(...)= ", y);
    while(fnt2h(y1,zall,&g1,&w1)) y1 = w1[2]; // y1; y;  .. //y1: All(x,A=B); y1: A=B;
    if(fnt2h(y1,zA,&g1,&w1)) y1 = w1[2];      // replace with fnt2 !!!
    if(!iseq(y1, &F,&G)) error("typseq: byeq: not eqv before byeq, eqv = ", y1);
    if(! hnbybyeq(F,y,g,w,G)) error("typ: wrong by-element = ", y, "\ny1= ", y1);
    if(istr0(y)) mktr(y1a);            // try istr0(y) 7.31.20
    else error("typseq:byeq: y1a must be true, y1= ", y1, " y= ", y, " y1a= ", y1a);
         // was wrdep(y1a,y);   // y1 depend on y, i.e. on z1, ... , zk;
    goto M_endfor;
   } // if(isrt(y,zbyeq,...)

   if(isrt(y,zbyimp,&w,&g))    // y1; y:byimp; y2;
   {
    if(typ(y2) == zel) error("typseq:byimp: wrong y2, \ny1= ", y1, "\nw[1]= ", w[1], "\ny2= ", y2);
   	byimp(y1,w[1],y2);
    goto M_endfor;
   } // zbyimp
  // } // else
  M_endfor: if(i > 1 && t != tpred) p1 = true;   // p1==true: cannot be r = seq(t);
  tpred = t; 
 } // end for(i)
 m = 0;  // m = cldep(zel, saveidep+1);  ???
 idep = saveidep; // ilot = save;    // saveilot;
 if(p) r = zel;
 else if(!p1) r = trm1(zseq1, t, zset);
 if(mm) ipp("-typseq z= ", z, " r= ", r);
 if(m) error("-typseq: the number of unproved formulas in module = ", m); 
 return r;  // at the end
} // end typseq

   elem typidu(elem z, headp h, elemp q, elem x)    // x : exclude from vin !
{
 elem r=zel; int save = rrr;
 assert(h->tel == pfs && idubs(q[0]) );
 if(mm){ ipp("\n-------------+typidu z= ", z, " x= ", x);  rrr = 1; }
 h->tp = zel; ats a = q[0].ad;
 if(mm) prlot("+typidu");
 pntu->visn(a, lvin-1); // all(lvin) visible names in vin
 rrr = save;
 if(ivin < 0)
 { 
  pntu->prach("typidu: name not define in z= ");  
  error("typidu: ivin < 0: name not define in z= ", z, "\nname= ", vts(a) );
 } // if(ivin < 0)
 r = ron(z,h,q,x);
 if(r==zel) ipp("typidu: no success term z = ", z);
 if(mm) ipp("-typidu z= ", z, " r= ", r); 
 return r;
}  // end typidu

/*  elem meth(elem z, headp h, elemp q)             // f(y)  
{
 elem r=zel; sbst s; // int i, kT;  elem  s, z,
 if(mm) ipp("+meth: z= ", z);   //  gabt: mel==abt || mel==pfs&&zdconj;
 // r = h->tp;
 // if(r != zel) goto ret;
 // r = mdt(z, h, 0);
	// if(m==zel){ if(mm) ipp("meth: not method term z= ", z); r = zel; goto ret; }
	// if(idubs(q[0])) q[0] = m;  // move to mdt ???
	// v = vdt(z,q[0],q[1],1);  // 1: all methods (from up to down), 2: only simple methods;
 // if(gmain(t) > 1 && !seqv(q[2])) v = z; else v = s.rep(q[1],t,q[2]);  // reduction of dot term z; ??? gabt, no type ???
 // wrv(h,v); //  q[hl] = v;  // see: fsq adds one extra element for dot tems.
 // if(typ(q[0])==zbool)           // ??? if(h->t) ???
 // {
 // trtr(q[0],z);  // transfer truth from m to z;
  // trtr(z,v);  // transfer truth from z to v; 
 // } // if(typ(q[1])==zbool)
 // t = typ(q[0]); 
 // istqab = -1; r = s.rep(t, 1); //  1: replace all methods(up to down);
	// h->tp = r;  iMod = -1;
 if(mm) ipp("-meth z= ", z, " r= ", r);    //, " T= ", kT, T); "\nt= ", t,
 return r;
} // elem meth(elem f, elem y)             // f(y)

 elem mthd(elem t1, elem y, elem t)     //  mthd(ngroup(G), G) = ngroup, else zel; t = Group;
{ 
 elem r=zel; headp h; elemp q;
 if(9) ipp("+mthd: t1= ", t1, " y= ", y, " t(y)= ", t);
 if(mel(t1, &h, &q)==pfs && h->l==2 && q[1]==y && scope(q[0])==t) r = q[0]; 
 if(9) ipp("-mthd: r= ", r);
 return r;
} // elem mthd(elem t1, elem y, elem t)

/* elem tmthd(elem z)                     // theory for method z, if not, returns zel1
{                                       // tmthd(abtbvar) = abterm; // tmthd(e) = group; 
 elem r=zel; headp h; elemp q; int m;        // ??? same as host ???
 if(9) ipp("+tmthd z= ", z);
 if(adel(z,&h,&q)) goto ret;
 m = h->tel;
 if(z.i)
 {
  // if(m==pfs && q[0]==zexistx) goto M; ??? z is var ???
  if(m==abt){ r = z; r.i = 0; goto ret; }       // r = htbv(z);
 } // if(z.i)
 r = scope(z);                         // if(unnamed(z),zel1, find in z.m-den (z-name,z,r), return r; not finding: r=ze
 // if(r==zel1) r = zel;                  // ??? if not founded, r = zel1, 
 ret: if(9) ipp("-tmthd z= ", z, " r= ", r); // ? if(mel(r) != abt) r = 
      return r;
} // elem tmthd(elemz)


  elem meth2(elem f, elem y, elem y1)     // f(y,y1);     // G/N; f = /(ats) // used only in typdclterm;
{
 elem t,t1, m=zel, r=zel; ats a;
 if(9) ipp("+meth2: f= ", f, " y= ", y, " y1= ", y1);
 if(!idubs(f, &a)) error("meth: not idubs, f= ", f, " y= ", y);
 t = abtyp(y);                           // 
 if(t == zel) goto ret;
 t1 = typnany(y1);                       // 
 m = mthd(t1,y,t);                       //  mthd(ngroup(G), G, group) = ngroup, else zel;
 if(m != zel && gabt(m)) r = fdent1(a,m);
 ret: if(9) ipp("-meth2: f= ", f, " y= ", y, "\ny1= ", y1, " r= ", r);
 return r;
} // elem meth2;

  elem adt(elem z, headp h, elemp q, elem t0)   // old version, see styp for a new version
{                          // abridged dot term: Q(M1,...,Mk): means Q.[M1,...,Mk);
 int n = int(h->l)-1; elem Q=q[0], M=q[1], d,t, r=zel;  // n : # of actuals;

 if(9) ipp("+adt: z= ", z, " Q= ", Q, " t(Q)= ", t0, " n= ", n);
 if(h->adt != 1) ipp("adt: ->adt != 1???, z= ", z);
 if(h->tel != pfs){ ipp("adt: not pfs, z= ", z); goto ret; }         // || h->l != 2
 d = scope(Q);                  // q[0] = Q; q[1] = x1; // was host(q[0]);
 if(d==zel || d==zel1) error("adt: wrong scope(Q), z= ", z, " Q= ", Q);
 if(n==1)
 {
  t = abtyp(M);  // ,&M1,&d1);  //abtyp(M) not working; || istr2(zin,q[1],d) ) || ismd(d,q,n)) r = t0; // ??? repq(t0) ???
  if(t==zel) 
  {
    if(mel(M,&h,&q) == bvar && h->tel==abt && kmain(h)==1) t = htbv(M);  // ??? inline abtbvar1 ???
    else error("adt:n==1: wrong abtyp(M), z= ", z, " Q= ", Q, " M= ", M); 
  } // if(t==zel) 
  if(mm) ipp("adt:n==1, d = scope(Q), d= ", d, " typ(M)= ", t); 
  if(d != t) error("adt: d != t, \nz= ", z, "\nQ= ", Q, "\nd= ", d, "\nt= ", t, "\nM= ", M);
  M: ipp("adt: assigning h->adt = 1, z= ", z);
  r = t0; h->adt = 1; goto ret;   // t0 == typ(q[0]) ??? rep(t0) ???
 } // if(n==1)
 if(ismd(d,q,n)) goto M;  // { r = t0; h->adt = 1; goto ret; }
 ippq2("adt: q is not model of d, z= ", z, " d= ", d, " q= ", q+1, n); // ??? repq(t0) ???
 ret: if(9) ipp("-adt: z= ", z, " r= ", r);             // , " x= ", x);
      return r;
} // end adt
*/

   bool disjlevbase(elem t1, elem t2)
{
 bool r=false;   bl X1, X2; ats L1,L2; elem B1,B2;
 if(mm) ipp("+disjlevbase t1= ", t1, " t2= ", t2);
 if(t1==zany || t2==zany) goto ret;
 X1 = blev(t1); B1 = X1.base; L1 = X1.lev;
 X2 = blev(t2); B2 = X2.base; L2 = X2.lev;
 // if(indisj(X1.base, X2.base) || indisj(X2.base, B1)){ r = true; goto ret; }
 // r = (B1==B2 && L1 != L2);
 if((B1==zany || B2==zany) /*&& L1==L2*/) goto ret;                   // added && L1==L2 on 11.25.21
 r = (B1 != B2 || L1 != L2);                                      // ??? {} empty set ???
 ret: if(mm) ipp("-disjlevbase t1= ", t1, " t2= ", t2, " r= ", r);
 return r;
} // end bool disjlevbase(elem t1, elem t2)

   bool disjoint(elem t1, elem t2)
{
 bool r = false; headp h1,h2;  elem x,x1, tt1, tt2; // elem mt1,mt2; // elem s1,s2; 
 if(mm) ipp("+disjoint t1= ", t1, " t2= ", t2);
 if(req(t1,t2)) goto ret;
 if(t1==zany || t2==zany) goto ret;
 /* mt1 = mait(t1); mt2 = mait(t2);
 if(9) ipp("disjoint:maits: t1= ",t1, " mt1= ", mt1, "\nt2= ",t2, " mt2= ", mt2); 
 if(!req(mt1,mt2))
 { 
  ipp("disjoint:t1,t1 are disjoint:mt1 != mt2, t1= ",t1, " mt1= ", mt1, "\nt2= ",t2, " mt2= ", mt2); 
  goto ret1;
 } // if(!req(mt1,mt2))
 */
 if(indisj(t1,t2) || indisj(t2,t1)) goto ret1;         // uses array disjoint in root.v; 
 if(disjP(t1,t2) || disjP(t2,t1)) goto ret1;           // disjP(t1,t2): P[t1] disj t1;
 if(disjlevbase(t1,t2)) goto ret1;
 if(t1 == t2 || Any(t1) || Any(t2)) goto ret; 
 if(t1 == zbool || t2 == zbool) goto ret1;
 if(fntP(t1,&x) && x==t2 || fntP(t2,&x) && x==t1) goto ret1;
 tt1 = typ(t1);   if(fntP(tt1,&x) && fntP(x,&x1) && x1==t2) goto ret1;  // case subgr, elg
 tt2 = typ(t2);   if(fntP(tt2,&x) && fntP(x,&x1) && x1==t1) goto ret1;  // ??? use lev ???
 if(mel(t1)==abt && htbv(t2)==t1 || mel(t2)==abt && htbv(t1)==t2)
    { if(9) ipp("disjoint: case group-elg, t1= ", t1, " t2= ", t2); goto ret1; }
 if(mel(t1,&h1)==abt && mel(t2,&h2)==abt && kmain(h1) != kmain(h2)) 
    { if(9) ipp("disjoint: case abt-abt, kmain(t1) != kmain(t2), t1= ", t1, " t2= ", t2); goto ret1; }
 // if(t1==zint && t2==zelg || t1==zelg && t2==zint) goto ret1;
 if(atomset(t1) && atomset(t2) && t1!=t2) goto ret1;
 if(atomset(t1) && fntP(t2) || atomset(t2) && fntP(t1)) goto ret1;
 // s1 = scope(t1); s2 = scope(t2);
 // if(s1 != zel1 && s2 != zel1 && s1 != s2 && s1 != zel && s2 != zel)  // ??? s1 != zel && s2 != zel => s1 <: s2 && s2 <: s1;
 //  { ipp("disjoint: s1 != s2, t1= ", t1, " t2= ", t2, "\ns1= ", s1, " s2= ", s2); goto ret1; }   // ??? d vs d&&p;
 // if((t1==zint || t1==znat || t1 == znat1 || t1 == znatm) && (t2==zSEQ  !!! use mait
 goto ret;
 /*mt1 = mait(t1);
 if(mm) ipp("disjoint: after mait t1= ", t1, " mt1= ", mt1);
 if(mt1 == t2) goto ret; 
 mt2 = mait(t2);
 if(mm) ipp("disjoint: after mait t2= ", t2, " mt2= ", mt2);
 if(mt1 == zel && mt2 == zel) error("disjoint: mt1= ", mt1, " mt2= ", mt2);
 if(mt1 == mt2 || mt1 == zset && isrt(mt2, zP)) goto ret;
 
 //if(r == 0) ippelm("kin: zmdot= ",  zmdot, zmdot);
 //if(r == 0) ippelm("kin: t1= ", t1, t1);
 //if(r == 0) ippelm("kin: t2= ", t2, t2);
 //if(isrt(t1, zmdot, &q) && isrt(t2, zmdot, &w) && (q[1] == w[1]))
 */ //   r = disjoint(q[2], w[2]);
 ret1: r = true;
 ret: if(mm) ipp("-disjoint: t1= ", t1, " t2= ", t2, " r= ", r);
 return r;
} // end disjoint

  bool indisj(elem t1, elem t2)                 // t1 and t2 are in disjoint array
{
 bool r = false; int i,k; elemp q; elem d1,d2;
 if(mm) ipp("+indisj: t1= ", t1, " t2= ", t2);
 if(! seqv(zdisjoint,&k,&q)) error("indisj: wrong disjoint = ", zdisjoint);
 for(i=1; i<=k; i+=2)
 {
  d1 = q[i]; d2 = q[i+1];
  if(t1==d1 && t2==d2){ r = true; break; }   // || t1==d2 && t2==d1
  if(t1==d1 && d2==zfntypes && fntype(t2)){ r = true; break; }
 } // for(i)
 if(mm) ipp("-indisj: t1= ", t1, " t2= ", t2, " r= ", r);
 return r;
} // end indisj

   bool disjP(elem t1, elem t2)                     //          P[t1](P1[t1]) disj t1;
{ 
 bool r=false; headp h; elemp q,w; int k;
 if(mm) ipp("+disjP t1= ", t1, "\nt2= ", t2);
 r = mel(t1,&h,&q)==pfs && h->l==2 && (q[0]==zP || q[0]==zP1);
 if(!r) goto ret;
 if(q[1]==t2){ r = true;  goto ret; }
 k = eqthms(q[1], &w);
 r = inList(t2,w,k);
 ret: if(mm && r) ipp("disjP found t1 disj t2, t1= ", t1, "\nt2= ", t2); 
 if(mm) ipp("-disjP t1= ", t1, "\nt2= ", t2, " r= ", r);
 return r;
} // bool disjP(elem t1, elem t2)

  elem tpax(elem t, headp h, elemp q, att i)   // merge with typax ???
  {
   elem r=t;
   return r;
  } // elem tpax(elem t, ... )

  elem mait(elem t)                // main type for t; t is a set;
{
 elem r = t,t1,t2; att i; int k,m;  headp h; elemp q; elem ar[lsbin]; ats static dpth=0;  // lsbin = 16;
 if(++dpth > lsbin) error("mait: dpth > lsbin, t= ", t, " dpth= ", dpth, " lsbin= ", lsbin);
 if(mm) ipp("+mait t= ", t);
 if(t==zFN){ r = zREL; goto ret; } // ??? must more think about relations and functions !!!
 if(t==zset || t==zREL || atomset(t)) goto ret;   // see r = t above; // int,bool checked in atomset;
 if(fntype(t)){ r = zREL; goto ret; }  // was r = sFN
 if(m = (mel(t,&h,&q)==abt))
 {
  k = kmain(h);
  if(k==1){ r = mait(tpax(t,h,q,1)); goto ret; }  // ??? typax: check 
  if(k >= lsbin) error("mait:abt: too big k=kmain(h), t= ", t, " k= ", k); // lsbin=16;
  ar[0] = zdp;    // ??? zDP ???
  for(i=1; i<=k; i++) ar[i] = mait(tpax(t,h,q,i));
  r = trmk(k+1,ar); goto ret;
 } // if(mel(t,&h,&q)==abt)
 if(m==pfs)
 {
  if(h->l==2)
  { 
   if(q[0]==zP || q[0]==zP1){ r = trm1(zP, mait(q[1]), zset); goto ret; }
  } // if(h->l==2)
  if(h->l==3)
  {
   if(q[0]==zdp){ r = trm2(zdp,mait(q[1]),mait(q[2]),zset); goto ret; }  // X1 # X2
   if(q[0]==zun)
   {
    t1 = mait(q[1]); t2 = mait(q[2]);
    if(!req(t1,t2)) error("mait:zun: (to research), t= ", t, " t1= ", t1, " t2= ", t2);
    r = t1; goto ret;
   } // if(q[0]==zun)
   if(q[0]==zinter)
   {
    t1 = mait(q[1]); t2 = mait(q[2]);
    if(!req(t1,t2)) error("mait:intersection: (to research), t= ", t, " t1= ", t1, " t2= ", t2);
    r = t1; goto ret;
   } // if(q[0]==zinter)
   if(q[0]==zsetdif)
   {
    t1 = mait(q[1]); t2 = mait(q[2]);
    if(!req(t1,t2)) error("mait:setdif: (to research), t= ", t, " t1= ", t1, " t2= ", t2);
    r = t1; goto ret;
   } // if(q[0]==zsetdif)
  } // if(h->l==3)
 } // if(m==pfs)
 if(9) ipp("mait: nonstandart case, r:=set, t= ", t); r = zset; 
 ret: if(mm) ipp("-mait t= ", t, " r= ", r); --dpth;
      return r;
} // end elem mait(elem t)
  
  elem Tp(elem x)
{
 headp h; elemp q; elem r = zel;
 if(!smel(x, &h, &q)) r = h->tp;
 return r;
} // end Tp

   elem typabbr(elem z, headp h, elemp q)
{
 elem r = zel;                   // check later for possible recursive abbreviations
 if(mm) ipp("+typabbr: z= ", z);
 assert(h->l == 3);
 r = typ(q[2]);
 if(mm) ipp("-typabbr: r= ", r);
 return r;
}

/*--------------Seo 6, 2021---   elem typbool(elem z, headp h, elemp q)           // typ(q[0]) = zbool; All(x
{
 elem r=zbool,y,t,P;  headp g; elemp v,w;  ats a; int k, hl1 = int(h->l)-1;
 if(mm) ipp("+typbool: z= ", z);
 /// if(!isst(q[0], &y)) y = q[0];
 if(freevar(q[0], &a, &t) && t==zbool) goto ret;
 if(fnt1(y, zTaut, &P))    // rework later !!! 11.25.20
 //{ 
 // if(typ(P) != zbool || !htaut(P)) error("typbool: P is not a tautology, z= ", z, " P= ", P); 
  goto ret;
 if(! fnt2(y, &g, &w))                         // y: Tisnorm4(H,H*K)
 {
  ipp("typbool: strange y(q[0]), z= ", z, "\ny= ", y);
  if(q[0]==zRed) goto ret;
  error("typbool: wrong y, z= ", z, "\ny= ", y);
 } // if(! fnt2(q[0], &g, &w))
 if(w[0] != zall && w[0] != zA && w[0] != zexist && (hl1 != 1 || w[0] != zimp && (!iseq(y))))
   { h->adt = 1; r = zel; goto ret; }
 //   error("typbool: wrong formula(not Exist,not All,not A[, not imp, not eq(v) \nz= ", z, "\nw[0]= ", w[0]);
 // A[d,P](q1,...,qk)
 if(w[0]==zA) //  && hl1 == 2)
 { 
  k = hl1; v = q;
  if(seqv(q[1],&k, &v)) k=k;
  typ(w[1]);
  if(typ(w[2]) != zbool) error("typbool: A[d,P](Q3): P is not a formula, z= ", z, " P= ", P);
  if(typ(q[1])==zbool && k==1){ r = zbool; goto ret; }
  if(!ismd(w[1], v, k)) error("typbool: not model, z= ", z, " d= ", w[1], "\nv[1]= ", v[1], " k= ", k);
  if(mel(w[2], &g) == pfs) h->t = g->t; goto ret;
 } // if(w[0]==zA)
 if(w[0]==zall && mel(w[2], &g) == pfs) h->t = g->t;
 // CheckPars: for(i=1; i<= hl1; i++)  // already checked in typ;
 //            if(typ(q[i]) == zel) error("typbool: wrong q[1], z= ",z, " q[1]= ", q[1]);  // was errmsg
 // r = zbool;
 ret: if(mm) ipp("-typbool: z= ", z, " r= ", r);
 return r;
}   // elem typbool
------------------------------------------------end typbool--------Sep 6, 2021--- */

   elem typbool(elem z, headp h, elemp q)           // typ(q[0]) = zbool; All(x
{
 elem r=zbool,y,t,P;  headp g; elemp w;  ats a; int hl1 = int(h->l)-1;
 if(mm) ipp("+typbool: z= ", z);
 if(!isst(q[0], &y)) y = q[0];                     // isst:7   typbool
 if(freevar(q[0], &a, &t) && t==zbool) goto ret;
 if(fnt1(y, zTaut, &P))    // rework later !!! 11.25.20
 //{ 
 // if(typ(P) != zbool || !htaut(P)) error("typbool: P is not a tautology, z= ", z, " P= ", P); 
  goto ret;
 if(! fnt2(y, &g, &w))                         // y: Tisnorm4(H,H*K)
 {
  ipp("typbool: strange y(q[0]), z= ", z, "\ny= ", y);
  if(q[0]==zRed) goto ret;
  error("typbool: wrong y, z= ", z, "\ny= ", y);
 } // if(! fnt2(q[0], &g, &w))
 if(w[0] != zall && w[0] != zA && w[0] != zexist && (hl1 != 1 || w[0] != zimp && (!iseq(y))))
 {
	 h->adt = 1; r = zel;
		ipp("typbool: (w[0] != zall && ...): making adt-term, z= ", z); 
		goto ret; 
	} // if(w[0] != zall && ...)
 //   error("typbool: wrong formula(not Exist,not All,not A[, not imp, not eq(v) \nz= ", z, "\nw[0]= ", w[0]);
                               // A[d,P](q1,...,qk)
 if(w[0]==zA) //  && hl1 == 2)
 { 
  // k = hl1;  // v = q;
  // if(seqv(q[1],&k, &v)){ ipp("typbool:seqv: z= ", z);  k=k; }   // commented on 11.7.21;
  typ(w[1]);                                                       // w[1] = d;
  if(typ(w[2]) != zbool) error("typbool: A[d,P](Q3): P is not a formula, z= ", z, "\nP= ", w[2]);
  if(typ(q[1])==zbool && hl1==1)                                     // q[1] = Q3; 
  { 
   if(!impequ(w[2])) error("typbool: P is not imp or equ in z= A[d,P](Q3), z= ", z, "\nP= ", w[2]);
   r = zbool; goto ret; 
  } // if(typ(q[1])==zbool && k==1)          
  if(!ismd(w[1], q, hl1)) error("typbool: not model, z= ", z, " d= ", w[1], "\nq[1]= ", q[1], " k= ", hl1);
   h->t = g->t;  // A[d,P] & Z is a model of d ->  A[d,P](z1,...,zk);   // if(mel(w[2], &g) == pfs)
  goto ret;
 } // if(w[0]==zA)
                        // All(x,P)(z) or All(z,P)(Q3)
 if(w[0]==zall)
 {
  if(typ(w[2]) != zbool)  error("typbool: All(x,P)(Z): P is not a formula, z= ", z, " P= ", w[2]);
  if(typ(q[1])==zbool && hl1==1)                                     // q[1] = Q3; 
  { 
   if(!impequ(w[2])) error("typbool: P is not imp or equ in z=  All(x,P)(Q3), z= ", z, "\nP= ", w[2]);
   // if(mel(w[2], &g) == pfs) h->t = g->t;
   goto ret;    // r = zbool;
  } // if(typ(q[1])==zbool && hl1==1)  
  if(hl1 != 1)
  {
   if(9) ipp("typbool: z is All(x,P)(z1,z2, ...), NOT making adt, z= ", z);
   // h->adt = 1;                                                     // All(x,P)(z1,z2, ...)
  } // if(hl1 != 1)
  goto ret;                                                        // All(x,P)(z)             
 } // if(w[0]==zall)
 // CheckPars: for(i=1; i<= hl1; i++)  // already checked in typ;
 //            if(typ(q[i]) == zel) error("typbool: wrong q[1], z= ",z, " q[1]= ", q[1]);  // was errmsg
 // r = zbool;
 ret: if(mm) ipp("-typbool: z= ", z, " r= ", r);
 return r;
}   // elem typbool

  elem typvarp(elem z, headp h, elemp q)  // variable with parameters
{
 elem r;
 if(mm) ipp("+typvarp: z= ", z);
 for(int i=1; i<int(h->l); i++)           // incomplete checking !!!
 {
  for(int j=1; j<i; j++) if(q[i]==q[j]) 
   ipp("typvarp: repeating parameters: z= ", z, " i= ", i, " j= ", j);  // errmsg ???
  if(!varbvar(q[i])) errmsg("typbvarp: parameter x is not var or bvar, z= ", z, " x= ", q[i]);
 } // for(i)
 r = typ(q[0]);                           // ??? tp(q[0]) ???
 if(mm) ipp("+typvarp: z= ", z, " r= ", r);
 return r;
} // end typvarp

  int Typ(elem z, elem ar[], int maxsizear) // ar := t(typ(z)) and all ti, such that t <: t1;
{
 int i, last = -1; elem t, t1;
 if(mm) ipp("+Typ: z= ", z, " maxsizear= ", maxsizear);
 t = typ(z);
 if(t == zel) goto ret;
 wrlist(t,ar,&last,maxsizear);
 i = 0;
 while(i <= last)
 {
  t = ar[i];
  t1 = istr2a(zincl,t);
  if(t1 != zel) wrlist(t1,ar,&last,maxsizear);
  ++i;
 } // while(i <= last)
 ret: if(mm){ ipp("-Typ z= ", z, " last= ", last); prlist("-Typ ", ar, last); }
 return last;
} // end int Typ

  elem typtlot(elem z, bool p)   // search z in _ in lot, then in tabts,if(p): only fn(...), bfn(A,B), ???
{
 if(mm) ipp("+typtlot: z= ", z, " p = ", p);
 elem r =  typlot(z,p);
 if(r==zel) r = ptt->typtabt(z,p);    // z in r is in tabt, true: look for function types
 // if(r==zel) r = typt(z);
 if(mm) ipp("-typtlot: z= ", z, " r= ", r);
 return r;
} // end elem typtlot

  elem tt::typtabt(elem z, bool fnt)  // fnt:true: looking for function types
{
 elem r=zel;  sbst s; int i,k; elem t,Q, A[lmftp]; // lmftp = 10; see typ.h;
 achs g(z); pntu->copy(&g); 
 if(mm) ipp("---------+tt::typtabt: z= ", z, " fnt= ", fnt);
 r = typthms(z,fnt);
 if(r != zel) goto ret;
 
 if(mm) ipp("tt::typtabt: using lview,prevt, z= ", z);
 for(i=0; i<lmftp; i++) A[i] = zel;
 imftp = -1;
 for(i=0; i <= lview; i++)
 { 
  Q = g.prevt(pntu,i);
  if(Q==zel) break;
  if(mm) ipp("tt::typtabt: found in tabt true  z= ", z, " Q = ", Q, " i= ", i);
  if(int(Q.m) != mym) ipp("tt::typtabt: Q.m != mym, Q= ", Q, " mym= ", mym);  // goto ret; }
  r = tfromin(z,Q);
  if(r != zel)
  {
   if(mm) ipp("--------tt::typtabt: found! z= ", z, " r= ", r, " i= ", i);
   if(!fnt) break;
   if(numfnt(r)) wrmftp(r); 
  } // if(r != zel)
 } // for(i)
 if(!fnt) goto ret;
 for(i=0; i<=imftp; i++)
 { 
  t = mftp[i]; k = numfnt(t);
  A[k] = t;
  if(mm) ipp("tt::typtabt: writing to A, t= ", t, " k= ", k, " i= ", i);
 } // for(i=0)
 /*{
  t = mftp[i]; A[numfnt(t)] = t;
  if(t==zFN) A[8] = zFN;
  else if(isrt(t,zfn)) A[1] = t;
  else if(isrt(t,zbfn)) A[2] = t;
 } */ // for(i)
 // r = zel;
 for(i=1; i<lmftp; i++){ r = A[i]; if(r != zel) break; } // i=1: because A[i] = 1,2,8;
 
 ret: if(mm) ipp("----------typtabt: z= ", z, " r= ", r, " lmftp= ", lmftp);
      return r;
} // end elem tt::typtabt

   void wrmftp(elem t)
{
 for(int i=0; i<=imftp; i++) if(mftp[i] == t) return;
 if(++imftp >= lmftp) error("wrmftp: too many function types, t= ", t, " imftp = ", imftp);
 mftp[imftp] = t; 
} // end void wrmftp(elem t)

   int numfnt(elem t)
{
 int r = 0;  
 if(t==zFN) r = 8;
 else if(t==zSEQ) r = 7;
 else if(t==zSEQ1) r = 6;
 else if(isrt(t,zseq)) r = 5;
 else if(isrt(t,zseq1)) r = 4;
 else if(isrt(t,zfn)) r = 1;
 else if(isrt(t,zbfn)) r = 2;
 return r;
} // end int numftp(elem t)

  elem tfromin(elem z, elem y)  // y: z' in t or y: p -> z' in t
{
 elem P=zel,a=zel,t=zel,r=zel; bool p,p1,p2 = false; sbst s;
 if(mm) ipp("+tfromin z= ",z, " y= ", y);    // found z' in t;
 if(z.ad==stad1 && y.ad==stad2)
 mm=mm;
 if(fnt2(y,zin, &a,&t)) // && s.instance(z,a))   // was req, instance: stripped bvar can be; 
 {
  if(mel(a)==var){ if(z==a) r=t;  goto ret; }
  p = s.instance(z,a,zel9);                          // zel9: all vars, bvars in a are constants;
  if(p) r = s.rep(t, "tfromin1");
  goto ret;
 } // if(fnt2(y,zin, ...)               
 s.size = 0;               // P -> a in t;
 if(fnt22r(y,zimp,zin,&P,&a,&t))
 {
  p1 = s.instance(z,a);
  if(p1) p2 = s.instlot(P);
  if(p1 & p2) r = s.rep(t, "tfromin2");
  if(mm) ipp("tfromin:fnt22r: y= ", y, " P= ", P, " t= ", t, " p1= ", p1, " p2= ", p2);
 } //  if(fnt22r
 ret: if(mm || r != zel) ipp("-tfromin: z= ", z, " y= ", y, "\nr= ", r, " p= ", p);
 return r;
} // end elem tfromin

  void chtead(elem z, char* s)    // check tead;
{
 if(tead != 0 && z.m==curm && z.i==0 && int(z.ad)==abs(tead)) // tead < 0 : also sss;
 {
  // mm=1; if(tead < 0){ sss=1;  ttt=1; }
  *pfhis << "\nchtead "<<s;
  prp("",z,pfhis); *pfhis<<" tead= "<<tead<<" sss= "<<sss<<" itt= "<< ptt->itt;  prlot();
 } // if(tead ...)
} // end void chtead

 elem typedax(elem d, att i)  // type from i-th type axiom of d, i=1, ..., kmain;
{
 elem r=zel, x,t,a=zel; headp h; elemp q; att k,hl,j;
 if(mm) ipp("+typedax: d= ", d, " i= ", i);
 if(mel(d,&h,&q) != abt){ ipp("typedax: wrong d(not abt), d== ", d, " i= ", i); goto ret; }
 k = kmain(h); hl = h->l;
 if(i > k){ ipp("typedax: wrong i, d= ", d, " i= ", i, " k= ", k); goto ret; }
 j = k + i;
 if(j >= hl){ ipp("typedax: wrong j = k+i, d= ", d, " i= ", i, " k= ", k); goto ret; }
 a = q[j];
 if(!fnt2(a,zin, &x, &t)){ ipp("typeax: wrong a: not in-term,  a= ", a); goto ret; }
 if(htbv(x) != d || x.i != i){ ipp("typeax: wrong x: not d.i bvar, x= ", x, "\nd= ", d, " i= ", i); goto ret; }
 r = t;
 ret:  if(mm) ipp("-typedax: a= ", a, "\nd= ", d, "\nr= ", r, " i= ", i);
       // if(r==zel) error("typedax: r==zel, d= ", d, " i= ", i);
       return r; 
} // end elem typedax(elem d, att i)

  elem typarg(elem f, att i)       // formal type of i-th argument of the function f;
{
 elem r=zel, t,A,B; headp h; elemp q;
 if(mm) ipp("+typarg f= ", f, " i= ", i);
 t = typ(f);
 if(!fnt2(t,zfn,&A,&B)) goto ret;
 if(simple(A)){ if(i != 1) ipp("typarg: simple(A): i!=1, f= ", f, " A= ", A, " i= ", i); else r = A; goto ret; }
 if(fnt2h(A, zdp, &h, &q)){ if(i<1 || i>2)
    ipp("typarg: A is t1#t2, but i<1 || i>2, f= ", f, " A= ", A, " i= ", i); else r = q[i]; goto ret; }
 r = typedax(t,i);              //assumed that Dterm(t) ???
 ret: if(mm) ipp("-typarg f= ", f, " t= ", t, " r= ", r, " i= ", i);
 return r;
} // end elem typarg

  bool isfn(elem z)                // z is a function;
{
 bool r; elem t; headp h; elemp q;
 if(mm) ipp("+isfn z= ", z);
 t = typ(z);
 r = (mel(t,&h,&q)==pfs && fntypn(q[0]));
 if(mm) ipp("-isfn z= ", z, " t= ", t, " r= ", r);
        return r;
} // end bool isfn(elem z) 

/*   void endchtead(elem z, char* s)
 {
 if(tead != 0 && int(z.m)==curm && int(z.i)==0 && int(z.ad)==abs(tead) && tead!=stad)
 {
  // mm = savemm; ttt = savettt; sss = savesss;
 } // if(tead != 0 && ...)
} // end void endchtead
 
  void restead(elem z, char* s)    // restore mm,ttt after  chtead;
{
 if(tead != 0 && int(z.m)==curm && int(z.i)==0 && int(z.ad)==abs(tead)) // tead < 0 : also sss;
 {
  // mm=1; if(tead < 0){ sss = 1;  ttt = 1; } 
  *pfhis << "\nchtead "<<s;
  prp("",z,pfhis); *pfhis<<" tead= "<<tead<<" sss= "<<sss<<" itt= "<< ptt->itt;  prlot();
 } // if(tead ...)
} // end void chtead
*/

// end Typ.cpp