#include <fstream.h> // 11/21/97  4/15/00 5/11/00 7/25/00 10/27/00
#include <string.h>  // 03/13/01                                                        
#include <stdlib.h>  
#include <ctype.h>
#include <ctime>
#include <assert.h>
#pragma warning(disable: 4200)

typedef short int ats;
typedef unsigned short att;   // was typedef short int att
typedef char* charc;

//#define  lts 512
//#define ltt   2048
#define pfs     0         
// #define psq     2
#define abt     1  
#define bvar    5  // bounded variable: {x |...}, A[x, P], ??? not used ???..
#define con     6
#define var     7

#define emps  255
#define ints  254
//#define intl  60
#define ident 253
#define ubs   252
#define strng 251
#define chara 250
// #define bvr   249    // bounded variable: (bvr,DeBruijn index, ats)
#define gcom  248    // ,44 ;59
#define gpc   247    // (40 [91 {123
#define meof  246
#define clp   245    // )41 ]93 }125
#define maxmod 240      // maximum number of modules 0..maxmod-1 (239) was lclad
#define lastmod 239;    // last possible module number; 
#define maxabtv 256     // max number of var in abt-term (1-255)
#define maxdepth 50     // max depth of terms, used in prp;
#define lsbin   16
#define end_pars 101 // exception 

#define undef 0
#define truth 1
#define ctruth 2      // fixed value!!! dont change: used in pars: ydexc:1, yexc:2;
#define truth3 3
// #define False 3
// #// define keq   3
// #// define kimp  4
// #// define keqim 5
// #// define blck  1
//#define bfndv 2
#define noname  -1
#define emptt 65535               // was -1
#define emptt2 65534              // was -2
#define emptt3 65533              // -3, used in mdln to block vals2; (vals(vals(z));
#define maxlltt 65530             // 65535 is used as empty place
#define all1but31 0xFFFFFFFEu             // 
#define top st[ist]
#define top1 st[ist-1]
#define top2 st[ist-2]
#define levs istscp
#define lst1   2048     // was lst
#define lach  100 
#define maxtypes 100  // 
#define lnms 100
#define lsteq 256
#define knd 255
#define minspn   1
#define maxspn   50
#define minmetan 1
#define maxmetan 9
#define minsptpn 101
#define maxsptpn 150
#define kdirname 100
#define maxlevqt 20       // maximum level of embedding fot Qab-terms(3 bits);
#define size_fnelematt2 20 // sizes of arrays in fnelematt2 class;
#define maxerrmsg 400
#define maxsynv 20        // maximum number of syntactic variables
#define maxvars 100       // maximum number of variables in term
#define maxarel 100       // move to dd ???
#define maxvars1 99       // maximum number of variables in term -1
#define maxnstr 12000     // maximum number of lines in .v files; // cannot be more than 16383;
#define emptyts -1
#define twoexp16 65536
#define sizehar 262144    // size for fylloc of hash array har: 524288 = 256K * 2; att har[262144];  
#define lndfns 512

 struct elem      // 4 bytes
{
 unsigned m:   8;  // mode or module number
 // unsigned namt:1;  // named term
 // unsigned vc:  1;  // flag of variable or constant
 // unsigned n:   1;  // negation 
 //unsigned rez: 1;  // rezerv
 unsigned i:   8;    // variable or constant number or ext. of ad
 unsigned ad:  16;   // address of definition (first 4096 entris in tabt)
 int ord(){return int(m) * twoexp16 + int(ad); }  // for qsort in sortden
}; // end elem (the size of elem must be always 4 bytes)

 struct elemint
{
 unsigned m:   8;    // mode = ints
 unsigned val: 24;   // value
}; // end elemint
 
#define CAPm   256         // 2^m
#define CAPi   256         // 2^i
#define CAPad  65536       // 2^ad == 2^16
#define INT_MAX24 16777215 // 2^24 = 16777216 (glex admits only nonnegative numbers ???)
#define twoexp24 16777216
#define twoexp16 65536     // 2^16 = 65536
#define INT_MAX16 32767
#define INT_MIN16 -32768
#define sizestscp 15       // emplevsct = sizestscp
#define iszthmb  4         // initial size of theorem block for den and tabt;
#define maxszthmbtabt 2048 // maximal size of theorem block tabt; // 2^11;
#define maxszthmbden 32768 // maximal size of theorem block for den; // 2^15; can be 2^16
#define lthmsic 1000       // size of thmsic: theorems of the form P1 & P12 -> Q;
// #define emplevsct 31       // 4 bits for levsct; last level: 14;

 struct head         // 12 bytes
{
 signed name:   16;  // name of the term, (-1) if term is unnamed, used only
 unsigned v:1;       // value of a r-term;  // reductive term; 
 unsigned levsct:4;  // level of scope terms, scp=zel == levsc = 0; ??? 4 bits is sufficient ???
 unsigned lth:  11;  // number of theorems;
// elem scp;         // scope in pars.cpp // 8 bits in scp can be used;
 unsigned tel:1;     //type of element (pfs, abt) // tpt,pdf) ??? can be eliminated ??? abt == q[0] = {++k
 unsigned t:  2;     //truth information(undef,truth,ctruth, truth3) // keq,kimp,keqim,ctruth,7:reserve)
 unsigned adt:1;     // abridged dot term
 unsigned postfix:1; // dcl is postfix;
 unsigned at:1;      // Z was derived from Z@S, assigned in rnam, example: TimE@FN ;
 unsigned l:  12;    //the number of sons, see sizel;        
 unsigned ln: 14;    //the line number, max 16785
 elem tp;            //typ of term size of head: 12
 elem son[0];        //the sons ( root=son[0] )
};  // end head

struct eden         // element of den
{
 ats a;             // addess in the current ts
 // signed a:16;    // address in the current ts;
 att lth;           // number of theorems, in which occurres the name;
 // unsigned sb: 8; // size of block (number of elems), act.size sb*sizeof(elem); 
 elem inn;          // inner name 
 elem scope;        // scope,  was elem d; // d:: ...
 elem son[];       // pointer to the theorems in current module, where occurres the name
 // int vis() { return d != zel1; };   // visibility of ychar* tt::vden1(elem x);  
};              

#define sizel 4095  //maximal value of l, see head.p

struct ecfs{ void* p; long k; char* pl; };

typedef elem* elemp;
typedef head* headp;
typedef eden* edenp;
typedef unsigned long ulong;
typedef short modsize_t;
typedef void* voidp ;
typedef att* attp;
typedef int* intp;
typedef char* charp;
typedef ecfs* cfsp;

//struct eant{ats a; att t;};
//extern ofstream mout;
extern ats asop,adot,aat,adclb,avar,aabt,aplint,amnbool,amnint,amnint1,amltint;
extern int nstr,aa,bb,ff,hhh,ii,jj,kk,mm,pp,dd,xx,gg,nn,sss,ppp,ttt,vv,ww,ee,repcount,instcount,sbstcount,typcount;
extern char** strvalue;
extern int  pait,sumcount; 
extern int prognum, numtrm,nummacr,numbdef,numrnam,numsortden,numtyp, ilot,idep,maxc; 
extern att llot, ldep,lst,lview;
extern elemp st;    //st[lst];
extern int ist;
extern int lsm;     // lsm=2, standard modules: 0_bool, 1_quant;
extern int iallm;
extern int ieul;
extern att curm;
extern att eul[maxmod];
extern int its;
extern char** ts;
extern int istscp;
extern att stad,stad1,stad2,endpait; 
extern int tead;             // for mm=1, if tead < 0, also ttt, sss;
extern int numthm;           // total number of theorems in the module;
extern int wrlot_c;          // wrlot count;
extern elem hint;            // a theorem to help prove a hard formula in simr;
extern char* hintstr;        // hint string - any string in module or proof scope;
extern elem zel;
extern ofstream* pfhis;
extern ofstream* pfmainhis;
extern ofstream* pfout;
extern ofstream* pfprp;
extern elem zel;        // elm(emps, 0, 0) 
extern elem zel0;       // elm(ints, 0, 0)
extern elem zel1;       // elm(ints, 0, 1)
extern elem zel9;       // elm(ints, 0, 9)
extern elem zcrlf;      // {a,b,c}
extern elem Tdefs;      // elm(ints, 0, 1)
extern elem Tsetdefs;   // elm(ints, 0, 2)
extern elem TDdcl;      // 
extern elem TDseq;      // 
extern elem zind;       // in d
extern elem zdbsl;      // \\ double back slash
extern elem zlseq; // lseq  
extern elem zin;   // in 
extern elem znin;  // nin
extern elem zseg;  // ..  
extern elem zALLFN; // ALLFN 
extern elem zdefs; // defs
extern elem zmaid;   // maid(d)
extern elem zInfRules;   // InfRules
extern elem zseq;  // seq
extern elem zSEQ;  // SEQ 
extern elem zseq1; // seq1
extern elem zSeq1; // SEQ1
extern elem TPstring; // string (elmint(13) )
extern elem zfnAB; // fn(A,B)
extern elem zfn;   // fn
extern elem zFn;   // Fn
extern elem zifn;  // ifn
extern elem zsfn;  // sfn
extern elem zbfn;  // bfn
extern elem zafn;  // afn
extern elem zFN;   // FN
extern elem zfinfnAB;  // f in fn(A, B)
extern elem zrel;  // zrel
extern elem zREL;  // REL
extern elem zint;  // int 
extern elem znat;  // nat
extern elem znat1;  // nat
extern elem znatm;  // nat
extern elem zNonempty;   
extern elem zP;    // P
extern elem zP1;   // P1
extern elem ztyp;  // typ
extern elem zinter; // /\ intersection
extern elem zincl;  // <:  inclusion
extern elem zany;  // any
extern elem zdclb;
extern elem zeps;  // eps
extern elem zset;  // set
extern elem zset1; // set1
extern elem zun;   // \/ union
extern elem zemp;   // {}
extern elem zempseq; // []
extern elem zfinset; // finset
extern elem ztrue; // true
extern elem zif;   // if
extern elem zif2;  // if2
extern elem zseqa; // seq(any)
extern elem zbool; // bool
extern elem ztrue; // true
extern elem zfalse;// false
extern elem znot;  // ~
extern elem zconj; // & 
extern elem zconjd; // & for definitions 
extern elem zimp;  // ->
extern elem zrimp; // <-
extern elem zeq;   // =
extern elem zneq;  // ~=
extern elem zequ;  // ==
extern elem znequ; // ~==
extern elem zdis;  // or
extern elem zrestr;  // |  restriction
extern elem zxor;  // xor
extern elem zxor3;  // xor3
extern elem zvariable;
extern elem zbvar;
extern elem zall;  // All(x, P]
extern elem zexist;
extern elem zexist1;
extern elem zexistx;
extern elem zexist1x;
extern elem zeps;   
extern elem zA;    // A[d, P]
extern elem zE;    // E[d, P]
extern elem zEx;   // Ex[d, P]
extern elem zE1;   // E1[d, P]
extern elem zR;    // R[d,f]
extern elem zU;    // U[d,w]
extern elem zF;    // F[d,f]
extern elem zS;    // S[d,f]
extern elem zProof;   // tproof
extern elem zEqProof; // tproof
extern elem zNotAxiom;
extern elem zTaut;
extern elem zStaut;
extern elem zis;
extern elem zby;
extern elem zbyeq;
extern elem zexc;     // Q is Q1 ! Q2;
extern elem last_y1, last_y;           // last typseq y1, y;
// extern elem zdexc;    // !!
extern elem zassume,yassume,zsuppose,zfrom,zwith,zInstance,zWitness, zAxab,zBred,zRed,zaxall,zsb,zbyimp;
extern elem zAssocinve,zanyd;   //F1;  by Associnve; F2;
extern elem zgroup;
extern elem zelg;
extern elem zdisjoint;
extern elem zabterm;   
extern elem zcomp;    // o composition
extern elem zinv;     // inv  for functions
extern elem zplint;   // +  int
extern elem zmltint;  // *  int
extern elem zmnbool;  // -  bool
extern elem zmnint;   // -  int binary
extern elem zmnint1;  // -  int unary
extern elem zmn1;  // -  int  unary
extern elem zmlt;  // *  int
extern elem zdiv;  // /  int
extern elem zlt;   // <  int
extern elem zle;   // <= int
extern elem zgt;   // >  int
extern elem zge;   // >= int
extern elem zmt;   // mt
extern elem zrecdef; // recdef
extern elem zRep;  // Rep(d,P,z)
extern elem zinst1; // inst1
// extern elem zreps;  // reps
extern elem zhost;  // host
extern elem zdcol;  // ::
extern elem zcrl;   // {a,  ... }
extern elem zcrl1;  // {d}
extern elem zcrl2;  // {d, f}
extern elem ymn;    // -
extern elem yasop;  // :=
extern elem yAb;    // A[
extern elem zat;    //  M@m  method m in module M
extern elem zdot;    // m.z : dot-term (like C++ z.m), m.z = Rep(d,m,z), d=typ(z)
extern elem zNI;     // NI   X NI Y == X/\Y={}
extern elem zsetdif; // set difference: X -- Y = X /\ ~Y
extern elem zadd;    // add: used only in EqProof
extern elem zopsqbr; // elm(247,91,0)
extern elem yvar;    // elm(ident,0,avar);
extern elem zdom;    // dom(f)
extern elem zim;     // im(f)
extern elem zvith;   // vith: very imp.theorems: vith := [FN <: REL, ... ];
extern elem zFNtypes; // {FN,FFN,SEQ,SEQ1,SEQ2, SEQinj,SEQinj1,SEQinj2};
extern elem zfntypes; // {fn,ifn,sfn,bfn,afn,ffn1,ffn,seq,seq1,seqinj,seqinj1,seqinj2};
extern elem ztypeaxiom;
extern elem zbegin;  // separator: begin("12 function restriction");
extern elem zdp;     // # = direct product;
extern elem zgiven;  // given
extern elem zDP;     // DP(A1,A2,A3) = #(A1,A2,A3) // = (A1#A2)#A3 ?;
extern elem zdebug;  // for printing: debug("hs"): hhh=1, sss=1;
extern elem opb;     //  [ : elm(gpc, '[',0)
extern elem zAFN;
extern elem zFFN;
extern elem zffn;
extern elem zII;
extern elem zdconj;
extern elem zseq1;
extern elem zSEQ1;
extern elem zlast;
extern elem zcol;           // x:t;  type term;
extern elem zfinabterm;
extern elem zfnsetbool;     // fn(set,bool);
extern elem zel999;         // undefined
extern elem scpe;
extern double time_trm, time_bdef, time_sortden, time_rnam, time_topt, tims_cthms, time_typa;
extern long alm;
extern int ippcount;  // count of all calls to ipps; (used like maxfilehis size)
extern int maxipp; // maximum for ippcount; must: ippcount * 100000 < maxipp;

// bool vterm(headp h);
void pelm(elem, ofstream* f=0);
inline void pelm(char* s, elem x, ofstream* f){ *f << s; pelm(x,f); };
void pelmar(char* s, elemp q, int k, ofstream* f);
void prh(headp h, ofstream* f);    // *f<<h->tel<<' '<<h->t<<' '<<h->postfix ...
void prh(att m, att ad, ofstream* f); // { prh(clad[m]->tabt[ad], f); }
bool popst(int k=1, bool err=true);   // err==true: error in popst; else error in the  popst caller;
void popst(elem); 
void wrst(elem x);
// void wrst1(elem z);
// void wrst2(elem z);
void pst(char* s,int k=12, ofstream* f = pfhis ); // s:place, k: print top k elements; move k to dd !!!;
inline int size(headp h){int k = h->l + h->lth; return sizeof(head) + k*sizeof(elem); } // full size of elem in tabt
inline int size(edenp h){int k = h->lth; return sizeof(eden) + k*sizeof(elem); } // full size of den-elem m in den;
int len(head h);
bool operator==(elem f, elem g);
bool operator!=(elem f, elem g);
bool operator!=(head h, head g);
inline bool eqex(elem x, elem y){ return x==y || x==zexist && y==zexistx || x==zexistx && y==zexist ||
            x==zexist1 && y==zexist1x || x==zexist1x && y==zexist1 || x==zE && y==zEx || x==zEx && y==zE; }
bool eqel(elem,elem);
bool feql(elem,elem);
void pelmcom(elem x, ofstream* f=0);
void prp(int i, elem z, ofstream* f=0);
void prp(elem z, ofstream* f=0);
void prp(char* s, elem z, ofstream* f=0);
void prpa();
void prpa(elemp q,int last,elem z=zel);
void prpe(elemp q,int last);
inline void pelmprp( elem x, ofstream* f){ pelm(x, f); prp(x, f); }
int srts(elemp a, int* alast);
// void bsort(elemp a, int last);  see bsort in etc.h, etc.cpp;
int lval(elem z);  // long (now int) value of z
att hash(elemp a, att last, att size, att* ad, elem z = zel);
att incr(att h, att d, att l);
int rtfm(char* S);  // raw time file modification (time in sec from 00.00 Jan 1, 1970)
int filesize(char* S);          // file size in bytes;
char* curtime();    // current time:  similar to  Sat Jan  8 20:07:41 2011 
char* mytime();     // ??
double myclock(char* s);   // ??
char* clon(char* s); // clon s using fylloc
bool sis(char* s1, char* s2);
bool findst(char* s, char* ar[]);
char* vts(elem z);
char* vts(ats a);
int findts(char*s);
// elem trm1(elem f,elem x,elem t);
// elem trm2(elem f, elem x, elem y, elem t);
// bool Dcltype(ats a);      // not used, 11.28.19
bool elsf(elem z);        // elementary set formula (X <: Y or X == Y)
bool elsforc(elem z);     // elsf or conjunction of elsfs
bool horn(elem z);        //  z is Horn formula (Q; or Q1->Q2, where Q,Q1,Q2 are elsforcs)
// int isrt(elem z, elem r, elemp* w, headp* g );
inline unsigned int unsvalelm(elem z){ return z.m * twoexp24 + z.i * twoexp16  + z.ad; } // 16777216 65536
inline bool Asop(elem z){ return int(z.m)==ubs && int(z.ad)==asop; } 
inline bool Aat(elem z){ return int(z.m)==ubs && int(z.ad)==aat; } 
inline bool Dcl(elem z){ return int(z.m)==ident && int(z.ad)==adclb; } 
inline bool Var(elem z){ return int(z.m)==ident && int(z.ad)==avar; } 
inline bool Abt(elem z, att* k=0){ bool r = z.m == ident && z.ad == att(aabt) ; if(r && k) *k = z.i; return r; }
// inline int Nabtnames(elem z) { assert(Abt(z)); return z.i; } // same as kmain(z)
inline bool comp(int m){ return m==pfs || m==abt; }
inline bool comp(elem z){ return z.m < maxmod && (z.i == 0); }   // z is a composite term ??? ieul ??? 2
inline bool simple(int m) { return m == var || m == con || m == bvar; }
inline bool simple(elem z) { return z.m >= maxmod || z.i != 0; }
inline int min(int a, int b){ return a<=b?a:b; }                     // added || z==zdconj on 2022.12.05;
inline bool bdname(elem z){ return z==zA || z==zE || z==zEx || z==zE1 || z==zF || z==zR || z==zU || z==zS; } // ? zE1x
inline bool bdname1(elem z){ return z==zA || z==zE || z==zEx || z==zE1 || z==zF || z==zR || z==zU || z==zS || z==zdconj; } 
inline bool inseg(int x, int a, int b){ return a <= x && x <= b; }  // x in a..b;
// inline bool defname(elem z){ return z==zdclb || z== yasop || z==zall || z==zexist || z==zexist1 || z==zexistx
//     || z==zassume || z==zA || z==zE || z==zE1 || z==zF || z==zR || z==zU || z==zS; }
bool vterm(headp h, elemp Q=0, elemp M=0);   //valued term Q(M) or Q.M: has value field
bool vterm(elem z, elemp Q=0, elemp M=0);    //valued term Q(M) or Q.M: has value field
void filltabt(att n);    // { ptt->tabt[n] = clad[0]->tabt[0]; }
inline ats numson1(headp h){ return (h->l); } // + vterm(h); } // number of sons + pos.extra elem;
inline ats numsonthm1(headp h){ return numson1(h) + h->lth; }  // number of sons and theorems + pos.extra // was numson1(h)
inline elemp thmbase0(headp h){ return &(h->son[0]) + h->l; }
inline elemp thmbase(headp h){ return &(h->son[0]) + h->l + h->v; } // + numson1(h); }
inline elemp thmbase(edenp h){ return &(h->son[0]); }
ats thmbase(elem z, elemp* base); // returns the number of theorems; 
inline bool allex1(elem a){ return a==zall || a==zexist || a==zexist1 || a==zexistx || a==zexist1x; }
inline att abtallex1(elem z){ att r=0, k;  if(Abt(z, &k)) return k; if(allex1(z)) return 1; return 0; }
inline qbdname(elem z){ return allex1(z) || bdname(z); }
inline bool defname(elem z){ return z==zdcol || z==zdclb || z== yasop || z==zassume || z==yvar || z==zis || 
     z==zby || z==zbyeq || z==zwith || allex1(z) || Abt(z) || z==zProof || z==zEqProof; }  // don'merge these terms ! // || bdname(z) 
elem fseg(int k, att n=emptt, int tel=pfs, headp* ah=0, att lev=sizestscp); // functional segment, body in pars;
bool inseqv(elem s, elem x);      // s = [x1,...,xk], return x in s;
void inith(headp h, int pfsabt, int l, elem t, int line, att lev=sizestscp, att isz=0);
void prps(elem x,  ofstream* f);  // pretty printing of simple x
void microcont(ofstream* f=0);    // sp1,s,s0,s01,s02
void prstcont(char* s);           // print st,cont,microcont;
inline bool prime(elem s){ return s.m==ident||s.m==ints||s.m==chara||s.m==strng; } 
void swapst(int k, int m);
void pvin(char* s= " ");          // printing  vin
void finish(char* s, char* M);             // printing total time and other statistics
bool insideqabt();                // inside of qab terms (body in pars);
void ph(headp h, ofstream* f);    // printing headp h;
int prext(char* place);          // print external: ist, repcount, instcount, sbstcount, typcount; returns the sum;
float ttime(char* place);         // total time: float(clock() - start_clock)/float(CLOCKS_PER_SEC);
inline bool constm(att m){ return m==ints || m==strng || m==chara; }
inline elem other(elem z,elem Q1,elem Q2){ elem r=zel; if(Q1==z) r = Q2; else if(Q2==z) r = Q1; return r; }
inline bool trivt(elem t){ return t==zset || t==zany || t==zREL || t==zSEQ; }
inline void swap(elem* x, elem* y){ elem t = *x; *x = *y; *y = t; }
inline bool iseqequ(elem f){ return f==zeq || f==zequ; }
inline void beep(int k){ for( int i=0; i < k; i++) cout << '\a'; }
void chilot(char* s, int newilot);        // change ilot: ilot = newilot;
// void chiMod(char* s, int newiMod);        // change iMod: iMod = newiMod;
// inline bool fnt1(elem z, elem f, elem a){ headp h; elemp q; return  mel(z,&h,&q)==pfs && h->l==2 && q[0]==f && q[1]==a; }

  class qab             // ar1: qabterms, R1: new address in tabt, R2: special (for remd: # of removed bvar);
{                       // replace maxlevqt with size_fnelematt2; ???
 public:
 elem ar[maxlevqt];     // elem stqab[maxlevqt];  // a qabterm to be replaced 
 att R1[maxlevqt];      // att stqab1[maxlevqt];  // a new place in the current tab for the correspoding new qabterm;
 att R2[maxlevqt];      // att stqab2[maxlevqt];   // emptt or the number of name removed from d (stqab);
 qab();
 int iar;               // istqab  
 void init();           // { iar = -1; if(mm) ipp("+-init: assigned -1 to iar= ", iar); } ERROR !!!
 bool wr(elem z, att n1, att m=emptt); // void wrstqab(elem z, att n1, att m=emptt);
 att val1(elem z);       // value of z in R1(emptt if z is not in ar1;  // att fstqab(elem z);     // find z in stqab;
 // att val2(elem z);    // value of z in R2;
 elem valbvar(elem z);  // value of bvar (zel if not) // elem valstqab(elem z);  // value of z from stqab;
 void pr(char* s = " "); // void prstqab(char* s = " ");     // Printing of the stack stqab; ( qabterms)
 elem repbv(elem z);  // keep in sbst;?   // replace bvar z using stqab (and s);
 elem repb(elem z);   // keep in sbst;?    //, sbst* s=0);     // replace in z every bvar x on repbv(x) using stqab (and s);
 bool bvarinqab(elem z);         // bounded var z is in stqab
 void pop(elem z, char* place);  // check ar[iar]==z, decrease iar by 1;
}; // end class qab;

// end lib.h
