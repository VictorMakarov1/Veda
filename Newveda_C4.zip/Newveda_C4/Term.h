// Term.h 01/06/99 5/27/00 7/12/00 12/02/00 12/04/00 12/20/00
#define llist 100      // 5/03/01
int hgt(elem);
int cmpl(elem z);
elem devc(elem x);
void freen(elem z, elemp* ar=0, int* iar=0);    //   ar: free variables, ar1: composites, ar2: bounded vars; 
int freenames(elem z, elem ar[], int maxsizear,elem ar1[]=0, int* lastar1=0, elem ar2[]=0, int* lastar2=0, elem ar3[]=0,
 int* lastar3=0, elem ar4[]=0, int* lastar4=0, sbst* s=0); // ar4: methods, using iMod from s;
 // result: number of names in ar, ar: free vars, ar1: others, ar2: local bvars, ar3: nonlocal bvars; 
inline bool closedterm(elem z) {elem ar[maxvars]; return freenames(z,ar,maxvars) > 0; }
bool goodimp(elem z, elemp a, elemp b);   // z is A->B & freenames(A) <: freenames(B);
//int vrit(elem z);   // variables in term
void simt(elem z);    // , int p=0); // 0:con&var, con: only cons, var: only vars
bool interm(elem x, elem z);   // elem x in term (or def) z
bool dinterm(elem d, elem z);  // d in term z; // A[d,P], All(x, A[d,P], A[d1, A[d,P]], ...
bool DinD(elem Dx, elem D, int* ds=0);    // Dx in D: Dx=D or D is Dx && Z or D is D1 && Dx or ... // ds: displacement Dx;
bool DinA(elem Dx, elem A);    // Dx in A := All(x, A[d1,A[d2, ... A[dk, a = b] ... ][
bool Varbvar(elem z, elem d0, elem dpat);        // bvar z is var;
bool bvarfree(elem Q, elem z);     // z is free from Q-bvars
elem trm1(elem f, elem x, elem t);  // =zel);
elem trm2(elem f, elem x, elem y, elem t, att n = emptt);  // elem t=zel
// elem trm2t(elem f, elem x, elem y, elem t=zel);  // if(istr2c(f,x,y)) return ztrue; else trm2(f,x,y);
elem trm3(elem f, elem x, elem y, elem z, elem t=zel);
elem trmk(int k, elem* ps, int p = pfs);         // k: size of ps;
elem trmk1(elem v, int k, elem* ps);          // k: size of ps(including unused ps[0]);
elem trmh(head h, elemp a);
elem trmseq(int k, elem* ps);
elem reproot(elem z, elem y);
elem clon(elem z);
bool dcld(headp h, elem* ad=0);
bool dterm(headp h, elem* ad=0);                                   // in bvarin, Q was unlocal in ntorbs := Q_orbs && #Q >1;
inline bool dterm1(headp h){ elem a = h->son[0]; return bdname1(a); }   // changed bdname(a) to bdname1(a): 2022.12.05;
// inline bool dterm1a(headp h){ elem a = h->son[0]; return bdname1(a); } 
inline bool dterm1(elem z, elem d){headp h; elemp q; return z==d || mel(z,&h,&q)==pfs && bdname(q[0]) && q[1]==d; } 
bool dterm(elem z, elem* ad=0, headp* ah=0);
bool dterm2(elem z, elem* ad=0, headp* ah=0);
elem scopeterm(elem z);       // z is a scope term: All(x,P(x)), ... (r=z), A[d,P],..., (r=d_
elem corr(elem x1, achs* f, achs* f1, sbst* s=0);          // find r in f that corresponds x1 in f1; else zel;
ats eqbvs(elem V, achs* f, elem V1, achs* f1, sbst* s, att peqt=0);  // 0: V != V1, 1: V==V1, 2: unknown; 
bool req(elem z1, elem z2, sbst* s0=0);   // recursive equality (now not recursive)
bool reqdot(elem z, elem z1); // Q.M == Q(M) or Q(M)==Q.M;
bool feq(elem z1, elem z2);   // full equality: req + istr2;
// bool isdot(elem z,elem z1, elem M, elem T, elem* av, elem* av1);  // z; is z1.M; 
int dif(elem z,elem z1, elem K[], elem L[]); // elem K[maxvars]; result: last occupied in K,L; 
int aseq(elem z1, elem z2);
bool seqv(elem z, int* ak=0, elemp* aq=0, headp* ah=0);
bool tupl(elem z, int* ak=0, elemp* aq=0, headp* ah=0);
int hml(elem z1, elem z2, int p=0);   // p=0 for the first call!
int isrt(elem z, elem r, elemp* w=0, headp* g=0);
bool isispr(elem z);                  // z is is(J) or Proof(T; ...) or EqProof(T: ...); ??? name(z)==T ???
bool isproof(elem z, elem* goal=0);   // z is Proof(goal; ...) or EqProof(goal; ...);
int isrtv(elem z, elem r);            // return var(r) || isrt(z, r);
elem vard(elem d, int k);             // in term.cpp!!! 12/08/99
int npfn(elem z);                     // number of parameters of function name
//int subt(elem z, elemp ar);  // subterms of z into ar (vars: include vars and cons), size ar = maxvars 
void freet(elem z,elemp ar,int* iar); // free  subterms into ar; size ar = maxvars(currently 100)
att inteq(elem z, elem a, elem b);    // intersection all free terms in z with equation a=b: r=1: a in z, 2:b in z, 0:else
int fsynv(elem K, elem ar[]);         // syntactic vars in K; "isynv = -1" must be before main call of fsynv(K)
void names(elem z, elem a[], int la); // names of s -> a
int intersect(elem z, elemp q);       // one of names of z in q
int dinn(elem d, elemp q);            // a d-name is in names q
// int TrueFormula(elem p);        // p.t = truth 
elem nega(elem z, int p=0);  // p==1: ~z; p==0: z.n^1
elem parent(int i);  // 1: parent, 2: grandparent, ...
// bool vterm(headp h, elemp Q=0, elemp M=0);   //valued term Q(M) or Q.M: has value field
int vart(elem md, elem d); // md is a variable or a composite term
int LocTerm(elem z); // Local term - contains invisible vars 
bool qterm(headp h); // Quantification term: All(x,P), Exist(x.P), Exist1(x,P)
// int bsons(headp h);              // beginning of sons of abterm
// bool cmpr(elem F, elem T, elem A, elem B); // compare F and t by modulo A=B
bool dname(elem x, elem d, int* ai);  // x == d ++ i, mel(d) == abt
bool bad1(elem y, elem z);  // dif(y,z) = ( g(x), g(g(x)) );
bool iter(elem y, elem z);  // y is g(x), z is g(g(x));
elem root(elem z, headp* ah=0, elemp* aq=0);  // if z is composite f(...), {...} then f, else z
elem  Axabt(elem d, headp g, elemp w);        // Full (conjunction of all axioms) Axiom of d; 
elem AllExAE(elem z, headp g, elemp w); // z=A[{x;P}, Q] => All(x, P->Q); c='A' or c='E';
void recdef(elemp q, int i, att hl1);   // handling of (primitive) recursive definitions;
int findnat(elem d, headp* ah);         // find first nat-bvar in d; (0: if no nat-bvars);
bool chterm(elem z, elem d1, int kd1, elem f, elem b); // z is f(d_1, ..., m:b, d_k), used for checking rec.definitions;
bool checkterm(elem z); // checks term after rep2i,now checks only for strange bvars, not related to z;
bool prefd(elem d1, headp h1, elemp q1,elem d, headp h, elemp q); // d1 is a proper prefix of d;
bool fanyd(elem V1, elemp d);           // checking that V1 = f(^d), typ(f) = fn(d,B); 
bool chfint(elem z, elem f, elem d, int kd1, elem n);  // subterm f(X,n) is in z2;
inline bool Allbvar(elem z){ elem y = z; y.i = 0; return isrt(y,zall) != 0; } // y = htbv(z)
inline bool Existxbvar(elem z){ elem y = z; y.i = 0; return isrt(y,zexistx) != 0; } // y = htbv(z)
elem strip(elem z, elem f);             // strip(f(f(x)), f) = x;
bool ground(elem z);                    // z is a ground term (not containing free vars);
elem typeth(elem z, elem* at);   // type theorem for a named term z: Lnamez_type := z in t;

// inline elem typelim(elem z){ elem y, t, r=z; if(fnt2(z, zcol, &y, &t)) r = y; return r; }  // type elimination: z:t => z;
