// elem.h 11/19/97 11/06/00 11/22/00 01/08/01
// elem.h 11/19/97 11/06/00 11/22/00 01/08/01
struct bl         // base, level
{
 ats lev;  
 elem base;
}; // struct bl    

bool boundvar(elem x, ats* a=0, headp* h=0);       // x is a bounded var (in qterm or abt term) 
bool boundvar1(elem z, ats* a);  // only for use in prp;
bool freevar(elem z, ats* adts=0, elem* atype=0);
bool freebvar(elem z, elemp av);   // M: All(xx, P) xx can be referenced also as (curm, 1, M) - is freebvar;
bool gvar(ats a);        // global variable in qterms; // xx, xx1, ..., yy, yy1, ... ,
bool isproptail(char* T, char* S);  // T is a proper tail of S (proper T!=S) // located in etc.h
// inline bool var_free(elem V, headp h, elemp q)  // V is v_free(x);
//    { ats a; return h->l==2 && freevar(q[0],&a) && isproptail("_free", vts(a)); }
elem pvar(elem z, elemp*w=0, int* k=0); // Q(x, ... ), returns Q, w=q, if pfs,else undef; k=h->l or k=0;
bool inlist(elem z, elem ar[], int last, char ppvar='0', char* place= "***");  // kar: last occ.
bool inList(elem z, elem ar[], int last, int* k=0);          // k: place in ar
bool find(elem z, elem ar[], int sizear);                  // find z in ar
bool wrlist(elem z, elem ar[], int* iar, int maxsizear);   // *iar : last occupied; r == z was new;
void prlist(char* s, elem ar[], int last);                 // last:  last occupied;
bool bvel(elem a, elem d, int i); // a is i-th d-bounded variable
bool qterm(headp h); // Quantification term: All(x,P), Exist(x.P), Exist1(x,P)
att kboun(headp h);   // number of bounded names (All, Exist, Exist1: 1, abt : abt.i, else 0;
att kboun(elem z);   // number of bounded names (All, Exist, Exist1: 1, abt : abt.i, else 0;
// int qtrm(elem z, elemp* w=0);  // quantification term
inline att kmain(headp h) { return h->tel == abt? h->son[0].i : qterm(h)?1:0; } // see kboun
inline att kmain(elem z, headp* ah=0) 
  { headp h; int m= mel(z,&h); int r= m==abt? h->son[0].i : m==pfs && qterm(h)?1:0; 
  if(r && ah) *ah = h; 
  return r; }
inline bool qterm(elem z) {headp h; bool r = (mel(z,&h)==pfs) && qterm(h); return r; } 
inline int beg(att m, headp h){ int r=0; if(m==abt) r = kmain(h)+1; return r; } // ??? All(x, P(x)), .... 2022.06.04
inline elem htbv(elem x){ elem r = zel; if(mel(x) == bvar){ r=x; r.i=0; } return r; } // host term for bv;
inline elem nami(elem z, int i) { elem r = z; r.i = i; return r; }
inline elem operator+(elem z, att i){ elem r = z; r.i = i; return r; };  // same as nami;
inline bool basic_name(elem x, elem s){ return htbv(x)==s; }
inline bool operator==(bl x, bl y){ return x.base == y.base && x.lev == y.lev; }
bool abtbvar(elem z, elem* d=0, headp* ah=0, elemp* aq=0);   // aq : points to d-axioms, not to d-names;
bool isname(elem x, elem d, elem dpat=zel0); // x is an internal name of d or dpat;
inline bool Const(elem z){ int m = mel(z); return m==con; } // || abtbvar(z,&d,&h) && h->name != noname; } headp h; elem d; 
inline bool varabt(elem z){ ats a; elem t; return freevar(z,&a,&t) && t==zabterm; }
inline bool qabterm(headp h) {  bool r = qterm(h) || h->tel == abt; return r; }  // h points to qterm(All,... or abterm;
inline bool Abterm(elem z, headp* ah){ ats a; elem t; headp h=0; elemp q; int m=mel(z,&h,&q); *ah = h;
            return m==abt || m==pfs && q[0]==zdconj || freevar(z,&a,&t) && t == zabterm; }
inline att fnterm(elem z, elemp* aq){ att r=0; headp h; if(mel(z,&h,aq) == pfs && !h->adt) r = h->l-1; return r; } 
inline ats name(elem z, headp* ah){ headp h; ats r = -2; if(comp(mel(z,&h))){ r = h->name; *ah = h;} return r; }
inline char* Name(elem z){ headp h; char* r = 0; if(comp(mel(z,&h)) && h->name != noname) r = vts(h->name); return r; }
inline char* Name1(elem z){ headp h; elemp q; ats a;   char* r = 0;  // also dclnames;
 if(comp(mel(z,&h))){ if(h->name != noname) r = vts(h->name); } else{ if(dclname(z,&h,&q,&a)) r = vts(a); }; return r; }
bool isfnt(elem t);   // fn,bfn,seq,ffn, ....
inline bool cltyp(elem z){ headp h; return  mel(z,&h)==abt && h->name != noname && scopeden(z)==zel || 
                z==zREL || inseqv(zFNtypes,z); } // closed type, no action in rep; // ??? REWORK !!!
bool rootname(elem z);
short qabterm(elem z, headp *ah=0, elemp *aq=0, int *am=0);  // returns k = kboun(h)
elem maid(elem z);                                         // main definition: maid(d&&P) = d;
inline int gmain(elem z){ elem d = maid(z); return kmain(d); } 
bool abterm(elem d, int* knames, elemp* qd, elemp* qax, int* kax);  // d is a real (not var) abterm
bool finabt(elem d);          // d is a finite abterm;
bool typax(elem d, elem a, int j, elem* at);      // a is j-th type axiom in d;
bool dax(elem x, elem d, int* ak=0); // x is an axiom of d;
bool Dax(elem x, elem D);            // x is an axiom of D; // D is d, D&&P, D&&D1, like DinD;
elem freered(elem d, int m);         // free-reduction of A[d,Q], E[d,Q], R[d,Q];
elem redconj(elem z, int m);         // Q1 & Q2 == Q1, if Q1 -> Q2;            // by Red("&, 1); // m = 1.2.
bool finset(elem t);     // t is a finite set
bool twav(elem z); // term with abt vars
ats avel(elem z, int* m=0, headp* h=0, elemp* q=0);   // ats value of element (if z.m < maxmod && clad[z.m] != 0); for nonnamed z, r = -1;
char* svel(elem z); // symbolic value of element;
ats intval(elem z); // z.m = ints, last 16 bits;  was 24 bits;
char* strval(elem z); // z.m = strng, vts(z.ad)
inline bool mystring(elem z, char* s){ return z.m==strng && strcmp(strval(z), s) == 0; } // strval(z)
elem elm(att, att, att);
elem elma(int m, int a);
elem elmint(int c);
att Att(elem a);
ats Ats(elem a);    // if(a.m == ident || a.m == ubs) return check(a.ad);
// inline int kabtn(elem x) { return x.i; };
bool idubs(elem x, ats* a=0, int* pr=0);
bool Ident(elem x, ats* a=0);
bool Ints(elem x, ats* a=0);
bool Ubs(elem x, ats* a=0, int* pr=0, bool* alfa=0);
bool Binary(elem x);
bool Bname(elem z);   // Bracket name; A,E,E1,dcl,R,F;
bool isvar(elem z);   // z is a variable
bool isneg(elem x, elem y); 
int ldev(elem d);     // number of bvars in abterm
// elem vname(elem z, headp h, bool* apv=0);  // virtual name (var or bvar)
inline bool sysname(elem z){ char* s = svel(z); return s[0] == '_'; } // system name 
bool syntvar(elem z);
bool ploop(elem z);                // potentially looping formula
elem typbvar(elem z);              // type of bvar: Exist(x, Q): look in Q for "x in t";
elem findtf(elem y, elem v);       // find type formula (v in t) in y; 
// elem mdln(elem z, elem M, elem T); // modelization of z: replace each T-method y in z with y@M; 
elem valm(elem M, int i);          // if M is [m1,...,mk] then m_i+p else M;
elem valm(elem z, elem T, elem M); // if(htbv(z)==T) then valm(M,z.i) else trm2(zdot,z,M,t1);
elem valm4(elem M, elem T, int kT, int i);  // if(K(T)==1) r=M; if(seqv(M,&kM,&q) r = q[i]; plus CHECKS !!!  
bool fntP(elem z, elemp x=0);      // z is P[*x] or P1[*x], use in disjoint;
bool atomset(elem z);              // z is an atomset: int,bool,elg, ...
bool conjunct(elem z, elem C);     // z is a conjunct of C;
elem arg(elem z, att n, elemp* aq=0);           // n-th argument of z; 0:root; q from mel(z,&h,&q);
bl blev(elem z);                   // (base, level) for z;
inline ats namet(elem z, headp* ah = 0)   // name of composite term (ats: address in ts)
  {ats r = -1; headp h; int m = mel(z,&h); if(m==pfs || m==abt){ r = h->name; if(ah) *ah = h; } return r; }
inline char* strnamet(elem z)           // name of composite term (ats: address in ts)
  { ats a = namet(z); return a == -1? "***": ts[a]; }
inline bool named(elem z)           // z is var,bvar or a composite term;
  { headp h; int m = mel(z,&h); return m==var || m==bvar || (m==pfs || m==abt) && h->name != noname; }
inline bool namedabt(elem z){ headp h; return mel(z, &h)==abt && h->name != noname; }
inline bool consttype(elem t){ return t==zbool || t == zint || t==znat || namedabt(t); }
int indelem(elem z, elemp q, int beg, int maxq); // index of z in q[beg..maxq): q[r]==z,else -1;
bool Capital(elem x);              // Ident(x,&a) && isupper(vts(q[1])[1]);
int cmpt(elem t1, elem t2);        // compare terms: for qsort;
att adtv(elem z, elemp* v);  // if z is an adt term Q(z1,...,zk) & host(Q) = d := {x1,...xk; ...} & xi=zi, r=k; 
inline ats npardcl(headp g){ return g->l - 3; }
inline elem rtdcl(headp g, elemp w){ return w[g->l - 1]; }
bool trivdt(elem z, elem Q, elem M);  // trivial dot term; z = Q.M or z = Q(M);
// end elem.h
