 // 04/29/15 12/16/17

 struct each      // element of active chain
{
 headp h;      // h for e
 short p;      // active place
 bool ch;      // changed in rep
 elem e;       // element
}; 

class achs{

public:
bool end;                              // ? iach < 0
int iach;
each ach[lach];

void init(elem z);                // initializations, z must be composite
void wach(elem z, int p = -1);    // write z onto stack ach, z must be composite
// void wach(elem z, headp h);    // not used
void prach(char* s = " ", elem z=zel);        // print ach
void popach(void* s=0);                       // pop ach
void cach();                      // control ach
// inline elem achs::parent(){ return iach>0 ? ach[iach-1].e : zel; }   // ach[iach-1].e:root ???
elem curvert(bool* finr=0);        // current vertex, finr : the vertex is the most right;
inline elem actarg(each Q){ elem r = Q.e; if(Q.h && Q.p != -1) r = (&(Q.h->son[0]))[Q.p]; return r; }
int actplace(elemp az);
each acteach(short* ai);
elem parent();
// inline int iparent(){ assert(iach >= 0); return comp(curvert() iach-1 else iach[
elem lbr();                       // left brother
bool mostr(short* p);             // the current vertex is the most right, p: the place; 
elem pred();                      // preceding vertex (predecessor)
elem prevt(achs* a, int i);       // previous theorem
void copy(achs* a);               // copy this to a;
each topach(); // {if(iach >= 0) error("topach: wrong iach= ", iach); return ach[iach]; } 
each topach1();
bool topachDabt(elem z);          // r  top.e == z && Dterm(top1.e) && top1.p == 1;
inline void wrp(int p){ assert(iach>=0); ach[iach].p = p; }
inline void wrel(elem z){ assert(iach>=0); --iach; wach(z); }
bool next(void* s= 0);           // true: finish // ? void
bool next1(void* s = 0);          // true: finish // ? void                    // ach[iach].e;
inline each elemach(int i){ assert(0 <= i && i <= iach); return ach[i]; }
inline elem justup(int i){ elem r=zel; assert(0 <= i && i <= iach); if(i>0) r = ach[i-1].e; return r; }
// int seek(elem d, int* k);         // s// r==1: ach[k].e == 1, r==2: dterm(... ) && ..: // not used
int seek(elem z);                 // seek z in ach, r: -1 : not in ach
// int seek1(elem z);                // seek z==ach[r].e in ach, r: -1 : not in ach
elem seekroot(elem f);            // r = ach[i].e; such that root(r) = f;
int findqabt(elem arqt[maxlevqt]);  // all qterms in achs, beginning from top, r: last occupied
int nqabt();                        // index of nearest(from top) qabterm in achs; -1 otherwise
bool bvarin(elem z, int* place=0, elem* d=0); // z is bvar of Q && ach[place].e=Q; p==true: All...; false:A[...;
bool bvarin1(elem z);             // a simplified version of bvarin (for checkterm);
bool varin(elem z);                // z freevar in Q && Q is in achs; ??? only first place checked ???
int qablev();                     // Quant level: (of embeddingness of Q-terms and abterms): DeBruijn index
                                  // for use in req to compare bvars of Q-terms
// void crstqab(elem V);             // create stqab from achs until V(not including);
elem clonch(elem y);              // clon of active element with changing his active son to y
elem repach(elem y, qab* W); // qab* W);    // clon all active terms, replacing at first active son on y
                                  // and so on moving up active chain
elem ndcol();                     // nearest(from top) dcol-term (T::z), returns T, else zel;
bool inproof();                   // inside of Proof(...) or EqProof(...);
bool inbyis();                    // inside of by(...) or is(...);
bool seekdcol(elem T);            // seek in achs dcol-term (T::z) or T&&P;
bool seekdt(elem T);              // seek in achs d-term A[T,P],..., T::z),T&&P;// seekdtd:if not,ret zel;
bool seekd(elem d);               // seek in achs d-term { }. A[d,P],..., d::z),d&&P;
elem seekdtd(elem f=zel,elem d=zel);  // seek in achs d-term f[d,...] or(if f==zel):{ }, A[d,P],..., S[d,f); d is variable; return d;
elem tpAdbv(elem z);              // seek in achs A[d,P], d==htbv(z), if found r = tp(z), else r = zel;
inline elem above(){ return iach>0 ? ach[iach-1].e : zel; }  // ach grew down;
elem tfromach(elem z);            // type from ach : z in t -> R, z is inside of R, r = t; 
// int nqt(headp* ah, elemp* aq);    // nearest(from top) Q-term (All, Exist, Exist1)
achs(elem z);                     // constructor
elem Scope(int ai, bool p=false); // p=true: Scope was called from 5.1(x := y)                     // normAEF: a: index of first name: 1 for A, 2 for dcl;
elem Exscope(int ai);             // scope for Ex[d,P]-bounded variables;
void normAEF(elem z,elemp q,int hl,int a);  // normalization of A,E,E1,F[x,t:t, a,b:t1, ,,, ,P]: q -> q;
elem spterm2(elem A, elem M);      // special or module term A@M; // M can be a scope;
void bdef();
void rnam();
void visn(ats a, int p, int k = 0);
void wapl(elem y);
elem fnam(ats a, int p=0, int k=0, bool postfix=false,  ats* id=0);  // find first p+1 visible names, 
                        // k: number of actual parameters  // q: actuals // id: index in den
elem lbr(int i);                       // left brother of ach[i].e;
elem rbr(int i);                       // right brother of ach[i].e;
inline void achs::jumpend(){ assert(iach>=0); ach[iach].p = ach[iach].h->l; }
//inline void achs:: prstgoals(){ for(int i=0; i <= iach; i++) if(stgoals[i] != zel) ipp(" stgoals[i]= ", stgoals[i], " i= ", i); } 
// ~ts();
};

elem spterm1(ats aA, ats aM);     // special term A@M (or A(M) ); (excluding module terms);
int typcmpr(elem t, elemp atz, elem z=zel, achs* f=0);    // 1: tz <: t, 0: disjoint, 2: unknown;  
int typcmpr1(elem t, elemp atz, elem z, achs* f=0); 
