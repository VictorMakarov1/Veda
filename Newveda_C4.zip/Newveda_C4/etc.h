
char* concat(char* s,char* t);   // etc.h - 11/07/99 09/25/00
bool isproptail(char* T, char* S);  // T is a proper tail of S (proper T!=S)
bool seqname(char* S);     // S is SEQ* or seq*; 
int intlen(int x);
void* mylloc(size_t k);
voidp fylloc(char* s, long k);
void myfree(void* p);
size_t frem();
long freh();
char* svin(int k);
int ival(char* s);
// voidp sylloc(long k, char* pl);
// void syfree(voidp p, char* place);
inline int even(int k) { return k % 2 == 0; }
char last(char* s);
void debug(ats a);
bool chch(elem x, char* place);  // check change of x after place, return true iff changed;
inline void swapelm(elem *x, elem *y){	elem temp = *x;	*x = *y;	*y = temp; }
// inline void swapint(int *x, int *y){	int temp = *x;	*x = *y;	*y = temp; }
att Lev(elem z); // {headp h; int m = mel(z, &h); return comp(m)? h->levsct : sizestscp; }
void bsort(elem arr[], int n);   // bubble sort
att numdig(int m);               // number of digits in m; also 0, -;
void spacesf(ofstream *f, int n); // output to *f n spaces;
void chint(elemp q, att i, att last);     // calculating hintstr = q[i+1], hint = q[i+2]; 
