#include "lib.h"              // etc.cpp: 11/07/99#include "etc.h"
#include "achs.h"
#include "sbs.h"
#include "tt.h"
#include "adl.h"
#include "elem.h"
#include <time.h>
#include "err.h"
#include "etc.h"
extern int cc, ee, ii, oo,kk,hhh,mm,rrr;
#define bigchunk 1000
long alm = 0;      // all allocated memory via fylloc, using malloc

   att Lev(elem z)
{
 headp h; int m = mel(z, &h); att r = 0;
 if(mm) ipp("+Lev z= ", z);
 if(z==zel) goto ret;
 if(comp(m)){ r = h->levsct; goto ret; }
 error("Lev: simple z= ", z, " m= ", m);
 ret: if(mm) ipp("-Lev z= ", z, " r= ", r);
 return r;
} // end att Lev

   char* concat(char* s,char* t)
{
 char* p; int i,k,m;  // char c;
 k=strlen(s); m=strlen(t);
 p = (char*) fylloc("concat", k+m+1);
 for(i=0; i<k; i++) p[i] = s[i];
 for(i=0; i<m; i++) p[i+k] = t[i];
 p[k+m]=0;
 return p;
 //if(pp){cout<<"\nconcat "<<s<<' '<<t<<' '<<p; cin>>c;}
}  // end concat

   bool isproptail(char* T, char* S)  // T is a proper tail of S (proper T!=S) 
{
 bool r = false; int kT = strlen(T), kS = strlen(S); char* S1="999";
 if(kT < kS)
 {
  S1 = S + (kS-kT);
  r = (strcmp(T,S1)==0);
 } // if(kT < kS)
 // if(mm) *pfhis<<"\n   +-isproptail T=  "<< T << " S= " << S << " S1= " << S1 << " r= " << r << " r1= "<<r1; 
 return r;
} // end isproptail

  bool seqname(char* S)     // S is SEQ* or seq*;
{
 bool r = false; int k = strlen(S); // char T[3];
 if(mm) ipp("seqname S= ", S);
 if(k < 3) goto ret;
 if((S[0]=='S' || S[0]=='s') && (S[1]=='E' || S[1]=='e') && (S[2]=='Q' || S[2]=='q')) r = true;
 ret: if(mm) ipp("seqname S= ", S, " r= ", r);
      return r;
} // end bool seqname(char* S)

   int intlen(int x)
{
 int k=0;
 if(x<0){k=1;x=-x;};
 if(x==0)return 1;
 while(x)
  {x=x/10; k++;}
 return k;
}

/*     void* mylloc(size_t k)
 {
  // static long salm;
  // if(pp) cout<<"\n+mylloc "<<k<<' '<<salm;
  // if(pp) *pfhis<<"\n+mylloc "<<k<<' '<<salm;
  void* p;
  if(k==0) return 0;
  p = malloc(k);
  // if(pp) cout<<"\n-mylloc "<<k<<' '<<salm<<' '<<p;
  // if(pp) *pfhis<<"\n-mylloc "<<k<<' '<<salm<<' '<<p;
  alm += k; //if(pp) cpp("mylloc k, salm= ", k, salm);
  if(p) return p;
  error("mylloc: no main memory k=", k, " alm= ", alm); return p;
 }
*/
     voidp fylloc(char*s, long k)
{
  // if(9) cout << "\n+fylloc k= " << k; // alm;
  // if(9) *pfhis << "\n+fylloc k= " << k; 
  voidp p;
  if(k==0){ipp("fylloc: k=0"); return 0; }//checkr(-4);
  p = malloc(k); // farfree(p); p=farmalloc(k);    //??????
  if(p==0)
  {
   *pfmainhis << "\nfylloc: ERROR: p==0: s= " << s << " k= "<<k<<" alm= "<<alm;
   *pfhis << "\nfylloc: ERROR: p==0: s= " << s << " k= "<<k<<" alm= "<<alm;
   pfmainhis->close();
   pfhis->close();
   beep(2); exit(1);
  } // if(p==0)
  alm += k;
  if(k > bigchunk) *pfhis << "\nfylloc: big chunk: s= " << s << " k= "<<k<<" alm= "<<alm;
  // if(9)cout<<"\n-fylloc "<<k<<' '<<alm<<' ';
  // if(9) *pfhis << "\n-fylloc k= " << k; 
  if(!p) 
  {
   cout <<"fylloc: no main memory k= " << k << " alm= " << alm;
   *pfhis <<"fylloc: no main memory k= " << k << " alm= " << alm;
   err();
  } // if(!p)
  return p;
} // end fylloc 

     void myfree(void* p)
{
 //static long count;
 if(pp)cout<<"\n+myfree p="<<long(p);
 free(p);
 if(pp)cout<<"\n-myfree ";
}

    size_t frem()
{
  size_t a=0;
  int i; int k = 10000;
   void* p[20];
  for(i=0; i<20; i++)
   {
    p[i] = malloc(k);
    if(p[i]) a+=k; else if(k==10000)k=1000;else break;
   }
  for(i=i-1; i>=0; i--) free(p[i]);
  return a;
} // end frem 

  long freh()
{
  long a=0;
  int i; long k = 100000L;  // char c;
    void* p[102];
  for(i=0; i<102; i++)
   {
    p[i]=malloc(k);
    if(p[i]) a+=k; else if(k==100000L)k=10000L; else break;
   }
  for(i=i-1; i>=0; i--) free(p[i]);
  return a;
} // end freh

  
   char* svin(int k)
{
 if(oo) ipp("+svin k= ", k);
 static char d[10]; int i=9; int s=0; char* r;
 d[9]='\0';
 if(k==0) return "0";
 if(k<0) { s=1; k=-k; }
 while(k)
 {
  d[--i] = '0'+k%10; k=k/10;
 }
 if(s) d[--i] = '-';
 r = &d[i];
 if(oo) ipp("-svin r= ", r);
 return r;
} // end svin

   int ival(char* s)
{
 int r=0; int l=strlen(s);  int i=0; char c;
 if(l==0) return 0;
 if(s[0] == '+' || s[0] == '-')
    { i=1; if(l==1) error("ival + - only"); }
 while(i<l)
 {
  c=s[i++];
  if(!isdigit(c)) error("ival not digit", c);
  r = r*10 + c - '0';
 }
 if(s[0] == '-') r = - r;
 return r;
} // end ival  


charp fsm;
long kfsm;
long lfsm;
cfsp cfs;
int lcfs;
int icfs;
int maxicfs;
long maxkfsm;

/*  voidp sylloc(long k, char* pl)
{
 voidp p;
 if(ii)cout<<"\n+sylloc k= "<<k<<" kfsm= "<<kfsm<<" icfs= "<<icfs;
 //p = malloc(k); return p;
 kfsm = kfsm + k;  if(ii) ipp("pl = ", pl);
 if(kfsm > lfsm) error("sylloc: overflow! kfsm,lfsm= ",kfsm,lfsm);
 if(kfsm > maxkfsm) maxkfsm = kfsm;
 p = fsm; fsm = fsm + k;
 if(ii) ipp("sylloc p= ", long(p));
 if(++icfs >= lcfs) error("sylloc: overflow, icfs,lcfs= ", icfs,lcfs);
 if(icfs > maxicfs) maxicfs = icfs;
 cfs[icfs].p = p;
 cfs[icfs].k = k;
 cfs[icfs].pl= pl;
 if(kfsm == 0) error("sylloc: kfsm=0, k= ",k); // was cpp
 if(ii)cout<<"\n-sylloc k= "<<k<<" kfsm= "<<kfsm<<" icfs= "<<icfs;
 return p;
} // end sylloc

  void syfree(voidp p, char* place)
{
 long k; voidp p1;
 //free(p); return;
 if(ii) cout<<"\n+syfree kfsm= "<<kfsm<<" icfs= "<<icfs;
 if(--icfs < -1 || icfs>=lcfs) error("syfree icfs= ", icfs);
 k = cfs[icfs+1].k;
 kfsm = kfsm - k; 
 fsm = fsm - k;  // 7/19/97
 if(kfsm < 0) error("syfree: kfsm < k ", kfsm+k, k);
 p1 = cfs[icfs+1].p;
 if(p != p1)
 {
  ipp("syfree: place in cfs= ", cfs[icfs+1].pl);
  ipp("syfree: this place= ", place);
  error("syfree: not matching p,p1",long(p),long(p1));
 }
 if(ii) ipp("syfree: p, p1= ", long(p), long(p1));
 if(ii) cout<<"\n-syfree kfsm= "<<kfsm<<" icfs= "<<icfs<<" k= "<<k;
 return;
} // end syfree
*/

   char last(char* s)
{
 int k = strlen(s);
 if(k == 0) return 0;
 return s[k-1];
} // end char last(char* s)

   void debug(ats a)
{
 char* s = vts(a);
 ipp("debug: s= ", s);
 if(strstr(s, "error")) error("debug: error, s= ", s);
 if(strchr(s,'a')) aa ^= 1;
 if(strchr(s,'b')) bb ^= 1;
 if(strchr(s,'c')) cc ^= 1;
 if(strchr(s,'d')) dd ^= 1;
 if(strchr(s,'e')) ee ^= 1;
 if(strchr(s,'f')) ff ^= 1;
 if(strchr(s,'g')) gg ^= 1;
 if(strchr(s,'h')) hhh ^= 1;
 if(strchr(s,'k')) kk ^= 1;
 if(strchr(s,'m')) mm ^= 1;
 if(strchr(s,'r')) rrr ^= 1;
 if(strchr(s,'s')) sss ^= 1;
 if(strchr(s,'t')) ttt ^= 1;
} // end debug

 bool chch(elem x, char* place)               // check change of elem x after place
{
 bool r= false; static elem pred = zel;  
 if(x != pred){ ipp("chch: x != pred= ", pred, " x= ", x, " place= ", place); pred = x; r = true;} 
 return r;
} // end chch
 
 void bsort(elem arr[], int n)    // An optimized version of Bubble Sort  // elem arr[n]
{                                 // sort in ascending order, using Lev(z): level of z;
int i, j; bool swapped; 
if(mm) ipp("+bsort n= , n"); 
for (i = 0; i < n-1; i++) 
{ 
	swapped = false; 
	for (j = 0; j < n-i-1; j++) 
	{ 
		if (Lev(arr[j]) < Lev(arr[j+1])) 
		{ 
		swapelm(&arr[j], &arr[j+1]); 
		swapped = true; 
		} //if (Lev(arr[j]) > Lev(arr[j+1])) 
	} // for (j = 0)

	// IF no two elements were swapped by inner loop, then break 
	if (swapped == false)	break; 
} // for(i=0)
if(mm && n>2) ipp("-bsort: arr[0]= ", arr[0], " arr[1]= ", arr[1], " n= " , n); 
if(mm) prlist("-bsort ", arr, n-1);
} // end void bsort(elem arr[], int n)

 att numdig(int m)
{
 att r = 0; int n = m;
 while(n != 0){ n = n/10; ++r; }
 if(m == 0) r = 1;
 if(m < 0) ++r;
 return r;
} // att numdig(int n)

 void spacesf(ofstream *f, int n)
{
 while(n>0){ *f << ' '; --n; }
} //  void spacesf

 void paddf(ofstream *f, int n, att width)  // pad n with spaces until width;
{
 int m = numdig(n); spacesf(f, width - m);
} // void paddf

  void chint(elemp q, att i, att last)     // calculating hintstr = q[i+1], hint = q[i+2];
 { 
  hintstr = " "; hint = zel;
  if(i >= last) goto ret;
  if(q[i+1].m==strng) hintstr = strval(q[i+1]);   // strcpy ???
  if(strcmp(hintstr, "hint")==0 && i < last-1) hint = q[i+2];
  ret: if(mm){ ipp("-chint q[i]= ",q[i]," hint= ",hint, " i= ",i, " last= ",last); *pfhis << " hintstr= "<< hintstr; }
 } // void chint
/*
// qsort(&den[0],iden+1,sizeof(void*),comparden);
   int comparden(const void* p1, const void* p2)   p1 = &(freqts[i]), (int*) p1 = 
{
 edenp P1 = *(edenp*)p1; edenp P2 = *(edenp*)p2; // s1 = ts[*(int*)p1]
 char* s1 = vts(P1->a);   s1 = 
 char* s2 = vts(P2->a);  
 int p = strcmp(s1, s2);
 if(p) return p;
 int k1 = (P1->scope).ord();
 int k2 = (P2->scope).ord();
 return k1-k2;
}  // end comparden

 int comparfreqts(const void* p1, const void* p2)
{
 int i1 = *(int*)p1; int i2 = *(int*)p2; 
 char* s1 = vts(i1);
 char* s2 = vts(i2);
 int p = strcmp(s1, s2);
 return -p;
} // end comparfreqts
*/
// qsort(ar, its+1, sizeof(int),comparfreqts);

// end etc.cpp 

