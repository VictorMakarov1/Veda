#define lfarb 10000   // myio.h 10/9/97
charp rstr(ifstream* f);   // read a line from f, allocating place
bool rstr(ifstream* f, char* s, int ssize=150); // read a line from f into s
bool rwcm(ifstream* f, char* s, int ssize=150);// read without emp. l-s and com-s
void wts(ofstream* f, charp* ts, int its);
void rts(ifstream* f, charp* ts, int its);
void ots(charp* ts, int its);
void wtb(ofstream* f, void* tb, int itb, int s, char* place);
// void wtb(ofstream* f, void* tb, int itb, int s);
void rtb(ifstream* f, void* tb, int itb, int s, char* place);
// void rtb(ifstream* f, void* tb, int itb, int s);
void ofts(ofstream* f, charp* ts, int its);
void rf(ifstream *f,int, void*, char* s=0 );
void rf(ifstream *f,int, char* );
void wf(ofstream *f,int v, int k, void* a, char* s);
void wf(ofstream *f,int k,char* a);
// prp in lib.h
void newl(ofstream* f, char* s = "");
void ut(ofstream* f, char* s);
void ut(ofstream* f, int x);
void prpt(ofstream* f, elem x, bool b1=false); // pretty printing of x, i1-flag ib=0
void compare(char* s, headp h, headp g); // print differences 
void mycopy(); // 0_bool.v => 0_bool_new.v line by line replacing Proof(T; => Proof T; and so on; 
void remproofs(ifstream* f, char* name); // name.v => name.vh line by line removing proofs;
void checkcnt();   // compare 2 his files looking for the lines "prext:..."if the corr.lines are not equal,stop;
// end myio.h
