// 11/21/97  01/06/00 3/9/00 3/13/00 4/27/00 10/17/00
bool adel(elem z, headp* h=0, elemp* q=0);  
att mel(elem z, headp *h=0, elemp *q=0, int place=0);
bool smel(elem z, headp *h=0, elemp *q=0);
inline bool emptpl(elem z){att m = z.m;  return !wrongm(m) && clad[m]->tabt[z.ad]==0; }
int size(head h);
int nel(head h);
//long incr(long hh, long decr, long lh);
//long hash(elem f,long* adecr,long lh);
int len(headp h);
bool badel(elem z);     // bad element
//int expb(elem f);      // exportdef block
bool iseq(elem z, elemp* w=0);
bool iseq(elem zz, elem* a, elem* b);
bool iseqmn(elem zz, elem* a, elem* b);
bool iseqmn(elem zz, bool mn, elem* a, elem* b);
bool iset(elem z);
elem mnot(elem a);
int dfex(elem d, headp h, elemp q, elem z);
void debs(char c);     // handling of debugging symbols
int isrl(elem z, elem* a, elem* b);   // is a relation
void assl(elem z, elem op, elemp a, int *ia, int la);
elem funt(elem z, elem a, sbst* s); // find unifying with a a subterm in z
elem daep(elem dx, elem dy, elem p, elem* p1); // def for A[dx,E[dy,p]]
long stbt(tt* p);   // size of tabt
elem valt(elem z);   // value of t-elements 
// int iscn(elem z, int* v); // z is (ints, v)  // Same as Ints;
bool fnt1h(elem z, headp* ah=0, elemp* aq=0);
bool fnt(elem z, elem f, headp* ah=0, elemp* aq=0);    // ! adel(z, h,q) & h->tel == pfs & q[0] == f
bool fnt1(elem z, elem f, elemp p1=0);                 // z = f(a)
bool fnt1(elem z, elem f, elemp* aq, headp* ah=0);     // z = f(a)
// inline bool fnt1(elem z, elem f, elem a){ headp h; elemp q; return  mel(z,&h,&q)==pfs && h->l==2 && q[0]==f && q[1]==a; }
bool PP1(elem z, elemp* aq=0);                         // z is P[y] or P1[y];
bool fnt2(elem z, headp* ah, elemp* aq);
bool fnt2(elem z, elem f, elemp p1=0, elemp p2=0);
bool eqPP1(elem z1, elem z2, elemp r1=0);             // z1 and z2 are P[y]  or P1[y];  *r1 = P[y];  
inline bool impequ(elem z, elemp p1=0, elemp p2=0){ headp h; elemp q; // z is p1->p2 or p1==p2;
  bool r = mel(z,&h,&q)==pfs && h->l==3 && (q[0]==zimp || q[0]==zequ); 
  if(r){ if(p1) *p1=q[1]; if(p2) *p2=q[2]; }; return r; } // end inline bool impequ(
bool fnt2h(elem z, elem f, headp* h=0, elemp* q=0);
bool fnt12(elem z, elem f1, elem f2, elemp a, elemp b);            // f1(f2(a,b));
bool fnt22r(elem z, elem f1, elem f2, elemp a, elemp b, elemp c);  //  P1 f1 (P2 f2 P3);
bool fnt22l(elem z,elem,elem, elem* P1, elem* P2, elem* P3);  // (P1 f1 P2) f2 P3
inline bool neqNeq(elem U, elem Z)
      { elem x,x1,y,y1; return fnt2(U,zneq,&x,&y) && fnt12(Z,znot,zeq,&x1,&y1) && x==x1 && y==y1; }
inline bool ninNin(elem U, elem Z)
      { elem x,x1,y,y1; return fnt2(U,znin,&x,&y) && fnt12(Z,znot,zin,&x1,&y1) && x==x1 && y==y1; }
bool parsimp(elem z, elemp* hyp, elem* concl, int* lhyp);          // parse an implication;
elemp linb(elem z, elem f, int* lastar);              // linearization p_0 f p_1 f ... &p_last; // b: binary f;
bool inabt(elem z, elem* u, elem* v);                // z: u in (v:={x1,...,xk; F}
elem fnabt(ats x, elem v, headp h);                  // Find name x in abterm (v,h)
bool Adp(elem x,elemp d,elemp P, elemp u, elemp t);  // x is A[d,P], u is d++1, t=tp(u); not used;
// elem valabbr(elem z, headp* ah=0, elemp* aq=0);   // val(x := z) = z, val(x) = z
// elem valdexc(elem z);   // !!(z) => z
bool varc(elem z);
bool dclname(elem z, headp* ah=0, elemp* aq=0, ats* a=0);  //  z is d.i & d is dcl[a, ..., t]
//inline rootname(elem z){ return dclname(z) && z.m==0 || cltyp(z) || z==zbool || Abt(z); }
inline bool postfixname(elem z){headp h; return dclname(z, &h) && h->postfix; }
bool dclname1(elem z, elemp t=0);  // not constant, at least 1 parameter
bool atomic(elem z, elemp* aq, ats* a);   // mel(z,&h,aq)==pfs && dclname(q[0],,,a); defrp( not dclterm) = zel;
bool atomic1s(elem z, elem* f, elem* st); // mel(z,&h,aq)==pfs && dclname(q[0],,,a) &&  h->l==2 && g->l==4 && w[2]==zset && ...
elem dclrin(elem z, elemp* aq=0);         // f=zel; if z is atomic f(...) (or z in atomic f(...)) return f;
elem defrp(elem z);  // right part of def: defrp(x nin A) = ~(x in A); defrp(X in P[Y]) = X <: Y; 
bool monotonic(elem f);   // dcl-name f is monotonic: A theorem T := A<:B -> f(A)<:f(B) is in thms(f);
inline ats Dclname(elem z){ headp h; elemp q; return z.i && !adel(z,&h,&q) && Dcl(q[0])?q[1].ad: -1;  }
inline bool abbr(elem x) { return fnt2(x, yasop); }
bool abt1(elem d, elem* ax1, elem* x1, elem* t1);  // if(d is {x1; ax1 := x1 in t1} return(ax1,x1,t1);
elem Abt1(elem d);  // if d is {x; x in t} returns t, otherwise zel;
inline elem Abt1a(elem d, headp h, elemp q){  elem r = zset, a,b;  // differs from Abt1 only no check " h->l == 3"; 
    if(fnt2(q[2],zin, &a, &b) && a.i==1 && a.m==d.m && a.ad==d.ad) r = b; return r; }
bool Abt2(elem d, elem* t1, elem* t2);             // if(d is {x1,x2; x1 in t1, x2 in t2} return true(t1,t2);
elem axabt1(elem d);     // if(d is {x; x in t} return  else zel;
inline bool Any(elem t){ return t==zany || t==zset || Abt1(t)==zany; } //  ??? Abt1(t)==zset
elem stripalls(elem y);    // strip Alls
inline bool varbvar(elem z){ int m = mel(z); return m==bvar || m==var; }
bool overname(elem z);     // dclname or F-name
ats npar(elem z);          // number of parameters of z: npar(=) = 2; npar(z) = 0, if unknown;
ats nparfn(elem t);        // number of parameters of t = fn(t1,t2,...,tr); 
inline bool check(att ad, att Astad){ return Astad != 0 && ad==Astad; }
inline bool Dterm(elem z){ headp h; elemp q; int m = mel(z,&h,&q); return m==abt || m==pfs && q[0]==zdconj; }
inline bool Truth(headp h){ return h->t == truth || h->t == truth3 ; } //  || h->t == ctruth; } // #define truth 1
bool Truth(elem z, bool p=true);  // { headp h; return mel(z,&h)==pfs &&( h->t == truth || p && h->t == truth3; }
bool normd(elem d);  // d is normal: only type axioms in d;
bool Dconj0(elem z, elemp d);  // z is d && x;
elem Athabv(elem d);   // if d is unnamed and mel(d)==abt and Q := A[d,P] is a theorem above d then return Q, else zel;
inline bool badthm(elem T){ headp h; return badm(T.m) || mel(T,&h) != pfs || h->tp != zbool || h->t != truth; } 

//void AddToDef(elem d, elem z); 9/30/97, moved to elem.h!

