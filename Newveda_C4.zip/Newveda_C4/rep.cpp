// rep.cpp 04/30/01 05/26/01

#include "lib.h" 
#include "achs.h" 
#include "sbs.h" 
#include "rep.h" 
#include "tt.h"
#include "adl.h"       
#include "typ.h"    
// #include "smp.h"
#include "cr.h"     
#include "elem.h"
#include "lot.h"
// #include "ismd.h"
#include "term.h"
#include "etc.h"
#include "err.h"
#include "assert.h"

// int istdd = -1;  // last
// int istdd1 = 0;  // first
// elem stdd[lst];
extern elem zexist1;
extern int kk,mm,hhh,isynv,iDd;                 //  isteq
// int iard = -1;                                     //  last occupied;
// int placeM = -1;
// int KM;
extern elem Dd[maxsynv];   // d1 && d2 && P              // ard = (d1,d2);
// elemp qM;   // current model: z21,z22; 
// extern elemp arM;  // big model: z11, z12, z21,z22;
extern int dispDd[maxsynv];          // dispDd[0] = 0, dispDd[i+1] = dispDd[i-1] + kmain(Dd[i-1]);  
// int arpM[maxvars];   // places in arM:  -1, 1;     // real place-1;
// int KqM;             // global counter in sbst1

   int PlDd(elem d)
{
 int r; bool p = inList(d,Dd,iDd,&r);
 if(!p){ ipp("PlDd: no d in Dd, d= ", d, " Dd= ", Dd, iDd); r = -1; }
 return r;
} //   elem PlDd(elem d)

   void chabt(elem z, elem y0, elem y)  // y0: old abterm, y: new abterm, z: raw subterm of y
{   // change abterm         // action: replace each old abname in z on new one
 int i,m,n; headp g; elemp q;
 if(mm&&sss) ipp("+chabt: z= ", z, " y0= ", y0, " y= ", y);
 assert(int(y.ad) > ptt->root);
 // assert(mel(y, &g) == abt);
 // assert(kmain(h) == kmain(g));
 m = mel(z, &g, &q);
 assert(m==pfs || m==abt);   // if
 //  if(z.ad <= ptt->root){ ipp("chabt: NOT CHANGING before ROOT z= ", z); return; }
  n = kmain(g);
  if(mm&&sss) ipp("chabt: n= ", n);
  for(i=n; i < int(g->l); i++)
  {
   elem v = q[i];
   if(v.m == y0.m && v.ad == y0.ad && v.i)
   {
    if(mm&&sss) ipp("chabt: CHANGING q[i]= ", v, " &q[i]= ", int(&q[i]), " to y.ad= ", y.ad);
    q[i].m = y.m; q[i].ad = y.ad; continue;
   } // if(q[i].m)
   if(comp(v)) chabt(v, y0, y);
  } // for(i)
 // } // if(m==pfs || m==abt)
 if(mm&&sss) ipp("-chabt: z= ", z, " y= ", y);
} // end void chabt(elem z,...) 

/*   void prstdd(char* s)
{
 *pfhis  << "\n   Printing stdd s= "<<s
         << "\nistdd= "<<istdd << " istdd1= "<<istdd1;
 for(int i=0; i<istdd; i++)
 {
  *pfhis << "\n"<<i<<") "; prp(stdd[i], pfhis);
 }
 *pfhis << "\n"<<i<<") " << Att(stdd[i]); // not ready yet
 *pfhis << "\n\n";
} */ // end prstdd

   elem fsegh(head h, att n)
{
  int k = h.l; int m = ist-k+1; // headp g; elemp w; 
  if(mm) ipp("+fsegh h.l= ", k, " ist= ", ist, " n= ", n); 
  if(mm && kk) pst("+fsegh");
  assert(ist >= 0); elem r; // v,f = st[m], t = st[ist]; // t: top
  if(m < 0)
  { 
   pst("fsegh"); 
   error("fsegh: wrong m<0, m= ", m, " k= ", k); 
  } // if(m < 0)
  /* if(k==4 && f==zsb){ r = redsb1(st[m+1],st[m+2],st[m+3]); goto M1; } // Sb(K,a,b)
  if(k == 2 && mel(f, &g, &w) == pfs) // special terms:  All(x,P)(a),..., ; 
  {
   // assert(ist-m == 1);  
   if(w[0] == zall || w[0] == zexist || w[0] == zexist1) // zimp ???
   {
    ipp("fsegh: special term like All(x,P)(y), f= ", f, " y = ", t);
    v = f; v.i = 1;                     // v = elm(bvr, 1, Ats(w[1]));
    r = rep2(w[2],v,t);
    goto M; 
   } // if(w[0])
  } */ // if(k == 2)
  r = ptt->wrtt(h, &st[m], n);
  popst(k);  // M1:
  wrst(r);   // in rep.cpp: in fsegh(head h), fsegh used only in remd;
  if(mm) ipp("-fsegh r= ", r); if(mm && kk) pst("-fsegh");
  return r;
} // end elem fsegh(head h)

   elem fsegh1(elem z, headp h, att n)   // z: the origin of st;
{
  elem r, tr=zel; int i, k = h->l, itt0= ptt->itt, m = ist-k+1; headp g; elemp q,w; att a;  // k: size of segment, m: place in st;, 
  if(mm){ pst("+fsegh1"); ipp("+fsegh1 z= ", z, "\nh->l= ", k, " ist= ", ist, " n= ", n, " itt0= ", itt0); }
  if(z.ad == stad2)
  mm=mm;
  if(ist==0){ r = st[0]; if(mm) ipp("fsegh1: ist==0, no action, r=st[0, z= ", z); goto ret; }   // tr = typ(z) ???
  assert(ist >= 0);  // v,f = st[m], t = st[ist]; // t: top
  if(m < 0)
  { 
   pst("fsegh1"); 
   error("fsegh1: wrong m<0, z= ", z, "\nm= ", m, " ist= ", ist, " k= ", k); 
  } // if(m < 0)
  q = &st[m];
  if(mm && allex1(q[0])) ipp("fsegh1: allex1(q[0]): possible error, \nz= ", z, " n= ", n, " mm= ", mm); 
  if(mm&&sss){ *pfhis << "\nfsegh1 st(m,k)= "; for(i=0; i<k; i++) pelm(q[i], pfhis); }  
  if(n==emptt)
  {
   if(h->tel == abt)                     // case 1: n==emptt && abt
   { 
    if(!Abt(q[0])){ pst("Abt(q[0])"); error("fsegh1: !Abt(q[0]), z= ", z, " q[0]= ", q[0], " m= ", m, " k= ", k); }// assert(Abt(q[0])); 
    // att wrtt(int m, int l, elem* a, att n = emptt, att levsct = sizestscp, bool fixed=false,att isz=iszthmb); // sizestscp = 31;
    a = ptt->wrtt(abt,k,q,emptt,sizestscp,true); // fixed==true: use itt;
    if(mm&&sss) ipp("fsegh1:abt:wrtt tp= ", tr = ptt->tabt[a]->tp, "a= ", a, " itt= ", ptt->itt);
   } //  if(h->tel == abt)
   else                                  // case 2: n==emptt && pfs
   { 
    if(h->tel != pfs) error("fsegh1: wrong pfs,  z= ", z, " h->tel= ", h->tel);
    a = ptt->findtabt(k,q);
    // if(ptt->itt != itt0) (ptt->tabt[a])->tp = zel9; // h->tp;  // zel9:  r is a fresh term;
    if(mm&&sss) ipp("fsegh1:findtabt tp= ", tr = ptt->tabt[a]->tp, " a= ", a, " itt0= ", itt0, " itt= ", ptt->itt);
   } // else case2
   r = elm(curm, 0, a);                           // curm==0;
   if(mm) ipp("fsegh1: end n==emptt, z= ", z, "\nr= ", r, " ist= ", ist); 
  } // if(n==emptt)
  else                                   // case 3:  n != emptt
  { 
   r = ptt->wrtt(*h, q, n); 
   if(mm&&sss) ipp("fsegh1:n != emptt:after wrtt, h->tp= ", h->tp, "\nr= ", r, " itt= ", ptt->itt, " ist= ", ist); 
  } // else case3
  // popst(k);  // M1:-------------------------?????????????
  if(mel(r,&g,&w)==pfs && w[0]==zRep) r = redRep(r); 
  popst(k);
  wrst(r);   // in rep.cpp, in fsegh1(headp h), fsegh1 used only 
  if(mm) ipp("fsegh1:after wrst(r),z= ",z," h->tp= ", h==0? zel999: h->tp, "\nr= ", r, " g->tp= ", comp(r)? g->tp: zel999);
  if(comp(r))
  { 
   if(g->tp != zel) tr = g->tp; 
   else{ 
    g->tp = ( tr = h->tp ); 
    if(mm) ipp("fsegh1: possible error z= ", z, " r= ", r); 
    if(r.ad == stad2)
    mm=mm;
   } // else{
  } // explain ??? else g->tp = ( tr = typ(r)); ???
  ret: if(mm&&sss && tr==zel) ipp("fsegh1: tr==zel, z= ", z, " itt-itt0= ", ptt->itt - itt0);
  if(mm){ pst("-fsegh1"); ipp("-fsegh1 z= ", z, "\nr= ", r, " tr= ", tr); } 
  return r;
} // end elem fsegh1(headp h)

   elem repq(elem z, elem d, elemp q, int nq) // replace in z all d.i on q[i], q points to model-1;
{                                             // nq: the size of model: if z=[a,b] then nq = 2;
 if(mm) ippq2("\n+repq: z= ", z, "\nd= ", d, "\nq= ", q+1, nq); // q+1: because q points to model-1;
 elem r; sbst s; int i,k;
 // sbst s(d,q,nq);  // headp h; 
 k = gmain(d); // inline int gmain(elem z){ elem d = maid(z); return kmain(d); } // maid(d&&P) = d;
 if(mel(d) != abt) ipp("repq:gmain: not abt: z= ", z, "\nd= ", d, " k= ", k);
 if(k != nq) 
   error("repq: k != nq, z = ", z, "\nd= ", d, "\nk= ", k, " nq= ", nq);
 for(i=1; i <= k; i++) s.adds(nami(d, i), q[i]);
 r = s.rep(z, "repq");
 if(req(r,z)) ipp("repq:strange: r=z, z= ", z, "\nr= ", r, "\nd= ", d, "\nq[1]= ", q[1]);
 if(mm || sss)
 {
  s.psbs("-repq"); 
  ipp("-repq z= ", z, "\nd= ", d, "\nr= ", r);
 } // if(mm || sss)
 return r;
} // end elem repq

   elem repqmd(elem z, elemp arm)     // repq multiple d, uses Dd,iDd, arM;
{                                     // arm: points to mode1-1;
 int i,j,k,p; elem x,y,r,d; sbst s;
 if(mm) ipp("+repqmd: z= ", z, " arm[1]= ", arm[1], " Dd= ", Dd, iDd);  // was ippq1
 for(i=0; i<=iDd; i++)
 {
  d = Dd[i];
  k = kmain(d);
  p = PlDd(d);           // place  for d in q;
  if(p == -1) error("repqmd: p == -1, z= ", z, "\nd= ", d);    // impossible !
  p = dispDd[p];
  if(mm) ipp("repqmd:for(i), d= ", d, " k= ", k, " p= ", p);
  for(j=1; j<=k; j++)
  { 
   x = nami(d,j); y = arm[p+j];
   s.adds(x,y);
   s.psbs("for:");
  } // for(j=1)
 } // for(i)
 r = s.rep(z,"repqmd");
 if(mm) ipp("-repqmd: z= ", z, " r= ", r, " s= ", &s);
 return r;
} // elem repqmd(elem z)

    elem Repq(elem z, elem D, elemp q, int nq)  // q points to model-1;
{
 elem r; int k;
 if(mm) ipp("+Repq z= ", z, " D= ", D, " q= ", q, nq);
 k = lind(D);
 if(k != nq) error("Repq: k != nq, z= ", z, "/nD= ", D, "/nq= ", q+1, nq);
 r = repqmd(z, q);
 if(mm) ipp("-Repq z= ", z, " D= ", D, " r= ", r);
 return r;
} // end elem Repq(elem z, ...)

    elem repd(elem z, elem d, elem md)        // replace in z all d.i on md[i];
{
 int k; elemp q; elem r=zel;
 if(mm) ipp("+repd: z= ", z, "\nd= ", d, "\nmd= ", md, " ist= ", ist);
 if(!seqv(md, &k, &q))                       // if md = [x1,...,xk] then q[0] = '[';
 {
  if(mm) ipp("repd: not sequence md, z= ", z, "\nd= ", d, "\nmd= ", md); 
  q = &(md) - 1; k = 1;                      // q must point to &md - 1; see repq; 
 }
 r = repq(z, d, q, k);
 if(mm) ipp("-repd: z= ", z, "\nr= ", r, " ist= ", ist);
 return r; 
} // end repd;

    elem rep2(elem z, elem x, elem y)       // replace in z x with y;
{
 elem r=z, d; sbst s;
 if(mm) ipp("+rep2 z= ", z, "\nx= ", x, " y= ", y, " ist= ", ist); 
 if(dterm(z,&d) && d==x) goto ret;   // cannot replace d in A[d,P];
 if(z == x){r = y; goto ret;}
 /*elem tx = typ(x);
 elem ty = typ(y);
 if(tx == zbool && ty != zbool || ty == zbool && tx != zbool)
 {
  ipp("\nrep2 tx = ", tx, " ty= ", ty);
  error("rep2: wrong x, y; z= ", z, "\n    x= ", x, "\n    y= ", y);
 } */
 s.adds(x, y);
 //if(p !=2) p=1;
 // ist = -1;
 r = s.rep(z,"rep2");  // false: any terms, not only variables
 ret: if(mm) ipp("-rep2 z= ", z, "\nr=", r, " ist= ", ist);
 return r;
} // end rep2

   elem rep2i1(elem z, elem a, elem b)    // simpler rep2i, using finst
{
 sbst s; elem a1, b1=zel, r = z;
 if(mm) ipp("+rep2i1: z= ", z, "\na= ", a, "\nb= ", b);
 a1 = s.finst(z,a);
 if(a1 != zel){ b1 = s.rep(b,"rep2i1"); r = rep2(z,a1,b1); }
 if(r != z)
 {
  if(mm) s.psbs("rep2i1");
  if(mm) ipp("\nrep2i1: found instance a1 of a in z= ",z,"\na= ", a," b= ",b,"\na1= ",a1,"\nb1= ",b1,"\nr= ",r); 
 } // if(r != z)
  if(mm) ipp("-rep2i1: z= ", z, "\na= ", a, "\b= ", b, "\nr= ", r); 
 return r;
} // end rep2i1

   elem rep2i(elem z, elem A, elem B, elem vars_are_cons, elem dpat, ats k)    // z, by A=B; r; find k-th instance V(s) of x in z
{                                        // and replace V in z on  s(y);
 elem r = z, V,u,a,B1=zel,B2;  int save=0, ir=0, savemm=mm, savebb=bb;  int static dpth=0; sbst s; 
 headp g; elemp w; ats occ=0;  // att n; bool pi; int kbv; // occAxab=0,occBred=0;
 // if(z.ad == stad2) // { mm=1; bb=1; }
 // mm=mm;
 if(mm) ipp("\n+rep2i z= ", z, "\nA= ", A, "\nB= ",B, 
            "\nvars_are_cons= ", vars_are_cons, "\ndpat= ", dpat, " k= ", k);
 if(++dpth >1) error("rep2i: recursive call, z= ", z, "\ndpth= ", dpth);
 achs f(z);
 if(bb) f.prach("rep2i: z= ", z);   
 while(f.iach >= 0)
 {
  V = f.curvert(); ++ir;
  if(mm) ipp("rep2i: while: V = ", V, "\nA= ", A, "\nir= ", ir);
  /*if((kbv=qabterm(V)) >0 )                                        // 2023.03.10
  {
   n = ptt->newtt("rep2i"); 
   if(99) ipp("rep2i:kbv z= ", z, " V= ", V, " n= ",n);
   s.stqab.wr(V, n);  s.stqab.pr("rep2i:kbv");
   filltabt(n);  // ptt->tabt[n] = ptt->tabt[0]; 
  } // if((kbv=qabterm(V)) >0 )
  */ // assert(!abbr(V));
  save = s.size;
  if(A==zRed || fnt1(A, zRed))     // ??? Red("F") ??? 11/28.21;
  {
   // if(isst(V,&y1) && (++occ == k || k==0)){ s.size = save; goto M; }  // V=A, y1=B ???
   if(mm) ipp("rep2i:Red:found z= ", z, " V= ", V);
   B1 = rterm(V);
   if(B1 != V && (++occ == k || k==0)){ s.size = save; goto M2; }  // V=A, y1=B ???
   goto Nxt; 
  } // if(x==zRed)
 
  if(A==zBred)  // move to isst ??? // Bracketed reduction: convert A[d,P],E[d,P] to All(...), Exist(....);
  {
   if(mel(V,&g,&w)==pfs && g->l==3 && (w[0]==zA || w[0]==zE) && (++occ == k || k==0))
   //   error("hnbybyeq:bred: not A[d,P] or E[d,P], z= ",z, "\nV= ", V); // , "\nA= ", A);
   { 
    if(mm) ipp("rep2i:Bred:found z= ", z, " V= ", V);
    s.crstqab(&f);
    B2 = AllExAE(V,g,w);
    goto M2a;                     // added s.crstqab(&f); 2023.03.10 
   } // if(mel(V,&g,&w)==pfs ...)
   //if(z == A) error("hnbybyeq: bred: not changed \nA= ", A, "\nby(i)= ", y, "\nF= ",F, "\ni= ", i);
   goto Nxt;
  } // if(y==zbred)
  
  if(A==zAxab) 
  { 
   if(inabt(V,&u,&a) && (++occ == k || k==0))
   {
    if(mm) ipp("rep2i:Axab:found z= ", z, " V= ", V);
    s.crstqab(&f);
    B1 = s.redinab(V,u,a); s.size = save;
    goto M2;                     // added s.crstqab(&f); 2023.03.10 // was s.crstqab(&f); goto M;
   } // if(inabt(V,&u,&a) 
   goto Nxt; 
  }  // if(x==zAxab)
  if(mm) f.prach(" rep2i: while V= ", V);
  if(s.instance(V,A,vars_are_cons,dpat) && (++occ == k || k==0) )    // main case; 
  {
   if(mm || k)   // occ > 1)
   {
    ipp("\nrep2i: found instance V= ", V, "\nof A= ", A, "\nB= ", B, "\nk= ", k, " s= ", &s);
    // if(mm) f.prach(" rep2i: found instance while" );  // 99: later replace with mm;
   } // if(mm || occ > 1)
   s.crstqab(&f);      // create stqab in s from f until V(not including); 
   B1 = s.rep(B, "rep2i:s.rep(B)");      // like s.rep(B) in instanse no n: y != z !!!!    2
   // B2 = s.stqab.repb(B1);
   M2:  B2 = s.rep(B1, "M2: rep2i:s.rep(B1)");    // because B1 may depend on stqab;
   M2a: if(mm) ipp("rep2i:M2a, B= ", B, "\nB1= ", B1, "\nB2= ", B2, " s= ", &s);
   if(f.iach==0 && f.ach[0].p == -1){ r = B2; goto ret; }
   // s.crstqab(&f);      // create stqab in sfrom f until V(not including);  
   // pi = k > 0;                                           //   3
   if(mm) ipp("rep2i:after M2a, z= ", z, "\nB= ", B, "\nV(inst of A)= ", V, " k= ", k, " s.size= ", s.size);
   if(k > 0){ r = f.repach(B2, &(s.stqab));  goto ret; }//  was rep2(z,V,y1);  // psbs
   // else{ y2 = y1;
   // if(s.stqab.iar >= 0)
   // { 
   //  if(mm) ipp("rep2i: s.stqab.iar >= 0, y1= ", y1, "\ns.stqab.iar= ", s.stqab.iar);
   // y2 = s.rep(y1, "rep2i:y2=rep(y1)");    // replacing possible bvars in y1;  // instead of repr, repr1'
   // } // if(s.stqab.iar >= 0)
   s.adds(V,B2);                      // s.adds(V,y2); 
              // s.repr()
   if(mm) ipp("rep2i: before main r = s.rep(z), z= ", z, "\nV= ", V, "\nB2= ", B2);  
   r = s.rep(z,"rep2i:main"); //  was rep2(z,V,y1);                                 
   if(mm) ipp("rep2i: after s.rep(z), z= ", z, "\nr= ", r, " s= ", &s);  // rep2(z, V, y1)
   // } // else{
   goto ret;
  } // if(s.instance)
  Nxt: s.size = save;   f.next();
 } // end while(f.iach >= 0)

 ret: if(mm) ipp("-rep2i z= ", z, "\nA= ", A, "\nr= ", r, "\nir= ", ir); // 
      mm=savemm; bb=savebb; --dpth;
      if(!checkterm(r)) ipp("rep2i:checkterm:false z= ", z, "\nr= ", r);
       return r;
} // end elem rep2i(...)

// moved to trash.txt; elem repm(elem z,elem M,elem T, bool p)       // replace in z every method m of T on m.z;                                             // repm: wrong: bounded terms !!!
// moved to trash.txt elem stripm(elem z,elem M)      // replace in z every x.M on x; (inverse to repm)
 
  elem qab::repbv(elem z)   // replace bvar z using stqab: d++i  // was sbst;
{ 
 elem x, d,d1,r=z; int i,k,m; att n;
 if(mm) ipp("+repbv: z= ", z, " iar= ", iar);
 k = z.i;
 if(k==0) error("repbv: z is not bvar, z= ", z);
 d = z; d.i = 0;
 for(i=iar; i >= 0; i--)
 {
  x = ar[i];                    // x = stqab[i];
  if(x == d) goto M;                  // found qab-term d;
  if(dterm(x,&d1) && d1==d) goto M;   // found dterm A,E,...[d,P]
 } // for(i)  prstqab();
 // if(mm) 
  ipp("repbv:  bvar z is not in stqab, valsp will try vals, z= ", z, " iar= ", iar);   // was ipp
 // r = vals(z); 
 // if(r != zel) goto ret; r = z;
 goto ret; 
 M: n = R1[i]; m = R2[i];
 if(m != emptt && k > m) --k;   // because xm was removed from d; see freered, remd;
 if(n != emptt) r = elm(curm,k,n); else error("repbv: n==emptt, z= ", z, " n= ", n);
 ret: if(mm) ipp("-repbv: z= ", z, " r= ", r);
 return r;
} // end elem repbv(elem z)
                                   // repb: used only in valsp;
  elem qab::repb(elem z)         // wasreplace in z every bvar x on repbv(x); used only in valsp;
{                                 //  p=true, replace T-abtbvar x.i on M[i-1]; ( not imp. yet);
 elem x,y, r=z; int i,k,hl,m; bool changed; headp h; elemp q;
 if(mm){ ipp("\n+repb: z= ", z, " ist= ", ist); pr("repb"); } // psbs("repb"); 
 if(ist < -1 || ist > lst-200) error("repb: ist < -1 || ist > lst-200, z= ", z, " ist= ", ist);
 m = mel(z,&h,&q);
 if(comp(m))
 {
  hl = h->l;
  if(mel(q[0]) == pfs) k = -1; else k = kmain(h);
  for(i=0; i<=k; i++) wrst(q[i]);                  // in qab::repb; copying All,x;   {x1;P}, All(x,P)
  changed = false;
  for(i=k+1; i < hl; i++)
  {
   x = q[i]; 
   y = repb(x);
   if(y != x) changed = true;
   wrst(y);                                        // in qab::repb;
  } // for(i)
  if(changed){ r = fsegh1(z,h); popst(r); }
  else popst(hl);
  goto ret; 
 } // comp(m)
 if(mm) ipp("repb: simple z= ", z);
 if(m==bvar) r = repbv(z);                      //  if(m==bvar)
 ret: if(mm) ipp("-repb: z= ", z, " r= ", r);
      return r;
} // end repb;

  elem reparg(elem z, headp h, elemp q, int p, elem y, qab* W) // replace p-th arg in z with y;
{
 elem r;  att n = W->val1(z);  int i, hl = h->l;  elem ar[maxvars]; 
 if(mm) ipp("+reparg z= ", z, "\ny= ", y, " p= ", p, " n= ", n);
 if(hl >= maxvars) error("reparg: hl >= maxvars, z= ", z, " hl= ", hl, " maxvars= ", maxvars);
 if(p == -1){ r = y; goto ret; }
 if(p < 0 || p >= hl) error("reparg: p < 0 || p >= hl, z= ", z, " p= ", p, " hl= ", hl);
 for(i=0; i<hl; i++) ar[i] = W->repb(i==p? y: q[i]);
 if(abtallex1(ar[0]))
 {
  if(mm) ipp("reparg: after 'n = abtallex1(ar[0]);', z= ", z, " n= ", n);
  r = ptt->wrtt(*h,ar,n);
 } // if(abtallex1(ar[0]))
 else r = elma(curm, ptt->wtrm(*h,ar));
 ret: if(mm) ipp("-reparg z= ", z, "\ny= ", y, "\nr= ", r, " p= ", p);
 return r;
} // end elem reparg;

// end of file rep.cpp
